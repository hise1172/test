<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductAttributesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_attributes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')
                ->nullable(false)
                ->references('id')
                ->on('products')
                ->onDelete('cascade');
            $table->foreignId('product_attribute_name_id')
                ->references('id')
                ->on('product_attribute_names')
                ->onDelete('cascade');
            $table->string('value');
            $table->unique(['product_id', 'product_attribute_name_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_attributes');
    }
}
