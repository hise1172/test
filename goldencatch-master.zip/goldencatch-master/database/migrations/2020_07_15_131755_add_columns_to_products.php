<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->float('weight')->nullable(true);
            $table->foreignId('type_id')
                ->nullable()
                ->references('id')->on('types')
                ->after('brand_id');
            $table->foreignId('type_fish_id')
                ->nullable()
                ->references('id')->on('type_fishes')
                ->after('brand_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropForeign('products_type_fish_id_foreign');
            $table->dropForeign('products_type_id_foreign');

            $table->dropColumn('weight');
            $table->dropColumn('type_id');
            $table->dropColumn('type_fish_id');

        });
    }
}
