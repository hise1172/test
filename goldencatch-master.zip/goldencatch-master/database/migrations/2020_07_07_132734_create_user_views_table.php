<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserViewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_views', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->nullable('false')
                ->references('id')->on('products')
                ->onDelete('cascade');
            $table->foreignId('user_id')
                ->nullable()
                ->references('id')->on('users')
                ->onDelete('cascade');
            $table->string('ip')->nullable(false);
            $table->unique(['product_id', 'user_id', 'ip']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_views');
    }
}
