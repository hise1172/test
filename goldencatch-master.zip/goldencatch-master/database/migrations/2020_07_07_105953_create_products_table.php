<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('parent_id')->nullable()
                ->references('id')
                ->on('products')
                ->onDelete('set null');
            $table->foreignId('category_id')->nullable()
                ->references('id')
                ->on('categories')
                ->onDelete('set null');
            $table->foreignId('brand_id')->nullable()
                ->references('id')
                ->on('brands')
                ->onDelete('set null');
            $table->string('name')->nullable(false);
            $table->decimal('price')->nullable(false);
            $table->text('description')->nullable(false);
            $table->text('short_description')->nullable(false);
            $table->string('article')->nullable(false);
            $table->string('status')->nullable();
            $table->date('date_arrival')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
