<?php

use App\Models\Product\ProductAnalog;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductAnalogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_analogs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->nullable(false)
                ->references('id')->on('products')
                ->onDelete('cascade');
            $table->foreignId('product_analog_id')->nullable(false)
                ->references('id')->on('products')
                ->onDelete('cascade');
            $table->enum('type', [ProductAnalog::TYPE_UP_SALE, ProductAnalog::TYPE_DOWN_SALE])
                ->nullable(false);
            $table->smallInteger('discount');
            $table->unique(['product_id', 'product_analog_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_analogs');
    }
}
