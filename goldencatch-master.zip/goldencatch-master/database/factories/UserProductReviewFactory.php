<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Product\Product;
use App\User;
use App\Models\UserProductReview;
use App\Models\UserRole;
use Faker\Generator as Faker;

$factory->define(UserProductReview::class, function (Faker $faker) {
    $users = User::with(['role' => function ($q) {
        $q->where('name', UserRole::ROLE_USER);
    }])->get()->pluck('id');
    $products = Product::all()->pluck('id');
    return [
        'user_id' => $faker->randomElement($users),
        'product_id' => $faker->randomElement($products),
        'comment' => $faker->realText(100),
        'bad_things' => $faker->realText(50),
        'good_things' => $faker->realText(50),
        'product_mark' => $faker->randomFloat(1, 1, 4),
        'is_moderated' => true
    ];
});
