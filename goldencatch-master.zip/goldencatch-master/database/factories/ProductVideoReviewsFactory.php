<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Product\ProductVideoReviews;
use Faker\Generator as Faker;

$factory->define(ProductVideoReviews::class, function (Faker $faker) {
    $urls = [
        'https://www.youtube.com/embed/K5gutv0ZYPc',
        'https://www.youtube.com/embed/lTf_xAe27xE',
        'https://www.youtube.com/embed/VR9ppnR87U',
        'https://www.youtube.com/embed/t7wUwC9Zj_8',
        'https://www.youtube.com/embed/6tk5uFD-EFY'
    ];
    return [
        'url' => $faker->randomElement($urls),
        'is_show' => true,
    ];
});
