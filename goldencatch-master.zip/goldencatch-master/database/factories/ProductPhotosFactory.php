<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Product\ProductPhoto;
use Faker\Generator as Faker;

$factory->define(ProductPhoto::class, function (Faker $faker) {
    $paths = ['images/bobbin.jpg', 'images/bobbin2.jpg', 'images/bobbin-lg.jpg'];
    return [
        'name' => $faker->name,
        'path' => $faker->randomElement($paths),
        'is_show' => $faker->boolean(80),
    ];
});
