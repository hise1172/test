<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Product\Product;
use App\Models\Product\ProductQuestionAnswer;
use App\Models\UserRole;
use Faker\Generator as Faker;

$factory->define(ProductQuestionAnswer::class, function (Faker $faker) {
    $users = UserRole::where('name', UserRole::ROLE_USER)->first()->users()->pluck('id');
    $products = Product::all()->pluck('id');
    return [
        'user_id' => $faker->randomElement($users),
        'product_id' => $faker->randomElement($products),
        'parent_id' => null,
    ];
});
