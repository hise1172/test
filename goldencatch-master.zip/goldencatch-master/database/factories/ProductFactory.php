<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product\Product;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(Product::class, function (Faker $faker) {
    $categories = Category::all()->pluck('id');
    $brands = Brand::all()->pluck('id');
    $name = Str::random(10);
    $photos = ['images/mirrox4000s.jpg','images/bobbin.jpg', 'images/image-4.jpg','images/aji-flat.jpg'];
    return [
        'SKU' => Str::random(8),
        'category_id' => $faker->randomElement($categories),
        'brand_id' => $faker->randomElement($brands),
        'photo' => $faker->randomElement($photos),
        'name' => $name,
        'slug' => $name,
        'price' => $faker->randomFloat(2, 100, 1000),
        'description' => $faker->text(500),
        'short_description' => $faker->text(200),
//        'article' => Str::random(5),
        'weight' => $faker->randomFloat(2, 100, 500),
//        'date_arrival' => $faker->randomElement([null, $faker->date()])
    ];
});
