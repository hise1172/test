<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ReviewAttach;
use Faker\Generator as Faker;

$factory->define(ReviewAttach::class, function (Faker $faker) {
    return [
        'path' => 'images/bobbin.jpg',
        'type' => ReviewAttach::ATTACH_PHOTO
    ];
});
