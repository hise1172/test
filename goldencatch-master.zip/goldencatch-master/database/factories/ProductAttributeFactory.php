<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Product\ProductAttribute;
use Faker\Generator as Faker;

$factory->define(ProductAttribute::class, function (Faker $faker) {
    $value = [null, 'значение1', 'значение2', 'значение3', 'значение4', 'значение5'];
    return [
        'value' => $faker->randomElement($value),
        'isVisible' => $faker->boolean()
    ];
});
