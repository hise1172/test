<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Hansa details
    |--------------------------------------------------------------------------
    | The service knocking to our API and make some actions.
    | In the section, there are details for Hansa access to our API
    |
    */

    'hansa_incoming_access' => [
        'allowed_ip' => env('HANSA_IP'),
        'api_token' => env('HANSA_KEY'),
    ],
];
