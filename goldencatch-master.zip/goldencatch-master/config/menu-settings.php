<?php

use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Services\Menu\Items\LinkItem;
use App\Services\Menu\Items\ParentItem;
use App\Models\LandingPage;

return [
    'catalogMenu' => [
        [
            'type'     => LinkItem::class,
            'linkData' => [Category::class => 1],
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 19 19" fill="none"><path d="M0 15.2501V19.0001H3.75L14.81 7.94006L11.06 4.19006L0 15.2501ZM17.71 5.04006C18.1 4.65006 18.1 4.02006 17.71 3.63006L15.37 1.29006C14.98 0.900059 14.35 0.900059 13.96 1.29006L12.13 3.12006L15.88 6.87006L17.71 5.04006Z" /></svg>',
            'title'    => 'header.rods',
        ],
        [
            'type'     => LinkItem::class,
            'linkData' => [Category::class => 2],
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 16 16" fill="none"><path d="M12 0L16 4V0H12ZM16 12L12 16H16V12ZM4 16L0 12V16H4ZM0 4L4 0H0V4ZM12.95 3.05C10.22 0.32 5.78 0.32 3.05 3.05C0.32 5.78 0.32 10.22 3.05 12.95C5.78 15.68 10.22 15.68 12.95 12.95C15.68 10.22 15.68 5.79 12.95 3.05ZM11.85 11.85C9.72 13.98 6.28 13.98 4.15 11.85C2.02 9.72 2.02 6.28 4.15 4.15C6.28 2.02 9.72 2.02 11.85 4.15C13.98 6.28 13.98 9.72 11.85 11.85Z" /></svg>',
            'title'    => 'header.coils',
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 23 22" fill="none"><path d="M21.7444 18L12.6444 8.90001C13.5444 6.60001 13.0444 3.90001 11.1444 2.00001C9.14437 1.20401e-05 6.14437 -0.399988 3.74437 0.700012L8.04437 5.00001L5.04437 8.00001L0.644373 3.70001C-0.555627 6.10001 -0.055627 9.10001 1.94437 11.1C3.84437 13 6.54437 13.5 8.84437 12.6L17.9444 21.7C18.3444 22.1 18.9444 22.1 19.3444 21.7L21.6444 19.4C22.1444 19 22.1444 18.3 21.7444 18Z" /></svg>',
            'title'    => 'header.spares',
            'children' => [
                ['type' => LinkItem::class, 'linkData' => [Category::class => 4]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 5]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 6]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 7]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 8]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 9]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 10]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 11]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 12]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 13]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 14]],
            ],
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 16 18" fill="none"><path d="M16 5H13.19C12.74 4.22 12.12 3.55 11.37 3.04L13 1.41L11.59 0L9.42 2.17C8.96 2.06 8.49 2 8 2C7.51 2 7.04 2.06 6.59 2.17L4.41 0L3 1.41L4.62 3.04C3.88 3.55 3.26 4.22 2.81 5H0V7H2.09C2.04 7.33 2 7.66 2 8V9H0V11H2V12C2 12.34 2.04 12.67 2.09 13H0V15H2.81C3.85 16.79 5.78 18 8 18C10.22 18 12.15 16.79 13.19 15H16V13H13.91C13.96 12.67 14 12.34 14 12V11H16V9H14V8C14 7.66 13.96 7.33 13.91 7H16V5ZM10 13H6V11H10V13ZM10 9H6V7H10V9Z" /></svg>',
            'title'    => 'Приманки',
            'children' => [
                ['type' => LinkItem::class, 'linkData' => [Category::class => 16]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 17]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 18]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 19]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 20]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 21]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 22]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 23]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 24]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 25]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 1001]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 1003]],
            ],
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 22 22" fill="none"><path d="M7 10.5C7 9.67 6.33 9 5.5 9C4.67 9 4 9.67 4 10.5C4 11.33 4.67 12 5.5 12C6.33 12 7 11.33 7 10.5ZM14 5.5C14 4.67 13.33 4 12.5 4H9.5C8.67 4 8 4.67 8 5.5C8 6.33 8.67 7 9.5 7H12.5C13.33 7 14 6.33 14 5.5ZM7.5 14C6.67 14 6 14.67 6 15.5C6 16.33 6.67 17 7.5 17C8.33 17 9 16.33 9 15.5C9 14.67 8.33 14 7.5 14ZM11 0C4.93 0 0 4.93 0 11C0 17.07 4.93 22 11 22C17.07 22 22 17.07 22 11C22 4.93 17.07 0 11 0ZM11 20C6.04 20 2 15.96 2 11C2 6.04 6.04 2 11 2C15.96 2 20 6.04 20 11C20 15.96 15.96 20 11 20ZM16.5 9C15.67 9 15 9.67 15 10.5C15 11.33 15.67 12 16.5 12C17.33 12 18 11.33 18 10.5C18 9.67 17.33 9 16.5 9ZM14.5 14C13.67 14 13 14.67 13 15.5C13 16.33 13.67 17 14.5 17C15.33 17 16 16.33 16 15.5C16 14.67 15.33 14 14.5 14Z" /></svg>',
            'title'    => 'Леска, шнур, флюорокарбон',
            'children' => [
                ['type' => LinkItem::class, 'linkData' => [Category::class => 27]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 28]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 29]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 30]],
            ],
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 14 14" fill="none"><path d="M0 12H14V14H0V12ZM7 0L0.33 10H13.67L7 0Z" /></svg>',
            'title'    => 'Элементы оснастки',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 33]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 34]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 35]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 36]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 37]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 38]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 41]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 42]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 43]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 44]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 294]],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 46]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 47]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 48]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 49]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 50]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 51]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 52]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 53]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 54]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 55]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 56]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 57]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 58]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 59]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 60]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 61]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 62]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 63]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 64]],
                    ],
                ],
            ],
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 19 18" fill="none"><path d="M2.58984 3.89C3.28984 3.18 3.98984 2.54 4.29984 2.67C4.79984 2.87 4.29984 3.7 3.99984 4.19C3.74984 4.61 1.13984 8.08 1.13984 10.5C1.13984 11.78 1.61984 12.84 2.47984 13.48C3.22984 14.04 4.21984 14.21 5.11984 13.94C6.18984 13.63 7.06984 12.54 8.17984 11.17C9.38984 9.68 11.0098 7.73 12.2598 7.73C13.8898 7.73 13.9098 8.74 14.0198 9.52C10.2398 10.16 8.63984 13.19 8.63984 14.89C8.63984 16.59 10.0798 17.98 11.8498 17.98C13.4798 17.98 16.1398 16.65 16.5398 11.88H18.9998V9.38H16.5298C16.3798 7.73 15.4398 5.18 12.4998 5.18C10.2498 5.18 8.31984 7.09 7.55984 8.02C6.97984 8.75 5.49984 10.5 5.26984 10.74C5.01984 11.04 4.58984 11.58 4.15984 11.58C3.70984 11.58 3.43984 10.75 3.79984 9.66C4.14984 8.57 5.19984 6.8 5.64984 6.14C6.42984 5 6.94984 4.22 6.94984 2.86C6.94984 0.69 5.30984 0 4.43984 0C3.11984 0 1.96984 1 1.71984 1.25C1.35984 1.61 1.05984 1.91 0.839844 2.18L2.58984 3.89ZM11.8798 15.55C11.5698 15.55 11.1398 15.29 11.1398 14.83C11.1398 14.23 11.8698 12.63 14.0098 12.07C13.7098 14.76 12.5798 15.55 11.8798 15.55Z" /></svg>',
            'title'    => 'Акксесуары',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 66]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 67]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 68]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 69]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 70]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 71]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 72]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 73]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 74]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 75]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 76]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 77]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 78]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 79]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 80]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 81]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 82]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 83]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 84]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 85]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 86]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 87]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 88]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 89]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 90]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 1002]],
                    ],

                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 91]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 92]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 93]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 94]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 95]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 96]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 97]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 98]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 99]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 100]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 101]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 102]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 103]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 104]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 105]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 106]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 107]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 108]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 109]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 110]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 111]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 112]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 113]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 114]],
                    ],
                ],
            ],
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 19 18" fill="none"><path d="M2.58984 3.89C3.28984 3.18 3.98984 2.54 4.29984 2.67C4.79984 2.87 4.29984 3.7 3.99984 4.19C3.74984 4.61 1.13984 8.08 1.13984 10.5C1.13984 11.78 1.61984 12.84 2.47984 13.48C3.22984 14.04 4.21984 14.21 5.11984 13.94C6.18984 13.63 7.06984 12.54 8.17984 11.17C9.38984 9.68 11.0098 7.73 12.2598 7.73C13.8898 7.73 13.9098 8.74 14.0198 9.52C10.2398 10.16 8.63984 13.19 8.63984 14.89C8.63984 16.59 10.0798 17.98 11.8498 17.98C13.4798 17.98 16.1398 16.65 16.5398 11.88H18.9998V9.38H16.5298C16.3798 7.73 15.4398 5.18 12.4998 5.18C10.2498 5.18 8.31984 7.09 7.55984 8.02C6.97984 8.75 5.49984 10.5 5.26984 10.74C5.01984 11.04 4.58984 11.58 4.15984 11.58C3.70984 11.58 3.43984 10.75 3.79984 9.66C4.14984 8.57 5.19984 6.8 5.64984 6.14C6.42984 5 6.94984 4.22 6.94984 2.86C6.94984 0.69 5.30984 0 4.43984 0C3.11984 0 1.96984 1 1.71984 1.25C1.35984 1.61 1.05984 1.91 0.839844 2.18L2.58984 3.89ZM11.8798 15.55C11.5698 15.55 11.1398 15.29 11.1398 14.83C11.1398 14.23 11.8698 12.63 14.0098 12.07C13.7098 14.76 12.5798 15.55 11.8798 15.55Z" /></svg>',
            'title'    => 'Прикормки, насадки',
            'children' => [
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 116]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 117]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 118]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 119]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 120]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 121]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 122]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 123]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 124]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 125]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 126]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 127]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 128]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 129]],
                ['type' => LinkItem::class, 'linkData' => [Category::class => 130]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 131]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 132]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 133]],
                // ['type' => LinkItem::class, 'linkData' => [Category::class => 134]],
            ]
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 19 18" fill="none"><path d="M2.58984 3.89C3.28984 3.18 3.98984 2.54 4.29984 2.67C4.79984 2.87 4.29984 3.7 3.99984 4.19C3.74984 4.61 1.13984 8.08 1.13984 10.5C1.13984 11.78 1.61984 12.84 2.47984 13.48C3.22984 14.04 4.21984 14.21 5.11984 13.94C6.18984 13.63 7.06984 12.54 8.17984 11.17C9.38984 9.68 11.0098 7.73 12.2598 7.73C13.8898 7.73 13.9098 8.74 14.0198 9.52C10.2398 10.16 8.63984 13.19 8.63984 14.89C8.63984 16.59 10.0798 17.98 11.8498 17.98C13.4798 17.98 16.1398 16.65 16.5398 11.88H18.9998V9.38H16.5298C16.3798 7.73 15.4398 5.18 12.4998 5.18C10.2498 5.18 8.31984 7.09 7.55984 8.02C6.97984 8.75 5.49984 10.5 5.26984 10.74C5.01984 11.04 4.58984 11.58 4.15984 11.58C3.70984 11.58 3.43984 10.75 3.79984 9.66C4.14984 8.57 5.19984 6.8 5.64984 6.14C6.42984 5 6.94984 4.22 6.94984 2.86C6.94984 0.69 5.30984 0 4.43984 0C3.11984 0 1.96984 1 1.71984 1.25C1.35984 1.61 1.05984 1.91 0.839844 2.18L2.58984 3.89ZM11.8798 15.55C11.5698 15.55 11.1398 15.29 11.1398 14.83C11.1398 14.23 11.8698 12.63 14.0098 12.07C13.7098 14.76 12.5798 15.55 11.8798 15.55Z" /></svg>',
            'title'    => 'Кемпинг',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 141]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 142]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 143]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 144]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 145]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 146]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 147]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 148]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 149]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 150]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 151]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 152]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 153]],
                        // ['type' => LinkItem::class, 'linkData' => [Category::class => 154]],

                        // Мебель
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 137]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 140]],
                    ],
                ],
                // [
                //     'type' => ParentItem::class,
                //     'title' => 'Мебель',
                //     'children' => [
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 137]],
                //         // ['type' => LinkItem::class, 'linkData' => [Category::class => 138]],
                //         // ['type' => LinkItem::class, 'linkData' => [Category::class => 139]],
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 140]],
                //     ],
                // ],
            ]
        ],
        [
            'type'     => ParentItem::class,
            'icon'     => '<svg class="mx-6 w-4 text-orange-500 fill-current" viewBox="0 0 19 18" fill="none"><path d="M2.58984 3.89C3.28984 3.18 3.98984 2.54 4.29984 2.67C4.79984 2.87 4.29984 3.7 3.99984 4.19C3.74984 4.61 1.13984 8.08 1.13984 10.5C1.13984 11.78 1.61984 12.84 2.47984 13.48C3.22984 14.04 4.21984 14.21 5.11984 13.94C6.18984 13.63 7.06984 12.54 8.17984 11.17C9.38984 9.68 11.0098 7.73 12.2598 7.73C13.8898 7.73 13.9098 8.74 14.0198 9.52C10.2398 10.16 8.63984 13.19 8.63984 14.89C8.63984 16.59 10.0798 17.98 11.8498 17.98C13.4798 17.98 16.1398 16.65 16.5398 11.88H18.9998V9.38H16.5298C16.3798 7.73 15.4398 5.18 12.4998 5.18C10.2498 5.18 8.31984 7.09 7.55984 8.02C6.97984 8.75 5.49984 10.5 5.26984 10.74C5.01984 11.04 4.58984 11.58 4.15984 11.58C3.70984 11.58 3.43984 10.75 3.79984 9.66C4.14984 8.57 5.19984 6.8 5.64984 6.14C6.42984 5 6.94984 4.22 6.94984 2.86C6.94984 0.69 5.30984 0 4.43984 0C3.11984 0 1.96984 1 1.71984 1.25C1.35984 1.61 1.05984 1.91 0.839844 2.18L2.58984 3.89ZM11.8798 15.55C11.5698 15.55 11.1398 15.29 11.1398 14.83C11.1398 14.23 11.8698 12.63 14.0098 12.07C13.7098 14.76 12.5798 15.55 11.8798 15.55Z" /></svg>',
            'title'    => 'Экипировка',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Одежда',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 158]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 159]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 160]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 161]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 162]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 163]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 164]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 165]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 166]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 167]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 168]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 169]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Головные уборы',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 179]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 180]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 181]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'children' => [
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 175]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 176]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 177]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 182]],
                                // ['type' => LinkItem::class, 'linkData' => [Category::class => 183]],
                            ],
                        ],
                        // [
                        //     'type' => ParentItem::class,
                        //     'title' => 'Обувь',
                        //     'children' => [
                        //         ['type' => LinkItem::class, 'linkData' => [Category::class => 171]],
                        //         ['type' => LinkItem::class, 'linkData' => [Category::class => 172]],
                        //         ['type' => LinkItem::class, 'linkData' => [Category::class => 173]],
                        //         ['type' => LinkItem::class, 'linkData' => [Category::class => 174]],
                        //     ],
                        // ],
                    ],
                ],

            ],
        ],

    ],
    'headerMenu' => [
        [
            'type'     => LinkItem::class,
            'linkData' => [LandingPage::class => 'carp'],
            'title'    => 'header.karp',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Вудилища',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 1, AttributeSlugValue::class => 1]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Котушки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 2, AttributeSlugValue::class => 1]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Гачки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 32, AttributeSlugValue::class => 1]],
                            ],
                        ],
                    ],
                ],
                // [
                //     'type' => ParentItem::class,
                //     'children' => [
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 33]],
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 34]],
                //     ],
                // ],
                // [
                //     'type' => ParentItem::class,
                //     'children' => [
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 46]],
                //         ['type' => LinkItem::class, 'linkData' => [Category::class => 47]],
                //     ],
                // ],
            ],
        ],
        [
            'type'     => LinkItem::class,
            'linkData' => [LandingPage::class => 'spinning'],
            'title'    => 'header.spining',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Вудилища',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Котушки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Гачки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
                            ],
                        ],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 33]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                    ],
                ],
            ],
        ],
        [
            'type'     => LinkItem::class,
            'linkData' => [LandingPage::class => 'float'],
            'title'    => 'header.poplavok',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Вудилища',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Котушки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Гачки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
                            ],
                        ],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 33]],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                    ],
                ],
            ],
        ],
        [
            'type'     => LinkItem::class,
            'linkData' => [LandingPage::class => 'saltwater'],
            'title'    => 'header.morskaia',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Вудилища',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Котушки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Гачки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
                            ],
                        ],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 33]],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                    ],
                ],
            ],
        ],
        [
            'type'     => LinkItem::class,
            'linkData' => [LandingPage::class => 'feeder'],
            'title'    => 'header.fidernaia',
            'children' => [
                [
                    'type' => ParentItem::class,
                    'children' => [
                        [
                            'type' => ParentItem::class,
                            'title' => 'Вудилища',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Котушки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
                            ],
                        ],
                        [
                            'type' => ParentItem::class,
                            'title' => 'Гачки',
                            'children' => [
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
                                ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
                            ],
                        ],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 32]],
                    ],
                ],
                [
                    'type' => ParentItem::class,
                    'children' => [
                        ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
                    ],
                ],
            ],
        ],
        // [
        //     'type'     => LinkItem::class,
        //     'linkData' => [Category::class => 2, AttributeSlugValue::class => 1],
        //     'title'    => 'header.camping',
        //     'children' => [
        //         [
        //             'type' => ParentItem::class,
        //             'children' => [
        //                 [
        //                     'type' => ParentItem::class,
        //                     'title' => 'Вудилища',
        //                     'children' => [
        //                         ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
        //                     ]
        //                 ],
        //                 [
        //                     'type' => ParentItem::class,
        //                     'title' => 'Котушки',
        //                     'children' => [
        //                         ['type' => LinkItem::class, 'linkData' => [Category::class => 157]],
        //                     ]
        //                 ],
        //                 [
        //                     'type' => ParentItem::class,
        //                     'title' => 'Гачки',
        //                     'children' => [
        //                         ['type' => LinkItem::class, 'linkData' => [Category::class => 39]],
        //                         ['type' => LinkItem::class, 'linkData' => [Category::class => 40]],
        //                     ]
        //                 ]
        //             ]
        //         ],
        //         [
        //             'type' => ParentItem::class,
        //             'children' => [
        //                 ['type' => LinkItem::class, 'linkData' => [Category::class => 44]],
        //             ],
        //         ],
        //         [
        //             'type' => ParentItem::class,
        //             'children' => [
        //                 ['type' => LinkItem::class, 'linkData' => [Category::class => 45]],
        //             ],
        //         ],
        //     ],
        // ],
        // [
        //     'type'     => LinkItem::class,
        //     'linkData' => [Category::class => 155],
        //     'title'    => 'header.ekiper'
        // ],
    ],
];
