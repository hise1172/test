<?php

return [
  ['routeName' => 'main',],
  ['routeName' => 'deliverypay',],
  ['routeName' => 'returnproduct',],
  ['routeName' => 'wholesaleclients',],
  ['routeName' => 'about',],
  ['routeName' => 'page.contacts',],
];
