<?php

return [
  'rozetka' => [
    'import' => [
      'brands' => env('MARKETPLACES_ROZETKA_IMPORT_BRANDS', '1,3,20,50,304'),
    ]
  ]
];
