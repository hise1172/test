<?php

return [
    'esputnik' => [
        'username' => env('ESPUTNIC_USERNAME'),
        'api_key' => env('ESPUTNIC_API_KEY'),
        'api_url' => 'https://esputnik.com/api/v1/',
        'sender_name' => env('ESPUTNIC_SENDER'), // use 'reklama' for test mode
    ],
    'epochta' => [
        'public_key' => env('EPOCHTA_PUBLIC_KEY'),
        'private_key' => env('EPOCHTA_PRIVATE_KEY'),
        'api_url' => 'http://api.atompark.com/api/sms/',
        'test_mode' => env('APP_DEBUG'),
        'sender_name' => env('APP_NAME'),
    ],
];
