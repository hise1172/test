<?php

return [
  'account' => [
    [
      'routeName' => 'account.index',
      'title' => 'header.Personal data',
      'activeRouteNames' => [
        'account.edit',
        'account.edit-password',
      ],
    ],
    [
      'routeName' => 'account.orders',
      'title' => 'header.Orders',
      'activeRouteNames' => [],
    ],
    [
      'routeName' => 'account.expected-items',
      'title' => 'header.Expected items',
      'activeRouteNames' => [],
    ],
    [
      'routeName' => 'account.favorites',
      'title' => 'header.Favorites',
      'activeRouteNames' => [],
    ],
    [
      'routeName' => 'account.review',
      'title' => 'header.Product Reviews',
      'activeRouteNames' => [],
    ],
    [
      'routeName' => 'account.question',
      'title' => 'header.Questions and answers',
      'activeRouteNames' => [],
    ],
    [
      'routeName' => 'product.compare',
      'title' => 'header.Product comparison',
      'activeRouteNames' => [],
    ],
    [
        'routeName' => 'account.bonus-club',
        'title' => 'account.bonus_club.title',
        'activeRouteNames' => [],
    ],
  ]
];
