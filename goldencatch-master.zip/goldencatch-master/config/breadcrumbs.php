<?php

return [

    /*
    |--------------------------------------------------------------------------
    | View file
    |--------------------------------------------------------------------------
    |
    | Here you may specify the view that will be used to render the breadcrumbs.
    | By default the package ships with a Bootstrap 3 compatible view, but you
    | can publish and adjust it in your own application, or change it to use
    | your own view instead.
    |
    */

    'view' => 'breadcrumbs::bootstrap3',

];
