<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Settings Path
    |--------------------------------------------------------------------------
    |
    | Path to the JSON file where settings are stored.
    |
    */

    'path' => storage_path('app/settings.json'),

    /*
    |--------------------------------------------------------------------------
    | Sidebar Label
    |--------------------------------------------------------------------------
    |
    | The text that Nova displays for this tool in the navigation sidebar.
    |
    */

    'sidebar-label' => 'Настройки',

    /*
    |--------------------------------------------------------------------------
    | Settings
    |--------------------------------------------------------------------------
    |
    | The good stuff :). Each setting defined here will render a field in the
    | tool. The only required key is `key`, other available keys include `type`,
    | `label`, `help`, `placeholder`, `language`, and `panel`.
    |
    */

    'settings' => [

        [
            'key' => 'homepage_banner_desktop_path',
            'label' => 'Изображение для дескотопа',
            'panel' => 'Баннер',
        ],

        [
            'key' => 'homepage_banner_mobile_path',
            'label' => 'Изображение для мобильных',
            'panel' => 'Баннер',
        ],

        [
            'key' => 'homepage_banner_url',
            'label' => 'Ссылка',
            'panel' => 'Баннер',
        ],

        #region Описание в оптовой корзине

        [
            'key' => 'wholesale_cart_description_title_ru',
            'label' => 'Заголовок (RU)',
            'panel' => 'Описание в оптовой корзине',
        ],

        [
            'key' => 'wholesale_cart_description_title_ua',
            'label' => 'Заголовок (UA)',
            'panel' => 'Описание в оптовой корзине',
        ],

        [
            'key' => 'wholesale_cart_description_text_ru',
            'label' => 'Описапние  (RU)',
            'type' => 'code',
            'language' => 'htmlmixed',
            'panel' => 'Описание в оптовой корзине',
        ],

        [
            'key' => 'wholesale_cart_description_text_ua',
            'label' => 'Описапние  (UA)',
            'type' => 'code',
            'language' => 'htmlmixed',
            'panel' => 'Описание в оптовой корзине',
        ],

        #endregion

        // Youtube

        [
            'key' => 'homepage_youtube_1_name',
            'label' => 'Видео 1: Название',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_1_url',
            'label' => 'Видео 1: Ссылка',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_1_date',
            'label' => 'Видео 1: Дата',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_2_name',
            'label' => 'Видео 2: Название',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_2_url',
            'label' => 'Видео 2: Ссылка',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_2_date',
            'label' => 'Видео 2: Дата',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_3_name',
            'label' => 'Видео 3: Название',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_3_url',
            'label' => 'Видео 3: Ссылка',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_3_date',
            'label' => 'Видео 3: Дата',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_4_name',
            'label' => 'Видео 4: Название',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_4_url',
            'label' => 'Видео 4: Ссылка',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_youtube_4_date',
            'label' => 'Видео 4: Дата',
            'panel' => 'Youtube',
        ],

        [
            'key' => 'homepage_about_text',
            'label' => 'Текст о компании',
            'type' => 'textarea',
            'panel' => 'О компании',
        ],

        [
            'key' => 'homepage_about_picture_url',
            'label' => 'Ссылка на изображение',
            'panel' => 'О компании',
        ],

        [
            'key' => 'contacts_email',
            'label' => 'Email',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'contacts_operator_phones',
            'label' => 'Телефон оператора',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'contacts_operator_phones_backup',
            'label' => 'Телефон оператора (дополнительный)',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'contacts_jobs_time_internet_shop',
            'label' => 'Время работы',
            'type' => 'textarea',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'contacts_address_internet_shop',
            'label' => 'Адрес',
            'type' => 'textarea',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'contacts_operator_of_resellers_phones',
            'label' => 'Телефоны операторов',
            'type' => 'textarea',
            'panel' => 'Контактные данные',
        ],

        [
            'key' => 'price_for_resellers_xls',
            'label' => 'Оптовый прайс',
            'placeholder' => 'Ссылка на XLS файл',
            'panel' => 'Прайс-лист',
        ],

        [
            'key' => 'categories_modifications_look_cards',
            'label' => 'Категории с товарами модификациями плиткой',
            'panel' => 'Другие',
        ],

    ],
];
