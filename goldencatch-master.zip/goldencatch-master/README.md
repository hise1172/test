### Запуск
Goldencatch требует
[PHP ^7.4](https://www.php.net/downloads)
[Node 6.14+](https://nodejs.org/en/download/)
[Composer](https://getcomposer.org/download/)

### Установка проекта
```sh
cd <папка проекта>
git init
git remote add origin https://github.com/haidarzhy/goldencatch
git pull origin master
```
### Сборка проекта
```sh
composer install
npm install -g gulp && npm install && gulp build
cp .env.example .env
php artisan key:generate
php artisan config:clear
php artisan cache:clear
```
### Конфигурация .env 
открыть файл .env любым текстовым редактором(или в среде разработки)
В строках ниже нужно указать данные для подключения к базе данных Mysql
```sh
DB_HOST=адрес(localhost, 127.0.0.1)
DB_PORT=3306
DB_DATABASE=имя базы данных
DB_USERNAME=имя пользователя
DB_PASSWORD=пароль пользователя
```
После конфигурации файла .env выполнить
```sh
php artisan nova:install
php artisan migrate
```
После пройти регистрацию по пути http://localhost/register (указать любые тестовые данные)
Админка доступна по адресу http://localhost/nova


## Система тимчасових бонусів / промо акцій

Система побудована на основі 3 таблиць

1. `promotions` - використовується лише в цій логіці 
2. `user_promotions` - використовується лише в цій логіці
3. `bonus_history` - використовується і для бонусів по програмі лояльності

Для того, щоб нарахувати бонуси, спочатку потрібно створити промо акцію (`promotion`), тоді зачислити користувачу можливість взяти участь в цій промо акції (`user_promotions`).
Після цього, якщо кошик відповідає умовам акції, на сторінці замовлення у користувача з'явиться можливість використати бонуси.


### Історія нарахованих бонусів по промо акціям

Оскільки не використані тимчасові бонуси списуються в момент завершення акції, то ми не можемо просто додати їх до бонусного балансу користувача. Тому розмір використаних тимчасових бонусів додається до бонусного балансу в момент списання з цього балансу (в момент створення замовлення).


## Hansa API integration

Авторизація відбувається за допомогою 2х параметрів конфігурації env
`HANSA_IP` - дозволене IP, з якого робиться запит
`HANSA_KEY` - токен, який передається у GET параметрі `$_GET['key']`

### Методи

#### Список замовлень

**Метод** `GET`
\
**URI**: `/api/hansa/orders`
\
**Параметри**:
- `filter.createdAtFrom` (default: "1970-01-01") - дата, починаючи від якої потрібно отримати замовлення
- `page` (default: 1) - номер сторінки для пагінації відповіді
- `limit` (default: 10) - кількість замовлень на сторінку

**Response**
```json
{
    "orders": [
        {
            "externalId": 5629,
            "createdAt": "2022-06-23T14:53:04.000000Z",
            "summ": 52.25,
            "totalSumm": "52.25",
            "lastName": "lastName",
            "firstName": "firstName",
            "phone": "+380980000000",
            "email": "email@ukr.net",
            "call": 1,
            "customerComment": null,
            "customer": {
                "externalId": 4628
            },
            "delivery": {
                "integrationCode": "newpost",
                "data": {
                    "pickuppointId": null
                },
                "tracking_code": ""
            },
            "items": [
                {
                    "id": 30140,
                    "article": "1000055",
                    "price": "52.25",
                    "quantity": 1
                }
            ]
        },
        ...
    ],
    "links": {
        "first": "http://goldencatch.store/api/hansa/orders?page=1",
        "last": "http://goldencatch.store/api/hansa/orders?page=2",
        "prev": null,
        "next": "http://goldencatch.store/api/hansa/orders?page=2"
    },
    "meta": {
        "current_page": 1,
        "from": 1,
        "last_page": 2,
        "links": [
            {
                "url": null,
                "label": "&laquo; Previous",
                "active": false
            },
            {
                "url": "http://goldencatch.store/api/hansa/orders?page=1",
                "label": "1",
                "active": true
            },
            ...
        ],
        "path": "http://goldencatch.store/api/hansa/orders",
        "per_page": 1,
        "to": 1,
        "total": 2
    }
}
```

#### Дані замовлення

**Метод** `GET`
\
**URI**: `/api/hansa/orders/<order_id>`
\
**Параметри**: немає

**Response**

```json
{
    "order": {
        "externalId": 5453,
        "createdAt": "2022-05-23T09:01:06.000000Z",
        "summ": 2409,
        "totalSumm": "2409",
        "lastName": "lastName",
        "firstName": "firstName",
        "phone": "0680000000",
        "email": null,
        "call": 1,
        "customerComment": null,
        "customer": {
            "externalId": 4485
        },
        "delivery": {
            "integrationCode": "newpost",
            "data": {
                "pickuppointId": "511fd008-e1c2-11e3-8c4a-0050568002cf"
            },
            "tracking_code": "1656346316"
        },
        "items": [
            {
                "id": 28918,
                "article": "2039314",
                "price": "2409.00",
                "quantity": 1
            },
            ...
        ]
    }
}
```

#### Оновити Track Number у замовлення

**Метод** `POST`
\
**URI**: `/api/hansa/orders/<order_id>`
\
**Параметри**: немає
- `delivery.trackNumber` - номер ТТН

**Response**

```json
{
    "order": {
        "externalId": 5453,
        "createdAt": "2022-05-23T09:01:06.000000Z",
        "summ": 2409,
        "totalSumm": "2409",
        "lastName": "lastName",
        "firstName": "firstName",
        "phone": "0680000000",
        "email": null,
        "call": 1,
        "customerComment": null,
        "customer": {
            "externalId": 4485
        },
        "delivery": {
            "integrationCode": "newpost",
            "data": {
                "pickuppointId": "511fd008-e1c2-11e3-8c4a-0050568002cf"
            },
            "tracking_code": "1656346316"
        },
        "items": [
            {
                "id": 28918,
                "article": "2039314",
                "price": "2409.00",
                "quantity": 1
            },
            ...
        ]
    }
}
```


### Тестування на dev сервері

Для того, щоб надіслати запит на тестовий сервер, потрібно в заголовках прописати авторизаційні дані:
\
`Authorization: Basic {{ bas64_encode('username:password') }}`
