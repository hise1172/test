<?php

namespace App\Listeners;

use App\Events\BonusesHasBeenApprovedEvent;
use App\Jobs\SendNewBonusAppliedNotificationToCustomerJob;

class SendNotificationToCustomerLisiner
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\BonusesHasBeenApprovedEvent $event
     *
     * @return void
     */
    public function handle(BonusesHasBeenApprovedEvent $event)
    {
        if ($event->user->botUser) {
            SendNewBonusAppliedNotificationToCustomerJob::dispatch($event->user);
        }
    }
}
