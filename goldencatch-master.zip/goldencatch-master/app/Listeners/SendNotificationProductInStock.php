<?php

namespace App\Listeners;

use App\Events\ProductInStock;
use App\Jobs\ClearWaitingProductsJob;
use App\Jobs\SendMailProductInStockJob;
use App\Mail\ProductInStockMail;
use App\Models\UserWaiting;
use App\Repositories\UserRepository;
use App\Repositories\UserWaitingRepository;
use App\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class SendNotificationProductInStock
{
    /**
     * @var UserWaitingRepository
     */
    private $userWaitingRepository;
    /**
     * @var UserRepository
     */
    private $userRepository;

    /**
     * Create the event listener.
     *
     * @param UserWaitingRepository $userWaitingRepository
     * @param UserRepository $userRepository
     */
    public function __construct(UserWaitingRepository $userWaitingRepository, UserRepository $userRepository)
    {
        //
        $this->userWaitingRepository = $userWaitingRepository;
        $this->userRepository = $userRepository;
    }

    /**
     * Handle the event.
     *
     * @param ProductInStock $event
     * @return void
     */
    public function handle(ProductInStock $event)
    {
        $usersId = $this->userWaitingRepository->getUsersId($event->product->id);
        $usersId = $this->userRepository->getUserByIds($usersId);
        ClearWaitingProductsJob::dispatch($event->product->id, $usersId->pluck('id'));
        $usersId->each(function (User $user) use ($event) {
            Mail::to($user->email)->queue(new ProductInStockMail($user, $event->product->slug));
        });
    }
}
