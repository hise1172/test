<?php

namespace App\Listeners;

use App\Repositories\ProductFavoriteRepository;
use Illuminate\Auth\Events\Login;

/**
 * Class ProductFavoritesMerge
 *
 * @package App\Listeners
 */
class ProductFavoritesMerge
{
    private ProductFavoriteRepository $repository;

    /**
     * FavoritesMerge constructor.
     *
     * @param ProductFavoriteRepository $repository
     */
    public function __construct(ProductFavoriteRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Handle the event.
     *
     * @param $event
     * @return void
     */
    public function handle(Login $event)
    {
        foreach ($this->repository->getFromSession() as $product_id) {
            $this->repository->add($product_id);
        }
    }
}
