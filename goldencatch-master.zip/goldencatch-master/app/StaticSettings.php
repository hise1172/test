<?php

namespace App;

use Spatie\Valuestore\Valuestore;

class StaticSettings extends Valuestore
{
    //
}
