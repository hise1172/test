<?php

namespace App\Nova;

use App\Models;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Badge;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Select;
use App\Nova\Metrics\BonusTrend;
use App\Nova\Metrics\BonusValue;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\MorphOne;
use App\Nova\Metrics\BonusPartition;
use Illuminate\Support\Facades\Storage;
use Spatie\NovaTranslatable\Translatable;
use Laravel\Nova\Http\Requests\NovaRequest;

class StatisticsBonus extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = Models\BonusHistory::class;


    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
        // 'user_id',
        'bonusable_id',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make()->sortable(),

            Badge::make('bonusable_type', function () {
                    if($this->amount < 0) {
                        return 'Снятия';
                    }

                    return 'Начисления';
                })
                ->map([
                    'Начисления' => 'success',
                    'Снятия' => 'danger',
                ])
                ->readonly(),

            Number::make('amount')
                ->sortable(),

            Text::make('Клиент', function () {
                    return '#' . $this->user_id . ' ' . $this->user->name . ' ' . $this->user->surname;
                })
                ->readonly(),

            Text::make('Товар / #Заказ', function () {
                    if('App\Models\Product\ProductOrder' == $this->bonusable_type) {
                        return $this->bonusable->product->SKU . ' ' . $this->bonusable->product->name . '(#' . $this->bonusable->order_id . ')';
                    }
                    elseif('App\Models\Order' == $this->bonusable_type) {
                        return 'Заказ #' . $this->bonusable_id;
                    }
                })
                ->readonly(),

            DateTime::make('Created At')
                ->sortable(),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [
            new BonusValue,
            new BonusPartition,
            new BonusTrend,
        ];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    public static function label()
    {
        return 'Бонуси кліентів';
    }

    public static function singularLabel()
    {
        return 'Бонус';
    }
}
