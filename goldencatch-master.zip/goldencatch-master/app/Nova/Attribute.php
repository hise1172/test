<?php

namespace App\Nova;

use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\HasMany;
use Spatie\NovaTranslatable\Translatable;
use Laravel\Nova\Fields\MorphOne;
use Laravel\Nova\Http\Requests\NovaRequest;

class Attribute extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Attribute::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public function title(){
        return '#' . $this->id . ' ' . $this->system_name;
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'system_name'
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),
            Text::make('Системное название', 'system_name'),
            Boolean::make('Показывать в таблице на странице товара', 'is_desc_attr'),
            Translatable::make([
                Text::make('Название в таблице', 'desc_attr_name'),
            ]),
            Number::make('Порядок в таблице', 'desc_attr_position'),
            Translatable::make([
                Text::make('Единица измерения в таблице', 'desc_attr_measurement_unit'),
            ]),
            
            Boolean::make('Показывать в фильтрах', 'is_filter'),
            Translatable::make([
                Text::make('Название в фильтре', 'filter_name')->rules('required'),
            ]),
            Text::make('slug в фильтре', 'filter_slug'),

            Select::make('Тип выбора в фильтре', 'filter_type')->options([
                1 => 'Выбор из списка',
                2 => 'Число',
                3 => 'Текст',
            ])->displayUsingLabels(),
            Number::make('Порядок в фильтре', 'filter_position'),
            Translatable::make([
                Text::make('Единица измерения в фильтре', 'filter_measurement_unit'),
            ]),
            

            DateTime::make('Created At')->withMeta(['extraAttributes' => [
                'readonly' => true
            ]])->onlyOnDetail(),
            DateTime::make('Updated At')->withMeta(['extraAttributes' => [
                'readonly' => true
            ]])->onlyOnDetail(),

            MorphOne::make('Semantic Rules', 'semanticRule'),

            HasMany::make('Attribute Slug Values', 'slugValues'),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    public static function label()
    {
        return 'Атрибути';
    }

    public static function singularLabel()
    {
        return 'Атрибут';
    }
}
