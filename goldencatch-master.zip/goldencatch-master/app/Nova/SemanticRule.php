<?php

namespace App\Nova;

use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\MorphTo;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Spatie\NovaTranslatable\Translatable;
use Laravel\Nova\Http\Requests\NovaRequest;

class SemanticRule extends Resource
{

    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\SemanticRule::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'replace_word', 'synonym', 'rulable_id', 'rulable_type'
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),

            MorphTo::make('Тип связи', 'Rulable')->types([
                Category::class,
                Brand::class,
                Attribute::class,
                AttributeSlugValue::class,
            ])->searchable()->sortable(),
            Boolean::make('Пропускаем', 'skip')->sortable(),

            Number::make('Приоритет в тексте', 'Position'),
            Boolean::make('Включить название атрибута', 'Includes attr name'),

            Select::make('Добавить "для рыбалки"', 'Includes fishing words')->options([
                0 => 'Нет',
                1 => 'Перед категорией',
                2 => 'После категории',
            ])->displayUsingLabels(),

            Translatable::make([
                Text::make('Слово замены', 'replace_word'),
            ]),

            Translatable::make([
                Text::make('Синоним', 'synonym'),
            ]),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    public static function label()
    {
        return 'Правила генерації мета';
    }

    public static function singularLabel()
    {
        return 'Правило';
    }
}
