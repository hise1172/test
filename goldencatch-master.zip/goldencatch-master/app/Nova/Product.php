<?php

namespace App\Nova;

use App\Nova\Field;
use Eminiarts\Tabs\Tab;
use Eminiarts\Tabs\Tabs;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Date;
use Laravel\Nova\Fields\Text;
use Eminiarts\Tabs\TabsOnEdit;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\HasMany;
use Laravel\Nova\Fields\Currency;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Fields\BelongsTo;
use App\Nova\Actions\ImportNewProducts;
use App\Nova\Field\PageConstructorField;
use Spatie\NovaTranslatable\Translatable;
use Laravel\Nova\Http\Requests\NovaRequest;
use Whitecube\NovaFlexibleContent\Flexible;
use App\Nova\Actions\ExportProductAttributes;
use App\Nova\Actions\ImportProductAttributes;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images;

class Product extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Product\Product::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public function title()
    {
        return '# ' . $this->id . ' ' . $this->name . ' (' . $this->slug . ')';
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'name', 'slug', 'SKU', 'barcode'
    ];

    public static $trafficCop = false;

    public static function usesScout()
    {
        return false;
    }

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            Tabs::make('Tabs', [
                Tab::make('Основное', [
                    ID::make()->sortable(),
                    Text::make('SKU', 'SKU')->sortable(),
                    Text::make('slug'),

                    Boolean::make('Is active'),
                    Boolean::make('Is Product of Week'),

                    Select::make('status')->options([
                        0 => 'Нет в наличии',
                        1 => 'В наличии',
                        2 => 'Предзаказ',
                    ])->displayUsingLabels(),

                    Date::make('date_arrival'),

                    Boolean::make('Wholesale'),
                    Boolean::make('Retail'),


                    BelongsTo::make('Parent Product', 'parentProduct', 'App\Nova\Product')->searchable()->nullable(),
//                     Text::make('parent_id', 'parent_id'),

                    BelongsTo::make('Category')->searchable(),
                    BelongsTo::make('Brand')->searchable(),

                    Field\Attribute::make('Attributes')->render(),

                    // Flexible::make('Content')
                    //     ->addLayout('Simple content section', 'wysiwyg', [
                    //         Text::make('Name'),
                    //         Textarea::make('description'),
                    //     ])
                    //     ->addLayout('Video section', 'video', [
                    //         Text::make('Name'),
                    //         Textarea::make('short_description'),
                    //     ]),

                    Image::make('Photo')->disk('products')->preview(function ($value, $disk) {
                            return $value;
                        })
                        ->thumbnail(function ($value, $disk) {
                            return $value;
                        })->nullable(),

                    Images::make('Photos', 'default'),
                    Currency::make('price')->currency('UAH')->sortable(),
                    Currency::make('stock_price')->currency('UAH'),



                    DateTime::make('Created At')->withMeta(['extraAttributes' => [
                        'readonly' => true
                    ]]),
                    DateTime::make('Updated At')->withMeta(['extraAttributes' => [
                        'readonly' => true
                    ]]),
                ]),
                Tab::make('Вариации', [


                ]),
                Tab::make('Атрибуты', [

                    HasMany::make('AttributeSlugValue', 'attrSlugValues'),
                ]),
                Tab::make('Тексты', [
                    Translatable::make([
                        Text::make('name')->sortable(),
                    ]),
                    Translatable::make([
                        Textarea::make('short_description'),
                    ]),
                    Translatable::make([
                        Textarea::make('description'),
                    ]),
                ]),

                PageConstructorField::make('Конструктор')
                    ->render(\App\Models\Product\Product::class),

                Tab::make('Оптовые цены', [
                    Currency::make('wholesale_price_uah')->currency('UAH')->onlyOnDetail(),
                    Currency::make('wholesale_price_uah_5')->currency('UAH')->onlyOnDetail(),
                    Currency::make('wholesale_price_uah_10')->currency('UAH')->onlyOnDetail(),
                    Currency::make('wholesale_price_uah_15')->currency('UAH')->onlyOnDetail(),

                    Currency::make('wholesale_usd')->onlyOnDetail(),
                    Currency::make('wholesale_usd_5')->onlyOnDetail(),
                    Currency::make('wholesale_usd_10')->onlyOnDetail(),
                    Currency::make('wholesale_usd_15')->onlyOnDetail(),
                ]),
                Tab::make('Склад', [
                    Number::make('stock')->onlyOnDetail(),
                    Number::make('stock_opt')->onlyOnDetail(),
                    Text::make('barcode')->onlyOnDetail(),
                    Text::make('width')->onlyOnDetail(),
                    Text::make('height')->onlyOnDetail(),
                    Text::make('depth')->onlyOnDetail(),
                    Text::make('volume')->onlyOnDetail(),
                    Text::make('brutto')->onlyOnDetail(),
                    Text::make('netto')->onlyOnDetail(),
                ]),
            ])->withToolbar(),

            HasMany::make('Modifications', 'modifications', 'App\Nova\Product'),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [
            ImportNewProducts::make()->standalone(),
            ImportProductAttributes::make()->standalone(),
            ExportProductAttributes::make()->standalone(),
        ];
    }

    public static function label()
    {
        return 'Товари';
    }

    public static function singularLabel()
    {
        return 'Товар';
    }
}
