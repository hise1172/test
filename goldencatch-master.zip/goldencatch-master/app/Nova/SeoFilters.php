<?php

namespace App\Nova;

use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Fields\Code;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\Boolean;
use Spatie\NovaTranslatable\Translatable;
use Laravel\Nova\Http\Requests\NovaRequest;
use App\Nova\Actions\ImportSeoFilters;

class SeoFilters extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\SeoFilters::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),
            Text::make('uri')->sortable(),
            Translatable::make([
                Text::make('h1')->sortable(),
            ]),
            Translatable::make([
                Text::make('title')->sortable(),
            ]),
            Translatable::make([
                Textarea::make('description')->sortable(),
            ]),
            Translatable::make([
                Code::make('text')->sortable(),
            ]),
            Boolean::make('robots_index')->sortable(),
            Boolean::make('robots_follow')->sortable(),
            Image::make('open_graph_image')->disk('social'),
            DateTime::make('Created At')->sortable()->exceptOnForms(),
            DateTime::make('Updatet At')->sortable()->exceptOnForms(),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [
            ImportSeoFilters::make()->standalone(),
        ];
    }

    public static function label()
    {
        return 'SEO фільтри';
    }

    public static function singularLabel()
    {
        return 'SEO фільтр';
    }
}
