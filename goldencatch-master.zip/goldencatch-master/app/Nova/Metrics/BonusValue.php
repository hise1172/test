<?php

namespace App\Nova\Metrics;

use App\Models\BonusHistory;
use Illuminate\Database\Eloquent\Builder;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Metrics\Value;
use Laravel\Nova\Nova;

class BonusValue extends Value
{
    /**
     * Calculate the value of the metric.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return mixed
     */
    public function calculate(NovaRequest $request)
    {
        return $this->count($request, BonusHistory::class, 'user_id');
    }

    protected function aggregate($request, $model, $function, $column = null, $dateColumn = null)
    {
        $query = $model instanceof Builder ? $model : (new $model)->newQuery();

        $column = $column ?? $query->getModel()->getQualifiedKeyName();

        $timezone = Nova::resolveUserTimezone($request) ?? $request->timezone;

        $previousValue = round(with(clone $query)->whereBetween(
            $dateColumn ?? $query->getModel()->getQualifiedCreatedAtColumn(),
            array_map(function ($datetime) {
                return $this->asQueryDatetime($datetime);
            }, $this->previousRange($request->range, $timezone))
            )
            ->where('bonusable_type', 'App\Models\Product\ProductOrder')
            ->distinct($column)
            ->count(),
            0);

        return $this->result(
            round(with(clone $query)->whereBetween(
                $dateColumn ?? $query->getModel()->getQualifiedCreatedAtColumn(),
                array_map(function ($datetime) {
                    return $this->asQueryDatetime($datetime);
                }, $this->currentRange($request->range, $timezone))
            )
            ->where('bonusable_type', 'App\Models\Product\ProductOrder')
            ->distinct($column)
            ->count(),
             0)
        )->previous($previousValue);
    }

    /**
     * Get the ranges available for the metric.
     *
     * @return array
     */
    public function ranges()
    {
        return [
            1 => 'День',
            7 => 'Неделя',
            30 => 'Месяц',
            365 => 'Год',
            # 50 лет, так как ALL не работал
            18250 => 'Всё время',
            // 'ALL' => 'All Time',
        ];
    }

    /**
     * Get the URI key for the metric.
     *
     * @return string
     */
    public function uriKey()
    {
        return 'statistics-bonus';
    }

    public function name()
    {
        return 'Клиентов с бонусами';
    }
}
