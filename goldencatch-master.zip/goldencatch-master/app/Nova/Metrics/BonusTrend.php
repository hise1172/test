<?php

namespace App\Nova\Metrics;

use App\Models\BonusHistory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Expression;
use Illuminate\Support\Facades\DB;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Metrics\Trend;
use Laravel\Nova\Metrics\TrendDateExpressionFactory;
use Laravel\Nova\Nova;

class BonusTrend extends Trend
{
    /**
     * Calculate the value of the metric.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return mixed
     */
    public function calculate(NovaRequest $request)
    {
        if( 1 == $request->get('range') ){
            // for showing period 24 hours
            $request->merge([
                'range' => 24,
            ]);
            return $this->countByHours($request, BonusHistory::class);
        }
        return $this->countByDays($request, BonusHistory::class);
    }

    protected function aggregate($request, $model, $unit, $function, $column, $dateColumn = null)
    {
        $query = $model instanceof Builder ? $model : (new $model)->newQuery();

        $timezone = Nova::resolveUserTimezone($request) ?? $request->timezone;

        $expression = (string) TrendDateExpressionFactory::make(
            $query, $dateColumn = $dateColumn ?? $query->getModel()->getQualifiedCreatedAtColumn(),
            $unit, $timezone
        );

        $possibleDateResults = $this->getAllPossibleDateResults(
            $startingDate = $this->getAggregateStartingDate($request, $unit, config('app.timezone')),
            $endingDate = now(),
            $unit,
            $timezone,
            $request->twelveHourTime === 'true'
        );

        $wrappedColumn = $column instanceof Expression
                ? (string) $column
                : $query->getQuery()->getGrammar()->wrap($column);


        $results = $query
                ->select(DB::raw("{$expression} as date_result, sum(amount) as aggregate"))
                ->whereBetween(
                    $dateColumn, array_map(function ($date) {
                        return $this->asQueryDatetime($date);
                    }, [$startingDate, $endingDate])
                )
                ->where('bonusable_type', 'App\Models\Product\ProductOrder')
                ->distinct($column)
                ->groupBy(DB::raw($expression))
                ->orderBy('date_result')
                ->get();

        $results = array_merge($possibleDateResults, $results->mapWithKeys(function ($result) use ($request, $unit) {
            return [$this->formatAggregateResultDate(
                $result->date_result, $unit, $request->twelveHourTime === 'true'
            ) => round($result->aggregate, 0)];
        })->all());

        if (count($results) > $request->range) {
            array_shift($results);
        }

        return $this->result()->trend(
            $results
        );
    }

    /**
     * Get the ranges available for the metric.
     *
     * @return array
     */
    public function ranges()
    {
        return [
            1 => 'День',
            7 => 'Неделя',
            30 => 'Месяц',
            365 => 'Год',
            // 10 лет, так как завсё время нет параметра
            3650 => 'Всё время',
        ];
    }

    /**
     * Get the URI key for the metric.
     *
     * @return string
     */
    public function uriKey()
    {
        return 'bonus-trend';
    }

    public function name()
    {
        return 'Накоплено бонусов';
    }
}
