<?php

namespace App\Nova\Metrics;

use App\Models\BonusHistory;
use Carbon\Carbon;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Metrics\Partition;

class BonusPartition extends Partition
{
    /**
     * Calculate the value of the metric.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return mixed
     */
    public function calculate(NovaRequest $request)
    {
        return $this->result([
            'Новые' => $this->getNewBonuses(),
            'Потратят' => $this->getFeatureBonuses(),
            'Потраченные' => $this->getSpendedBonuses(),
        ])->colors(
            [
                'yellow',
                'green',
                'blue',
            ]
        );

        return $this->count($request, BonusHistory::class, 'amount');
    }

    public function getNewBonuses()
    {
        return BonusHistory::
            where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('bonusable_type', 'App\Models\Product\ProductOrder')
            ->where('created_at', '>', Carbon::now()->subDays(14)->toDateTimeString())
            ->sum('amount');
    }

    public function getFeatureBonuses()
    {
        return BonusHistory::
            where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('bonusable_type', 'App\Models\Product\ProductOrder')
            ->where('created_at', '<', Carbon::now()->subDays(14)->toDateTimeString())
            ->sum('amount');
    }

    public function getSpendedBonuses()
    {
        return BonusHistory::
            where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('bonusable_type', 'App\Models\Order')
            ->sum('amount');
    }

    /**
     * Get the URI key for the metric.
     *
     * @return string
     */
    public function uriKey()
    {
        return 'bonus-partition';
    }

    public function name()
    {
        return 'Общее количество бонусов';
    }
}
