<?php

namespace App\Nova\Flexible;

use App\Nova\Flexible\Layout\UniqueLayout;
use Whitecube\NovaFlexibleContent\Flexible;

class UniqueFieldsList extends Flexible
{
    /**
     * @inheritDoc
     */
    public function addLayout(...$arguments)
    {
        $count = count($arguments);

        if($count > 1) {
            $this->registerLayout(new UniqueLayout(...$arguments));
            return $this;
        }

        return parent::addLayout(...$arguments);
    }
}
