<?php

namespace App\Nova\Flexible\Layout;

use Whitecube\NovaFlexibleContent\Layouts\Layout;

class UniqueLayout extends Layout
{
    protected $limit = 1;
}
