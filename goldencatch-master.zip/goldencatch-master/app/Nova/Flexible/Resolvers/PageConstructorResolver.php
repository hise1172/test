<?php

namespace App\Nova\Flexible\Resolvers;

use App\Libs\PageConstructor;
use App\Libs\PageConstructor\Block;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Whitecube\NovaFlexibleContent\Layouts\Layout;
use Whitecube\NovaFlexibleContent\Value\ResolverInterface;

class PageConstructorResolver implements ResolverInterface
{
    private ?PageConstructor\Interfaces\PageBlocksInterface $landing_page = null;

    #region Actions

    /**
     * Set the field's value
     *
     * @param  Model|PageConstructor\Interfaces\PageBlocksInterface  $model
     * @param  string $attribute
     * @param  Collection|Layout[] $groups
     * @return string
     */
    public function set($model, $attribute, $groups)
    {
        $this->landing_page = $model;
        $blocks = collect();
        $processed_blocks = [];

        foreach ($groups ?? [] as $item) {
            $processed_blocks[] = $block = BlockFields::factory($item->name())
                ->import($item->getAttributes());

            $blocks->add(
                PageConstructor\Block::factory($block->getType(), $block->getPropertiesValues())
                    ->validated()
            );
        }

        $this->landing_page->save();
        $this->landing_page->saveBlocks($blocks);

        foreach ($processed_blocks as $block) {
            $block->afterSave();
        }

        return  $groups;
    }

    /**
     * Gets a field's value
     *
     * @param  Model|PageConstructor\Interfaces\PageBlocksInterface $langing
     * @param  string $attribute
     * @param  \Whitecube\NovaFlexibleContent\Layouts\Collection|Layout[] $layouts
     * @return Collection
     */
    public function get($langing, $attribute, $layouts)
    {
        $result = collect();

        foreach ($langing->getBlocks() as $block) {
            $layout = $layouts->find($block->getType());

            if(!$layout) {
                continue;
            }

            $result->add($this->getFieldValue($block, $layout));
        }

        return $result;
    }

    #endregino

    #region Helpers

    /**
     * @param Block $block
     * @param Layout $layout
     *
     * @return Layout
     */
    private function getFieldValue(Block $block, Layout $layout)
    {
        $return_fields = [];

        $required_fields = BlockFields::factory($block->getType())::getRequiredFields();

        foreach ($layout->fields() as $field) {
            $field = clone $field;

            // Find Layout field details
            foreach ($required_fields as $required_field) {
                if (!$required_field->hasLayoutField($field)) {
                    continue;
                }

                if ($required_field->isMeta() || BasicFieldValue::isMetaComponent($field)) {
                    $return_fields[] = $field;

                    break;
                }

                $required_field->resolveLayoutField($field, $block);

                $return_fields[$field->attribute] = $field;

                break;
            }
        }

        return new Layout(
            $layout->title(),
            $layout->name(),
            array_values($return_fields),
            $layout->key(),
            $layout->getAttributes()
        );
    }

    #endregion
}
