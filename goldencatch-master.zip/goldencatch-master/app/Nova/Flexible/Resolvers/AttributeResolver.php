<?php

namespace App\Nova\Flexible\Resolvers;

use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Product\Product;
use App\Models\ProductsAttributesNumericValues;
use App\Models\ProductsAttributesTextValues;
use Illuminate\Support\Collection;
use Outl1ne\MultiselectField\Multiselect;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Layouts\Layout;
use Whitecube\NovaFlexibleContent\Value\ResolverInterface;
use Whitecube\NovaFlexibleContent\Layouts;

class AttributeResolver implements ResolverInterface
{
    #region Setters

    /**
     * Set the field's value
     *
     * @param  Product $product
     * @param  string $attribute
     * @param  Collection $groups
     * @return string
     */
    public function set($product, $attribute, $groups)
    {
        $collection = collect();

        $attr_list = Attribute::getAll();

        foreach ($groups as $item) {
            /** @var Attribute $descAttr */
            $descAttr = $attr_list
                ->map(function (Attribute $attr) use ($item) {
                    return $attr->id == $item->name()
                        ? $attr
                        : false;
                })
                ->reject(fn ($name) => empty($name))
                ->first();

            /** @var Layouts\Layout $item */
            $value = $item->attributesToArray();

            switch ($descAttr->filter_type) {
                case Attribute::TYPE_SLUG:
                    $value = array_shift($value);
                    $value = json_decode($value, true);
                    break;

                case Attribute::TYPE_NUMERIC:
                    $multiplaxer = '1';

                    for ($i = 0; $i < ProductsAttributesNumericValues::DECIMAL_PLACES; $i++) {
                        $multiplaxer .= '0';
                    }

                    $value = round(array_shift($value) * $multiplaxer) / $multiplaxer;

                    break;
            }

            $collection->add([
                'id' => $item->name(),
                'value' => $value,
            ]);
        }

        $product->all_attributes = $collection;

        return $groups;
    }

    #endregion

    #region Getters

    /**
     * get the field's value
     *
     * @param  Product $product
     * @param  string $attribute
     * @param  Layouts\Collection $layouts
     * @return Collection
     */
    public function get($product, $attribute, $layouts)
    {
        $result = collect();

        foreach ($product->getAllAttributesAttribute(true) as $attr_data) {
            /** @var Attribute $parent */
            $parent = $attr_data['parent'];

            /** @var Layout $layout */
            $layout = $layouts->find($parent->id);

            if(!$layout) {
                continue;
            }

            $layouts_collection = collect();

            switch ($parent->filter_type) {
                case Attribute::TYPE_SLUG:
                    $values = [];

                    foreach ($attr_data['children'] as $attr) {
                        /** @var AttributeSlugValue $attr */
                        $values[] = $attr->id;
                    }

                    $layouts_collection->add($this->collectMultiField($values, $layout));

                    break;

                case Attribute::TYPE_NUMERIC:
                case Attribute::TYPE_TEXT:
                    $layouts_collection = collect();

                    foreach ($attr_data['children'] as $attr) {
                        /** @var ProductsAttributesNumericValues|ProductsAttributesTextValues $attr */
                        $layouts_collection->add($this->collectSingleField($attr, $layout));
                    }

                    break;
            }

            $result = $result->isEmpty()
                ? $layouts_collection
                : $result->merge($layouts_collection);
        }

        return $result;
    }

    #endregion

    #region Helpers

    /**
     * @param ProductsAttributesNumericValues|ProductsAttributesTextValues $attr
     * @param Layout $layout
     *
     * @return Layout
     */
    private function collectSingleField($attr, Layout $layout)
    {
        $return_fields = [];

        foreach ($layout->fields() as $field) {
            switch (get_class($field)) {
                case Number::class:
                    $multiplaxer = '1';

                    for ($i = 0; $i < ProductsAttributesNumericValues::DECIMAL_PLACES; $i++) {
                        $multiplaxer .= '0';
                    }

                    /** @var Number $field */
                    $return_fields[$field->attribute] = $field
                        ->resolveUsing(function ($value) use ($attr, $multiplaxer) {
                            return round($attr->value * $multiplaxer) / $multiplaxer;
                        });

                    break;

                case Text::class:
                    /** @var Text $field */
                    $return_fields[$field->attribute] = $field
                        ->resolveUsing(function () use ($attr, $field) {
                            return $attr->getTranslation('value', $field->attribute);
                        });

                    break;
            }
        }

        return new Layout(
            $layout->title(),
            $layout->name(),
            array_values($return_fields),
            $layout->key(),
            $layout->getAttributes()
        );
    }

    /**
     * @param array $values
     * @param Layout $layout
     *
     * @return Layout
     */
    private function collectMultiField(array $values, Layout $layout)
    {
        $return_fields = [];

        foreach ($layout->fields() as $field) {
            switch (get_class($field)) {
                case Multiselect::class:

                    $result = [];

                    /** @var Multiselect $field */
                    foreach ($field->meta['options'] ?? [] as $item) {
                        if (!in_array($item['value'], $values)) {
                            continue;
                        }

                        $result[] = $item['value'];
                    }

                    $field->resolveCallback = function () use ($result) {
                        return $result;
                    };

                    $return_fields[$field->attribute] = $field;

                    break;
            }
        }

        return new Layout(
            $layout->title(),
            $layout->name(),
            array_values($return_fields),
            $layout->key(),
            $layout->getAttributes()
        );
    }

    #endregion
}
