<?php

namespace App\Nova\Field;

use App\Libs\PageConstructor;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Flexible\Resolvers\PageConstructorResolver;
use Laravel\Nova\Fields\Field;
use Laravel\Nova\Panel;
use Whitecube\NovaFlexibleContent\Flexible;

class PageConstructorField extends Field
{
    #region Actions

    /**
     * Returns the necessary fields
     *
     * @param PageConstructor\Interfaces\PageBlocksInterface $model
     *
     * @return Panel
     * @throws \Exception
     */
    public function render(string $model)
    {
        return new Panel($this->name, [
            $this->getBlocksSelector($model)
        ]);
    }

    #endregion

    #regino Getters

    /**
     * @param PageConstructor\Interfaces\PageBlocksInterface $model
     *
     * @return mixed
     * @throws \Exception
     */
    private function getBlocksSelector(string $model)
    {
        $field = Flexible::make('Блоки', 'block_layouts_selector')
            ->resolver(PageConstructorResolver::class)
            ->required()
            ->menu('flexible-search-menu', [
                'selectLabel' => 'Press enter to select',
            ])
            ->button('Добавить блок')
            ->collapsed()
            ->fullWidth();

        foreach (BlockFields::getAllowedBlocks() as $block_type => $name) {
            if (!in_array($block_type, $model::getAllowedBlocks())) {
                continue;
            }

            $temp_fields = [];

            foreach (BlockFields::factory($block_type)::getRequiredFields() as $property) {
                $property->collectSubFields($temp_fields);
            }

            $field->addLayout($name, $block_type, $temp_fields);
        }

        return $field;
    }

    #endregion

}
