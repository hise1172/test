<?php

namespace App\Nova\Field;

use App\Models;
use App\Models\ProductsAttributesNumericValues;
use App\Nova\Flexible\UniqueFieldsList;
use App\Nova\Flexible\Resolvers\AttributeResolver;
use Laravel\Nova\Fields\Field;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Text;
use Outl1ne\MultiselectField\Multiselect;
use Whitecube\NovaFlexibleContent\Flexible;

class Attribute extends Field
{
    #region Actions

    /**
     * Returns the necessary fields
     *
     * @return Flexible
     */
    public function render()
    {
        $field = UniqueFieldsList::make($this->name)
            ->resolver(AttributeResolver::class)
            // ->menu('flexible-search-menu', [
            //     'selectLabel' => 'Press enter to select',
            // ])
            ->button('Add attribute');

        $descAttrs = Models\Attribute::getAll();

        foreach ($descAttrs as $descAttr) {
            /** @var Models\Attribute $descAttr */
            switch ($descAttr->filter_type) {
                case Models\Attribute::TYPE_SLUG:
                    self::collectSlugAttributes($field, $descAttr);
                    break;

                case Models\Attribute::TYPE_NUMERIC:
                    self::collectNumericAttributes($field, $descAttr);
                    break;

                case Models\Attribute::TYPE_TEXT:
                    self::collectTextAttributes($field, $descAttr);
                    break;
            }
        }

        return $field;
    }

    #endregion

    #region Helpers

    /**
     * @param Flexible $field
     * @param string $attribute
     *
     * @throws \Exception
     */
    private static function collectSlugAttributes(Flexible $field, Models\Attribute $attribute)
    {
        $options = [];

        foreach (Models\AttributeSlugValue::where('attribute_id', $attribute->id)->get() as $attr) {
            /** @var Models\AttributeSlugValue $attr */
            $options[$attr->id] = $attr->value;
        }

        if (!$options) {
            return;
        }

        $field->addLayout($attribute->system_name, $attribute->id, [
            Multiselect::make($attribute->system_name, $attribute->filter_slug)
                ->options($options),
        ]);
    }

    /**
     * @param Flexible $field
     * @param string $name
     *
     * @throws \Exception
     */
    private static function collectNumericAttributes(Flexible $field, Models\Attribute $attribute)
    {
        $multiplaxer = '0.';

        for ($i = 0; $i < ProductsAttributesNumericValues::DECIMAL_PLACES - 1 ; $i++) {
            $multiplaxer .= '0';
        }

        $field->addLayout($attribute->system_name, $attribute->id, [
            Number::make($attribute->system_name)
                ->step($multiplaxer . 1),
        ]);
    }

    /**
     * @param Flexible $field
     * @param string $name
     */
    private static function collectTextAttributes(Flexible $field, Models\Attribute $attribute)
    {
        $field->addLayout($attribute->system_name, $attribute->id, [
            Text::make('RU'),
            Text::make('UA'),
        ]);
    }

    #endregion
}
