<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor;
use App\Libs\PageConstructor\Block;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;

class WideYoutubeFields extends BlockFields
{
    #region Updates methods

    #ebdregion

    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        return collect([
            'youtube_url' => BasicFieldValue::build('URL', 'youtube_url')
                ->required()
                ->fieldType(BasicFieldValue::TYPE_TEXT)
        ]);
    }

    #endregion
}
