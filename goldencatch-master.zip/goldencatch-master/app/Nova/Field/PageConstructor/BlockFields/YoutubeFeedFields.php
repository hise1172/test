<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;

class YoutubeFeedFields extends BlockFields
{
    #region Updates methods

    #ebdregion

    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        for ($i = 0; $i < PageConstructor\Block\YoutubeFeed::COUNT; $i ++) {
            $fields_list[] = BasicFieldValue::build('Video ' . ($i + 1))
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'video_title_' . $i;

            $fields_list[$key] = TranslatableFieldValue::build('Title', $key)
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'video_date_' . $i;

            $fields_list[$key] = BasicFieldValue::build('Date', $key)
                ->fieldType(BasicFieldValue::TYPE_DATE);

            $key = 'video_url_' . $i;

            $fields_list[$key] = BasicFieldValue::build('URL', $key)
                ->fieldType(BasicFieldValue::TYPE_TEXT);
        }

        return $fields_list;
    }

    #endregion
}
