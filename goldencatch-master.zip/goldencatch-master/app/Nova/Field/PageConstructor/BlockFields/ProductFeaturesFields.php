<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use Illuminate\Support\Collection;

class ProductFeaturesFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        $fields_list[] = BasicFieldValue::build('Заголовки')
            ->fieldType(BasicFieldValue::TYPE_HEADING);

        $fields_list['header'] = TranslatableFieldValue::build('Заголовок', 'header')
            ->required()
            ->fieldType(BasicFieldValue::TYPE_TEXT);

        $fields_list['subheader'] = TranslatableFieldValue::build('Подзаголовок', 'subheader')
            ->required()
            ->fieldType(BasicFieldValue::TYPE_TEXT);

        for ($i = 0; $i < PageConstructor\Block\ProductFeatures::COUNT; $i ++) {
            $fields_list[] = BasicFieldValue::build('Особенность ' . ($i + 1))
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'feature_title_' . $i;

            $fields_list[$key] = TranslatableFieldValue::build('Заголовок', $key)
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'feature_description_' . $i;

            $fields_list[$key] = TranslatableFieldValue::build('Описание', $key)
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'feature_image_' . $i;

            $fields_list[$key] = ImageFieldValue::build('Изображение', $key);
        }

        return $fields_list;
    }

    #endregion
}
