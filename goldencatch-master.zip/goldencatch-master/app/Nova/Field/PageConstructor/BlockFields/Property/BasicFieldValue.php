<?php

namespace App\Nova\Field\PageConstructor\BlockFields\Property;

use App\DataContainers\AbstractDataContainer;
use App\Libs\PageConstructor\Block;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\Currency;
use Laravel\Nova\Fields\Date;
use Laravel\Nova\Fields\Field;
use Laravel\Nova\Fields\Heading;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;

class BasicFieldValue extends AbstractDataContainer
{
    const META_KEY_PREF = 'is_meta.';
    const HIDDEN_KEY_PREF = 'is_hidden.';

    /**
     * @var callable
     * function (Field $field) {}
     */
    protected $setup;
    protected bool $required = false;
    protected bool $make_heading = false;

    // Simple field types
    const TYPE_TEXT = 'Text';
    const TYPE_TEXTAREA = 'Textarea';
    const TYPE_CURRENCY = 'Currency';
    const TYPE_DATE = 'Date';
    const TYPE_SELECT = 'Select';
    const TYPE_HEADING = 'Heading';

    // Special field types
    const TYPE_MULTI_SELECT = 'MultiSelect';
    const TYPE_IMAGE = 'Image';
    const TYPE_URL = 'URL';

    #region Builders

    /**
     * @param string $name
     * @param string $key
     *
     * @return static
     */
    public static function build(string $name, string $key = null)
    {
        return static::make([
                'name' => $name,
                'key' => $key,
            ])
            ->afterInit();
    }

    #endregion

    #regino Actions

    /**
     * @return $this
     */
    protected function afterInit(): self
    {
        return $this;
    }

    #endregion

    #region Actions

    /**
     * @return $this
     */
    public function afterSave()
    {
        return $this;
    }

    #endregion

    #region Is Condition methods

    /**
     * Meta field does not have a value. E.g. it's information block or header
     *
     * @param string $type
     *
     * @return bool
     */
    public static function isMetaFieldKey(string $field_key): bool
    {
        return substr($field_key, 0, 8) === self::META_KEY_PREF;
    }

    /**
     * @see static::isMetaFieldKey()
     */
    public function isMeta(): bool
    {
        return $this->is_meta || static::isMetaFieldKey($this->getKey());
    }

    /**
     * @param string $type
     *
     * @return bool
     */
    public static function isHiddenFieldKey(string $field_key): bool
    {
        return substr($field_key, 0, 10) === self::HIDDEN_KEY_PREF;
    }

    /**
     * @see static::isHiddenComponent()
     */
    public function isHidden(): bool
    {
        return static::isHiddenFieldKey($this->getKey());
    }

    /**
     * @param $layout_field
     *
     * @return bool
     */
    public static function isMetaComponent($layout_field): bool
    {
        return $layout_field instanceof Field
            && static::isMetaFieldKey($layout_field->attribute);
    }

    /**
     * @param $layout_field
     *
     * @return bool
     */
    public static function isHiddenComponent($layout_field): bool
    {
        return $layout_field instanceof Field
            && static::isHiddenFieldKey($layout_field->attribute);
    }

    /**
     * @param Field $field
     *
     * @return bool
     */
    public function hasLayoutField(Field $field): bool
    {
        if (static::isMetaComponent($field)) {
            return true;
        }

        $field_details = $this->getFieldToPropertyMapping();

        $origin_key = static::isHiddenComponent($field)
            ? static::getKeyFromHidden($field->attribute)
            : $field->attribute;

        return isset($field_details[$origin_key]);
    }

    /**
     * @return bool
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    #endregion

    #region Setters

    /**
     * @param string $field_type
     *
     * @return $this
     */
    public function fieldType(string $field_type)
    {
        $this->type = $field_type;

        if ($field_type === static::TYPE_HEADING) {
            $this->itMeta();
        }

        return $this;
    }

    /**
     * The statement calls to add some settings to Nova field
     *
     * @param \Closure $settings
     * function (Field $field) {}
     */
    public function setup(\Closure $settings)
    {
        $this->setup = $settings;

        return $this;
    }

    /**
     * @return $this
     */
    public function required()
    {
        $this->required = true;

        return $this;
    }

    /**
     * @return $this
     */
    public function makeHeading()
    {
        $this->make_heading = true;

        return $this;
    }

    /**
     * @return $this
     */
    public function itMeta()
    {
        $this->is_meta = true;

        $this->key = strpos($this->key, self::META_KEY_PREF) === false
            ? self::META_KEY_PREF . $this->key
            : $this->key;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name ?: '';
    }

    /**
     * @return string
     */
    public function getKey()
    {
        return $this->key ?: '';
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->type ?: '';
    }

    /**
     * @param string $field_type
     *
     * @return Field
     */
    protected function getField(): string
    {
        switch ($this->type) {
            case static::TYPE_TEXT:
                return Text::class;

            case static::TYPE_TEXTAREA:
                return Textarea::class;

            case static::TYPE_CURRENCY:
                return Currency::class;

            case static::TYPE_DATE:
                return Date::class;

            case static::TYPE_SELECT:
                return Select::class;

            case static::TYPE_HEADING:
                return Heading::class;

            default:
                throw new \InvalidArgumentException('The property does not implement: `' . $this->type . '`');
        }
    }

    /**
     * @param bool $collect_meta
     *
     * @return array
     * [
     *      field_key => [
     *          'property_name' => string,
     *          'component' => string,
     *      ],
     *      ...
     * ]
     */
    public function getFieldToPropertyMapping($collect_meta = true): array
    {
        $result
            = $fields_list
            = [];

        $this->collectSubFields($fields_list);

        foreach ($fields_list as $field) {
            if (static::isMetaComponent($field)) {
                if (!$collect_meta) {
                    continue;
                }

                $result[] = [
                    'property_name' => '',
                    'component' => $field->component,
                ];

                continue;
            }

            $result[$field->attribute] = [
                'property_name' => $field->attribute,
                'component' => $field->component,
            ];
        }

        return $result;
    }

    /**
     * @param $hidden_field
     *
     * @return string
     */
    protected static function getKeyFromMeta(string $field_key): string
    {
        if (substr($field_key, 0, 8) === self::META_KEY_PREF) {
            throw new \InvalidArgumentException('Passed field has to be hidden');
        }

        return substr($field_key, 0, 8);
    }

    /**
     * @param $hidden_field
     *
     * @return string
     */
    protected static function getKeyFromHidden(string $field_key): string
    {
        if (!static::isHiddenFieldKey($field_key)) {
            throw new \InvalidArgumentException('Passed field has to be hidden');
        }

        return substr($field_key, 10);
    }

    /**
     * @param $filed_value
     *
     * @return Heading
     */
    protected static function getMetaField($filed_value)
    {
        $meta = Heading::make($filed_value->getName());
        $meta->attribute = static::META_KEY_PREF . $filed_value->getKey();

        return $meta;
    }

    /**
     * @param array $field_details
     * @param string $field
     * @param Block $block
     *
     * @return mixed|string|null
     */
    protected function getValueForResolving(array $field_details, Field $field, Block $block)
    {
        if (!isset($field_details[$field->attribute])) {
            throw new \InvalidArgumentException('Tries to resolve wrong layout field');
        }

        $field_details = $field_details[$field->attribute];

        return $block->getPropertyRealValue($field_details['property_name']) ?: '';
    }

    #endregion

    #region Helpers

    /**
     * A field value could be complicated and requires a few inputs or other fields.
     * E.g. translatable field includes a field for each locale
     *
     * @param array|Field[] $fields_list
     * @param bool $collect_meta // should the method pass a field meta fields or not
     */
    public function collectSubFields(array &$fields_list, bool $collect_meta = true): self
    {
        if ($this->make_heading && $collect_meta) {
            $fields_list[] = static::getMetaField($this);
        }

        $field_class = $this->getField();

         $filed = $field_class::make($this->getName(), $this->getKey());

        $this->collectFieldSettings($filed);

        $fields_list[] = $filed;

        return $this;
    }

    /**
     * Collects a data to save it into DB
     *
     * @param Collection $collection
     * @param array $field_values
     */
    public function addPropertyValueToCollection(Collection $collection, array $field_values): self
    {
        if ($this->isMeta()) {
            return $this;
        }

        foreach ($this->getFieldToPropertyMapping(false) as $field_key => $value) {
            $collection->put($value['property_name'], $field_values[$field_key]);
        }

        return $this;
    }

    /**
     * @param Field $field
     * @param Block $block
     *
     * @return $this
     */
    public function resolveLayoutField(Field $field, Block $block)
    {
        if ($this->isMeta() || static::isMetaComponent($field)) {
            return $this;
        }

        $value = $this->getValueForResolving($this->getFieldToPropertyMapping(), $field, $block);

        if ($value === null) {
            return $this;
        }

        $field->resolveUsing(function () use ($value) {
            return $value;
        });

        return $this;
    }

    /**
     * @param Field $filed
     */
    protected function collectFieldSettings(Field $filed)
    {
        if ($this->required) {
            $filed->required();
        }

        if ($this->setup) {
            $setup = $this->setup;

            $setup($filed);
        }
    }

    #endregion
}
