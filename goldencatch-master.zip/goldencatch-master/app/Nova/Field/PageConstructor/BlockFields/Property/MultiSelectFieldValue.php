<?php

namespace App\Nova\Field\PageConstructor\BlockFields\Property;

use App\Libs\PageConstructor\Block;
use Laravel\Nova\Fields\Field;
use Outl1ne\MultiselectField\Multiselect;

class MultiSelectFieldValue extends BasicFieldValue
{
    #regino Actions

    /**
     * @return $this
     */
    protected function afterInit(): self
    {
        $this->type = static::TYPE_MULTI_SELECT;

        return $this;
    }

    #endregion

    #region Setters

    /**
     * @deprecated The method execution has no effect
     * @see afterInit()
     *
     * @inheritDoc
     */
    public function fieldType(string $field_type)
    {
        throw new \BadMethodCallException('The method execution has no effect');
    }

    #endregion

    #region Getters

    /**
     * @inheritDoc
     */
    protected function getValueForResolving(array $field_details, Field $field, Block $block)
    {
        if (!isset($field_details[$field->attribute])) {
            throw new \InvalidArgumentException('Tries to resolve wrong layout field');
        }

        $values = json_decode($block->getPropertyRealValue($field->attribute));
        $result = [];

        /** @var Multiselect $field */
        foreach ($field->meta['options'] ?? [] as $item) {
            if (!in_array($item['value'], $values)) {
                continue;
            }

            $result[] = $item['value'];
        }

        $field->resolveCallback = function () use ($result) {
            return $result;
        };

        return null;
    }

    #endregion

    #region Helpers

    /**
     * @param array $fields_list
     */
    public function collectSubFields(array &$fields_list, $collect_meta = true): self
    {
        if ($this->make_heading && $collect_meta) {
            $fields_list[] = static::getMetaField($this);
        }

        $field = Multiselect::make($this->getName(), $this->getKey());

        $this->collectFieldSettings($field);

        $fields_list[] = $field;

        return $this;
    }

    #endregion
}
