<?php

namespace App\Nova\Field\PageConstructor\BlockFields\Property;

use Laravel\Nova\Fields\Text;

class UrlFieldValue extends BasicFieldValue
{
    #region Actions

    /**
     * @inheritDoc
     */
    protected function afterInit(): self
    {
        $this->type = ImageFieldValue::TYPE_URL;

        return $this;
    }

    #endregion

    #region Setters

    /**
     * @deprecated The method execution has no effect
     * @see afterInit()
     *
     * @inheritDoc
     */
    public function fieldType(string $field_type)
    {
        throw new \BadMethodCallException('The method execution has no effect');
    }

    #endregion

    #region Getters

    /**
     * @inheritDoc
     */
    protected function getField(): string
    {
        return Text::class;
    }

    #endregion
}
