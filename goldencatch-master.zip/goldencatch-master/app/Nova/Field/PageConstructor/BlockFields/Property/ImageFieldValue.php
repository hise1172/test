<?php

namespace App\Nova\Field\PageConstructor\BlockFields\Property;

use App\Libs\PageConstructor\Block;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;
use Laravel\Nova\Fields\Field;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Text;

class ImageFieldValue extends BasicFieldValue
{
    const DISC = 'landings';

    private string $old_image = '';

    #region Actions

    /**
     * @inheritDoc
     */
    protected function afterInit(): self
    {
        $this->type = ImageFieldValue::TYPE_IMAGE;

        return $this;
    }

    /**
     * @return $this
     */
    public function afterSave()
    {
        parent::afterSave();

        if (!$this->old_image) {
            return $this;
        }

        Storage::disk(static::DISC)
            ->delete($this->old_image);

        return $this;
    }

    #endregion

    #region Setters

    /**
     * @deprecated The method execution has no effect
     * @see afterInit()
     *
     * @inheritDoc
     */
    public function fieldType(string $field_type)
    {
        throw new \BadMethodCallException('The method execution has no effect');
    }

    #endregion

    #region Getters

    /**
     * @param string $file_name
     *
     * @return string
     */
    public function getURL(string $file_name): string
    {
        return Storage::disk(static::DISC)->url($file_name);
    }

    #endregion

    #region Helpers

    /**
     * @param array $fields_list
     */
    public function collectSubFields(array &$fields_list, $collect_meta = true): self
    {
        if ($this->make_heading && $collect_meta) {
            $fields_list[] = static::getMetaField($this);
        }

        $image_field = Image::make($this->getName(), $this->getKey())
            ->disk(static::DISC)
            ->deletable(false)
            ->preview(function ($value) {
                return Storage::disk(static::DISC)->url($value);
            });

        $this->collectFieldSettings($image_field);

        $fields_list[] = $image_field;
        $fields_list[] = Text::make('', static::HIDDEN_KEY_PREF . $this->getKey())
            ->withMeta(['type' => 'hidden']);

        return $this;
    }

    /**
     * Collects a data to save it into DB
     *
     * @param Collection $collection
     * @param array $field_values
     */
    public function addPropertyValueToCollection(Collection $collection, array $field_values): self
    {
        if ($this->isMeta()) {
            return $this;
        }

        $result = [];

        foreach ($this->getFieldToPropertyMapping(false) as $field_key => $value) {
            if (static::isHiddenFieldKey($field_key)) {
                if (isset($field_values[static::getKeyFromHidden($field_key)])) {
                    $this->old_image = $field_values[$field_key] ?? '';
                }

                continue;
            }

            $result[$value['property_name']] = $field_values[$field_key] ?? $field_values[static::HIDDEN_KEY_PREF . $field_key];
        }

        foreach ($result as $field_key => $value) {
            $collection->put($field_key, $value);
        }

        return $this;
    }

    /**
     * @inheritDoc
     */
    protected function getValueForResolving(array $field_details, Field $field, Block $block)
    {
        $origin_key = static::isHiddenFieldKey($field->attribute)
            ? static::getKeyFromHidden($field->attribute)
            : $field->attribute;

        if (!isset($field_details[$origin_key])) {
            throw new \InvalidArgumentException('Tries to resolve wrong layout field');
        }

        $field_details = $field_details[$origin_key];

        return $block->getPropertyRealValue($field_details['property_name']) ?: '';
    }

    #endregion
}
