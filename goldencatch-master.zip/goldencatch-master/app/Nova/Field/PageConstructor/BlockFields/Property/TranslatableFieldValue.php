<?php

namespace App\Nova\Field\PageConstructor\BlockFields\Property;

use App\Libs\PageConstructor\Block;
use App\Models\Translate;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\Field;

class TranslatableFieldValue extends BasicFieldValue
{
    private static $locales_list = [
        Translate::RU,
        Translate::UA,
    ];

    /**
     * @param bool $get_meta_fields
     *
     * @return array
     * [
     *      field_key => [
     *          'property_name' => string,
     *          'locale' => string,
     *      ],
     *      ...
     * ]
     */
    public function getFieldToPropertyMapping($get_meta_fields = true) : array
    {
        $result
            = $fields_list
            = [];

        $this->collectSubFields($fields_list, $get_meta_fields);

        foreach ($fields_list as $field) {
            if (static::isMetaComponent($field)) {
                $result[] = [
                    'property_name' => '',
                    'component' => $field->component,
                    'locale' => '',
                ];

                continue;
            }

            [$property_name, $locale] = explode('.', $field->attribute, 2);

            $result[$field->attribute] = [
                'property_name' => $property_name,
                'component' => $field->component,
                'locale' => $locale,
            ];
        }

        return $result;
    }

    #region Helpers

    /**
     * @param array $fields_list
     */
    public function collectSubFields(array &$fields_list, $collect_meta = true): self
    {
        if ($this->make_heading && $collect_meta) {
            $fields_list[] = static::getMetaField($this);
        }

        foreach (static::$locales_list as $locale) {
            $field = $this->getField()::make(
                $this->make_heading ? strtoupper($locale) : $this->getName() . ' (' . strtoupper($locale) . ')',
                    $this->getKey() . '.' . $locale
                )
                ->placeholder($this->getName() . ' (' . strtoupper($locale) . ')');

            $this->collectFieldSettings($field);

            $fields_list[] = $field;
        }

        return $this;
    }

    /**
     * Collects a data to save it into DB
     *
     * @param Collection $collection
     * @param array $field_values
     */
    public function addPropertyValueToCollection(Collection $collection, array $field_values): self
    {
        $result = [];

        foreach ($this->getFieldToPropertyMapping(false) as $field_key => $value) {
            $result[$value['property_name']][$value['locale']] = $field_values[$field_key];
        }

        foreach ($result as $field_key => $value) {
            $collection->put($field_key, $value);
        }

        return $this;
    }

    /**
     * @inheritDoc
     */
    protected function getValueForResolving(array $field_details, Field $field, Block $block)
    {
        if (!isset($field_details[$field->attribute])) {
            throw new \InvalidArgumentException('Tries to resolve wrong layout field');
        }

        $field_details = $field_details[$field->attribute];

        return $block->getPropertyRealValue($field_details['property_name'])
            ? $block->getPropertyRealValue($field_details['property_name'])[$field_details['locale']]
            : '';
    }

    #endregion
}
