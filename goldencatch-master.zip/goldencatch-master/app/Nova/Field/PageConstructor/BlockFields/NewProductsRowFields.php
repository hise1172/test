<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Nova\Field\PageConstructor\BlockFields\Property\MultiSelectFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Repositories\ProductRepository;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Outl1ne\MultiselectField\Multiselect;

class NewProductsRowFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $field_key = 'taxonomies_data';

        $options_list = static::getOptionsList();

        return collect([
            $field_key => MultiSelectFieldValue::build('Лента новинок', $field_key)
                ->required()
                ->setup(function (Multiselect $field) use ($options_list) {
                    $field->options($options_list);
                }),
        ]);
    }

    /**
     * @return array
     */
    protected static function getOptionsList(): array
    {
        $options_list = Cache::get(static::class, []);

         if ($options_list) {
             return $options_list;
         }

        foreach (Brand::all() as $attr) {
            /** @var Brand $attr */
            $options_list[ProductRepository::TAXONOMY_BRAND . '.' . $attr->id] = $attr->name . ' (Brand)';
        }

        $attribute_slug_values = AttributeSlugValue::all();
        $attribute_types = Attribute::all();

        foreach ($attribute_slug_values as $attr) {
            /** @var AttributeSlugValue $attr */
            /** @var Attribute $attribute_type */
            $attribute_type = $attribute_types
                ->where('id', $attr->attribute_id)
                ->first();

            $options_list[ProductRepository::TAXONOMY_ATTR_SLUG_VALUE . '.' . $attr->id] = $attr->value . " - {$attribute_type->system_name} (Аттрибут)";
        }

        $options_list
            && Cache::put(static::class, $options_list, 3600); // An hour

        return $options_list;
    }

    #endregion
}
