<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\UrlFieldValue;

use Illuminate\Support\Collection;

/**
 * @property array $field_values
 * [
 *      desktop_image_ru => file,
 *      desktop_image_ua => file,
 *
 *      mobile_image_ru => file,
 *      mobile_image_ua => file,
 *
 *      url_ru => string,
 *      url_ua => string,
 * ]
 */
class ThreeBannersFields extends BlockFields
{
    #region Updates methods

    #ebdregion

    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        for ($i = 0; $i < PageConstructor\Block\ThreeBanners::COUNT; $i ++) {

            $fields_list[] = BasicFieldValue::build('Баннер ' . ($i + 1))
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'banner_title_' . $i;

            $fields_list[$key] = TranslatableFieldValue::build('Title', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'banner_url_' . $i;

            $fields_list[$key] = UrlFieldValue::build('Ссылка', $key);

            $key = 'banner_image_' . $i;

            $fields_list[$key] = ImageFieldValue::build('Изображение', $key)
                ->required();

        }

        return $fields_list;
    }

    #endregion
}
