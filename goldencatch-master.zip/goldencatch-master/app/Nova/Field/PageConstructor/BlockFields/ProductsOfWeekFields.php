<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor\Block\ProductsOfWeek;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\UrlFieldValue;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\Currency;
use Laravel\Nova\Fields\Select;

class ProductsOfWeekFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        for ($i = 0; $i < ProductsOfWeek::COUNT; $i ++) {

            $fields_list[] = BasicFieldValue::build('Товар ' . ($i + 1))
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'product_'  . $i . '_title';

            $fields_list[$key] = TranslatableFieldValue::build('Title', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'product_'  . $i . '_url';

            $fields_list[$key] = UrlFieldValue::build('URI', $key)
                ->required();

            $key = 'product_'  . $i . '_type';

            $fields_list[$key] = BasicFieldValue::build('Price Description', $key)
                ->fieldType(BasicFieldValue::TYPE_SELECT)
                ->required()
                ->setup(function (Select $field)
                {
                    $field->options([
                            1 => 'цена',
                            2 => 'цена от',
                        ]);
                });

            $key = 'product_'  . $i . '_price';

            $fields_list[$key] = BasicFieldValue::build('Price', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_CURRENCY)
                ->setup(function (Currency $field)
                {
                    $field->currency('UAH');
                });

            $key = 'product_'  . $i . '_cashback';

            $fields_list[$key] = BasicFieldValue::build('Max Cashback', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_CURRENCY)
                ->setup(function (Currency $field)
                {
                    $field->currency('UAH');
                });

            $key = 'product_'  . $i . '_image';

            $fields_list[$key] = ImageFieldValue::build('Image', $key)
                ->required();

        }

        return $fields_list;
    }

    #endregion
}
