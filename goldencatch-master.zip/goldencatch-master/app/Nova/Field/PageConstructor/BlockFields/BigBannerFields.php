<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\UrlFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;

/**
 * @property array $field_values
 * [
 *      desktop_image_ru => file,
 *      desktop_image_ua => file,
 *
 *      mobile_image_ru => file,
 *      mobile_image_ua => file,
 *
 *      url => string,
 * ]
 */
class BigBannerFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        return collect([
            BasicFieldValue::build('Десктоп')
                ->required()
                ->fieldType(BasicFieldValue::TYPE_HEADING),

            'desktop_image_ru' => ImageFieldValue::build('Катринка (RU)', 'desktop_image_ru')
                ->required(),
            'desktop_image_ua' => ImageFieldValue::build('Катринка (UA)', 'desktop_image_ua')
                ->required(),

            BasicFieldValue::build('Телефон')
                ->fieldType(BasicFieldValue::TYPE_HEADING),

            'mobile_image_ru' => ImageFieldValue::build('Катринка (RU)', 'mobile_image_ru')
                ->required(),
            'mobile_image_ua' => ImageFieldValue::build('Катринка (UA)', 'mobile_image_ua')
                ->required(),

            'url' => UrlFieldValue::build('Ссылка на банер', 'url')
                ->makeHeading(),
        ]);
    }

    #endregion
}
