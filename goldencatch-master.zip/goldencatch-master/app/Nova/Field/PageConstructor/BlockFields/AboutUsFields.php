<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;

class AboutUsFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        return collect([
            'title' => TranslatableFieldValue::build('Заголовок', 'title')
                ->fieldType(BasicFieldValue::TYPE_TEXT)
                ->required()
                ->makeHeading(),
            'description' => TranslatableFieldValue::build('Описание', 'description')
                ->fieldType(BasicFieldValue::TYPE_TEXTAREA)
                ->required()
                ->makeHeading(),
            'image' => ImageFieldValue::build('Image', 'image')
                ->required()
                ->makeHeading(),
        ]);
    }

    #endregion
}
