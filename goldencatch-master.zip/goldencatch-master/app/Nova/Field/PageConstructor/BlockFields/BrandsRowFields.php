<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor\Block;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;

class BrandsRowFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        for ($i = 0; $i < Block\BrandsRow::COUNT; $i ++) {
            $fields_list[] = BasicFieldValue::build('Brand ' . ($i + 1))
                ->required()
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'brand_title_' . $i;

            $fields_list[$key] = BasicFieldValue::build('Title', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'brand_url_' . $i;

            $fields_list[$key] = BasicFieldValue::build('URL', $key)
                ->required()
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'brand_image_' . $i;

            $fields_list[$key] = ImageFieldValue::build('Image', $key)
                ->required();
        }

        return $fields_list;
    }

    #endregion
}
