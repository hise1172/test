<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Nova\Field\PageConstructor\BlockFields\Property\MultiSelectFieldValue;
use Illuminate\Support\Collection;
use Outl1ne\MultiselectField\Multiselect;

class BestSellingFields extends NewProductsRowFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $field_key = 'taxonomies_data';

        $options_list = static::getOptionsList();

        return collect([
            $field_key => MultiSelectFieldValue::build('Топ продаж', $field_key)
                ->required()
                ->setup(function (Multiselect $field) use ($options_list) {
                    $field->options($options_list);
                }),
        ]);
    }

    #endregion
}
