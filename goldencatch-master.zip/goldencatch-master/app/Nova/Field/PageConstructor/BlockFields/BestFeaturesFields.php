<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\Field;

class BestFeaturesFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        return collect([
            BasicFieldValue::build('<p class="text-info">В данном блоке нет редактируемых полей</p>')
                ->fieldType(BasicFieldValue::TYPE_HEADING)
                ->setup(function (Field $field) {
                    $field->asHtml();
                }),
        ]);
    }

    #endregion
}
