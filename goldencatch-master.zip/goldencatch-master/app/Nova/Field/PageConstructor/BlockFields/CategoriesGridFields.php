<?php

namespace App\Nova\Field\PageConstructor\BlockFields;

use App\Libs\PageConstructor;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\UrlFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use Laravel\Nova\Fields\Field;
use Laravel\Nova\Fields\Select;
use Illuminate\Support\Collection;

class CategoriesGridFields extends BlockFields
{
    #region Getters

    /**
     * @inheritDoc
     */
    public static function getRequiredFields(): Collection
    {
        $fields_list = collect();

        $fields_list['all_products_url'] = UrlFieldValue::build('Ссылка на все товары', 'all_products_url');
        $fields_list['title'] = TranslatableFieldValue::build('Название блока(по умолчанию: Категории)', 'title')
            ->fieldType(BasicFieldValue::TYPE_TEXT)
            ->makeHeading();
        $fields_list['titleTag'] = BasicFieldValue::build('Тег заголовка', 'titleTag')
                ->fieldType(BasicFieldValue::TYPE_SELECT)
                ->setup(function (Field $field) {
                    $field->options(['h1' => 'h1', 'h2' => 'h2', 'h3' => 'h3', 'h4' => 'h4', 'h5' => 'h5', 'h6' => 'h6'])
                        ->withMeta(['value' => 'h3'])
                        ->displayUsingLabels();
                });

        for ($i = 0; $i < PageConstructor\Block\CategoriesGrid::COUNT; $i ++) {
            $fields_list[] = BasicFieldValue::build('Категория ' . ($i + 1))
                ->fieldType(BasicFieldValue::TYPE_HEADING);

            $key = 'category_title_' . $i;

            $fields_list[$key] = TranslatableFieldValue::build('Title', $key)
                ->fieldType(BasicFieldValue::TYPE_TEXT);

            $key = 'category_url_' . $i;

            $fields_list[$key] = UrlFieldValue::build('Ссылка', $key);

            $key = 'category_image_' . $i;

            $fields_list[$key] = ImageFieldValue::build('Изображение', $key);
        }

        return $fields_list;
    }

    #endregion
}
