<?php

namespace App\Nova\Field\PageConstructor;

use App\DataContainers\AbstractDataContainer;
use App\Libs\PageConstructor\Block;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use Illuminate\Support\Collection;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

abstract class BlockFields extends AbstractDataContainer
{
    protected array $field_values = [];
    /** @var Collection|BasicFieldValue[]  */
    protected Collection $block_fields;

    #region Abstracts

    /**
     * @return BasicFieldValue[]|Collection
     * [
     *      field_key => BasicFieldValue,
     *      ...
     * ]
     */
    abstract public static function getRequiredFields(): Collection;

    #endregion

    #region Builders

    /**
     * @param $block_type
     *
     * @return static
     */
    public static function factory($block_type)
    {
        $class_name = static::getClass($block_type);

        return $class_name::make()
            ->afterInit();
    }

    /**
     * @param Layout $layout
     *
     * @return $this
     */
    public function import(array $fields_list)
    {
        foreach ($this->block_fields as $required_property) {
            $property_names = [];

            if ($required_property->isMeta()) {
                continue;
            }

            $required_property->collectSubFields($property_names, false);

            foreach ($property_names as $name) {
                if (BasicFieldValue::isHiddenFieldKey($name->attribute)) {
                    continue;
                }

                if (
                    !isset($fields_list[$name->attribute])
                    && !isset($fields_list[BasicFieldValue::HIDDEN_KEY_PREF . $name->attribute])
                    && $required_property->isRequired()
                ) {
                    throw new \InvalidArgumentException('Missed required field. Field key: `' . $required_property->getKey() . '`');
                }
            }
        }

        $this->field_values = $fields_list;

        return $this;
    }

    #endregion

    #region Actions

    /**
     * @return $this
     */
    protected function afterInit(): self
    {
        $this->block_fields = static::getRequiredFields();

        return $this;
    }

    /**
     * @return $this
     */
    public function afterSave(): self
    {
        foreach ($this->block_fields as $field) {
            $field->afterSave();
        }

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    final public function getType(): string
    {
        $class_base_name = substr(basename(str_replace('\\', '/', static::class)), 0, -6);

        /** @var Block $class_name */
        $class_name = Block::class . '\\' . $class_base_name;

        return $class_name::getBlockType();
    }

    /**
     * @return array
     */
    final public static function getAllowedBlocks(): array
    {
        return Block::getTypesList();
    }

    /**
     * Returns a data to save it into DB
     *
     * @return array
     */
    public function getPropertiesValues(): array
    {
        $result = collect();

        foreach ($this->block_fields as $field) {
            $field->addPropertyValueToCollection($result, $this->field_values);
        }

        return $result->toArray();
    }

    /**
     * @param string $class_name
     *
     * @return string|static
     */
    private static function getClass(string $block_type): string
    {
        if (!isset(static::getAllowedBlocks()[$block_type])) {
            throw new \InvalidArgumentException('Invalid block type. Given: ' . $block_type);
        }

        // Get correct class name
        $names = explode('_', $block_type);

        foreach ($names as &$name) {
            $name = ucfirst($name);
        }

        return static::class . '\\' . implode('', $names) . 'Fields';
    }

    #endregion

    #region Helpers


    #endregion
}
