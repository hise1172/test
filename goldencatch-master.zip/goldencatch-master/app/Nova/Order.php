<?php

namespace App\Nova;

use Laravel\Nova\Panel;
use Laravel\Nova\Fields\ID;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\BelongsToMany;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Fields\Textarea;

class Order extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Order::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'name', 'surname', 'phone', 'email'
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            new Panel('Замовлення', [
                ID::make()->sortable(),
                Textarea::make('Комментар', 'comments')
                ->alwaysShow()
                ->rows(3),
                Boolean::make('Передзвонити', 'need_call')->sortable(),
                Number::make('Ціна покупки', 'price')->sortable(),
                Number::make('Використано бонусів', 'discount')->sortable(),
                Number::make('Повна ціна без бонусів', 'price_without_discount')->sortable(),
                DateTime::make('Дата і час', 'created_at')->sortable(),
            ]),

            new Panel('Клієнт', [
                Text::make('Ім\'я', 'name')->sortable(),
                Text::make('Прізвище', 'surname')->sortable(),
                Number::make ('Телефон', 'phone')->sortable(),
                Text::make('Email')->sortable(),
                BelongsTo::make('Користувач сайту', 'user', 'App\Nova\User')->hideFromIndex(),
            ]), 
            
            new Panel('Оплата та доставка', [
                Text::make('Адреса доставки', 'Delivery Address')->hideFromIndex(),
                BelongsTo::make('Метод доставки', 'Delivery', 'App\Nova\Delivery')->hideFromIndex(),
                BelongsTo::make('Метод оплати', 'paymentMethod', 'App\Nova\PaymentMethod')->hideFromIndex(),
            ]),

            BelongsToMany::make('Товари в замовленні', 'products', 'App\Nova\Product')
            ->fields(function () {
                return [
                    Number::make('Count'),
                    Number::make('Price'),
                ];
            })
        ];
    }

    protected function addressFields()
    {
        return [
            // BelongsTo::make('Delivery')->hideFromIndex(),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    public static function label()
    {
        return 'Замовлення';
    }

    public static function singularLabel()
    {
        return 'Замовлення';
    }

    public static function authorizedToCreate(Request $request)
    {
        return false;
    }
}
