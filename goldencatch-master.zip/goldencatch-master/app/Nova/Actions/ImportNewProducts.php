<?php

namespace App\Nova\Actions;

use App\Services\ExportImport\NewProducts\Import;
use Illuminate\Bus\Queueable;
use Illuminate\Http\UploadedFile;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Collection;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\ActionFields;
use Maatwebsite\Excel\Facades\Excel;

class ImportNewProducts extends ImportProductAttributes
{
    use InteractsWithQueue, Queueable;

    /**
     * Perform the action on the given models.
     *
     * @param  \Laravel\Nova\Fields\ActionFields  $fields
     * @param  \Illuminate\Support\Collection  $models
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        set_time_limit(1800);

        /** @var UploadedFile $attachment */
        $attachment = $fields->getAttributes()['attachment'];
        $separator = $fields->getAttributes()['separator'] ?: ',';

        $import = new Import($separator);

        Excel::import($import, $attachment);

        $import->save();

        return Action::message('Processed ' . $import->getProductsCount() . ' and created ' . $import->getChangesCount() . ' products');
    }
}
