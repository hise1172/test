<?php

namespace App\Nova\Actions;

use Illuminate\Bus\Queueable;
use Laravel\Nova\Fields\File;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Actions\Action;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Facades\Excel;
use Laravel\Nova\Fields\ActionFields;
use App\Services\ExportImport\SeoFilters\Import;
use Illuminate\Queue\InteractsWithQueue;
use Laravel\Nova\Http\Requests\NovaRequest;

class ImportSeoFilters extends Action
{
    use InteractsWithQueue, Queueable;

    /**
     * Perform the action on the given models.
     *
     * @param  \Laravel\Nova\Fields\ActionFields  $fields
     * @param  \Illuminate\Support\Collection  $models
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        set_time_limit(1800);

        /** @var UploadedFile $attachment */
        $attachment = $fields->getAttributes()['attachment'];
        $separator = $fields->getAttributes()['separator'] ?: ',';

        $import = new Import($separator);

        Excel::import($import, $attachment);

        $import->save();

        return Action::message('Processed ' . $import->getFiltersCount() . ' and created ' . $import->getChangesCount() . ' filters');
    }

    public function fields(NovaRequest $request)
    {
        return [
            File::make('Attachment'),
            Select::make('Separator')
                ->options([
                    ',' => ', (coma)',
                    ';' => '; (semicolon)',
                ])
                ->withMeta([
                    'value' => ';' // default value for the select
                ]),
        ];
    }
}
