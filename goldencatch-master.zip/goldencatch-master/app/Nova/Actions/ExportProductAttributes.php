<?php

namespace App\Nova\Actions;

use App\Models\Brand;
use App\Models\Category;
use Illuminate\Bus\Queueable;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Heading;
use Outl1ne\MultiselectField\Multiselect;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\ActionFields;
use Illuminate\Queue\InteractsWithQueue;
use Laravel\Nova\Http\Requests\NovaRequest;

class ExportProductAttributes extends Action
{
    use InteractsWithQueue, Queueable;

    /**
     * The text to be used for the action's confirm button.
     *
     * @var string
     */
    public $confirmButtonText = 'Export';

    /**
     * Perform the action on the given models.
     *
     * @param  \Laravel\Nova\Fields\ActionFields  $fields
     * @param  \Illuminate\Support\Collection  $models
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        $brand_ids = json_decode($fields['brand'] ?? '[]', true);
        $category_ids = json_decode($fields['category'] ?? '[]', true);
        $products_of_week_only = (bool) $fields['products_of_week_only'] ?? false;
        $include_attributes = (bool) $fields['include_attributes'] ?? false;

        return Action::openInNewTab(route('nova-export-products', [
            'brands' => $brand_ids,
            'categories' => $category_ids,
            'products_of_week_only' => $products_of_week_only,
            'include_attributes' => $include_attributes,
        ]));
    }

    /**
     * Get the fields available on the action.
     *
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        $brand_list = [];

        foreach (Brand::all() as $attr) {
            /** @var Brand $attr */
            $brand_list[$attr->id] = $attr->name;
        }

        $category_list = [];

        foreach (Category::all() as $attr) {
            /** @var Category $attr */
            $category_list[$attr->id] = $attr->name;
        }

        return [
            Heading::make('<p class="text-info">Эта форма работает по логическому принципу «и». То есть, если выбрано и категорию, и бренд, то будет экспортировано все продукты, которые одновременно принадлежат к выбраному бренду и категории.</p>')
                ->asHtml(),

            Boolean::make('Products of Week only', 'products_of_week_only')
                ->default(false),

            Multiselect::make('Brand', 'brand')
                ->options($brand_list),

            Multiselect::make('Category', 'category')
                ->options($category_list),

            Boolean::make('Include Attributes', 'include_attributes')
                ->default(true),
        ];
    }
}
