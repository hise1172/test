<?php

namespace App\Nova;

use Carbon\Carbon;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Currency;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Http\Requests\NovaRequest;
use App\Models;
use Laravel\Nova\Panel;
use Spatie\NovaTranslatable\Translatable;

class Promotion extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = Models\Promotion::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
        'title',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make()->sortable(),

            Translatable::make([
                Text::make('Title', 'title')
                    ->sortable()
                    ->required()
            ]),

            Text::make('Promo Code', 'promo_code')
                ->sortable()
                ->help('Unique code of a promo action. Leave empty to make auto-generated code'),

            Textarea::make('Description of the promo', 'description'),

            Select::make('Apply on', 'trigger_id')
                ->options([
                    Models\Promotion::TRIGGER_REGISTRATION => 'Registration',
                    Models\Promotion::TRIGGER_CHECKOUT => 'Checkout',
                ])
                ->hideFromIndex()
                ->required(),

            Currency::make('Min cart amount', 'min_cart_amount')
                ->currency('UAH')
                ->required(),

            Boolean::make('Display in Account', 'is_display_in_account')
                ->help('Check it out to show the action in an user account, e.g. on Bonus Club page'),

            DateTime::make('Start At', 'start_at')
                ->default(Carbon::today())
                ->sortable()
                ->required(),

            DateTime::make('Expire At', 'expire_at')
                ->sortable(),

            new Panel('Bonus value', [
                Number::make('Amount', 'amount')
                    ->min(0.01)
                    ->step(0.01)
                    ->sortable()
                    ->required(),

                Select::make('Units', 'units')
                    ->options([
                        'uah' => 'UAH',
                        '%' => '%',
                    ])
                    ->sortable()
                    ->required(),

            ]),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    public static function label()
    {
        return 'Промо Акції';
    }

    public static function singularLabel()
    {
        return 'Акція';
    }
}
