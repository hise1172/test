<?php

namespace App\Nova;

use App\User;
use Laravel\Nova\Fields\ID;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Http\Requests\NovaRequest;

class BotUser extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\BotUser::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'first_name', 'last_name', 'username',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make()->sortable(),

            Text::make('First name')
                ->sortable()
                ->rules('required', 'string', 'max:255'),

            Text::make('Last name')
                ->sortable()
                ->rules('required', 'string', 'max:255'),

            Text::make('Username')
                ->sortable()
                ->rules('string', 'max:255'),

            Text::make('Provider User Id')
                ->sortable()
                ->rules('string', 'max:255'),

            Select::make('User', 'user_id')
                ->searchable()
                ->options(
                    User::all()
                        ->mapWithKeys(function (User $user) {
                            return [$user->id => "{$user->name} {$user->surname} ({$user->email})"];
                        })
                )
                ->rules('int'),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }

    /**
     * @inheritDoc
     */
    public static function indexQuery(NovaRequest $request, $query)
    {
        return [];
    }

    public static function label()
    {
        return 'Юзери боту';
    }

    public static function singularLabel()
    {
        return 'Юзер боту';
    }

    public static function authorizedToCreate(Request $request)
    {
        return false;
    }
}
