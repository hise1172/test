<?php

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use App\Helpers\RouteLocaleSwitcher;

if (!Collection::hasMacro('ungroup')) {
    /**
     * Ungroup a previously grouped collection (grouped by {@see Collection::groupBy()})
     */
    Collection::macro('ungroup', function () {
        // create a new collection to use as the collection where the other collections are merged into
        $newCollection = Collection::make([]);
        // $this is the current collection ungroup() has been called on
        // binding $this is common in JS, but this was the first I had run across it in PHP
        $this->each(function ($item) use (&$newCollection) {
            // use merge to combine the collections
            $newCollection = $newCollection->merge($item);
        });

        return $newCollection;
    });
}

if (!Collection::hasMacro('sortByMulti')) {
    /**
     * An extension of the {@see Collection::sortBy()} method that allows for sorting against as many different
     * keys. Uses a combination of {@see Collection::sortBy()} and {@see Collection::groupBy()} to achieve this.
     *
     * @param array $keys An associative array that uses the key to sort by (which accepts dot separated values,
     * as {@see Collection::sortBy()} would) and the value is the order (either ASC or DESC)
     *
     * @method Collection::sortByMulti
     */
    Collection::macro('sortByMulti', function (array $sortSettings) {
        $currentIndex = 0;
        $sortSettings = array_map(function ($settingsRow) {
            if (!empty($settingsRow['sortBy'])) {
                return [
                    'sort' => $settingsRow['sort'] ?? 'asc',
                    'sortBy' => $settingsRow['sortBy']
                ];
            }
        }, $sortSettings);

        $sortBy = function (Collection $collection) use (&$currentIndex, $sortSettings, &$sortBy) {
            if ($currentIndex >= count($sortSettings)) {
                return $collection;
            }

            $sortBy = $sortSettings[$currentIndex]['sortBy'];
            $sortFunc = $sortSettings[$currentIndex]['sort'] === 'desc' ? 'sortByDesc' : 'sortBy';
            $currentIndex++;
            return $collection->$sortFunc($sortBy)->groupBy($sortBy)->map($sortBy)->ungroup();
        };

        return $sortBy($this);
    });
}

if( ! function_exists('settings') ){
    function settings($key = null, $default = null) {
        if ($key === null) {
            return app(App\StaticSettings::class);
        }

        return app(App\StaticSettings::class)->get($key, $default);
    }
}

if( ! function_exists('routeLocale') ){
    function routeLocale($name, $parameters = []) {
        if (!is_array($parameters)) {
            $parameters = [$parameters];
        }
        if (!array_key_exists('locale', $parameters) && app()->getLocale() != config('app.default_locale')) {
            $parameters['locale'] = app()->getLocale();
            $name .= '-l';
        }

        return route($name, $parameters);
    }
}

if ( ! function_exists('routeLangChange') ) {
    function routeLangChange( $parameters )
    {
        if ( ! Request::isMethod('GET') )
        {
            return route('main');
        }

        $route_switcher = RouteLocaleSwitcher::build(Route::currentRouteName(), $parameters + Route::current()->parameters());

        return route($route_switcher->getRouteName(), $route_switcher->getParameters());
    }
}

if ( ! function_exists('deprecated') ) {
    /**
     * Logs a deprecated place
     *
     * @param string|null $place
     */
    function deprecated(string $place = null)
    {
        [, $trace, ] = debug_backtrace();

        $backtrace = $trace['file'] . ':' . $trace['line'];
        $function = ($trace['class'] ?? '') . ($trace['type'] ?? '') . $trace['function'] . '()';

        $function_array = explode('\\', $function);

        $place = $place ?: $function_array[array_key_last($function_array)];

        $method = Request::method();
        $uri = Request::path();
        /** @var Illuminate\Routing\Route $route */
        $route = Request::route();

        Log::channel('deprecated')
            ->info("place: {$place} | fn: {$function} | backtrace: {$backtrace} | HTTP method: {$method} | URI: {$uri} | controller: '{$route->getActionName()}'");
    }
}

/**
 * Prepare a float value for view
 *
 * @param $float
 *
 * @return string
 */
function floatToView($float, $decimals = 2)
{
    return number_format($float, $decimals, ',', '');
}
