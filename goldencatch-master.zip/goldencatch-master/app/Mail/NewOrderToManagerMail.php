<?php

namespace App\Mail;

use App\Models\Order;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewOrderToManagerMail extends Mailable
{
    use Queueable, SerializesModels;

    private Order $order;
    private bool $is_resellers_console;

    /**
     * @param Order $order
     * @param User $user
     * @param bool $is_resellers_console
     */
    public function __construct(Order $order, bool $is_resellers_console)
    {
        $this->order = $order;
        $this->is_resellers_console = $is_resellers_console;
    }

    /**
     * @inheritDoc
     */
    public function build()
    {
        $this->subject = "Новый заказ №{$this->order->id}, {$this->order->name} {$this->order->surname}";

        return $this->view('emails.new-order-to-manager')
            ->with([
                'order' => $this->order,
                'is_resellers_console' => $this->is_resellers_console,
            ]);
    }
}
