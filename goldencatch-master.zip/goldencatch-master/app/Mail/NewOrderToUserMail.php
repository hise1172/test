<?php

namespace App\Mail;

use App\Models\Order;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewOrderToUserMail extends Mailable
{
    use Queueable, SerializesModels;

    private Order $order;
    private bool $is_resellers_console;

    /**
     * @param Order $order
     * @param User $user
     * @param bool $is_resellers_console
     */
    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    /**
     * @inheritDoc
     */
    public function build()
    {
        $this->subject = __('order.email_to_user.new_order') . " №{$this->order->id}, {$this->order->name} {$this->order->surname}";

        return $this->view('emails.new-order-to-user')
            ->with([
                'order' => $this->order,
            ]);
    }
}
