<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\URL;

/**
 * Class VerifyMail
 * @package App\Mail
 */
class VerifyMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Get user name, verification token
     * @var User
     */
    private $user;

    /**
     * Create a new message instance.
     *
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $this->subject = __('account.emails.register.subject');

        $url = $this->verificationUrl();
        $user = $this->user;
        return $this->view('emails.verifyUser', compact('user', 'url'));
    }

    /**
     * Create temporary url verification email
     * @return string
     */
    protected function verificationUrl()
    {
        return URL::temporarySignedRoute(
            'verification.verify',
            Carbon::now()->addMinutes(Config::get('auth.verification.expire', 60)),
            [
                'id' => $this->user->getKey(),
                'hash' => $this->user->verifyUser->token
            ]
        );
    }
}
