<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ProductInStockMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var User
     */
    public $user;
    /**
     * @var string
     */
    public $productSlug;

    /**
     * Create a new message instance.
     *
     * @param User $user
     * @param string $productSlug
     */
    public function __construct(User $user, string $productSlug)
    {
        $this->user = $user;
        $this->productSlug = $productSlug;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.product-in-stock');
    }
}
