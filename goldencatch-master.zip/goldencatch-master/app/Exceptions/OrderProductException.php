<?php

namespace App\Exceptions;

use Throwable;

class OrderProductException extends \RuntimeException
{
    private array $errors;

    public function __construct($message, $code = 0, Throwable $previous = null)
    {
        $this->errors = (array) $message;

        parent::__construct('', $code, $previous);
    }

    /**
     * @return array
     */
    public function getErrors()
    {
        return $this->errors;
    }
}
