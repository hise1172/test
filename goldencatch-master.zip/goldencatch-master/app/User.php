<?php

namespace App;

use App\Mail\VerifyMail;
use App\Models\BonusHistory;
use App\Models\BotUser;
use App\Models\CommentsLikes;
use App\Models\Order;
use App\Models\Product\Product;
use App\Models\Promotion;
use App\Models\ResetPassword;
use App\Models\SubscribeEmail;
use App\Models\UserPromotion;
use App\Models\UserRole;
use App\Models\UserView;
use App\Models\VerifyUser;
use Illuminate\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use RuntimeException;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class User
 *
 * @package App
 *
 * @property int id
 * @property int user_role_id
 * @property string name
 * @property string surname
 * @property string email
 * @property string telephone
 * @property string password
 * @property VerifyUser verifyUser
 * @property boolean verified
 * @property string facebook_id
 * @property string google_id
 * @property string access_token
 *
 * @property float incoming_bonuses_amount // @see $this->getIncomingBonusesAmountAttribute()
 * @property float bonuses_balance // @see $this->getBonusesBalanceAttribute()
 * @property float earned_bonuses_sum // @see $this->getEarnedBonusesSumAttribute()
 * @property float spent_bonuses_sum // @see $this->getSpentBonusesSumAttribute()
 *
 * @property Collection|BonusHistory[] bonusHistory
 * @property BotUser botUser
 * @property Collection|Promotion[] promotions
 * @property Collection|UserPromotion[] userPromotions @see $this->userPromotions()
 *
 * @property-read UserRole role
 */
class User extends Authenticatable
{
    use Notifiable, MustVerifyEmail;

    const TABLE_NAME = 'users';

    protected $table = self::TABLE_NAME;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'surname',
        'telephone',
        'verified',
        'user_role_id',
        'google_id',
        'facebook_id',
        'bonuses',
        'amount_of_purchases',
        'birthdate',
        'access_token'
    ];

    /**
     * A User can has one role only
     *
     * @var UserRole|null
     */
    private ?UserRole $_role = null;

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    #region Relations

    /**
     * User views product
     * @return HasManyThrough
     */
    public function views()
    {
        return $this->hasManyThrough(
            Product::class, UserView::class, 'user_id',
            'id', 'id', 'product_id');
    }

    /**
     * User role
     * @return BelongsTo
     */
    public function role()
    {
        return $this->belongsTo(UserRole::class, 'user_role_id');
    }

    /**
     * @return HasOne
     */
    public function botUser()
    {
        return $this->hasOne(BotUser::class);
    }

    /**
     * @return HasMany
     */
    public function userPromotions()
    {
        return $this->hasMany(UserPromotion::class, 'user_id')
            ->with('spentBonuses')
            ->with('promotion')
            ->whereIn('status_id', [UserPromotion::STATUS_NOT_USED, UserPromotion::STATUS_PARTIAL_USAGE])
            ->whereHas('promotion', function ($query) {
                $today = date('Y-m-d H:i:s');

                $query->where('start_at', '<=', $today)
                    ->where('expire_at', '>', $today)
                    ->orderBy('created_at');
            })
            ->orderBy('created_at');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function promotions()
    {
        $today = date('Y-m-d H:i:s');

        return $this->belongsToMany(Promotion::class, UserPromotion::TABLE_NAME)
            ->using(UserPromotion::class)
            ->withPivot('user_id', 'promotion_id')
            ->wherePivotIn('status_id', [UserPromotion::STATUS_NOT_USED, UserPromotion::STATUS_PARTIAL_USAGE])
            ->where('start_at', '<=', $today)
            ->where('expire_at', '>', $today)
            ->orderByPivot('created_at');
    }

    #endregion

    /**
     * User role
     * @return UserRole
     */
    public function getRole(): UserRole
    {
        if ($this->_role) {
            return $this->_role;
        }

        $this->_role = $this->role()->first();

        if (!$this->_role) {
            throw new RuntimeException('User does not have a role');
        }

        return $this->_role;
    }

    /**
     * @return HasOne
     */
    public function verifyUser()
    {
        return $this->hasOne(VerifyUser::class, 'user_id');
    }

    /**
     * Send the email verification notification.
     *
     * @return void
     */
    public function sendEmailVerificationNotification()
    {
        $this->notify(new VerifyMail($this));
    }

    public function getSubscriberAttribute()
    {
        $model = $this->subscribe()->first();
        if ($model) {
            return (bool)$model->active;
        }
        return false;
    }

    public function productWaiting()
    {
        return $this->belongsToMany(Product::class, 'user_waitings', 'user_id', 'product_id');
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'user_id');
    }

    public function likes()
    {
        return $this->hasMany(CommentsLikes::class, 'user_id');
    }

    public function subscribe()
    {
        return $this->belongsTo(SubscribeEmail::class, 'email', 'email');
    }

    /**
     * @return HasMany
     */
    public function bonusHistory()
    {
        return $this->hasMany(BonusHistory::class, 'user_id');
    }

    #region Is Condition Methods

    /**
     * Returns TRUE, if a current user has a Reseller role
     *
     * @return bool
     */
    public function isReseller(): bool
    {
        /** @var UserRole $role */
        $role = $this->getRole();

        return $role->isReseller();
    }

    /**
     * @return bool
     */
    public function hasOldPassword(): bool
    {
        return $this->password !== null
            || (
                !$this->facebook_id
                && !$this->google_id
            );
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function generateAccessToken(): string
    {
        $this->access_token = md5(rand(5, 5) . '.' . time() . ".{$this->id}.{$this->email}");

        $this->save();

        return $this->access_token;
    }

    /**
     * @return string
     */
    public function getAccessToken(): string
    {
        if ($this->access_token) {
            return $this->access_token;
        }

        return $this->generateAccessToken();
    }

    /**
     * Returns bonuses total sum, which were applied yesterday
     *
     * @return int
     */
    public function getLastApprovedBonusesBalance()
    {
        $now = new \DateTime(date('Y-m-d 00:00:00'));

        $result = $this->bonusHistory
            ->where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('amount', '>', 0)
            ->filter(function (BonusHistory $bonus_history) use ($now) {
                $start_date = (clone $now)
                    ->sub(new \DateInterval('P15D'));
                $end_date = (clone $now)
                    ->sub(new \DateInterval('P14D'));

                return $bonus_history->created_at > $start_date
                    && $bonus_history->created_at < $end_date;
            });

        return (int) $result->sum('amount');
    }

    /**
     * @return Collection|UserPromotion[]
     */
    public function getAppliedPromos()
    {
        return $this->userPromotions
            ->filter(fn (UserPromotion $user_promo) => $user_promo->getDiscount() > 0);
    }

    /**
     * @param float $min_cart_amount
     *
     * @return Collection|UserPromotion[]
     */
    public function getAvailalePromos(float $min_cart_amount)
    {
        return $this->getAppliedPromos()
            ->filter(fn (UserPromotion $user_promo) =>
                $user_promo->promotion->min_cart_amount <= $min_cart_amount
            );
    }

    /**
     * @param float $min_cart_amount
     *
     * @return float|int
     */
    public function getAvailablePromosDiscount(float $min_cart_amount)
    {
        /** @var UserPromotion[] $user_promos */
        $user_promos = $this->getAvailalePromos($min_cart_amount);

        $discount = 0;

        foreach ($user_promos as $promotion) {
            $discount += $promotion->getDiscount();
        }

        return $discount;
    }

    /**
     * @param float $min_cart_amount
     *
     * @return float|int
     */
    public function getTotalAvailableBonuses(float $min_cart_amount)
    {
        return ($this->bonuses_balance ?? 0) + $this->getAvailablePromosDiscount($min_cart_amount);
    }

    #endregion

    #region Get Virtual Attribute

    /**
     * @return int
     */
    public function getIncomingBonusesAmountAttribute()
    {
        return (int) $this->bonusHistory
            ->where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('amount', '>', 0)
            ->filter(function (BonusHistory $bonus_history) {
                $two_weeks_before = new \DateTime;
                $two_weeks_before->sub(new \DateInterval('P14D'));

                return $bonus_history->created_at >= $two_weeks_before
                    && $bonus_history->bonusable_type != UserPromotion::class;
            })
            ->sum('amount');
    }

    /**
     * @return int
     */
    public function getBonusesBalanceAttribute()
    {
        return (int) $this->bonusHistory
            ->where('status_id', BonusHistory::STATUS_ACTIVE)
            ->filter(function (BonusHistory $bonus_history) {
                $two_weeks_before = new \DateTime;
                $two_weeks_before->sub(new \DateInterval('P14D'));

                return $bonus_history->amount < 0
                    || (
                        $bonus_history->amount > 0
                        && (
                            $bonus_history->created_at < $two_weeks_before
                            || $bonus_history->bonusable_type == UserPromotion::class
                        )
                    );
            })
            ->sum('amount');
    }

    /**
     * @return float|int
     */
    public function getEarnedBonusesSumAttribute()
    {
        return $this->bonusHistory
                ->where('status_id', BonusHistory::STATUS_ACTIVE)
                ->where('amount', '>', 0)
                ->sum('amount');
    }

    /**
     * @return float|int
     */
    public function getSpentBonusesSumAttribute()
    {
        return -1 * $this->bonusHistory
            ->where('status_id', BonusHistory::STATUS_ACTIVE)
            ->where('amount', '<', 0)
            ->sum('amount');
    }

    #endregion
}
