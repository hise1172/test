<?php

namespace App\ApiIntegration;

use App\User;
use Illuminate\Support\Facades\Config;
use InvalidArgumentException;

/**
 * Class SMS
 *
 * @package App\ApiIntegration
 */
abstract class SMS
{
    const DRIVER_eSPUTNIC = 'ESputnik';
    const DRIVER_ePOCHTA = 'EPochta'; // ToDo: the driver was not implemented completely, please debug it before using

    const DEFAULT_DRIVER = self::DRIVER_eSPUTNIC;
    const CODE_LENGTH = 5;

    protected User $user;
    private string $config_name;

    #region Magic methods

    /**
     * Abstract constructor.
     *
     * @param User $user
     */
    protected function __construct(User $user)
    {
        if (!$user->telephone) {
            throw new InvalidArgumentException('Passed user has invalid telephone');
        }

        $this->user = $user;
        $this->config_name = strtolower(class_basename($this));
    }

    #endregion

    #region Builders

    /**
     * A factory method
     *
     * @param User $user
     * @param string $driver_name
     *
     * @return SMS
     */
    final public static function build(User $user, string $driver_name = self::DEFAULT_DRIVER)
    {
        switch ($driver_name) {
            case static::DRIVER_eSPUTNIC:
                break;

            default:
                throw new InvalidArgumentException('Invalid $driver_name');
        }

        /** @var static $class_name */
        $class_name = self::class . '\\' . $driver_name;

        return $class_name::init($user);
    }

    /**
     * @param User $user
     *
     * @return static
     */
    public static function init(User $user): self
    {
        return new static($user);
    }

    #endregion

    #region Abstract methods

    /**
     * @return object
     */
    abstract protected function apiClient();

    /**
     * @return int|float
     */
    abstract public function getBalance(): float;

    /**
     * @param string $message
     *
     * @return object - response data
     */
    abstract public function sendSMS(string $message): object;

    #endregion

    #region Getters

    /**
     * @return int
     * @throws \Exception
     */
    public static function generateSMSCode()
    {
        return random_int(
            (int) substr('1000000000000000000000000000000000000000000000', 0, self::CODE_LENGTH),
            (int) substr('9999999999999999999999999999999999999999999999', 0, self::CODE_LENGTH)
        );
    }

    /**
     * @return array
     */
    public function getConfig(): array
    {
        return Config::get("sms.{$this->config_name}");
    }

    /**
     * @param string $method
     *
     * @return string
     */
    public function getEndpoint(string $method): string
    {
        return Config::get("sms.{$this->config_name}.api_url") . $method;
    }

    /**
     * @return string
     */
    public function getSenderName(): string
    {
        return Config::get("sms.{$this->config_name}.sender_name");
    }

    #endregion
}
