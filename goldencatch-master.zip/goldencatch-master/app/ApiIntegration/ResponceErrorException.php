<?php

namespace App\ApiIntegration;

/**
 * Class ResponceErrorException
 *
 * @package App\ApiIntegration
 */
class ResponceErrorException extends \RuntimeException
{
    protected $request_data;

    /**
     * @param $data
     *
     * @return $this
     */
    public function setRequestData($data): self
    {
        $this->request_data = $data;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRequestData()
    {
        return$this->request_data;
    }
}
