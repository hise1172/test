<?php

namespace App\ApiIntegration\SMS;

use App\ApiIntegration\SMS;
use Illuminate\Support\Facades\Log;

/**
 * Class ESputnik
 *
 * @package App\ApiIntegration\SMS
 */
class ESputnik extends SMS
{
    #region Actions

    /**
     * @param string $message
     *
     * @return object
     */
    public function sendSMS(string $message): object
    {
        if (env('APP_DEBUG')) {
            Log::debug($message);

            return (object) [
                'id' => 0,
                "results" => [
                    "id" => 0,
                    "locator" => $this->user->telephone,
                    "status" => "OK",
                    "requestId" => "16477950-db33-11eb-9713-eb6b0ced51ff",
                ],
            ];
        }

        $client = $this->apiClient();

        $client->post($this->getEndpoint('message/sms'), [
            'from' => $this->getSenderName(),
            'text' => $message,
            'phoneNumbers' => $this->user->telephone,
        ]);

        if ($client->hasError()) {
            $client->processError();
        }

        /**
         * @var object $response
         * [
         *  "id" => 0
         *  "results" => [
         *      "id" => 0,
         *      "locator" => "380980000000",
         *      "status" => "OK",
         *      "requestId" => "16477950-db33-11eb-9713-eb6b0ced51ff",
         *  ],
         * ]
         */
        $response = $client->getResponse();

        return $response;
    }

    #endregion

    #region Getters

    /**
     * @return SMS\ESputnik\Client
     */
    protected function apiClient()
    {
        $config = $this->getConfig();

        return SMS\ESputnik\Client::build($config['username'], $config['api_key']);
    }

    /**
     * @return int|float
     */
    public function getBalance(): float
    {
        $client = $this->apiClient()
            ->get($this->getEndpoint('balance'));

        if ($client->hasError()) {
            $client->processError();
        }

        /**
         * @var object $response
         * [
         *  "currentBalance" => 0.0
         *  "creditLimit" => 0.0
         *  "currency" => "UAH"
         *  "bonusEmails" => 2500
         *  "bonusSmses" => 10
         * ]
         */
        $response = $client->getResponse();

        if ($response->bonusSmses > 0) {
            return 100500;
        }

        return $response->currentBalance + $response->creditLimit;
    }

    #endregion
}
