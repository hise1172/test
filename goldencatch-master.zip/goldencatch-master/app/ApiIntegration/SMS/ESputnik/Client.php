<?php

namespace App\ApiIntegration\SMS\ESputnik;

use App\ApiIntegration\ResponceErrorException;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use LogicException;

/**
 * Class Client
 *
 * @see https://esputnik.com/api/methods.html - API Documentatioon
 *
 * @package App\ApiIntegration\SMS\ESputnik
 */
class Client
{
    private $request_data;
    private ?Response $response = null;
    private PendingRequest $curl;

    #region Magic Methods

    /**
     * Client constructor.
     *
     * @param string $username
     * @param string $api_key
     */
    private function __construct(string $username, string $api_key)
    {
        $this->curl = Http::withBasicAuth($username, $api_key);
    }

    #endregion

    #region Builders

    /**
     * @param string $username
     * @param string $api_key
     *
     * @return static
     */
    public static function build(string $username, string $api_key): self
    {
        return new static($username, $api_key);
    }

    #endregion

    #region Actions

    /**
     * @param $url
     * @param array $data
     *
     * @return $this
     */
    public function get($url, $data = []): self
    {
        $this->request_data = $data;
        $this->response = $this->curl->get($url, $data);

        return $this;
    }

    /**
     * @param $url
     * @param array $data
     *
     * @return $this
     */
    public function post($url, $data = []): self
    {
        $this->request_data = $data;
        $this->response = $this->curl->post($url, $data);

        return $this;
    }

    #endregion

    #region Is Condition methods

    /**
     * @return bool
     */
    public function hasError(): bool
    {
        if (!$this->response) {
            throw new LogicException('Invalid $this->response');
        }

        return $this->response->failed();
    }

    #endregion

    #region Getters

    /**
     * @return object
     */
    public function getResponse(): object
    {
        if (!$this->response) {
            throw new LogicException('Invalid $this->response');
        }

        $response = $this->response->body();

        return json_decode($response) ?: (object) ['error' => $response];
    }

    #endregion

    #region Helpers

    /**
     * @throws ResponceErrorException
     */
    public function processError()
    {
        throw (new ResponceErrorException('API Responded Error: ' . $this->getResponse()->error))
            ->setRequestData($this->request_data);
    }

    #endregion
}
