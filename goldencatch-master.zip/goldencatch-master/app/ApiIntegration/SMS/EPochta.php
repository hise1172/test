<?php

namespace App\ApiIntegration;

use App\User;
use Illuminate\Support\Facades\Config;
use InvalidArgumentException;

/**
 * Class EPochta
 *
 * @package App\ApiIntegration
 */
class EPochta
{
    private User $user;
    private string $sender_name;

    private ?EPochta\APISMS $_sms_api_getaway = null;
    private ?EPochta\Account $_sms_api_account = null;
    private ?EPochta\Stat $_sms_api_client = null;

    #region Magic methods

    /**
     * EPochta constructor.
     *
     * @param User $user
     */
    public function __construct(User $user)
    {
        if (!$user->telephone) {
            throw new InvalidArgumentException('Passed user has invalid telephone');
        }

        $this->user = $user;
        $this->sender_name = $this->SMSGetaway()->isTestMode()
            ? 'allservice'
            : Config::get('sms.epochta.sender_name');
    }

    #endregion

    #region Builders

    /**
     * @param User $user
     *
     * @return static
     */
    public static function init(User $user): self
    {
        return new static($user);
    }

    /**
     * @return EPochta\APISMS
     */
    private function SMSGetaway(bool $force = false)
    {
        if ($this->_sms_api_getaway && !$force) {
            return $this->_sms_api_getaway;
        }

        $public_key = Config::get('sms.epochta.public_key');
        $private_key = Config::get('sms.epochta.private_key');
        $api_url = Config::get('sms.epochta.api_url');
        $test_mode = Config::get('sms.epochta.test_mode');

        return $this->_sms_api_getaway = new EPochta\APISMS($private_key, $public_key, $api_url, $test_mode);
    }

    /**
     * @return EPochta\Account
     */
    private function SMSAccount()
    {
        if ($this->_sms_api_account) {
            return $this->_sms_api_account;
        }

        return $this->_sms_api_account = new EPochta\Account($this->SMSGetaway());
    }

    /**
     * @return EPochta\Stat
     */
    private function SMSClient()
    {
        if ($this->_sms_api_client) {
            return $this->_sms_api_client;
        }

        return $this->_sms_api_client = new EPochta\Stat($this->SMSGetaway());
    }

    #endregion

    #region Actions

    /**
     * Length of a SMS
     * - 160 chars on English
     * - 70 chars in Cyrillic
     *
     * If a message contains few SMSes, you lose
     * - 7 chars for English for a SMS, e.g. two sms it's 306 chars instead 320
     * - 3 chars for Cyrillic for a SMS, e.g. two sms it's 134 chars instead 140
     *
     * @param string $message
     *
     * @return $this
     */
    public function sendSMS(string $message): self
    {
        $result = $this->SMSClient()->sendSMS($this->sender_name, $message, trim($this->user->telephone, '+'));

        return $this;

        dd([
            'request' => [
                'sender_name' => $this->sender_name,
                'message' => $message,
                'telephone' => trim($this->user->telephone, '+'),
            ],
            'response' => $result,
        ]);

        if (isset($result["result"]["error"])) {
            throw new ResponceErrorException($result["result"]["code"]);
        }

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return int
     * @throws \Exception
     */
    public static function generateSMSCode()
    {
        return random_int(10000, 99999);
    }

    /**
     * @return int|float
     */
    public function getBalance()
    {
        if ($this->SMSGetaway()->isTestMode()) {
            return 100500;
        }

        $result = $this->SMSAccount()->getUserBalance();

        return isset($result["result"]["error"]) || !isset($result["result"]["balance_currency"]) || $result["result"]["balance_currency"] <= 0
            ? 0
            : $result["result"]["balance_currency"];
    }

    #endregion
}
