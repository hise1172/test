<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string product_0-9_title
 * @property string product_0-9_url
 * @property string product_0-9_image
 * @property string product_0-9_type
 * @property string product_0-9_price
 * @property string product_0-9_cashback
 */
class ProductsOfWeek extends Block
{
    const COUNT = 5;

    /**
     * @return string
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_PRODUCTS_OF_WEEK;
    }

    /**
     * @param array $item
     *
     * @return bool
     */
    public function isFinalPrice(array $item): bool
    {

        switch ($item['type'] ?? 1) {
            case 2:
                return false;
        }

        return true;
    }
}
