<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

class BestFeatures extends Block
{
    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_BEST_FEATURES;
    }
}
