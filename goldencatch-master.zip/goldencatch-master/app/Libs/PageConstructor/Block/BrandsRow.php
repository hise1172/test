<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string brand_title_([0-4])
 * @property string brand_image_([0-4])
 * @property string brand_url_([0-4])
 */
class BrandsRow extends Block
{
    const COUNT = 5;

    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_BRANDS_ROW;
    }

    /**
     * @param int $i
     *
     * @return string
     */
    public function getBrandImage(int $i)
    {
        return $this->getImageFullURL('brand_image_' . $i);
    }
}
