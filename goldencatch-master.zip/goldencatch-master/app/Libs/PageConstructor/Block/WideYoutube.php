<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string[] video_title_[0-4]
 * @property string video_date_[0-4]
 * @property string video_url_[0-4]
 */
class WideYoutube extends Block
{
    const COUNT = 4;

    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_WIDE_YOUTUBE;
    }
}
