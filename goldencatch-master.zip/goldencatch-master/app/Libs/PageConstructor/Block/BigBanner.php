<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string desktop_image_ru
 * @property string desktop_image_ua
 * @property string mobile_image_ru
 * @property string mobile_image_ua
 * @property string url
 */
class BigBanner extends Block
{
    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_BIG_BANNER;
    }

    /**
     * @param string|null $locale
     *
     * @return string|null
     */
    public function getDesktopImage(string $locale = null)
    {
        $locale = $locale ?? app()->getLocale();

        return $this->{'desktop_image_' . $locale};
    }

    /**
     * @param string|null $locale
     *
     * @return string|null
     */
    public function getMobileImage(string $locale = null)
    {
        $locale = strtolower($locale ?? app()->getLocale());

        return $this->{'mobile_image_' . $locale};
    }

    /**
     * @return string
     */
    public function getURL(): string
    {
        return $this->url;
    }
}
