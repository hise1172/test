<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string banner_title_[0-2]
 * @property string banner_url_[0-2]
 * @property string banner_image_[0-2]
 */
class ThreeStepsExplainer extends Block
{
    const COUNT = 3;

    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_THREE_STEPS_EXPLAINER;
    }

    public function getImage($index)
    {
        return $this->{'banner_image_' . $index };
    }

    /**
     * @return string
     */
    public function getURL($index): string
    {
        return $this->{'banner_url_' . $index};
    }
}
