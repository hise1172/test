<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string all_products_url
 * @property string category_title_[0-4]
 * @property string category_image_[0-4]
 * @property string category_url_[0-4]
 */
class CategoriesGrid extends Block
{
    const COUNT = 14;

    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_CATEGORIES_GRID;
    }

    public function getImage($index)
    {
        return $this->{'category_image_' . $index};
    }

    /**
     * @return string
     */
    public function getURL($index): string
    {
        return $this->{'category_url_' . $index};
    }

    public function getAllURL(): string
    {
        return $this->all_products_url;
    }
}
