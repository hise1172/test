<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;
use App\Repositories\ProductRepository;
use Illuminate\Support\Collection;

class BestSelling extends NewProductsRow
{
    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_BEST_SELLING;
    }

    /**
     * @inheritDoc
     */
    public function getProductsList(): Collection
    {
        /** @var ProductRepository $repository */
        $repository = app()->make(ProductRepository::class);

        return $repository->getBestSelling($this->getTaxonomies());
    }
}
