<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;
use App\Models\Product\Product;
use App\Repositories\ProductRepository;
use Illuminate\Support\Collection;

/**
 * @property string|json taxonomies_data
 */
class NewProductsRow extends Block
{
    /**
     * @var array
     * [
     *      'brand' => [
     *          brand_id,
     *          ...
     *      ],
     *      'attribute_slug_value' => [
     *          attribute_slug_value_id,
     *          ...
     *      ],
     * ]
     */
    private array $_taxonomies = [];

    /**
     * @inheritDoc
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_NEW_PRODUCTS_ROW;
    }

    /**
     * @return Collection|Product[]
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function getProductsList(): Collection
    {
        /** @var ProductRepository $repository */
        $repository = app()->make(ProductRepository::class);

        return $repository->getNewProduct($this->getTaxonomies());
    }

    /**
     * @return Collection[]
     */
    protected function getTaxonomies(): array
    {
        if ($this->_taxonomies) {
            return $this->_taxonomies;
        }

        $this->_taxonomies = [
            ProductRepository::TAXONOMY_BRAND => collect(),
            ProductRepository::TAXONOMY_ATTR_SLUG_VALUE => collect(),
        ];

        foreach (json_decode($this->taxonomies_data, true) as $data_string) {
            [$type, $value] = explode('.', $data_string, 2);

            switch ($type) {
                case ProductRepository::TAXONOMY_BRAND:
                case ProductRepository::TAXONOMY_ATTR_SLUG_VALUE:
                    $this->_taxonomies[$type][] = $value;
                    break;
            }
        }

        return $this->_taxonomies;
    }
}
