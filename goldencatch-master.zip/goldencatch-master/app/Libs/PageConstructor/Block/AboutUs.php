<?php

namespace App\Libs\PageConstructor\Block;

use App\Libs\PageConstructor\Block;

/**
 * @property string[] title
 * @property string[] description
 * @property string image
 */
class AboutUs extends Block
{
    /**
     * @return string
     */
    public static function getBlockType(): string
    {
        return Block::TYPE_ABOUT_US;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->getImageFullURL('image');
    }
}
