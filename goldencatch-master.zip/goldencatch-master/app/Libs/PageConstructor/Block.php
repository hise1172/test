<?php

namespace App\Libs\PageConstructor;

use App\DataContainers\AbstractDataContainer;
use App\Helpers\Url;
use App\Models\Translate;
use App\Nova\Field\PageConstructor\BlockFields\Property\BasicFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\TranslatableFieldValue;
use App\Nova\Field\PageConstructor\BlockFields\Property\UrlFieldValue;
use App\Nova\Field\PageConstructor\BlockFields;
use Illuminate\Support\Collection;
use InvalidArgumentException;

/**
 * @property string block_type
 */
abstract class Block extends AbstractDataContainer
{
    const TYPE_BIG_BANNER = 'big_banner';
    const TYPE_THREE_BANNERS = 'three_banners';
    const TYPE_CATEGORIES_GRID = 'categories_grid';
    const TYPE_SEASON_PROMO = 'season_promo';
    const TYPE_BRANDS_ROW = 'brands_row';
    const TYPE_NEW_PRODUCTS_ROW = 'new_products_row';
    const TYPE_BEST_SELLING = 'best_selling';
    const TYPE_YOUTUBE_FEED = 'youtube_feed';
    const TYPE_BEST_FEATURES = 'best_features';
    const TYPE_ABOUT_US = 'about_us';
    const TYPE_PRODUCT_FEATURES = 'product_features';
    const TYPE_WIDE_YOUTUBE = 'wide_youtube';
    const TYPE_THREE_STEPS_EXPLAINER = 'three_steps_explainer';
    const TYPE_PRODUCTS_OF_WEEK = 'products_of_week';

    #region Magic methods

    /**
     * @param array $data
     */
    protected function __construct(array $data)
    {
        parent::__construct($data);

        $this->block_type = $this->getType();
    }

    /**
     * @param $name
     *
     * @return mixed|null
     */
    public function __get($name)
    {
        if (property_exists($this, $name)) {
            return static::getPropertyValue($name, $this->$name);
        }

        if (!isset($this->_data[$name])) {
            return null;
        }

        return static::getPropertyValue($name, $this->_data[$name]);
    }

    #endregion

    #region Abstract methods

    /**
     * @return string|BlockFields
     */
    abstract public static function getBlockType(): string;

    #endregion

    #region Builders

    /**
     * @param string $type
     * @param array $data
     *
     * @return static
     */
    public static function factory(string $type, array $data)
    {
        $class_name = static::getClass($type);

        return $class_name::make($data);
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    final public function getType(): string
    {
        return static::getBlockType();
    }

    /**
     * @return BasicFieldValue[]|Collection
     */
    final public static function getRequiredProperties()
    {
        $class_name = static::getBlockFieldsClass();

        return $class_name::getRequiredFields();
    }

    /**
     * @inheritDoc
     */
    public function toArray() : array
    {
        $properties = parent::toArray();
        $properties['block_type'] = $this->getType();

        return $properties;
    }

    /**
     * @return string[]
     */
    public static function getTypesList(): array
    {
        return [
            static::TYPE_BIG_BANNER => 'Широкий баннер',
            static::TYPE_BRANDS_ROW => 'Лента брендов',
            static::TYPE_NEW_PRODUCTS_ROW => 'Лента новинок',
            static::TYPE_BEST_SELLING => 'Топ продаж',
            static::TYPE_YOUTUBE_FEED => 'Видео с Youtube',
            static::TYPE_BEST_FEATURES => 'Преимущества магазина',
            static::TYPE_ABOUT_US => 'О магазине',
            static::TYPE_THREE_BANNERS => 'Три баннера',
            static::TYPE_CATEGORIES_GRID => 'Сетка категорий',
            static::TYPE_SEASON_PROMO => 'Сезонный блок',
            static::TYPE_PRODUCT_FEATURES => 'Особенности товара',
            static::TYPE_WIDE_YOUTUBE => 'Широкое видео',
            static::TYPE_THREE_STEPS_EXPLAINER => 'Трехшаговая инструкция',
            static::TYPE_PRODUCTS_OF_WEEK => 'Товары недели',
        ];
    }

    /**
     * @param string $type
     *
     * @return string|static
     */
    private static function getClass(string $type): string
    {
        if (!isset(static::getTypesList()[$type])) {
            throw new InvalidArgumentException('Invalid block type. Given: ' . $type);
        }

        // Get correct class name
        $names = explode('_', $type);

        foreach ($names as &$name) {
            $name = ucfirst($name);
        }

        return static::class . '\\' . implode('', $names);
    }

    /**
     * @deprecated
     * @param string $property_name
     *
     * @return string
     */
    protected function getImageFullURL(string $property_name)
    {
        return $this->$property_name;
    }

    /**
     * @deprecated
     * @param string $property_name
     *
     * @return string
     */
    protected function getCurrentLocaleUrl(string $property_name): string
    {
        return $this->$property_name;
    }

    /**
     * @param string $property_name
     * @param $value
     *
     * @return mixed
     */
    static private function getPropertyValue(string $property_name, $value)
    {
        $filed = static::getField($property_name);

        if (!$filed) {
            return $value;
        }

        $local = app()->getLocale();

        switch (get_class($filed)) {
            case UrlFieldValue::class:
                return Url::getLocatedUrl($value, $local);

            case TranslatableFieldValue::class:
                switch ($local) {
                    case Translate::UA:
                    case Translate::RU:
                        return $value[$local];

                    default:
                        throw new \LogicException('Unknown locale ' . $local);
                }

            case ImageFieldValue::class:
                return $value ? $filed->getURL($value) : null;

        }

        return $value;
    }

    /**
     * Returns a value, which is stored in DB
     *
     * @param string $property_name
     *
     * @return mixed|string|null
     */
    public function getPropertyRealValue(string $property_name)
    {
        if (property_exists($this, $property_name)) {
            return $this->$property_name;
        }

        if (!isset($this->_data[$property_name])) {
            return null;
        }

        return $this->_data[$property_name];
    }

    /**
     * @param string $field_name
     *
     * @return BasicFieldValue|null
     */
    private static function getField(string $field_name): ?BasicFieldValue
    {
        $fields = static::getRequiredProperties();

        return $fields[$field_name] ?? null;
    }

    /**
     * @return string|BlockFields
     */
    final protected static function getBlockFieldsClass(): string
    {
        return BlockFields::class . '\\' . basename(str_replace('\\', '/', static::class)) . 'Fields';
    }

    /**
     * @return string
     */
    public function getPropertiesGroup($group_name): array
    {
        $result = [];

        foreach ($this->_data as $property_name => $value) {
            if (strpos($property_name . '_', $group_name) !== 0) {
                continue;
            }

            static::collectGroupPropertyValue($result, $property_name, $this->$property_name, $group_name);
        }

        return $result
            ? ($result[$group_name] ?? $result)
            : [];
    }

    #endregion

    #region Helpers

    /**
     * @return $this
     */
    public function validated(): self
    {
        foreach (static::getRequiredProperties() as $property_name => $field) {
            if (!$field->isMeta() && $field->isRequired() && !$this->$property_name) {
                throw new InvalidArgumentException('Field `' . $field->getName() . '` is empty. Field key: `' . $property_name . '`');
            }
        }

        return $this;
    }

    /**
     * @param array $result
     * @param string $group_name
     * @param string $property_name
     * @param $value
     */
    private static function collectGroupPropertyValue(array &$collection, string $property_name, $value, string $group_name = null)
    {
        $property_name = $group_name
            ? substr($property_name, strlen($group_name . '_'))
            : $property_name;

        if (!isset($collection[$group_name])) {
            $collection[$group_name] = [];
        }

        $names = explode('_', $property_name);

        static::buildArrayStructure($collection[$group_name], $names, $value);
    }

    /**
     * @param array $array
     * @param array $property_names
     * @param $value
     */
    private static function buildArrayStructure(array &$array, array $property_names, $value)
    {
        if (!$property_names) {
            return;
        }

        $key = array_shift($property_names);

        if (count($property_names) === 0) {
            $array[$key] = $value;

            return;
        }

        if (!isset($array[$key])) {
            $array[$key] = [];
        }

        static::buildArrayStructure($array[$key], $property_names, $value);
    }

    #endregion
}
