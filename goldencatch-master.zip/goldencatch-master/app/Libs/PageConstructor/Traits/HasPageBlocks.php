<?php

namespace App\Libs\PageConstructor\Traits;

use App\Libs\PageConstructor\Block;
use App\Libs\PageConstructor\Interfaces\PageBlocksInterface;
use Illuminate\Support\Collection;

/**
 *  HOW TO USE
 * ============
 *
 * For correct work, a model has to implement the interface `App\Models\LandingPage\Interfaces\LandingPageBlocks::class`
 *
 * ============
 *
 * @method string getPageBlocksDataPropertyName() // @see App\Models\LandingPage\Interfaces\LandingPageBlocks::class
 */
trait HasPageBlocks
{
    /** @var Block[]|Collection  */
    private ?Collection $_blocks = null;

    /**
     * @param Block[] $blocks
     *
     * @return $this
     */
    public function saveBlocks(Collection $blocks): self
    {
        $this->validateInstance();

        $blocks_data = [];

        foreach ($blocks as $block) {
            $blocks_data[] = $block->toArray();
        }

        $this->{$this->getPageBlocksDataPropertyName()} = $blocks_data;

        $this->save();

        return $this;
    }

    /**
     * @return string[]
     */
    public static function getAllowedBlocks() : array
    {
        return array_keys(Block::getTypesList());
    }

    /**
     * @return Block[]|Collection
     */
    public function getBlocks(): Collection
    {
        $this->validateInstance();

        if ($this->_blocks) {
            return $this->_blocks;
        }

        $this->_blocks = collect();

        if (!$this->{$this->getPageBlocksDataPropertyName()}) {
            return $this->_blocks;
        }

        foreach ($this->{$this->getPageBlocksDataPropertyName()} as $properties) {
            $this->_blocks[] = Block::factory($properties['block_type'], $properties);
        }

        return $this->_blocks;
    }

    /**
     *
     */
    private function validateInstance()
    {
        if (!$this instanceof PageBlocksInterface) {
            throw new \LogicException('The instance has implements interface `' . PageBlocksInterface::class . '`');
        }
    }
}
