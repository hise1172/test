Конструктор сторінок
====

Складається з двох архітектурних частин
1. Редактор
2. Виведення даних на сайті

### 1. Редактор

Збирає інформацію в потрібному форматі даних (json) і передає її в модель, яка зберігає в базу.

Редактор знає про те, які дані мають переклад, а які ні (типи властивостей).
Валідація даних відбувається на рівні кожного окремого поля.

### 2. Виведення даних на сайті

Складається з:
1. Моделі представлення
2. Контролера
3. Шаблонів для відбудови потрібних блоків

Валідація даних відбувається на рівні окремих блоків, які самі знаю, як валідувати свої поля.

## Реалізація моделі 

Ви можете додати до сторінки якоїсь моделі конструктор блоків. Для цього потрібно:
1. Імплементувати інтерфейс `App\Libs\PageConstructor\Interfaces\PageBlocksInterface::class`
2. Додати trait у модель `App\Libs\PageConstructor\Traits\HasPageBlocks::class`
3. Реалізувати всі необхідні методи.

Використовуйте метод `static::getAllowedBlocks()`. @see `App\Libs\PageConstructor\Traits\HasPageBlocks::getAllowedBlocks()`


## Додати новий блок

1. Додати в клас `App\Libs\PageConstructor\Block::class` нову константу типу блоку. Для прикладу, приймемо, що значення константи `about_us`,
2. Додати константу блока в метод `App\Libs\PageConstructor\Block::getTypesList()` і вказати назву блоку, яка виводитиметься в адмінці,
3. Реалізувати нову модель, наслідувану від `App\Libs\PageConstructor\Block::class`. В нашому випадку, ім'я класу модулі буде `App\Libs\PageConstructor\Block\AboutUs::class`, 
4. Реалізувати клас, наслідуваний від `App\Nova\Field\PageConstructor\BlockFields::class`. Його неймспейс та ім'я мають відповідати шаблону `App\Nova\Field\PageConstructor\BlockFields\{block_class_name}Fields`, в нашому прикладі: `\App\Nova\Field\PageConstructor\BlockFields\AboutUsFields::class`,
5. Додати шаблон блоку у папку `views/page-constructor/blocks/{block_type}.blade.php`.


## Групові поля (Поля-об'єкти)

Для того, щоб сворити групу подів з наступною структурою:

```
{
    group_name: [
        {
            "title": 123,
            "deacription": 123,
            "url": 123
        }
        ...
    ]
}
```

Потрібно в Nove вказати наступну структуру ключа поля `{group_name}_{i}_{property_name}`, наприклад `category_0_title` або `category_0_url`.

### Доступ до групових полів у в'юхах

```blade
@foreach($block->getPropertiesGroup('category') as $item)
    {{ $item['title'] }}
    {{ $item['deacription'] }}
    {{ $item['url'] }}
@endforeach
```

> !!! Важливо !!! використання `_` в імені властивості проведе до неочікуваної структури масиву, тому не використовуйте `snake_case` як ім'я властивості
> Тобто замість `category_0_short_description` треба використовувати `category_0_shortDescription` або `category_0_short-description` або будь який інший стиль.

> Вкладеність масиву нічим не обмежена, тому ви можете робити будь-яку структуру, розділяючи ключі `_`.
