<?php

namespace App\Libs\PageConstructor\Interfaces;

use App\Libs\PageConstructor\Block;
use Illuminate\Support\Collection;

interface PageBlocksInterface
{
    /**
     * @param Block[] $block
     *
     * @return $this
     */
    public function saveBlocks(Collection $blocks): self;

    /**
     * @see Block::getTypesList()
     *
     * @return string[]
     * [
     *      block_type_1,
     *      block_type_2,
     *      ...
     * ]
     */
    public static function getAllowedBlocks(): array;

    /**
     * @return Block[]|Collection
     */
    public function getBlocks(): Collection;

    /**
     * @return string
     */
    public function getPageBlocksDataPropertyName(): string;
}
