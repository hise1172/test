<?php


namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;

/**
 * Class NovaPoshtaService
 * @package App\Services
 */
class NovaPoshtaService
{
    const BASE_URL = 'https://api.novaposhta.ua/v2.0/json/';

    /**
     * @param $modelName
     * @param $calledMethod
     * @param array $methodProperties
     * @return array
     */
    private function body($modelName, $calledMethod, $methodProperties = [])
    {
        $data = array_merge([
            'apiKey' => env('NOVAPOSHTA_KEY'),
        ], compact('modelName', 'calledMethod'));
        if (!empty($methodProperties)) {
            $data = array_merge($data, compact('methodProperties'));
        }
        return $data;
    }

    /**
     * @param $data
     * @return mixed
     */
    private function request($data)
    {
        $client = new Client();
        $headers = ['Content-type' => 'application/json'];
        $response = $client->post(self::BASE_URL, [
            RequestOptions::JSON => $data,
            'headers' => $headers
        ]);
        return json_decode($response->getBody()->getContents(), true, 512, JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed
     */
    public function getAreas()
    {
        $data = $this->body('Address', 'getAreas');
        return $this->request($data);
    }

    public function getCities()
    {
        $data = $this->body('Address', 'getCities');
        return $this->request($data);
    }

    public function getWarehouse()
    {
        $data = $this->body('AddressGeneral', 'getWarehouses');
        return $this->request($data);
    }
}
