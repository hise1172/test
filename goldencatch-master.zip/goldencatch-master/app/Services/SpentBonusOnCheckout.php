<?php

namespace App\Services;

use App\DataContainers\AbstractDataContainer;
use App\Helpers\Cart;
use App\Models\BonusHistory;
use App\Models\Order;
use App\Models\UserPromotion;
use App\User;

/**
 * @property User user
 * @property Order order
 * @property Cart cart
 */
class SpentBonusOnCheckout extends AbstractDataContainer
{
    /**
     * @param User $user
     * @param Order $order
     * @param Cart $cart
     *
     * @return static
     */
    public static function build(User $user, Order $order, Cart $cart)
    {
        return static::make([
            'user' => $user,
            'order' => $order,
            'cart' => $cart,
        ]);
    }

    /**
     * @return $this
     */
    public function execute()
    {
        $this->processPromotions();

        $this->order->usedBonus()->save(new BonusHistory([
            'user_id' => $this->order->user_id,
            'amount' => -$this->cart->getDiscount(),
        ]));

        return $this;
    }

    /**
     * Gets available bonuses and write off those
     */
    private function processPromotions()
    {
        $total_cart_sum = $this->cart->getTotalSumm()->UAH;
        $tmp_total_bonus_amount = $this->user->getAvailablePromosDiscount($total_cart_sum);
        $available_promo_discount = 0;
        $affected_user_promos = collect();

        // Define available bonuses
        foreach ($this->user->getAvailalePromos($total_cart_sum) as $user_promo) {
            $available_bonus = $user_promo->getDiscount();
            $available_promo_discount += $available_bonus;
            $tmp_total_bonus_amount -= $available_bonus;

            $affected_user_promos[] = $user_promo;

            if ($tmp_total_bonus_amount <= 0) {
                break;
            }
        }

        $available_promo_discount = $this->cart->getDiscount() >= $available_promo_discount
            ? $available_promo_discount
            : $this->cart->getDiscount()
        ;

        if ($available_promo_discount <= 0) {
            return;
        }

        $tmp_total_bonus_amount = $available_promo_discount;

        // Add bonuses to the history, because it will subtract with order
        foreach ($affected_user_promos as $user_promo) {
            $available_bonus = $user_promo->getDiscount();

            $spent_bonus = $tmp_total_bonus_amount < $available_bonus
                ? $tmp_total_bonus_amount
                : $available_bonus;

            $tmp_total_bonus_amount -= $available_bonus;

            $user_promo
                ->spentBonuses()
                ->save(new BonusHistory([
                    'user_id' => $this->order->user_id,
                    'amount' => $spent_bonus,
                    'comment' => 'Because Order ID ' . $this->order->id,
                ]));

            switch (true) {
                case $spent_bonus == $available_bonus:
                    $user_promo->status_id = UserPromotion::STATUS_USED;
                    break;

                case $spent_bonus < $available_bonus:
                    $user_promo->status_id = UserPromotion::STATUS_PARTIAL_USAGE;
                    break;
            }

            $user_promo->save();

            if ($tmp_total_bonus_amount <= 0) {
                break;
            }
        }
    }
}
