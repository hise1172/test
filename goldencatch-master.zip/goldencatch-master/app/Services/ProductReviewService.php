<?php

namespace App\Services;

use App\Helpers\FileUploaded;
use App\Http\Requests\ProductReviewStore;
use App\Models\ReviewAttach;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

/**
 * Class ProductReviewService
 * @package App\Services
 */
class ProductReviewService
{
    /**
     * @param ProductReviewStore $reviewStore
     * @return array
     */
    public function getReviewData(ProductReviewStore $reviewStore)
    {
        $review = $reviewStore->except('photo');
        Arr::set($review, 'user_id', Auth::id());
        if( \Auth::user()->getRole()->isExpert() || \Auth::user()->getRole()->isAdmin() ){
            Arr::set($review, 'is_moderated', 1);
            Arr::set($review, 'is_expert', 1);
        }
        return $review;
    }

    public function storeImageAttach(ProductReviewStore $reviewStore, $product_reviews_id)
    {
        $photos = $reviewStore->file('photo', []);
        $userReview = FileUploaded::saveUserReview($photos);
        foreach ($userReview as $item) {
            $path = $item['path'];
            $type = $item['type'];
            ReviewAttach::create(compact('product_reviews_id', 'path', 'type'));
        }
        return back();
    }
}
