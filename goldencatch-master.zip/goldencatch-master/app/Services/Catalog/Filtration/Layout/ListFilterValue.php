<?php

namespace App\Services\Catalog\Filtration\Layout;

class ListFilterValue
{
    private string $slug;

    private string $name;

    private int $count;

    private bool $isHidden = true;

    private bool $isActive = false;

    public function __construct(array $valueData)
    {
        $this->slug = (string)($valueData['slug'] ?? '');
        $this->name = (string)($valueData['name'] ?? '');
        $this->count = (int)($valueData['count'] ?? 0);
    }

    /**
     * @return ListFilterValue
     */
    public function setToShown(): ListFilterValue
    {
        $this->isHidden = false;

        return $this;
    }

    /**
     * @return ListFilterValue
     */
    public function setToActive(): ListFilterValue
    {
        $this->isActive = true;

        return $this;
    }

    /**
     * @return bool
     */
    public function isHidden(): bool
    {
        return $this->isHidden;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getSlug(): string
    {
        return $this->slug;
    }

    /**
     * @return int
     */
    public function getCount(): int
    {
        return $this->count;
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return $this->isActive;
    }

}
