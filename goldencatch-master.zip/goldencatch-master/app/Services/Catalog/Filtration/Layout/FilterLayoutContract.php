<?php

namespace App\Services\Catalog\Filtration\Layout;

use Illuminate\Contracts\View\View;

interface FilterLayoutContract
{
    public function setViewName(string $viewName);

    public function getView(): View;
}
