<?php

namespace App\Services\Catalog\Filtration\Layout;

use Illuminate\Support\Facades\View;
use Illuminate\Contracts\View\View as ViewContract;

class RangeFilter extends BaseFilter
{
    private int $allowableMin;

    private int $allowableMax;

    private int $currentMin;

    protected int $currentMax;

    protected string $viewName;

    /**
     * @param array $allowable
     * @param array $current
     */
    public function __construct(array $allowable, array $current)
    {
        $this->allowableMin = (int)($allowable['min'] ?? 0);
        $this->allowableMax = (int)($allowable['max'] ?? 0);

        $this->currentMin = (int)($current['min'] ?? 0);
        $this->currentMax = (int)($current['max'] ?? 0);
    }

    public function getAllowableMin(): int
    {
        return $this->allowableMin;
    }

    public function getAllowableMax(): int
    {
        return $this->allowableMax;
    }

    public function getCurrentMin(): int
    {
        if (
            !$this->currentMin
            || $this->currentMin < $this->allowableMin
            || $this->currentMin > $this->allowableMax
        ) {
            return $this->allowableMin;
        }

        return $this->currentMin;
    }

    public function getCurrentMax(): int
    {
        if (
            !$this->currentMax
            || $this->currentMax > $this->allowableMax
            || $this->currentMax < $this->allowableMin
        ) {
            return $this->allowableMax;
        }

        return $this->currentMax;
    }

    /**
     * @return bool
     */
    public function hasDisplayFilter(): bool
    {
        return (
                $this->allowableMax
                && $this->allowableMin != $this->allowableMax
            )
            || $this->currentMax
        ;
    }
}
