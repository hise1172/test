<?php

namespace App\Services\Catalog\Filtration\Layout;

use Illuminate\Contracts\View\View as ViewContract;
use Illuminate\Support\Facades\View;

class BaseFilter implements FilterLayoutContract
{
    private string $viewName;
    private array $viewData = [];

    private string $filterName;

    private string $filterId;

    /**
     * @return string
     */
    public function getFilterId(): string
    {
        return $this->filterId;
    }

    #region Setters

    /**
     * @param string $filterId
     * @return BaseFilter
     */
    public function setFilterId(string $filterId): BaseFilter
    {
        $this->filterId = $filterId;

        return $this;
    }

    /**
     * @param string $filterName
     * @return BaseFilter
     */
    public function setFilterName(string $filterName): BaseFilter
    {
        $this->filterName = $filterName;

        return $this;
    }

    /**
     * @param string $viewName
     * @return $this
     */
    public function setViewName(string $viewName): self
    {
        $this->viewName = $viewName;

        return $this;
    }

    /**
     * @param array $data
     *
     * @return $this
     */
    public function setViewData(array $data): self
    {
        $this->viewData = $data;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->filterName;
    }

    /**
     * @return ViewContract
     */
    public function getView(): ViewContract
    {
        return View::make($this->viewName, ['filter' => $this] + $this->viewData);
    }

    #endregion
}
