<?php

namespace App\Services\Catalog\Filtration\Layout;

use Illuminate\Support\Collection;

class ListFilter extends BaseFilter
{
    private $shownValuesLimit = 6;

    private Collection $values;

    public function __construct(Collection $allowableValues)
    {
        $this->values = $allowableValues->sortByDesc(function (ListFilterValue $filterValue) { return $filterValue->getCount(); })
            ->filter(function (ListFilterValue $filterValue) { return $filterValue->getCount() > 0; });

        $needToShown = ($this->shownValuesLimit - $this->getActiveValues()->count());
        if ($needToShown > 0) {
            $this->getHiddenValues()->slice(0, $needToShown)->each(fn (ListFilterValue $filterValue) => $filterValue->setToShown());
        }
    }

    public function setActiveValues(Collection $activeValues)
    {
        if ($activeValues->isNotEmpty()) {
            $this->values->each(function (ListFilterValue $filterValue) use ($activeValues) {
                if ($activeValues->contains($filterValue->getSlug())) {
                    $filterValue->setToActive()->setToShown();
                }
            });
        }

        return $this;
    }

    public function getActiveValues(): Collection
    {
        return $this->values->filter(fn(ListFilterValue $filterValue) => $filterValue->isActive());
    }

    public function getShownValues(): Collection
    {
        return $this->values->filter(fn(ListFilterValue $filterValue) => (!$filterValue->isActive() && !$filterValue->isHidden()));
    }

    public function getHiddenValues(): Collection
    {
        return $this->values->filter(fn(ListFilterValue $filterValue) => $filterValue->isHidden());
    }

}
