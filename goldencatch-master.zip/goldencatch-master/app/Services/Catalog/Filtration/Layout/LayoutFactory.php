<?php

namespace App\Services\Catalog\Filtration\Layout;

use App\Models\Brand;
use App\Models\Category;
use App\Services\Catalog\Filtration\Filter;
use App\Services\Catalog\Filtration\FilterValue;
use App\Services\Catalog\Repository as CatalogRepository;
use App\Services\Catalog\Routing\RouteParams;
use Illuminate\Support\Collection;

/**
 * Class LayoutFactory
 *
 * @package App\Services\Catalog\Filtration\Layout
 */
class LayoutFactory
{
    /** @var CatalogRepository */
    private $_catalog_repository;

    #region Actions

    /**
     * @return ListFilter
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function makeCategoryFilter(string $view_namespace): ListFilter
    {
        $allowableValues = collect();
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        $this->getCatalogRepository()
            ->getCategoryFilterValues()
            ->each(function (Category $category) use ($allowableValues) {
                $allowableValues->push([
                    'slug' => $category->slug,
                    'name' => $category->name,
                    'count' => $category->productsCount,
                ]);
            });

        return (new ListFilter($allowableValues->mapInto(ListFilterValue::class)))
            ->setViewName("livewire.{$view_namespace}.list-filter")
            ->setFilterName(__('catalog.filters.category'))
            ->setFilterId(RouteParams::PARAM_NAME__CATEGORY)
            ->setActiveValues(
                $routeParams->has(RouteParams::PARAM_NAME__CATEGORY)
                    ? $routeParams->get(RouteParams::PARAM_NAME__CATEGORY)->getValues()
                    : collect()
            );
    }

    /**
     * @return ListFilter
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function makeBrandFilter(string $view_namespace): ListFilter
    {
        $allowableValues = collect();
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        $this->getCatalogRepository()
            ->getBrandFilterValues()
            ->each(function (Brand $brand) use ($allowableValues) {
                $allowableValues->push([
                    'slug' => $brand->slug,
                    'name' => $brand->name,
                    'count' => $brand->productsCount,
                ]);
            });

        return (new ListFilter($allowableValues->mapInto(ListFilterValue::class)))
            ->setViewName("livewire.{$view_namespace}.list-filter")
            ->setFilterName(__('catalog.filters.brand'))
            ->setFilterId(RouteParams::PARAM_NAME__BRAND)
            ->setActiveValues(
                $routeParams->has(RouteParams::PARAM_NAME__BRAND)
                    ? $routeParams->get(RouteParams::PARAM_NAME__BRAND)->getValues()
                    : collect()
            );
    }

    /**
     * @param string $view_namespace
     * @param int $min_price
     * @param int $max_price
     *
     * @return RangeFilter
     */
    public function makePriceFilter(string $view_namespace): RangeFilter
    {
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        if ($routeParams->has(RouteParams::PARAM_NAME__PRICE)) {
            $currentValues = [
                'min' => $routeParams->get(RouteParams::PARAM_NAME__PRICE)->getValues()->first(null, 0),
                'max' => $routeParams->get(RouteParams::PARAM_NAME__PRICE)->getValues()->last(null, 0),
            ];
        } else {
            $currentValues = ['min' => null, 'max' => null,];
        }

        $extreme_values = $this->getCatalogRepository()
            ->getPriceFilterValues();

        return (new RangeFilter(['min' => $extreme_values['min_price'], 'max' => $extreme_values['max_price']], $currentValues))
            ->setViewName("livewire.{$view_namespace}.price");
    }

    /**
     * @param string $view_namespace
     * @param int $min_weight
     * @param int $max_weight
     *
     * @return RangeFilter
     */
    public function makeWeightFilter(string $view_namespace): RangeFilter
    {
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        if ($routeParams->has(RouteParams::PARAM_NAME__WEIGHT)) {
            $currentValues = [
                'min' => $routeParams->get(RouteParams::PARAM_NAME__WEIGHT)->getValues()->first(null, 0),
                'max' => $routeParams->get(RouteParams::PARAM_NAME__WEIGHT)->getValues()->last(null, 0),
            ];
        } else {
            $currentValues = ['min' => null, 'max' => null,];
        }

        $extreme_values = $this->getCatalogRepository()
            ->getWeightFilterValues();

        return (new RangeFilter(['min' => $extreme_values['min_weight'], 'max' => $extreme_values['max_weight']], $currentValues))
            ->setViewName("livewire.{$view_namespace}.weight");
    }

    /**
     * @param string $view_namespace
     *
     * @return RangeFilter
     */
    public function makeSpecificFilter(string $view_namespace): ListFilter
    {
        $allowableValues = collect();
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        $this->getCatalogRepository()
            ->getSpecificFilterValues()
            ->each(function ($data) use ($allowableValues) {
                $allowableValues->push([
                    'slug' => $data['slug'],
                    'name' => $data['name'],
                    'count' => $data['productsCount'],
                ]);
            });

        return (new ListFilter($allowableValues->mapInto(ListFilterValue::class)))
            ->setViewName("livewire.{$view_namespace}.list-filter")
            ->setFilterName(__('catalog.filters.specific'))
            ->setFilterId(RouteParams::PARAM_NAME__SPECIFIC)
            ->setActiveValues(
                $routeParams->has(RouteParams::PARAM_NAME__SPECIFIC)
                    ? $routeParams->get(RouteParams::PARAM_NAME__SPECIFIC)->getValues()
                    : collect()
            );
    }

    /**
     * @param string $view_namespace
     *
     * @return Collection
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function makeAttributeFilters(string $view_namespace): Collection
    {
        $attributeFiltersLayout = collect();
        $routeParams = $this->getCatalogRepository()->getRouteParams();

        $this->getCatalogRepository()
            ->getFilters()
            ->each(function (Filter $filter) use ($attributeFiltersLayout, $routeParams, $view_namespace) {
                $filterLayout = new ListFilter(
                    $filter->getValues()->map(function (FilterValue $filterValue) {
                        return new ListFilterValue([
                            'slug' => $filterValue->getSlug(),
                            'name' => $filterValue->getValue(),
                            'count' => $filterValue->getCount(),
                        ]);
                    })
                );

                $filterLayout->setViewName("livewire.{$view_namespace}.list-filter")
                    ->setFilterName($filter->getName())
                    ->setFilterId($filter->getSlug());

                if ($routeParams->has($filter->getSlug())) {
                    $filterLayout->setActiveValues($routeParams->get($filter->getSlug())->getValues());
                }

                $attributeFiltersLayout->push($filterLayout);
            });

        return $attributeFiltersLayout;
    }

    #endregion

    #region Setters

    /**
     * @param CatalogRepository $repository
     *
     * @return $this
     */
    public function setCatalogRepository(CatalogRepository $repository)
    {
        $this->_catalog_repository = $repository;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return CatalogRepository
     */
    protected function getCatalogRepository()
    {
        return $this->_catalog_repository ?? ($this->_catalog_repository = app()->make(CatalogRepository::class));
    }

    #endregoion
}
