<?php

namespace App\Services\Catalog\Filtration;

use App\Models\AttributeSlugValue;

class FilterValue
{
    private string $value;

    private string $slug;

    private int $count;

    public function __construct(AttributeSlugValue $attributeSlugValue)
    {
        $this->value = $attributeSlugValue->value;
        $this->slug = $attributeSlugValue->slug;
        $this->count = $attributeSlugValue->getProductsCount();
    }

    public function getValue(): string
    {
        return $this->value;
    }

    public function getSlug(): string
    {
        return $this->slug;
    }

    public function getCount(): int
    {
        return $this->count;
    }
}
