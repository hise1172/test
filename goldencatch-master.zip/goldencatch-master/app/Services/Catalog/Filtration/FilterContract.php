<?php

namespace App\Services\Catalog\Filtration;

interface FilterContract
{

}
