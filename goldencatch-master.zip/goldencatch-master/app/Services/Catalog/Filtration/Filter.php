<?php

namespace App\Services\Catalog\Filtration;

use App\Models\Attribute;
use Illuminate\Support\Collection;

class Filter
{
    const FILTER_TYPE_SLUG = 1;
    const DEFAULT_POSITION = 100;

    private int $attributeId;

    private string $name;

    private string $slug;

    private int $position;

    private int $type;

    private Collection $values;

    public function __construct(Attribute $attribute)
    {
        $this->attributeId = $attribute->id;
        $this->name = $attribute->filter_name;
        $this->slug = $attribute->filter_slug;
        $this->position = $attribute->filter_position ?? static::DEFAULT_POSITION;
        $this->type = self::FILTER_TYPE_SLUG;

        $this->values = collect();
    }

    public function setValue(Collection $filterValue)
    {
        $this->values = $this->values->merge($filterValue);
    }

    public function getId()
    {
        return $this->attributeId;
    }

    public function getSlug(): string
    {
        return $this->slug;
    }

    public function getValues(): Collection
    {
        return $this->values;
    }

    public function getType(): int
    {
        return $this->type;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function hasType(int $type): bool
    {
        return $this->type == $type;
    }

    /**
     * @return mixed|string
     */
    public function getName(): string
    {
        return $this->name;
    }
}
