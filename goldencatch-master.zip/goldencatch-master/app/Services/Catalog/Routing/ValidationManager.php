<?php

namespace App\Services\Catalog\Routing;

use App\Services\Catalog\Filtration\Filter;
use App\Services\Catalog\Repository;
use App\Services\Catalog\Routing\Validators\{BrandParamValidator,
    CategoryParamValidator,
    FilterAttributeValidator,
    ParamValidatorContract,
    MinMaxParamValidator};
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Support\Collection;

/**
 * Class RouteValidator
 * @package App\Services\Catalog\Routing
 */
class ValidationManager
{
    private Repository $repository;

    private ?RouteParams $routeParams;

    /** @var array ParamValidatorContract[] */
    private array $paramsValidators = [];

    /**
     * RouteValidator constructor.
     * @throws BindingResolutionException
     */
    public function __construct()
    {
        $this->repository = app()->make(Repository::class);
    }

    public function reset()
    {
        $this->routeParams = null;
    }

    public function validateRouteParams(RouteParams $routeParams): bool
    {
        $this->routeParams = $routeParams;
        $this->initParamsValidators();

        if (!$this->validatePositions()) {
            return false;
        }

        /** @var ParamValidatorContract $paramValidator */
        foreach ($this->paramsValidators as $paramName => $paramValidator) {
            if (!$paramValidator->validate($this->routeParams->get($paramName)->getValues())) {
                return false;
            }
        }

        return true;
    }

    public function validateParam(string $paramName, string $paramValue): bool
    {
        $this->routeParams = (new RouteParams())->appendTo($paramName, $paramValue);
        $this->initParamsValidators();

        /** @var ParamValidatorContract $paramValidator */
        foreach ($this->paramsValidators as $paramName => $paramValidator) {
            if (!$paramValidator->validate($this->routeParams->get($paramName)->getValues())) {
                return false;
            }
        }

        return true;
    }

    private function initParamsValidators(): void
    {
        $this->initStaticParamsValidators();

        if ($this->routeParams->getDynamic()->isNotEmpty()) {
            $dynamicFilters = $this->repository->getFiltersBySlug($this->routeParams->getDynamic()->keys()->toArray());
            foreach ($dynamicFilters as $dynamicFilter) {
                switch ($dynamicFilter->getType()) {
                    case Filter::FILTER_TYPE_SLUG:
                        $this->setParamValidator(
                            $dynamicFilter->getSlug(),
                            new FilterAttributeValidator($dynamicFilter)
                        );
                        break;
                }
            }
        }
    }

    /**
     * @return void
     */
    private function initStaticParamsValidators(): void
    {
        if ($this->routeParams->has(RouteParams::PARAM_NAME__CATEGORY)) {
            $this->setParamValidator(RouteParams::PARAM_NAME__CATEGORY, new CategoryParamValidator());
        }

        if ($this->routeParams->has(RouteParams::PARAM_NAME__BRAND)) {
            $this->setParamValidator(RouteParams::PARAM_NAME__BRAND, new BrandParamValidator());
        }

        if ($this->routeParams->has(RouteParams::PARAM_NAME__PRICE)) {
            $this->setParamValidator(RouteParams::PARAM_NAME__PRICE, new MinMaxParamValidator());
        }

        if ($this->routeParams->has(RouteParams::PARAM_NAME__WEIGHT)) {
            $this->setParamValidator(RouteParams::PARAM_NAME__WEIGHT, new MinMaxParamValidator());
        }
    }

    private function setParamValidator(string $paramName, ParamValidatorContract $validator): void
    {
        $this->paramsValidators[$paramName] = $validator;
    }

    /**
     * @return bool
     */
    private function validatePositions(): bool
    {
        $currentPositions = $this->routeParams->getAll()->sortBy(fn(RouteParam $routeParam) => $routeParam->getPosition())->keys();

        return static::getRouteParamsOrder($this->routeParams)
            ->diffAssoc($currentPositions)
            ->isEmpty();
    }

    /**
     * @param RouteParams $routeParams
     *
     * @return Collection
     */
    public static function getRouteParamsOrder(RouteParams $routeParams): Collection
    {
        $correctPositions = collect();
        $repository = app()->make(Repository::class);

        foreach ($routeParams->getAllowableStatic() as $paramName) {
            if ($routeParams->has($paramName)) {
                $correctPositions->push($paramName);
            }
        }

        $dynamicFilters = $repository->getFiltersBySlug($routeParams->getDynamic()->keys()->toArray())
            ->sortBy(fn(Filter $filter) => $filter->getPosition());

        /** @var Filter $filter */
        foreach ($dynamicFilters as $filter) {
            $correctPositions->push($filter->getSlug());
        }

        return $correctPositions;
    }
}
