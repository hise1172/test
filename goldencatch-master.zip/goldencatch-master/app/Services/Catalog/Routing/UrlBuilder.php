<?php

namespace App\Services\Catalog\Routing;

use App\Models\Category;

/**
 * Class UrlBuilder
 *
 * @package App\Services\Catalog\Routing
 */
class UrlBuilder
{
    private const CATALOG_ROUTE_NAME = 'catalog';
    private const WHOLESALE_CATALOG_ROUTE_NAME = 'wholesale-catalog';

    private RouteParams $routeParams;

    private ?Category $category;

    private array $queryParams = [];
    private string $basec_route_name = self::CATALOG_ROUTE_NAME;

    /**
     * UrlBuilder constructor.
     *
     * @param RouteParams $routeParams
     * @param Category|null $category
     * @param array $queryParams
     */
    public function __construct(RouteParams $routeParams, ?Category $category = null, array $queryParams = [])
    {
        $this->routeParams = $routeParams;
        $this->category = $category;
        $this->queryParams = $queryParams;
    }

    #region Builders

    /**
     * @param RouteParams $routeParams
     * @param Category|null $category
     * @param array $queryParams
     *
     * @return static
     */
    public static function catalog(RouteParams $routeParams, ?Category $category = null, array $queryParams = [])
    {
        $object = new static($routeParams, $category, $queryParams);
        $object->basec_route_name = self::CATALOG_ROUTE_NAME;

        return $object;
    }

    /**
     * @param RouteParams $routeParams
     * @param Category|null $category
     * @param array $queryParams
     *
     * @return static
     */
    public static function wholesaleCatalog(RouteParams $routeParams, ?Category $category = null, array $queryParams = [])
    {
        $object = new static($routeParams, $category, $queryParams);
        $object->basec_route_name = self::WHOLESALE_CATALOG_ROUTE_NAME;

        return $object;
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function get()
    {
        return route($this->getRouteName(), $this->getRouteParams(), false);
    }

    /**
     * @return string
     */
    private function getRouteName()
    {
        if (!$this->category) {
            if ($this->basec_route_name === self::WHOLESALE_CATALOG_ROUTE_NAME) {
                return $this->basec_route_name . (
                    $this->routeParams->getAll()->isNotEmpty()
                        ? '.filter'
                        : ''
                    );
            }

            return 'catalog.filter';
        }

        if ($this->routeParams->getAll()->isEmpty() && $this->basec_route_name !== self::WHOLESALE_CATALOG_ROUTE_NAME) {
            return 'category.filter';
        }

        return $this->basec_route_name . '.filters';
    }

    /**
     * @return array
     */
    private function getRouteParams()
    {
        $routeParamsArr = [];

        if ($this->category) {
            $routeParamsArr['category'] = $this->category->slug;
        }

        if ($this->routeParams->getAll()->isNotEmpty()) {
            $filterKey = 1;
            $filterPrefix = 'filter';

            foreach (ValidationManager::getRouteParamsOrder($this->routeParams) as $paramName) {
                $routeParamsArr[$filterPrefix.$filterKey] = $paramName
                    . RouteParams::PARAM_SEPARATOR
                    . $this->routeParams->get($paramName)->getValues()->join(RouteParams::PARAM_VALUE_SEPARATOR);

                $filterKey++;
            }
        }

        return array_merge($routeParamsArr, $this->queryParams);
    }

    #endregion
}
