<?php

namespace App\Services\Catalog\Routing\Validators;

use Illuminate\Support\Collection;

class PriceParamValidator extends AbstractParamValidator
{
    public function validate(Collection $values): bool
    {
        if (empty($values)) {
            return true;
        }

        $minPrice = $values->first();
        $maxPrice = $values->last();
        if ($minPrice >= $maxPrice) {
            $this->message = 'Min price higher than max price';
            return false;
        }

        return true;
    }
}
