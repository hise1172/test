<?php

namespace App\Services\Catalog\Routing\Validators;

use App\Services\Catalog\Filtration\Filter;
use App\Services\Catalog\Filtration\FilterValue;
use App\Services\Catalog\Repository;
use Illuminate\Support\Collection;

class FilterAttributeValidator extends AbstractParamValidator
{
    private Repository $repository;

    private Filter $filter;

    public function __construct(Filter $filter)
    {
        $this->filter = $filter;
    }

    public function validate(Collection $values): bool
    {
        $validFilterValues = $this->filter->getValues()->filter(
            fn(FilterValue $filterValue) => $values->contains($filterValue->getSlug())
        );

        if ($validFilterValues->count() !== $values->count()) {
            $this->message = 'Invalid filter values count';
            return false;
        }

        $index = 0;
        /** @var FilterValue $filterValue */
        $sortedValues = $validFilterValues->sortBy(function (FilterValue $filterValue) { return $filterValue->getSlug(); });
        foreach ($sortedValues as $filterValue) {
            if ($filterValue->getSlug() !== $values->get($index)) {
                $this->message = 'Invalid values sorting';
                return false;
            }
            $index++;
        }

        return true;
    }


}
