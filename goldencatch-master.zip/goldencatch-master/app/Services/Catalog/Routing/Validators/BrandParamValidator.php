<?php

namespace App\Services\Catalog\Routing\Validators;

use App\Services\Catalog\Repository;
use Illuminate\Support\Collection;

class BrandParamValidator extends AbstractParamValidator
{
    private Repository $repository;

    public function __construct()
    {
        $this->repository = app()->make(Repository::class);
    }

    public function validate(Collection $values): bool
    {
        if ($values->isEmpty()) {
            return true;
        }

        $brands = $this->repository->getBrandsBySlug($values->toArray());
        if ($brands->count() !== $values->count()) {
            $this->message = 'Values count invalid';
            return false;
        }

        $index = 0;
        foreach ($brands->sortBy('slug') as $brand) {
            if ($brand->slug !== $values->get($index)) {
                $this->message = 'Slug position invalid';
                return false;
            }
            $index++;
        }

        return true;
    }
}
