<?php

namespace App\Services\Catalog\Routing\Validators;

use Illuminate\Support\Collection;

interface ParamValidatorContract
{
    public function validate(Collection $values): bool;

    public function message(): string;
}
