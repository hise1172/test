<?php

namespace App\Services\Catalog\Routing\Validators;

use App\Services\Catalog\Repository;
use Illuminate\Support\Collection;

class CategoryParamValidator extends AbstractParamValidator
{
    private Repository $repository;

    /**
     * CategoryParamValidator constructor.
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function __construct()
    {
        $this->repository = app()->make(Repository::class);
    }

    /**
     * @param Collection $values
     *
     * @return bool
     */
    public function validate(Collection $values): bool
    {
        if ($values->isEmpty()) {
            return true;
        }

        $categories = $this->repository->getCategoriesBySlug($values->toArray());

        if ($categories->count() !== $values->count()) {
            $this->message = 'Values count invalid';
            return false;
        }

        $index = 0;

        foreach ($categories->sortBy('slug') as $category) {
            if ($category->slug !== $values->get($index)) {
                $this->message = 'Slug position invalid';

                return false;
            }

            $index++;
        }

        return true;
    }
}
