<?php

namespace App\Services\Catalog\Routing\Validators;

abstract class AbstractParamValidator implements ParamValidatorContract
{
    protected string $message = '';

    public function message(): string
    {
        return $this->message;
    }
}
