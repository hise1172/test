<?php

namespace App\Services\Catalog\Routing;

use App\Services\Catalog\Repository;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

/**
 * Class RouteParams
 *
 * @package App\Services\Catalog\Routing
 */
class RouteParams
{
    public const PARAM_SEPARATOR = '-';

    public const PARAM_VALUE_SEPARATOR = ',';

    public const PARAM_NAME__CATEGORY = 'category';

    public const PARAM_NAME__BRAND = 'brand';

    public const PARAM_NAME__PRICE = 'price';

    public const PARAM_NAME__WEIGHT = 'weight';

    public const PARAM_NAME__SPECIFIC = 'specific';

    /** @var Collection */
    private Collection $params;

    protected array $skippedParams = ['locale', 'category'];

    /**
     * Params that always has static url position
     * @var array|string[]
     */
    private array $staticParams = [
        self::PARAM_NAME__CATEGORY,
        self::PARAM_NAME__BRAND,
        self::PARAM_NAME__PRICE,
        self::PARAM_NAME__WEIGHT,
        self::PARAM_NAME__SPECIFIC,
    ];

    public function __construct()
    {
        $this->params = collect();
    }

    /**
     * Init route params from http request
     * @param Request $request
     * @return $this
     */
    public function initFromRequest(Request $request): self
    {
        $paramIndex = 1;
        foreach ($request->route()->parameters() as $paramKey => $paramValue) {
            if (in_array($paramKey, $this->skippedParams)) {
                continue;
            }

            $routeParam = (new RouteParam(Str::before($paramValue, self::PARAM_SEPARATOR)))
                ->setPosition($paramIndex);

            $paramIndex++;

            $routeParamValues = collect(explode(self::PARAM_VALUE_SEPARATOR, Str::after($paramValue, self::PARAM_SEPARATOR)));
            $routeParam->setValues($routeParamValues);

            $this->params->put($routeParam->getSlug(), $routeParam);
        }

        return $this;
    }

    /**
     * @param array $params
     * @return $this
     */
    public function initFromExistsSetup(array $params): self
    {
        foreach ($params as $param) {
            if (in_array($param['slug'], $this->skippedParams)) {
                continue;
            }

            $routeParam = (new RouteParam($param['slug']))
                ->setPosition($param['position'])
                ->setValues(collect($param['values']));
            $this->params->put($routeParam->getSlug(), $routeParam);
        }

        return $this;
    }

    /**
     * @param string $paramName
     * @param string $paramValue
     */
    public function appendTo(string $paramName, string $paramValue)
    {
        $isNumericParam = in_array($paramName, [RouteParams::PARAM_NAME__PRICE, RouteParams::PARAM_NAME__WEIGHT]);

        if ($isNumericParam) {
            $paramValues = collect(explode(RouteParams::PARAM_VALUE_SEPARATOR, $paramValue));

            if ($this->has($paramName)) {
                $this->get($paramName)->setValues($paramValues);
            } else {
                $routeParam = new RouteParam($paramName);

                $position = $this->isStatic($paramName)
                    ? $this->getAllowableStatic()->search($paramName)
                    : app()->make(Repository::class)->getFiltersBySlug([$paramName])
                        ->first()
                        ->getPosition() + 10;

                $routeParam->setPosition($position)->setValues($paramValues);
                $this->params->put($routeParam->getSlug(), $routeParam);
            }
        } else {
            if ($this->has($paramName)) {
                $this->get($paramName)->toggleValue($paramValue);
            } else {
                $routeParam = (new RouteParam($paramName))->appendValue($paramValue);

                $position = $this->isStatic($paramName)
                    ? $this->getAllowableStatic()->search($paramName)
                    : app()->make(Repository::class)->getFiltersBySlug([$paramName])
                        ->first()
                        ->getPosition() + 10;

                $routeParam->setPosition($position);

                $this->params->put($routeParam->getSlug(), $routeParam);
            }
        }

        $this->params = $this->params->filter(fn(RouteParam $routeParam) => $routeParam->getValues()->isNotEmpty())
            ->sortBy(fn(RouteParam $routeParam) => $routeParam->getPosition());

        return $this;
    }

    public function getAll(): Collection
    {
        return $this->params;
    }

    public function getStatic(): Collection
    {
        return $this->params->filter(function ($paramValues, $paramName) {
            return in_array($paramName, $this->staticParams);
        });
    }

    public function isStatic(string $paramName): bool
    {
        return $this->getAllowableStatic()->contains($paramName);
    }

    public function getAllowableStatic(): Collection
    {
        return collect($this->staticParams);
    }

    public function getDynamic(): Collection
    {
        return $this->params->filter(fn($paramValues, $paramName) => !in_array($paramName, $this->staticParams));
    }

    public function has(string $paramName): bool
    {
        return $this->params->has($paramName);
    }

    public function get(string $paramName): ?RouteParam
    {
        return $this->params->get($paramName);
    }

    /**
     * Returns bool column name of product
     *
     * @return string[]
     */
    public static function getSpecificFiltersList()
    {
        return [
            'productsOfWeek' => 'is_product_of_week',
        ];
    }
}
