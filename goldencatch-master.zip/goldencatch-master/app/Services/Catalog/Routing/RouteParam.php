<?php

namespace App\Services\Catalog\Routing;

use Illuminate\Support\Collection;

class RouteParam
{
    private string $slug;

    private int $position;

    private Collection $values;

    public function __construct(string $slug)
    {
        $this->values = collect();
        $this->slug = $slug;
    }

    public function setPosition(int $position): self
    {
        $this->position = $position;

        return $this;
    }

    public function appendValue(string $value): self
    {
        $this->values->push($value);
        $this->resortValues();

        return $this;
    }

    public function setValues(Collection $values): self
    {
        $this->values = $values;

        return $this;
    }

    public function toggleValue(string $value): self
    {
        if ($this->values->contains($value)) {
            $this->values = $this->values->filter(fn ($v) => $v != $value);
            $this->resortValues();
        } else {
            $this->appendValue($value);
        }

        return $this;
    }


    public function getValues()
    {
        return $this->values;
    }

    public function getPosition()
    {
        return $this->position;
    }

    public function getSlug()
    {
        return $this->slug;
    }


    private function resortValues()
    {
        $this->values = $this->values->unique()->sort()->values();
    }

}
