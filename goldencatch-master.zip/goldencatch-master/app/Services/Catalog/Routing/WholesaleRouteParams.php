<?php

namespace App\Services\Catalog\Routing;

/**
 * Class WholesaleRouteParams
 *
 * @package App\Services\Catalog\Routing
 */
class WholesaleRouteParams extends RouteParams
{
    protected array $skippedParams = ['locale'];
}
