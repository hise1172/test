<?php

namespace App\Services\Catalog;

use App\Services\Catalog\Routing\WholesaleRouteParams;
use App\Models\{Attribute, AttributeSlugValue, Brand, Category, Product\Product, ProductsAttributesNumericValues};
use App\Services\Catalog\Filtration\Filter;
use App\Services\Catalog\Filtration\FilterValue;
use App\Services\Catalog\Routing\RouteParams;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use InvalidArgumentException;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Repository
{
    const GET_CART_ITEMS = -1; // get cart items
    const GET_PRODUCT_IDS = 'get_product_ids';

    private Collection $filtersStorage;

    private Collection $brandsStorage;

    private Collection $categoriesStorage;

    private RouteParams $routeParams;

    private string $searchString = '';

    private int $categoryId = 0;

    private int $requiresCatalogType = Catalog::TYPE_RETAIL;

    /**
     * Repository constructor.
     *
     * @param RouteParams $routeParams
     */
    public function __construct(RouteParams $routeParams)
    {
        $this->routeParams = $routeParams;
        $this->filtersStorage = collect();
        $this->brandsStorage = collect();
        $this->categoriesStorage = collect();
        DB::enableQueryLog();
    }

    #region Is Condition methods

    /**
     * @return bool
     */
    private function isWholesaleCatalog(): bool
    {
        return $this->getRouteParams() instanceof WholesaleRouteParams;
    }

    #endregion

    #region Setters

    /**
     * @param string $searchString
     * @return Repository
     */
    public function setSearchString(string $searchString): Repository
    {
        $this->searchString = Str::lower($searchString);

        return $this;
    }

    /**
     * @param int $categoryId
     * @return $this
     */
    public function setCategoryId(int $categoryId): Repository
    {
        $this->categoryId = $categoryId;

        return $this;
    }

    /**
     * @param bool $flag
     *
     * @return $this
     */
    public function setCatalogType(int $catalog_type): self
    {
        switch ($catalog_type) {
            case Catalog::TYPE_RETAIL:
            case Catalog::TYPE_WHOLESALE:
                break;

            default:
                throw new InvalidArgumentException('Invalid $catalog_type');
        }

        $this->requiresCatalogType = $catalog_type;

        return $this;
    }

    /**
     * @param RouteParams $routeParams
     *
     * @return $this
     */
    public function setRouteParams(RouteParams $routeParams)
    {
        $this->routeParams = $routeParams;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return RouteParams
     */
    public function getRouteParams()
    {
        return $this->routeParams;
    }

    /**
     * @param array $slugs
     * @return Collection
     */
    public function getFiltersBySlug(array $slugs): Collection
    {
        $untouchedSlugs = collect($slugs)->diff($this->filtersStorage->keys());
        if ($untouchedSlugs->isNotEmpty()) {
            $untouchedFilters = Attribute::query()
                ->where('is_filter', 1)
                ->whereIn('filter_slug', $untouchedSlugs)
                ->get()
                ->mapInto(Filter::class);
            $this->loadFiltersValues($untouchedFilters);

            /** @var Filter $untouchedFilter */
            foreach ($untouchedFilters as $untouchedFilter) {
                $this->filtersStorage->put($untouchedFilter->getSlug(), $untouchedFilter);
            }
        }

        return $this->filtersStorage->filter(function (Filter $filter) use ($slugs) {
            return in_array($filter->getSlug(), $slugs);
        });
    }

    /**
     * @param Collection $filters
     * @param array $loadingParams
     */
    public function loadFiltersValues(Collection &$filters, array $loadingParams = [])
    {
        $slugFilterIds = $filters->filter(function(Filter $filter) { return $filter->hasType(Filter::FILTER_TYPE_SLUG); })
            ->map(function(Filter $filter) { return $filter->getId(); });

        $values = AttributeSlugValue::query()
            ->whereIn('attribute_id', $slugFilterIds->toArray())
            ->get();

        $withProductsCount = (bool)($loadingParams['withProductsCount'] ?? false);

        if ($withProductsCount) {
            $products_query = $this->getProductsIdsQuery();

            // Grab all product IDs, parent and child which have needed attributes
            $slugValueProductIDs = DB::table('products_attributes_slug_values AS pasv')
                ->select('pasv.product_id')
                ->where(function (Builder $query) use ($products_query) {
                    $query->whereIn('pasv.product_id', $products_query)
                        ->orWhereIn(
                            'pasv.product_id',
                            Product::query()
                                ->select('id')
                                ->whereIn('parent_id', $products_query)
                        );
                });

            // Grab attribute_slug_value_ids for each parent product
            $slugValuesCount = DB::table('products_attributes_slug_values AS pasv')
                ->select(
                    'pasv.attribute_slug_value_id',
                    DB::raw('COUNT(p_par.id) AS productsCount')
                )
                ->join(Product::TABLE_NAME . ' AS p_par', function(JoinClause $query) {
                    $query->whereIn(
                        'p_par.id',
                        Product::query()
                            ->select(
                                DB::raw('COALESCE(parent_id, id) AS id'),
                            )
                            ->where('id', '=', DB::raw('pasv.product_id'))
                    );
                })
                ->whereIn('pasv.product_id', $slugValueProductIDs)
                ->groupBy('pasv.attribute_slug_value_id')
                ->groupBy('p_par.id');

            // Count the parent products for an attribute
            $slugValuesProductsCount = DB::table( DB::raw("({$slugValuesCount->toSql()}) AS sub") )
                ->select(
                    DB::raw('sub.attribute_slug_value_id'),
                    DB::raw('COUNT(sub.attribute_slug_value_id) AS productsCount')
                )
                ->mergeBindings($slugValuesCount)
                ->groupBy('sub.attribute_slug_value_id')
                ->get()
                ->keyBy('attribute_slug_value_id');

            foreach ($values as $key => $value) {
                if (!$slugValuesProductsCount->has($value->id)) {
                    unset($values[$key]);

                    continue;
                }

                $value->setProductsCount($slugValuesProductsCount->get($value->id)->productsCount);
            }
        }

        /** @var Filter $filter */
        foreach ($filters as $filter) {
            $filterValues = $values->filter(function (AttributeSlugValue $value) use ($filter) { return $value->attribute_id == $filter->getId(); });
            if ($filterValues->isNotEmpty()) {
                $filter->setValue($filterValues->mapInto(FilterValue::class));
            }
        }
    }

    /**
     * @return Collection
     */
    public function getFilters(): Collection
    {
        $cache_key = 'all.is_filter.' . Attribute::class;

        $filters = Cache::get($cache_key);

        if (!$filters) {
            $filters = Attribute::query()
                ->where('is_filter', 1)
                ->orderBy('filter_position')
                ->get()
                ->mapInto(Filter::class);

            Cache::put($cache_key, $filters, 600); // 10 minutes
        }

        $filters = clone $filters;

        $this->loadFiltersValues($filters, ['withProductsCount' => true]);

        return $filters->filter(fn(Filter $filter) => $filter->getValues()->isNotEmpty());
    }

    /**
     * @param array $slugs
     * @return Collection
     */
    public function getCategoriesBySlug(array $slugs): Collection
    {
        $untouchedSlugs = collect($slugs)->diff($this->categoriesStorage->keys());
        if ($untouchedSlugs->isNotEmpty()) {
            $untouchedCategories = Category::query()->whereIn('slug', $slugs)->get();

            /** @var Category $untouchedCategory */
            foreach ($untouchedCategories as $untouchedCategory) {
                $this->categoriesStorage->put($untouchedCategory->slug, $untouchedCategory);
            }
        }

        return $this->categoriesStorage->filter(function (Category $category) use ($slugs) { return in_array($category->slug, $slugs); });
    }

    /**
     * @param array $slugs
     * @return Collection
     */
    public function getBrandsBySlug(array $slugs): Collection
    {
        $untouchedSlugs = collect($slugs)->diff($this->brandsStorage->keys());
        if ($untouchedSlugs->isNotEmpty()) {
            $untouchedBrands = Brand::query()->whereIn('slug', $slugs)->get();

            /** @var Brand $untouchedBrand */
            foreach ($untouchedBrands as $untouchedBrand) {
                $this->brandsStorage->put($untouchedBrand->slug, $untouchedBrand);
            }
        }

        return $this->brandsStorage->filter(function (Brand $brand) use ($slugs) {
            return in_array($brand->slug, $slugs);
        });
    }

    /**
     * @param array $params
     * @return LengthAwarePaginator
     */
    public function getPageProducts(array $params): LengthAwarePaginator
    {
        $statusOrder = [Product::STATUS_IN_STOCK, Product::STATUS_WAITING, Product::STATUS_OUT_STOCK];

        $lowestPriceQuery = Product::query()
            ->select(
                DB::raw('parent_id AS childParentId'),
                DB::raw('MIN(price) AS lowestPrice'),
                DB::raw('MAX(created_at) AS lowestCreatedAt'),
            )
            ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
            ->where('stock', '>', '0')
            ->groupBy('childParentId');

        static::addRelationsToProductQuery($lowestPriceQuery);

        $statusQuery = DB::table((new Product())->getTable() . ' AS childStatusProducts')
            ->select('status')
            ->where('childStatusProducts.parent_id', '=', DB::raw('products.id'))
            ->orderByRaw(DB::raw('FIELD(status, ' . implode(',', $statusOrder) . ')'))
            ->limit(1);

        $query = Product::query()
            ->select(
                '*',
                DB::raw('IFNULL(childrenProducts.lowestPrice, price) AS lowestPrice'),
                DB::raw('IFNULL(childrenProducts.lowestCreatedAt, created_at) AS lowestCreatedAt'),
            )
            ->selectSub($statusQuery, 'childStatus')
            ->joinSub($lowestPriceQuery, 'childrenProducts', 'childrenProducts.childParentId', '=', 'products.id', 'LEFT')
            ->whereIn('id', ($params[self::GET_CART_ITEMS] ?? false)
                ? $params[self::GET_PRODUCT_IDS] ?? []
                : $this->getProductsIdsQuery()
            )
            ->orderByRaw(DB::raw('FIELD(IFNULL(childStatus, products.status), ' . implode(',', $statusOrder) . ')'))
            ->with('modifications', function (HasMany $modifications) {
                static::addRelationsToProductQuery($modifications);
            });

        static::addRelationsToProductQuery($query);

        $allowableOrderBy = collect((
            $this->isWholesaleCatalog()
                ? [
                    'price' => 'price',
                    'wholesale_price_uah' => 'wholesale_price_uah',
                    'wholesale_usd' => 'wholesale_usd',
                    'wholesale_price_uah_5' => 'wholesale_price_uah_5',
                    'wholesale_usd_5' => 'wholesale_usd_5',
                    'wholesale_price_uah_10' => 'wholesale_price_uah_10',
                    'wholesale_usd_10' => 'wholesale_usd_10',
                    'wholesale_price_uah_15' => 'wholesale_price_uah_15',
                    'wholesale_usd_15' => 'wholesale_usd_15',
                ]
                : []
            ) + [
                'price' => 'lowestPrice',
                'name' => 'name',
                'views' => 'views',
                'newProducts' => 'lowestCreatedAt',
            ]
        );

        $orderBy = $allowableOrderBy->get($params['sort'] ?? '', 'id');

        if ($orderBy) {
            $order = in_array(($params['by'] ?? ''), ['asc', 'desc']) ? $params['by'] : 'asc';
            $query->orderBy($orderBy, $order);
        }

        return $query->paginate($params['count'])->appends($params);
    }

    /**
     * Returns Categories list to display it in filter
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getCategoryFilterValues(): Collection
    {
        $categoryProductsCount = Product::query()
            ->select(
                'products.category_id',
                DB::raw('COUNT(products.id) AS productsCount')
            )
            ->whereIn('products.id', $this->getProductsIdsQuery(['skipCategories' => true]))
            ->groupBy('products.category_id')
            ->get()
            ->keyBy('category_id');

        $categoryIds = $categoryProductsCount->pluck('category_id')->filter()->toArray();

        /** @var Collection $categories */
        $categories = Category::find($categoryIds);
        $categories->each(function (Category $category) use ($categoryProductsCount)
        {
            $category->productsCount = $categoryProductsCount->has($category->id)
                ? (int)$categoryProductsCount->get($category->id)->productsCount
                : 0;
        });

        return $categories->sortByDesc('productsCount');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getBrandFilterValues(): Collection
    {
        $brandProductsCount = Product::query()
            ->select(
                'products.brand_id',
                DB::raw('COUNT(products.id) AS productsCount')
            )
            ->whereIn('products.id', $this->getProductsIdsQuery(['skipBrand' => true]))
            ->groupBy('products.brand_id')
            ->get()
            ->keyBy('brand_id');

        $brandIds = $brandProductsCount->pluck('brand_id')->filter()->toArray();
        /** @var Collection $brands */
        $brands = Brand::find($brandIds);
        $brands->each(function (Brand $brand) use ($brandProductsCount) {
            $brand->productsCount = $brandProductsCount->has($brand->id) ? (int)$brandProductsCount->get($brand->id)->productsCount : 0;
        });

        return $brands->sortByDesc('productsCount');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getSpecificFilterValues(): Collection
    {
        $brandProductsCount = DB::query();
        $sub_tables = [
            '*',
        ];

        foreach (RouteParams::getSpecificFiltersList() as $name => $column) {
            $sub_tables[] = DB::raw($name . ".productsCount AS {$column}_count");

            $sub_query = Product::query()
                ->select(
                    DB::raw('COUNT(id) AS productsCount')
                )
                ->whereIn('id', $this->getProductsIdsQuery(['skipSpecific' => true]))
                ->where(function(EloquentBuilder $query) use ($column)
                {
                    $query->where($column, 1)
                        ->orwhereHas('modifications', function (EloquentBuilder $query) use ($column)
                        {
                            $query->where($column, 1);
                        });
                });

            $brandProductsCount
                ->fromSub(
                    $sub_query,
                    $name
                );
        }


        $result = $brandProductsCount->select($sub_tables)
            ->limit(1)
            ->get()
        ;

        $specific_filters = collect();

        foreach (RouteParams::getSpecificFiltersList() as $name => $column) {
            $specific_filters[$column] = [
                'slug' => $name,
                'name' => __('catalog.filters.' . $name),
                'productsCount' => (int) $result->first()->{$column . '_count'},
            ];
        }

        return $specific_filters->sortByDesc('productsCount');
    }

    /**
     * @return array
     */
    public function getPriceFilterValues(): array
    {
        $product_query = Product::query()
            ->select(
                DB::raw('MIN(products.price) AS min_price'),
                DB::raw('MAX(products.price) AS max_price')
            )
            ->where('price', '>', 0)
            ->whereIn('id', $this->getProductsIdsQuery(['skipPrice' => true]))
            ->where(function (EloquentBuilder $query) {
                $this->collectActiveProductConditions($query);

                $query->orHas('modifications');
            });

        $children_product_query = Product::query()
            ->select(
                DB::raw('MIN(products.price) AS min_price'),
                DB::raw('MAX(products.price) AS max_price')
            )
            ->whereIn('parent_id', $this->getProductsIdsQuery(['skipPrice' => true]));

        $this->collectActiveProductConditions($children_product_query);

        $query = DB::table(Product::TABLE_NAME)
            ->from($product_query)
            ->union($children_product_query)
            ->get()
            ;

        return [
            'min_price' => (int) ($query->min('min_price') ?: 0),
            'max_price' => ceil($query->max('max_price') ?: 0),
        ];
    }

    /**
     * @return
     */
    public function getActiveProductsAnatylicsData()
    {
        $products_1 = $this->getProductsIdsQuery(['skipPrice' => true]);
        $products_2 = $this->getProductsIdsQuery();

        $conditions_to_get_all_orderable_products = function ($products) {
            return function(EloquentBuilder $query) use ($products) {
                $query
                    ->where(function(EloquentBuilder $query) use ($products) {
                        // Дочірні
                        $query->whereNotNull('parent_id')
                            ->where(function (EloquentBuilder $query) use ($products) {
                                $query
                                    ->whereIn('parent_id', $products)
                                    ->orWhereIn('id', $products);
                            });
                    })->orWhereIn('id', $products);
            };
        };

        $result = Product::query()
            ->select(
                DB::raw('MIN(products.price) AS min'),
                DB::raw('MAX(products.price) AS max'),
                DB::raw('COUNT(products.id) AS products_in_stock'),
                DB::raw('all_p.all_no_parent_products_in_stock')
            )
            ->where($conditions_to_get_all_orderable_products($products_1))
            ->where('is_active', true)
            ->where('status', Product::STATUS_IN_STOCK)
            ->leftJoinSub(
                Product::query()
                    ->select(DB::raw('COUNT(products.id) AS all_no_parent_products_in_stock'))
                    ->whereIn('products.id', $products_2),
                'all_p', 'products.id', 'products.id'
            )
            ->groupBy('all_p.all_no_parent_products_in_stock')
            ->first()
        ;

        return [
            'min' => $result->min ?? 0,
            'max' => $result->max ?? 0,
            'products_in_stock' => $result->products_in_stock ?? 0,
            'all_no_parent_products_in_stock' => $result->all_no_parent_products_in_stock ?? 0, // returns single products and group products count, that's why it could be less than products_in_stock
        ];
    }

    /**
     * @return array
     */
    public function getWeightFilterValues(): array
    {
        $attribute = DB::table(Attribute::TABLE_NAME)
            ->select('id')
            ->where('filter_slug', RouteParams::PARAM_NAME__WEIGHT);

        $query = ProductsAttributesNumericValues::query()
            ->select(
                DB::raw('MIN(' . ProductsAttributesNumericValues::TABLE_NAME . '.value) AS min_weight'),
                DB::raw('MAX(' . ProductsAttributesNumericValues::TABLE_NAME . '.value) AS max_weight')
            )
            ->whereIn('attribute_id', $attribute)
            ->whereIn('product_id', $this->getProductsIdsQuery(['skipPrice' => true]));

        $children_product_query = Product::query()
            ->select('id')
            ->whereIn('parent_id', $this->getProductsIdsQuery(['skipPrice' => true]));

        $this->collectActiveProductConditions($children_product_query);

        $children_query = ProductsAttributesNumericValues::query()
            ->select(
                DB::raw('MIN(' . ProductsAttributesNumericValues::TABLE_NAME . '.value) AS min_weight'),
                DB::raw('MAX(' . ProductsAttributesNumericValues::TABLE_NAME . '.value) AS max_weight')
            )
            ->whereIn('attribute_id', $attribute)
            ->whereIn('product_id', $children_product_query);

        $query = DB::table(ProductsAttributesNumericValues::TABLE_NAME)
            ->from($query)
            ->union($children_query)
            ->get()
        ;

        return [
            'min_weight' => (int) ($query->min('min_weight') ?: 0),
            'max_weight' => ceil($query->max('max_weight') ?: 0),
        ];
    }

    /**
     * @param array $queryParams
     * @return Builder
     */
    private function getProductsIdsQuery(array $queryParams = []): Builder
    {
        // Collect Query conditions
        if ($this->isWholesaleCatalog()) {
            return $this->getProductsIdsQueryForWholesaleCatalog($queryParams);
        }

        $productsQuery = Product::query()
            ->select('id')
            ->whereNull('parent_id')
            ->where(function (EloquentBuilder $query) use ($queryParams) {
                $query
                    ->where(function (EloquentBuilder $query) use ($queryParams) {
                        $query->where($this->getSingleProductsCallback($queryParams));
                    })
                    ->orWhereHas('modifications', $this->getSingleProductsCallback($queryParams));
            });

        return DB::table('products')
            ->select('id')
            ->from($productsQuery);
    }

    /**
     * @param array $queryParams
     *
     * @return Builder
     */
    private function getProductsIdsQueryForWholesaleCatalog(array $queryParams = [])
    {
        $simpleProductsQuery = Product::query()
            ->whereDoesntHave('modifications')
            ->where('is_active', 1)
            ->where($this->getCatalogTypeConditions());

        if ($this->categoryId) {
            $simpleProductsQuery->where('category_id', $this->categoryId);
        }

        $skipCategories = (bool)($queryParams['skipCategories'] ?? false);

        if (
            !$skipCategories
            && $categoryParam = $this->routeParams->get(RouteParams::PARAM_NAME__CATEGORY)
        ) {
            $categoryIds = $this->getCategoriesBySlug($categoryParam->getValues($this->routeParams::PARAM_NAME__CATEGORY)->toArray())
                ->map(fn(Category $category) => $category->id);

            if ($categoryIds->isNotEmpty()) {
                $simpleProductsQuery->whereIn('category_id', $categoryIds->toArray());
            }
        }

        $skipBrand = (bool)($queryParams['skipBrand'] ?? false);

        if (
            !$skipBrand
            && $brandParam = $this->routeParams->get(RouteParams::PARAM_NAME__BRAND)
        ) {
            $brandIds = $this->getBrandsBySlug($brandParam->getValues($this->routeParams::PARAM_NAME__BRAND)->toArray())
                ->map(fn(Brand $brand) => $brand->id);

            if ($brandIds->isNotEmpty()) {
                $simpleProductsQuery->whereIn('brand_id', $brandIds->toArray());
            }
        }

        $skipPrice = (bool)($queryParams['skipPrice'] ?? false);

        if (
            !$skipPrice
            && $priceParam = $this->routeParams->get(RouteParams::PARAM_NAME__PRICE)
        ) {
            $simpleProductsQuery->whereBetween('price', $priceParam->getValues()->toArray());
        }

        if ($this->routeParams->getDynamic()->isNotEmpty()) {
            $filters = $this->getFiltersBySlug($this->routeParams->getDynamic()->keys()->toArray());

            /** @var Filter $filter */
            foreach ($filters as $filter) {
                $routeParam = $this->routeParams->get($filter->getSlug());

                if (!$routeParam) {
                    continue;
                }

                $productsAttributesQuery = Product::query()
                    ->select('id')
                    ->whereHas('attributeValues', function (EloquentBuilder $query) use ($filter, $routeParam) {
                        $query->where('attribute_id', $filter->getId())
                            ->whereIn('slug', $routeParam->getValues()->toArray());
                    });

                $simpleProductsQuery->whereIn('id', $productsAttributesQuery);
            }
        }

        if ($this->searchString) {
            $simpleProductsQuery->where(function (EloquentBuilder $query){
                $query->where(DB::raw('LOWER(name)'), 'like', "%{$this->searchString}%")
                    ->orWhere(DB::raw('LOWER(SKU)'), 'like', "{$this->searchString}%")
                    ->orWhere(DB::raw('LOWER(description)'), 'like', "%{$this->searchString}%");
            });
        }

        return DB::table('products')
            ->select('id')
            ->from($simpleProductsQuery);
    }

    /**
     * @param array $queryParams
     *
     * @return \Closure
     */
    private function getSingleProductsCallback(array $queryParams)
    {
        return function (EloquentBuilder $query) use ($queryParams) {
            $query
                ->where('is_active', 1)
                ->where($this->getCatalogTypeConditions());

            $this->collectDefaultConditions($query, $queryParams);
        };
    }

    /**
     * @param EloquentBuilder|Builder $query
     */
    private function collectActiveProductConditions($query)
    {
        $query->where('is_active', 1)
            ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
            ->where(
                $this->isWholesaleCatalog() ? 'stock_opt' : 'stock',
                '>',
                0
            )
        ;
    }

    /**
     * Adds catalog type conditions to a query
     *
     * @return \Closure
     */
    private function getCatalogTypeConditions()
    {
        return function (EloquentBuilder $query)
        {
            switch ($this->requiresCatalogType) {
                case Catalog::TYPE_RETAIL:
                    $query->where('retail', 1);
                    break;

                case Catalog::TYPE_WHOLESALE:
                    $query->where('retail', 1)
                        ->orWhere('wholesale', 1);

                    break;
            }
        };
    }

    #endregion

    #region Helpers

    /**
     * @param EloquentBuilder|Builder|HasMany|BelongsTo $product
     */
    private static function addRelationsToProductQuery($product)
    {
        $product
            ->with('attrSlugValues')
            ->with('attrTextValues')
            ->with('attrNumericValues')
            ->with('brand')
            ->with('category')
            ->with('parentProduct', function (BelongsTo $parentProduct) {
                static::addRelationsToProductQuery($parentProduct);
            })
            ->with('productAttribute', function (HasMany $productAttribute) {
                $productAttribute->with('info');
            });
    }

    /**
     * Adds the conditions related to single products and to child products
     *
     * @param EloquentBuilder $query
     */
    private function collectDefaultConditions(EloquentBuilder $query, array $queryParams)
    {
        if ($this->categoryId) {
            $query->where('category_id', $this->categoryId);
        }

        $skipCategories = (bool)($queryParams['skipCategories'] ?? false);

        if (
            !$skipCategories
            && $categoryParam = $this->routeParams->get(RouteParams::PARAM_NAME__CATEGORY)
        ) {
            $categoryIds = $this->getCategoriesBySlug($categoryParam->getValues()->toArray())
                ->map(fn(Category $category) => $category->id);

            if ($categoryIds->isNotEmpty()) {
                $query->whereIn('category_id', $categoryIds->toArray());
            }
        }

        $skipBrand = (bool)($queryParams['skipBrand'] ?? false);

        if (
            !$skipBrand
            && $brandParam = $this->routeParams->get(RouteParams::PARAM_NAME__BRAND)
        ) {
            $brandIds = $this->getBrandsBySlug($brandParam->getValues()->toArray())
                ->map(fn(Brand $brand) => $brand->id);

            if ($brandIds->isNotEmpty()) {
                $query->whereIn('brand_id', $brandIds->toArray());
            }
        }

        $skipPrice = (bool)($queryParams['skipPrice'] ?? false);

        if (
            !$skipPrice
            && $priceParam = $this->routeParams->get(RouteParams::PARAM_NAME__PRICE)
        ) {
            $between = [$priceParam->getValues()->min(),  $priceParam->getValues()->max()];

            $query->where(function(EloquentBuilder $query) use ($between) {
                $query
                    ->where('price', '>', 0)
                    ->whereBetween('price', $between)
                    ->orwhereHas('modifications', function (EloquentBuilder $query) use ($between) {
                        $query->whereBetween('price', $between);
                        $this->collectActiveProductConditions($query);
                    });
            });
        }

        $skipWeight = (bool)($queryParams['skipWeight'] ?? false);

        if (
            !$skipWeight
            && $weightParam = $this->routeParams->get(RouteParams::PARAM_NAME__WEIGHT)
        ) {
            $productsAttributesQuery = Product::query()
                ->select('id')
                ->whereHas('attrNumericValues', function (EloquentBuilder $query) use ($weightParam) {
                    $query->whereIn(
                            'attribute_id',
                            Attribute::query()
                                ->select('id')
                                ->where('filter_slug', RouteParams::PARAM_NAME__WEIGHT)
                        )
                        ->whereBetween('value', [$weightParam->getValues()->min(),  $weightParam->getValues()->max()]);
                });

            $query->where(function(EloquentBuilder $query) use ($productsAttributesQuery) {
                $query->whereIn('id', $productsAttributesQuery)
                    ->orwhereHas('modifications', function (EloquentBuilder $query) use ($productsAttributesQuery) {
                        $query->whereIn('id', $productsAttributesQuery);
                        $this->collectActiveProductConditions($query);
                    });
            });
        }

        $skipSpecific = (bool)($queryParams['skipSpecific'] ?? false);

        if (
            !$skipSpecific
            && $specificParam = $this->routeParams->get(RouteParams::PARAM_NAME__SPECIFIC)
        ) {
            foreach ($specificParam->getValues() as $value) {
                $column_name = RouteParams::getSpecificFiltersList()[$value] ?? null;

                if (!$column_name) {
                    continue;
                }

                $query->where(function(EloquentBuilder $query) use ($column_name)
                {
                    $query->where($column_name, 1)
                        ->orwhereHas('modifications', function (EloquentBuilder $query) use ($column_name)
                        {
                            $query->where($column_name, 1);
                        });
                });
            }
        }

        if ($this->routeParams->getDynamic()->isNotEmpty()) {
            $filters = $this->getFiltersBySlug($this->routeParams->getDynamic()->keys()->toArray());

            /** @var Filter $filter */
            foreach ($filters as $filter) {
                $routeParam = $this->routeParams->get($filter->getSlug());

                if (!$routeParam) {
                    continue;
                }

                $productsAttributesQuery = Product::query()
                    ->select('id')
                    ->whereHas('attributeValues', function (EloquentBuilder $query) use ($filter, $routeParam) {
                        $query->where('attribute_id', $filter->getId())
                            ->whereIn('slug', $routeParam->getValues()->toArray());
                    });

                $query->where(function(EloquentBuilder $query) use ($productsAttributesQuery) {
                    $query->whereIn('id', $productsAttributesQuery)
                        ->orwhereHas('modifications', function (EloquentBuilder $query) use ($productsAttributesQuery) {
                            $query->whereIn('id', $productsAttributesQuery);
                            $this->collectActiveProductConditions($query);
                        });
                });
            }
        }

        if ($this->searchString) {
            try {
                $key = 'ProductsSearchString:' . json_encode($this->searchString);

                if (Cache::has($key)) {
                    $product_ids = Cache::get($key);
                } else {
                    $product_ids = Product::search($this->searchString)
                        ->paginateRaw(
                            Product::search($this->searchString)
                                ->paginate(1)
                                ->total()
                        );
                    $product_ids = array_column($product_ids->items()['hits'], 'id');

                    Cache::put($key, $product_ids, 14400); // 24 hours
                }

                $query->whereIn('id', $product_ids);
            } catch (\Throwable $e) {
                Log::debug(print_r([
                    'message' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                    'Route' => __FILE__ . ':' . __LINE__,
                ], true));

                $query->where(function (EloquentBuilder $query) {
                    $query
                        ->where(DB::raw('LOWER(name)'), 'like', "%{$this->searchString}%")
                        ->orWhere(DB::raw('LOWER(SKU)'), $this->searchString)
                        ->orWhere(DB::raw('LOWER(barcode)'), $this->searchString)
                        ->orWhere(DB::raw('LOWER(description)'), 'like', "%{$this->searchString}%");
                });
            }
        }
    }

    #emdregion
}
