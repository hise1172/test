<?php

namespace App\Services\Catalog\Pricing;

use App\DataContainers\AbstractDataContainer;
use InvalidArgumentException;

/**
 * Thet's just a data container
 *
 * @package App\Services\Catalog\Pricing
 *
 * @property float $UAH
 * @property float $USD
 */
class CurrencyExchange extends AbstractDataContainer
{
    #region Magic Methods

    /**
     * @param string $name
     *
     * @return mixed
     */
    public function __get($name)
    {
        switch ($name) {
            case 'UAH':
            case 'USD':
                return round((float) parent::__get($name), 2);
        }

        throw new InvalidArgumentException('There is no property ' . $name);
    }

    #endregion
}
