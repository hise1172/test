<?php

namespace App\Services\Catalog;

use App\Services\Catalog\Filtration\Layout\FilterLayoutContract;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class Catalog
{
    const TYPE_RETAIL = 1;
    const TYPE_WHOLESALE = 2;

    private string $displayFormat = 'default';

    private LengthAwarePaginator $products;

    private ?FilterLayoutContract $categoryFilter;

    private ?FilterLayoutContract $brandFilter;

    private ?FilterLayoutContract $priceFilter;

    private ?FilterLayoutContract $weightFilter;

    private ?FilterLayoutContract $specific_filters;

    private ?Collection $filters;

    public function __construct(LengthAwarePaginator $products, string $format = '')
    {
        $this->products = $products;
        if (!empty($format)) {
            $this->displayFormat = $format;
        }
    }

    /**
     * @param FilterLayoutContract $categoryFilter
     *
     * @return $this
     */
    public function setCategoryFilter(FilterLayoutContract $categoryFilter): self
    {
        $this->categoryFilter = $categoryFilter;

        return $this;
    }

    /**
     * @param FilterLayoutContract $brandFilter
     *
     * @return $this
     */
    public function setBrandFilter(FilterLayoutContract $brandFilter): self
    {
        $this->brandFilter = $brandFilter;

        return $this;
    }

    public function setPriceFilter(FilterLayoutContract $priceFilter): self
    {
        $this->priceFilter = $priceFilter;

        return $this;
    }

    public function setWeightFilter(FilterLayoutContract $weightFilter): self
    {
        $this->weightFilter = $weightFilter;

        return $this;
    }

    /**
     * @param FilterLayoutContract $specific_filters
     *
     * @return $this
     */
    public function setSpecificFilters(FilterLayoutContract $specific_filters): self
    {
        $this->specific_filters = $specific_filters;

        return $this;
    }

    public function setFilters(Collection $filters): self
    {
        $this->filters = $filters;

        return $this;
    }

    public function getDisplayFormat(): string
    {
        return $this->displayFormat;
    }

    /**
     * @return FilterLayoutContract
     */
    public function getCategoryFilter(): FilterLayoutContract
    {
        return $this->categoryFilter;
    }

    /**
     * @return FilterLayoutContract
     */
    public function getBrandFilter(): FilterLayoutContract
    {
        return $this->brandFilter;
    }

    public function getPriceFilter(): FilterLayoutContract
    {
        return $this->priceFilter;
    }

    public function getWeightFilter(): FilterLayoutContract
    {
        return $this->weightFilter;
    }

    /**
     * @return FilterLayoutContract
     */
    public function getSpecificFilters(): FilterLayoutContract
    {
        return $this->specific_filters;
    }

    public function getProducts(): LengthAwarePaginator
    {
        return $this->products;
    }

    public function getFilters(): Collection
    {
        return $this->filters;
    }
}
