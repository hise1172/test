<?php

namespace App\Services\Catalog;

use App\Services\Catalog\Routing\RouteParams;
use Illuminate\Support\ServiceProvider as BaseServiceProvider;

class CatalogServiceProvider extends BaseServiceProvider
{
    public function register()
    {
        $this->app->singleton(RouteParams::class);

        $this->app->singleton(Repository::class);
    }
}
