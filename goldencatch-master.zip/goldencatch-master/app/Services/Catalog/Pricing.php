<?php

namespace App\Services\Catalog;

use App\Models\Product\Product;
use App\Models\UserRole;
use App\Services\Catalog\Pricing\CurrencyExchange;
use App\User;
use LogicException;
use InvalidArgumentException;

/**
 * Class Pricing
 *
 * @package App\Services\Catalog
 */
class Pricing
{
    const CURRENCY_UAH = 'UAH';
    const CURRENCY_USD = 'USD';

    const SIMPLE_WHOLESALE_DISCOUNT = 0.85;

    const TYLE_SIMPLE_SALE = 'simple_sale';

    private ?User $user;

    #region Magic methods

    /**
     * Pricing constructor.
     *
     * @param User $user
     */
    private function __construct(User $user = null)
    {
        $this->user = $user;
    }

    #endregion

    #region Builders

    /**
     * @param User $user
     *
     * @return static
     */
    public static function init(User $user = null)
    {
        return new static($user);
    }

    /**
     * @param Product $product
     * @param bool $min_needs
     *
     * @return CurrencyExchange
     */
    private static function buildWholesaleCurrencyExchange(string $role_name, Product $product, bool $min_needs): CurrencyExchange
    {
        if (!$product->wholesale) {
            $uah_price_column = ($min_needs ? 'min_' : '') . 'price';
            $usd_price_column = ($min_needs ? 'min_' : '') . 'wholesale_usd';

            return CurrencyExchange::create([
                static::CURRENCY_UAH => $product->{$uah_price_column} * static::SIMPLE_WHOLESALE_DISCOUNT,
                static::CURRENCY_USD => $product->{$usd_price_column},
            ]);
        }

        $uah_price_column = ($min_needs ? 'min_' : '') . static::getWholesalePriceName($role_name, static::CURRENCY_UAH);
        $usd_price_column = ($min_needs ? 'min_' : '') . static::getWholesalePriceName($role_name, static::CURRENCY_USD);

        return CurrencyExchange::create([
            static::CURRENCY_UAH => $product->{$uah_price_column},
            static::CURRENCY_USD => $usd_price_column ? $product->{$usd_price_column} : null,
        ]);
    }

    #endregion

    #region Getters

    /**
     * @param Product $product
     * @param bool $for_reseller_console
     *
     * @return CurrencyExchange
     */
    public function getMinPrice(Product $product, bool $for_reseller_console): CurrencyExchange
    {
        $currency = CurrencyExchange::create();

        if (!$for_reseller_console || !$this->user) {
            $currency->UAH = $product->min_price;

            return $currency;
        }

        // Define min price for Reseller Console

        if (!$product->wholesale) {
            $currency->UAH = $product->min_price * static::SIMPLE_WHOLESALE_DISCOUNT;

            return $currency;
        }

        /** @var UserRole $role */
        $role = $this->user->getRole();

        $price_type = 'min_' . static::getWholesalePriceName($role->name, static::CURRENCY_UAH);

        $currency->UAH = $product->{$price_type};

        return $currency;
    }

    /**
     * @param Product $product
     * @param string $currency
     *
     * @return CurrencyExchange
     */
    public function getWholesalePrice(Product $product): CurrencyExchange
    {
        if (!$this->user) {
            throw new LogicException('A $this->user is requires to define wholesale price');
        }

        if (!$this->user->isReseller()) {
            throw new LogicException('The current user is not reseller and there is no wholesale price for them');
        }

        /** @var UserRole $role */
        $role = $this->user->getRole();

        return $this->buildWholesaleCurrencyExchange(
            $product->wholesale
                ? $role->name
                : static::TYLE_SIMPLE_SALE,
            $product,
            $product->modifications->isNotEmpty()
        );

    }

    /**
     * @param User $user
     * @param string $currency
     *
     * @return string
     */
    public static function getWholesalePriceName($role_name, string $currency): string
    {
        switch ($role_name) {
            case UserRole::ROLE_OPT:
                $uah_price_column = 'wholesale_price_uah';
                $usd_price_column = 'wholesale_usd';

                break;


            case UserRole::ROLE_OPT_5:
                $uah_price_column = 'wholesale_price_uah_5';
                $usd_price_column = 'wholesale_usd_5';

                break;

            case UserRole::ROLE_OPT_10:
                $uah_price_column = 'wholesale_price_uah_10';
                $usd_price_column = 'wholesale_usd_10';

                break;

            case UserRole::ROLE_OPT_15:
                $uah_price_column = 'wholesale_price_uah_15';
                $usd_price_column = 'wholesale_usd_15';

                break;

            default:
                throw new InvalidArgumentException('Unknown user role');
        }

        switch ($currency) {
            case static::CURRENCY_UAH:
                return $uah_price_column;

            case static::CURRENCY_USD:
                return $usd_price_column;

            default:
                throw new InvalidArgumentException('Invalid $currency');
        }
    }

    #endregion
}
