<?php

namespace App\Services\Catalog;

use App\Models\Category;
use App\Models\SeoFilters;
use Illuminate\Support\Str;

/**
 * Class Lookup
 *
 * @package App\Services\Catalog
 */
class Lookup
{
    private Category $category;

    /**
     * @param Category $category
     */
    function __construct( Category $category )
    {
        $this->category = $category;
    }

    public function getLinks()
    {
        $categoryItems = SeoFilters::where('uri', 'LIKE', 'catalog/' . $this->category->slug . '/%')->get();
        return $categoryItems;
    }

    public function getCategoryLinks( $limit = 999 )
    {
        return SeoFilters::where('uri', 'LIKE', 'catalog/' . $this->category->slug . '/%')->limit( $limit )->get();
    }


    public function getCategoryLinksFilters( $url )
    {
        $urlArray = $this->convertUrlToArray( $url );
        $activeLinks = [];
        $i = 0;

        foreach($this->getCategoryLinks() as $link ){

            if ($i >= 5) return $activeLinks;
            
            if( $this->existInArray( $urlArray, $this->convertUrlToArray( $link->uri ) ) ){
                $activeLinks[] = $link;
                $i++;
            }
        }

        return $activeLinks;
    }


    public function existInArray( $reqUrlArray, $seoItemArray )
    {
        // we not show same link as Request URL
        if(array_diff($reqUrlArray, $seoItemArray) === array_diff($seoItemArray, $reqUrlArray)){
            return FALSE;
        }

        $identical = 0;
        foreach ($seoItemArray as $value) {
            if( in_array($value, $reqUrlArray) ){
                $identical++;
            }
        }
        return count( $reqUrlArray ) == $identical;
    }


    public function convertUrlToArray( $url )
    {
        $arrayParams = [];
        $stringParams = Str::after($url, 'catalog/' . $this->category->slug . '/');
        foreach(explode('/', $stringParams) as $value){
            if( Str::contains($value, '-') && Str::contains($value, ',') ){
                $filterName = Str::before($value, '-');
                foreach ( explode(',', Str::after($value, '-'))  as $filterString) {
                    $arrayParams[] = $filterName . '-' . $filterString;
                }
            }
            else{
                $arrayParams[] = $value;
            }
        }

        return $arrayParams;
    }
}
