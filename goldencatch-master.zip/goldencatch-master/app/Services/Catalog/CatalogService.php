<?php

namespace App\Services\Catalog;

use App\Helpers\Cart;
use App\Repositories\ProductRepository;
use App\Services\Catalog\Routing\RouteParams;
use App\Services\Catalog\Routing\ValidationManager;
use App\Services\FilterService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

/**
 * Class CatalogService
 * @package App\Services
 */
class CatalogService
{
    const GET_CART_ITEMS = -1; // get cart items

    const MAX_FILTERS_COUNT = 7;

    private ProductRepository $productRepository;

    private FilterService $filterService;

    private Repository $catalogRepository;

    private Filtration\Layout\LayoutFactory $layoutFactory;

    private Cart $cart;

    public function __construct(
        ProductRepository $productRepository,
        FilterService $filterService,
        Repository $catalogRepository,
        Filtration\Layout\LayoutFactory $layoutFactory
    )
    {
        $this->productRepository = $productRepository;
        $this->catalogRepository = $catalogRepository;
        $this->filterService = $filterService;
        $this->layoutFactory = $layoutFactory;
        $this->cart = Session::get('cart', new Cart());
    }

    #region Getters

    /**
     * @param Request $request
     * @param int $categoryId
     * @param array $displayParams
     * @param string $searchQuery
     * @return Catalog
     */
    public function getCatalog(Request $request, int $categoryId, array $displayParams, string $searchQuery = '', RouteParams $routeParams = null): Catalog
    {
        if ($searchQuery) {
            $this->catalogRepository->setSearchString($searchQuery);
        }

//        if ($request->get('search', '')) {
//            $skuProduct = Product::query()->where('SKU', $request->get('search', ''))->first();
//            if (!empty($skuProduct)) {
//                return redirect()->route('product', [$skuProduct->slug]);
//            } else {
//                $this->catalogRepository->setSearchString($request->get('search', ''));
//            }
//        }

        if ($categoryId > 0) {
            $this->catalogRepository->setCategoryId($categoryId);
        }

        $this->catalogRepository->setCatalogType(
            $request->isResellersConsole
                ? Catalog::TYPE_WHOLESALE
                : Catalog::TYPE_RETAIL
        );

        if ($routeParams) {
            $this->catalogRepository->setRouteParams($routeParams);
        }

        $this->layoutFactory->setCatalogRepository($this->catalogRepository);

        $params = array_replace_recursive([
            'count' => 24,
            'page' => 1,
            'sort' => 'views',
            'by' => 'desc',
            'format' => '',
            'search' => '',
            Repository::GET_CART_ITEMS => $categoryId === Repository::GET_CART_ITEMS,
            Repository::GET_PRODUCT_IDS => $categoryId === Repository::GET_CART_ITEMS
                ? array_column($this->cart->toArray(), 'product')
                : [],
            'filters_view_namespace' => [
                'simple_list' => 'catalog.filters',
                'price' => 'catalog.filters',
                'weight' => 'catalog.filters',
            ],
        ], $displayParams);

        $prods_list = $this->catalogRepository->getPageProducts($params); // get a products list by required params

        $catalog = new Catalog(
            $prods_list,
            (string)$request->get('format', '')
        );

        // Get filters lists
        $catalog
            ->setCategoryFilter($this->layoutFactory->makeCategoryFilter($params['filters_view_namespace']['simple_list']))
            ->setBrandFilter($this->layoutFactory->makeBrandFilter($params['filters_view_namespace']['simple_list']))
            ->setPriceFilter($this->layoutFactory->makePriceFilter($params['filters_view_namespace']['price']))
            ->setWeightFilter($this->layoutFactory->makeWeightFilter($params['filters_view_namespace']['weight']))
            ->setFilters($this->layoutFactory->makeAttributeFilters($params['filters_view_namespace']['simple_list']))
            ->setSpecificFilters($this->layoutFactory->makeSpecificFilter($params['filters_view_namespace']['simple_list']));

        return $catalog;
    }

    #endregion

    #region Checkers

    /**
     * @param Request $request
     * @param RouteParams|null $routeParams
     *
     * @return bool
     */
    public function validateRequest(Request $request, RouteParams $routeParams = null): bool
    {
        $routeParams = ($routeParams ?? new RouteParams())->initFromRequest($request);

        return (new ValidationManager())->validateRouteParams($routeParams);
    }

    /**
     * @param string $filterName
     * @param string $filterValue
     *
     * @return bool
     */
    public function validateFilter(string $filterName, string $filterValue): bool
    {
        return (new ValidationManager())->validateParam($filterName, $filterValue);
    }

    #endregion

//    /**
//     * Product without filters
//     * @param Request $request
//     * @return ViewContract
//     */
//    public function indexRequest(Request $request)
//    {
//        $count = $request->get('count', 24);
//        $page = $request->get('page');
//        $products = $this->productRepository->getProductList($count, compact('count', 'page'));
//        return $this->viewWithProduct($request->get('format'), $products);
//    }
//
//    private function viewWithProduct(Catalog $listing, $url, ?Category $category)
//    {
//        $siteSettings = SiteSetting::query()->whereIn('key', ['address_internet_shop', 'jobs_time_internet_shop', 'operator_phones', 'email'])->get();
//        $seo = SeoFiltersModel::where('uri', $url)->first();
//
//        $viewData = [
//            'listing' => $listing,
//            'seo' => $seo,
//            'seof' => $seo,
//            'seofilters' => $seo,
//            'address' => $siteSettings->keyBy('key')->get('address_internet_shop'),
//            'jobs_time' => $siteSettings->keyBy('key')->get('jobs_time_internet_shop'),
//            'operator_phones' => $siteSettings->filter(function(SiteSetting $settingsItem) { return $settingsItem->key == 'operator_phones'; } ),
//            'email' => $siteSettings->keyBy('key')->get('email'),
//            'meta' => isset($category->name) ? SeoHelper::meta($category->name, '') : SeoHelper::meta('', ''),
//        ];
//
//        return $listing->getDisplayFormat() == 'list'
//            ? ViewFacade::make('catalog.index-list', $viewData)
//            : ViewFacade::make('catalog.index', $viewData);
//    }

}

