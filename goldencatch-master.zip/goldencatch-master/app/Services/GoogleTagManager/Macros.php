<?php

GoogleTagManager::macro('detail', function($product) {
    GoogleTagManager::push([
        'event' => 'detail',
        'ecommerce' => [
            'detail' => [
                'products' => [[
                    'name' => $product->name,
                    'id' => strval($product->id),
                    'price' => number_format($product->min_price, 2),
                    'brand' => $product->brand_name,
                    'category' => $product->category_name,
                ]],
            ],
        ],
    ]);
});

GoogleTagManager::macro('checkout', function($cart)
{
    if (empty($cart['products'])) {
        return;
    }

    $products = [];
    foreach($cart['products'] as $cart_product){
        $product_model = App\Models\Product\Product::find($cart_product['id']);
        if($product_model->parent_id){
            $product_model = App\Models\Product\Product::find($product_model->parent_id);
        }
        $products[] = [
            'name' => $product_model->name,
            'id' => strval($product_model->id),
            'price' => number_format($cart_product['price'], 2),
            'brand' => $product_model->brand_name,
            'category' => $product_model->category_name,
            'quantity' => $cart_product['count'],
        ];
    }

    $order = [
        'event' => 'checkout',
        'ecommerce' => [
            'checkout' => [
                'actionField' => ['step' => '1'],
                'products' => $products,
            ],
        ],
    ];

    GoogleTagManager::push($order);
});

GoogleTagManager::macro('purchase', function($order_products, $order) {
    /**
     * @var array $order_products
     * [
     *      'products' => [
     *          [
     *              'id' => int,
     *              'price' => float,
     *              'count' => int,
     *          ],
     *          ...
     *      ]
     * ]
     * @var \App\Models\Order $order
     */

    $datalayer_products = [];

    foreach($order_products['products'] as $order_product){
        $product_model = App\Models\Product\Product::find($order_product['id']);

        if($product_model->parent_id){
            $product_model = App\Models\Product\Product::find($product_model->parent_id);
        }

        $datalayer_products[] = [
            'name' => $product_model->name,
            'id' => strval($product_model->id),
            'price' => number_format($order_product['price'], 2),
            'brand' => $product_model->brand_name,
            'category' => $product_model->category_name,
            'quantity' => $order_product['count'],
        ];
    }

    $order = [
        'event' => 'purchase',
        'ecommerce' => [
            'purchase' => [
                'actionField' => [
                    'id' => strval($order->id),
                    'revenue' => strval($order->price),
                ],
                'products' => $datalayer_products,
            ],
        ],
    ];

    GoogleTagManager::push($order);
});
