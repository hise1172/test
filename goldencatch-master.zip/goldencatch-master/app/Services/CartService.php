<?php

namespace App\Services;

use App\Helpers\Cart;
use App\Models\Product\Product;
use App\Repositories\ProductRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\View;

/**
 * Class CartService
 * @package App\Services
 */
class CartService
{
    const VALIDATION_DEFAULT = 'default';
    const VALIDATION_CHANGES = 'changes';

    private const CART_SESSION = 'cart';
    private const CART_DESKTOP = 'product-cart';
    private const CART_MOBILE = 'mobile-cart';

    /**
     * @var ProductRepository
     */
    private $productRepository;
    private array $validation_errors = [];

    /**
     * CartService constructor.
     * @param ProductRepository $productRepository
     */
    public function __construct(ProductRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    #region Updates methods

    /**
     * @param Request $request
     * @return int
     */
    public function addProduct(Request $request)
    {
        $cart = $this->getCart();
        $product_id = $request->get('product');
        $cart->add($product_id, $request->get('count', 1));

        Session::put(self::CART_SESSION, $cart);

        return $cart->countProduct($product_id);
    }

    /**
     * @param Request $request
     * @return int
     */
    public function removeProduct(Request $request)
    {
        $cart = $this->getCart();
        $cart->remove($request->get('product'));
        $count = $cart->count();
        Session::put(self::CART_SESSION, $cart);
        return $count;
    }

    /**
     * Clear cart
     */
    public function clear()
    {
        $cart = Session::get(self::CART_SESSION, new Cart());
        Session::put(self::CART_SESSION, $cart->clear());
    }

    /**
     * @param Request $request
     */
    public function minusPlusProduct(Request $request)
    {
        $cart = $this->getCartOrCreate();

        if ($request->filled('minus')) {
            $cart->minusProduct($request->get('product'));
        } else {
            $cart->plusProduct($request->get('product'));
        }

        Session::put(self::CART_SESSION, $cart);
    }

    /**
     * @param bool $for_resellers
     *
     * @return $this
     */
    public function fixProductsCount(bool $for_resellers = false): self
    {
        $cart = $this->getCartOrCreate();

        foreach ($cart->toArray() as $cart_item) {
            $product = static::getProductInstance($cart_item['product'], $cart);

            if (!$product) {
                throw new \LogicException('There is not required cart item. Product ID ' . $cart_item['product']);
            }

            $stock_balance = $product->getStockBalance($for_resellers);

            if ($cart_item['count'] <= $stock_balance) {
                continue;
            }

            $cart->remove($product->id);

            if ($stock_balance == 0) {
                continue;
            }

            $cart->add($product->id, $stock_balance);
        }

        return $this;
    }

    #endregion

    #region Is Condition method

    /**
     * @param int $product_id
     * @param int $count
     * @param bool $for_resellers
     *
     * @return bool
     */
    public function canAddItem(int $product_id, bool $for_resellers): bool
    {
        $cart = $this->getCartOrCreate();
        $in_cart = $cart->toArray();

        $product = static::getProductInstance($product_id, $cart);
        $key = $cart->getKey($product_id);

        if (!isset($in_cart[$key]) || !$product) {
            return true;
        }

        $cart_item = $in_cart[$key];

        if ($cart_item['count'] < $product->getStockBalance($for_resellers)) {
            return true;
        }

        $this->validation_errors = [
            __('catalog.cart.stoke_is_empty', [
                'product_url' => routeLocale('product', ['product' => $product]),
                'product_name' => $product->name,
                'product_stock_balance'  => $product->getStockBalance($for_resellers),
            ]),
        ];

        return false;
    }

    /**
     * Returns if there is a product which has count biggest as stock value
     *
     * @param bool $for_resellers
     * @param Cart|null $cart
     *
     * @return bool
     */
    public function isValid(bool $for_resellers, Cart $cart = null): bool
    {
        $this->validation_errors = [];

        $cart = $cart ?? $this->getCartOrCreate();

        foreach ($cart->toArray() as $cart_item) {
            $product = static::getProductInstance($cart_item['product'], $cart);

            if (!$product) {
                throw new \LogicException('There is not required cart item. Product ID ' . $cart_item['product']);
            }

            if ($cart_item['count'] <= $product->getStockBalance($for_resellers)) {
                continue;
            }

            $this->validation_errors[] = __('catalog.cart.stoke_is_empty', [
                'product_url' => routeLocale('product', ['product' => $product]),
                'product_name' => $product->name,
                'product_stock_balance'  => $product->getStockBalance($for_resellers),
            ]);
        }

        return !$this->validation_errors;
    }

    #endregion

    #region Getters

    /**
     * @return Cart
     */
    private function getCart()
    {
        return Session::get(self::CART_SESSION, new Cart());
    }

    /**
     * @return Cart
     */
    public function getCartOrCreate()
    {
        $cart = Session::get(self::CART_SESSION, new Cart());
        Session::put(self::CART_SESSION, $cart);
        return $cart;
    }

    /**
     * @return int
     */
    public function countProducts()
    {
        return $this->getCart()->count();
    }

    /**
     * @param Request $request
     * @return Product
     */
    public function getProductCart(Request $request)
    {
        $product_id = $request->get('product');
        return $this->productRepository->findById($product_id);
    }

    /**
     * @param bool $for_resellers_console
     *
     * @return array
     */
    public function makeView(bool $for_resellers_console = false)
    {;
        return [
            self::CART_DESKTOP => View::make('components.cart', $this->getCartOrCreate()->productCart($for_resellers_console))->render(),
            self::CART_MOBILE => View::make('components.cart-mobile', $this->getCartOrCreate()->productCart($for_resellers_console))->render()
        ];
    }

    /**
     * @return string[]
     */
    public function getValidationErrors(): array
    {
        return $this->validation_errors;
    }

    /**
     * @param int $product_id
     * @param Cart $cart
     *
     * @return Product|null
     */
    public static function getProductInstance(int $product_id, Cart $cart): ?Product
    {
        foreach ($cart->getCartProducts() as $product) {
            if ($product_id != $product->id) {
                continue;
            }

            return $product;
        }

        return null;
    }

    #endregion
}
