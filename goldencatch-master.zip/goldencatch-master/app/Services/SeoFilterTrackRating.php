<?php

namespace App\Services;

use App\DataContainers\AbstractDataContainer;
use App\DataContainers\Catalog\ChildrenFilterHintButton;
use App\Helpers\Url;
use App\Models\SeoFilters;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cookie;

/**
 * @property string uri
 * @property SeoFilters seo_filter
 */
class SeoFilterTrackRating extends AbstractDataContainer
{
    const COOKIE_KEY = 'TrackFilterRating';
    const COOKIE_TIME = 10; // minutes
    const ITEMS_COUNT = 5;

    #region Builders

    /**
     * @param string $uri
     *
     * @return static
     */
    public static function build(?string $uri)
    {
        if (!$uri) {
            return static::make(['uri' => $uri]);
        }

        [$uri, ] = explode('?', $uri, 2);

        $uri = trim($uri, '/');

        /** ModelsSeoFilters */
        $seo_filter = SeoFilters::query()
            ->where('uri', $uri)
            ->first();

        return static::make([
            'uri' => $uri,
            'seo_filter' => $seo_filter,
        ]);
    }

    /**
     * @return static|null
     */
    public static function buildFromCookie()
    {
        return static::build(Cookie::get(static::COOKIE_KEY));
    }

    #endregion

    #region Updates methods

    /**
     * @return $this
     */
    public function applyRating()
    {
        if (!$this->seo_filter) {
            return $this;
        }

        $this->seo_filter->next_rating ++;
        $this->seo_filter->save();

        return $this;
    }

    #endregion

    #region Setters

    /**
     * @return $this
     */
    public function setCookie()
    {

        Cookie::queue(
            static::COOKIE_KEY,
            $this->uri,
            static::COOKIE_TIME
        );

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return Collection
     */
    public function getChildrenFiltersList(): Collection
    {
        if (!$this->seo_filter) {
            return collect();
        }

        return SeoFilters::query()
            ->where('uri', 'LIKE', $this->seo_filter->uri . '%')
            ->where('step', '>', $this->seo_filter->step)
            ->orderByDesc('current_rating')
            ->limit(static::ITEMS_COUNT)
            ->get()
            ->map(fn (SeoFilters $seo_filter) => ChildrenFilterHintButton::make([
                'title' => ChildrenFilterHintButton::prepareTitle($this->seo_filter, $seo_filter),
                'url' => Url::getLocatedUrl($seo_filter->uri),
            ]));
    }

    #endregion
}
