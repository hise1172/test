<?php

namespace App\Services;

use App\Http\Requests\UserUpdateRequest;
use App\Repositories\UserRepository;
use App\Repositories\UserSubscribeRepository;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

/**
 * Class UserService
 * @package App\Services
 */
class UserService
{
    /**
     * @var UserRepository
     */
    private $repository;
    /**
     * @var UserSubscribeRepository
     */
    private $subscribeRepository;

    /**
     * UserService constructor.
     * @param UserRepository $repository
     * @param UserSubscribeRepository $subscribeRepository
     */
    public function __construct(UserRepository $repository, UserSubscribeRepository $subscribeRepository)
    {
        $this->repository = $repository;
        $this->subscribeRepository = $subscribeRepository;
    }

    public function updateUser(UserUpdateRequest $request)
    {
        $validated = $this->normalizeDate( $request->validated() );
        $success = $this->repository->update(Auth::id(), $validated);
        if (!$request->filled('subscribe')) {
            $this->subscribeRepository->unsubscribe(Auth::user()->email, Auth::id());
        }
        if ($success && $request->filled('subscribe')) {
            $this->subscribeRepository->subscribe($request->get('email'), Auth::id());
        }
        return $success;
    }

    public function normalizeDate( $validated )
    {
        if( $validated['birthdate'] != '' ){
            $validated['birthdate'] = \Carbon\Carbon::createFromFormat('d.m.Y', $validated['birthdate'] )->format('Y-m-d');
        }
        return $validated;
    }

    /**
     * @param $data
     *
     * @return bool
     */
    public function changePassword($data)
    {
        /** @var User $user */
        $user = Auth::user();

        $user->password = Hash::make($data['new_password']);

        return $user->save();
    }
}
