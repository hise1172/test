<?php

namespace App\Services;

use App\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class UserWaitingService
 * @package App\Services
 */
class UserWaitingService
{
    /**
     * @param Request $request
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function getUserWaitingProduct(Request $request)
    {
        /**
         * @var User $user
         */
        $user = Auth::user();
        return $user->productWaiting()->paginate($request->get('count'))->appends($request->all());
    }

    /**
     * @param Request $request
     * @return array
     */
    public function getData(Request $request)
    {
        $data['product_id'] = $request->get('product');
        $data['user_id'] = Auth::id();
        return $data;
    }
}
