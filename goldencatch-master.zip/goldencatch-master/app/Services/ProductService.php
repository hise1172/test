<?php

namespace App\Services;

use App\DataContainers\Catalog\Breadcrumb;
use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use App\Models\Product\Product;
use App\Repositories\ProductRepository;
use App\Services\Catalog\Pricing;
use Illuminate\Http\Request;
use Illuminate\View\View;
use GoogleTagManager;
use Illuminate\Support\Str;
use Lang;

/**
 * Class ProductService
 * @package App\Services
 */
class ProductService
{
    /**
     * @var ProductRepository
     */
    private $productRepository;
    /**
     * @var CompareProductService
     */
    private $compareProductService;
    private $orderService;

    /**
     * ProductService constructor.
     * @param ProductRepository $productRepository
     * @param CompareProductService $compareProductService
     */
    public function __construct(ProductRepository $productRepository, CompareProductService $compareProductService, OrderService $orderService)
    {
        $this->productRepository = $productRepository;
        $this->compareProductService = $compareProductService;
        $this->orderService = $orderService;
    }

    /**
     * @param Product $product
     * @param Request $request
     * @return View
     */
    public function getProduct(Product $product, Request $request)
    {
        $product = $this->productRepository->getProductById($product->id);
        $viewed_products = [];

        if (null !== session('viewed_products')) {
            $viewed_products = session('viewed_products');
        }
        if (!in_array($product->id, $viewed_products)) {
            $this->addViewedProduct($product->id);
        }
        array_push($viewed_products, $product->id);
        $product->setAttribute('purchased_count', $this->orderService->getPurchasedProducts($product));
        session(['viewed_products' => $viewed_products]);
        $products_viewed = $this->productRepository->whereIn(array_unique($viewed_products));
        $products_viewed->load('modifications');
        $related_products_category = $request->get('related_products_category');

        if ($related_products_category) {
            $product->related = $product->related->where('category_id', $related_products_category);
            $product->setAttribute('related_products_category', $related_products_category);
        }
        $product->expertReview = $product->expertReview->first();
        $productLiked = $this->productRepository->getTopBuysProduct();
        $modifications = $product->modifications()->where('is_active', 1)->where('retail', 1)->get()->sortByDesc( function($product) {
            return $product->isInStock();
        });
        $compare = $this->compareProductService->getAttributesCompare($modifications);

        return $this->getView($product, $products_viewed, $productLiked, $modifications, $compare, $request)
            ->with([
                'isResellersConsole' => $request ? $request->isResellersConsole : false,
                'pricing' => Pricing::init(auth()->user()),
            ]);
    }

    /**
     * @param Product $product
     * @param $product_view
     * @param $user_liked
     * @param $modifications
     * @param $compare
     *
     * @return View
     */
    private function getView(Product $product, $product_view, $user_liked, $modifications, $compare)
    {
        GoogleTagManager::detail($product);
        \LaravelFacebookPixel::createEvent('ViewContent', $parameters = [
            'content_type' => 'product',
            'content_ids' => [$product->id],
        ]);

        $modificationsLook = $this->modificationsLook( $product );

        $seo = SeoFilters::getSeo();

        if( empty($seo['uri']) ){
            $seo['uri'] = routeLocale('product', ['product' => $product->slug]);
        }

        if( empty($seo['open_graph_image']) ){
            $seo['open_graph_image'] = asset( $product->photo );
        }

        $seo['og_type'] = 'product.item';

        $meta = SeoHelper::meta($product->name . ': ' . \Lang::get('seo.title-after-product'), $product->name . ' ' . \Lang::get('seo.description-after-product'));
        $schemaorg = $this->schemaorg( $product );

        return view('product.index', compact('product', 'product_view', 'user_liked', 'modifications',
            'modificationsLook',
            'schemaorg',
            'compare', 'seo', 'meta'));
    }

    /**
     * @param Product $product
     */
    public function modificationsLook(Product $product)
    {
        if( '' == trim( settings('categories_modifications_look_cards') ) ) {
            return ;
        }

        foreach( explode(',', settings('categories_modifications_look_cards')) as $categoryId ){
            if( trim( $categoryId ) == $product->category_id ){
                return 'cards';
            }
        }

    }

    /**
     * @param Product $product
     *
     * @return array
     */
    public function schemaorg( Product $product )
    {
        $schemaorg['breadcrumbs'] = [
            Breadcrumb::make([
                'url' => routeLocale('main'),
                'title' => __('header.main_title'),
                'seo_title' => __('seo.title-main'),
            ]),
            Breadcrumb::make([
                'url' => routeLocale('catalog'),
                'title' => Lang::get('header.catalog'),
            ]),
        ];

        if ( $product->category ) {
            $schemaorg['breadcrumbs'][] = Breadcrumb::make([
                'url' => routeLocale('category.filter', ['category' => $product->category->slug]),
                'title' => $product->category->name,
            ]);

            if ( $product->brand ) {
                $schemaorg['breadcrumbs'][] = Breadcrumb::make([
                    'url' => routeLocale('catalog.filters', ['category' => $product->category->slug, 'filter1' => 'brand-' . $product->brand->slug]),
                    'title' => $product->category->name . ' ' . $product->brand->name,
                ]);
            }
        }

        $schemaorg['breadcrumbs'][] = Breadcrumb::make([
            'url' => routeLocale('product', ['product' => $product->slug]),
            'title' => $product->name,
        ]);

        $schemaorg['product'] = $product;

        return $schemaorg;
    }

    /**
     * @param $product_id
     * @return string
     */
    public function addViewedProduct($product_id)
    {
        $viewed_product = Product::find($product_id);
        $viewed_product->views = $viewed_product->views + 1;
        $viewed_product->save();
        return 'all its ok:)';
    }

    /**
     * @param Request $request
     * @return string
     */
    public function getCountProducts(Request $request)
    {
        $product = Product::findOrFail($request->get('id'));
        if ($product) {
            return $product->stock;
        }
        return 'Not Found';
    }
}
