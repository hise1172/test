<?php

namespace App\Services\ChatBot;

use App\Models\BotUser;
use App\Services\ChatBot;
use Telegram\Bot\Api;
use App\Services\ChatBot\DataContainers\BotResponse;
use Telegram\Bot\FileUpload\InputFile;

/**
 * @property Api client
 * @property array request
 * Array(
 *      [update_id] => 8187
 *      [message] => Array
 *      (
 *          [message_id] => 2230
 *          [from] => Array
 *          (
 *              [id] => 23525
 *              [is_bot] =>
 *              [first_name] => Pavlo M.
 *              [username] => tym
 *              [language_code] => uk
 *          )
 *
 *          [chat] => Array
 *          (
 *              [id] => 23525
 *              [first_name] => Pavlo M.
 *              [username] => tym
 *              [type] => private
 *          )
 *
 *          [date] => 16378
 *          [text] => /start test
 *          [entities] => Array
 *          (
 *              [0] => Array
 *              (
 *                  [offset] => 0
 *                  [length] => 6
 *                  [type] => bot_command
 *              )
 *          )
 *      )
 * )
 */
class Telegram extends ChatBot
{
    /**
     * @inheritDoc
     * @throws \Telegram\Bot\Exceptions\TelegramSDKException
     */
    public static function build(?BotUser $bot_user): self
    {
        if (!config('telegram.bots.mybot.token')) {
            throw new \LogicException('Invalid telegram bot API token');
        }

        $object = static::make([
            'client' => new Api(config('telegram.bots.mybot.token')),
            'bot_user' => $bot_user,
        ]);

        return $object;
    }

    #region Actions

    /**
     * @inheritDoc
     */
    public function setupWebhook(): self
    {
        $request = [
            'url' => route(config('telegram.bots.mybot.webhook_url'), []),
        ];

        if (config('telegram.bots.mybot.certificate_path')) {
            $request['certificate'] = config('telegram.bots.mybot.certificate_path');
        }

        $responce = $this->client->setWebhook($request);

        if ($responce !== true) {
            throw new \RuntimeException('Webhook has not been set');
        }

        return $this;
    }

    /**
     * @see https://telegram-bot-sdk.readme.io/reference/sendmessage
     * @inheritDoc
     */
    public function send(BotResponse $message): self
    {
        if (!$this->bot_user) {
            throw new \LogicException('Invalid bot_user');
        }
        
        if ($message->media) {
            $this->client->sendMediaGroup([
                'chat_id' => $this->bot_user->provider_user_id,
                'media' => $message->media,
                'text' => 'test',
            ]);

            return $this;
        }

        if (!$message->image) {
            $this->client->sendMessage([
                'chat_id' => $this->bot_user->provider_user_id,
                'text' => $message->message,
                'parse_mode' => $message->parse_mode,
                'reply_markup' => $message->reply_markup
            ]);

            return $this;
        }

        if (mb_strlen($message->message) <= 200) {
            $this->client->sendPhoto([
                'chat_id' => $this->bot_user->provider_user_id,
                'photo' => InputFile::create($message->getImage()),
                'caption' => $message->message,
                'parse_mode' => $message->parse_mode,
                'reply_markup' => $message->reply_markup
            ]);

            return $this;
        }

        $this->client->sendPhoto([
            'chat_id' => $this->bot_user->provider_user_id,
            'photo' => InputFile::create($message->getImage()),
            'reply_markup' => $message->reply_markup
        ]);

        $this->client->sendMessage([
            'chat_id' => $this->bot_user->provider_user_id,
            'text' => $message->message,
            'parse_mode' => $message->parse_mode,
            'reply_markup' => $message->reply_markup
        ]);

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @inheritDoc
     */
    public function getProviderId(): int
    {
        return static::TELEGRAM_ID;
    }

    /**
     * @inheritDoc
     */
    public function getProviderUserId()
    {
        if (!$this->request || empty($this->request['message']['from']['id'])) {
            if ($this->bot_user) {
                return $this->bot_user->provider_user_id;
            }

            throw new \LogicException('Invalid request data');
        }

        return $this->request['message']['from']['id'];
    }

    /**
     * @inheritDoc
     */
    public static function getProviderUserIdFromRequest(array $request)
    {
        return $request['message']['from']['id'] ?? $request['callback_query']['from']['id'];
    }

    /**
     * @inheritDoc
     */
    public static function getFirstNameFromRequest(array $request)
    {
        if( isset($request['message']['from']['first_name']) ){
            return $request['message']['from']['first_name'];
        }

        if( isset($request['callback_query']['from']['first_name'])){
            return $request['callback_query']['from']['first_name'];
        }

        return null;
    }

    /**
     * @inheritDoc
     */
    public static function getLastNameFromRequest(array $request)
    {
        if( isset($request['message']['from']['last_name']) ){
            return $request['message']['from']['last_name'];
        }

        if( isset($request['callback_query']['from']['last_name'])){
            return $request['callback_query']['from']['last_name'];
        }

        return null;
    }

    /**
     * @inheritDoc
     */
    public static function getUsernameFromRequest(array $request)
    {
        if( isset($request['message']['from']['username']) ){
            return $request['message']['from']['username'];
        }

        if( isset($request['callback_query']['from']['username'])){
            return $request['callback_query']['from']['username'];
        }

        return null;
    }

    /**
     * @inheritDoc
     */
    public static function getDeepLinkMarkFromRequest(array $request): ?string
    {
        if (
            empty($request['message']['text'])
            || strpos($request['message']['text'], ' ') === false
            || strpos($request['message']['text'], '/start') === false
        ) {
            return null;
        }

        [$command, $deeplink_mark] = explode(' ', $request['message']['text'], 2);

        if ($command !== '/start') {
            return null;
        }

        return base64_decode($deeplink_mark) ?: null;
    }

    /**
     * @inheritDoc
     */
    public static function getLocaleFromRequest(array $request) : string
    {
        switch ($request['message']['from']['language_code'] ??  $request['callback_query']['from']['language_code'])  {
            case 'uk':
                return 'ua';

            case 'ru':
                return 'ru';

            default:
                return config('app.default_locale');
        }
    }

    /**
     * @param array $request
     *
     * @return string|null
     */
    public static function getMessageFromRequest(array $request): ?string
    {
        $message = $request['message']['text'] ?? null;

        if (!$message) {
            return null;
        }

        if ($message[0] === '/') {
            return null;
        }

        return $message;
    }

    /**
     * @param array $request
     *
     * @return string|null
     */
    public static function getCallbackDataFromRequest(array $request): ?string
    {
        $callback_data = $request['callback_query']['data'] ?? null;

        if (!$callback_data) {
            return null;
        }

        return $callback_data;
    }

    /**
     * @param string|null $deeplink_mark
     *
     * @return string
     */
    protected static function getLink(string $deeplink_mark = null): string
    {
        if (!$deeplink_mark) {
            return 'https://t.me/' . config('telegram.bots.mybot.username');
        }

        return 'https://t.me/' . config('telegram.bots.mybot.username') . '?start=' . $deeplink_mark;
    }

    #endregion
}
