<?php

namespace App\Services\ChatBot;

use App\User;
use App\Models\BotUser;
use App\Services\ChatBot;
use App\Models\Product\Product;
use App\Services\Catalog\Pricing;
use Telegram\Bot\Keyboard\Keyboard;
use App\Repositories\ProductRepository;
use Telegram\Bot\Laravel\Facades\Telegram;
use App\DataContainers\AbstractDataContainer;
use App\Services\ChatBot\DataContainers\BotResponse;
use App\Services\ChatBot\Exceptions\ResponseErrorException;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;

/**
 * @property ChatBot chat_bot
 * @property array request_data
 */
class RequestHandler extends AbstractDataContainer
{
    #region Builders

    /**
     * @param ChatBot $chat_bot
     *
     * @return static
     */
    public static function build(array $request_data, ChatBot $chat_bot): self
    {
        $handler = static::make([
            'chat_bot' => $chat_bot,
            'request_data' => $request_data,
        ]);

        app()->setLocale($handler->getLocale());

        return $handler;
    }

    #endregion

    #region Actions

    /**
     * @return $this
     */
    public function process()
    {
        if ($this->getDeepLinkMark()) {
            $this->processDeeplink();
        }

        if ($this->getCallbackData()) {
            $this->processCallbackData();
            return $this;
        }

        if ($this->getMessage()) {
            $this->processMessage();
        }

        return $this;
    }

    /**
     * @return void
     */
    private function processDeeplink()
    {
        $access_token = $this->getDeepLinkMark();

        if (!$access_token) {
            throw new \LogicException('Invalid data in DeepLink processing');
        }

        /** @var BotUser $bot_user */
        $bot_user = BotUser::query()
            ->where('provider_id', $this->chat_bot->getProviderId())
            ->with('user')
            ->first();

        if ($bot_user && $bot_user->provider_user_id != $this->chat_bot->bot_user->provider_user_id) {
            throw new ResponseErrorException(__('bots.errors.the_chat_already_linked_to_other_user'));
        }

        /** @var User $user */
        $user = User::query()
            ->where('access_token', $access_token)
            ->first();

        if (!$user) {
            throw new ResponseErrorException(__('bots.errors.invalid_request'));
        }

        if ($bot_user && $bot_user->user_id) {
            if ($bot_user && $bot_user->user_id != $user->id) {
                throw new ResponseErrorException(__('bots.errors.invalid_request'));
            }

            $this->chat_bot->sendMessage(__('bots.messages.account_linked_successfully'));

            return;
        }

        $user->generateAccessToken();

        $this->chat_bot->bot_user->user_id = $user->id;
        $this->chat_bot->bot_user->locale = $this->getLocale();

        $this->chat_bot->bot_user->save();

        $this->chat_bot->sendMessage(__('bots.messages.account_linked_successfully'));
    }

    /**
     * @return void
     */
    private function processMessage()
    {
        $message = $this->getMessage();

        if (!$message) {
            throw new \LogicException('Invalid data in Message processing');
        }

        /** @var Product $product */
        $product = Product::query()
            ->where(function (EloquentBuilder $query) use ($message) {
                $query
                    ->where('SKU', $message)
                    ->orWhere('barcode', $message);
            })
            ->where('is_active', true)
            ->first();

        if (!$product) {
            $this->chat_bot->sendMessage(__('bots.errors.product_not_found'));

            return;
        }

        if( strlen($message) > 7 ){
            $searched_by_barcode = true;
        }else{
            $searched_by_barcode = false;
        }

        $this->sendProduct($product, $searched_by_barcode);
    }

    /**
     * @return void
     */
    private function processCallbackData()
    {
        $callback_data = $this->getCallbackData();

        [$sku, $callback_action] = explode(":", $callback_data);

        $product = Product::where('SKU', $sku)->first();

        switch($callback_action){
            case 'getPreviousProduct':
                $this->sendProduct(ProductRepository::getPreviousProductBySku($product), true);
                break;
            case 'getNextProduct':
                $this->sendProduct(ProductRepository::getNextProductBySku($product), true);
                break;
            case 'getFullGallery':
                $this->sendGallery($product);
                break;

        }

        return false;
    }

    private function sendGallery(Product $product){
        $this->chat_bot->send(BotResponse::make([
            'media' => [$product->photo_path, $product->photo_path]
        ]));
    }

    /**
     * @param Product $product
     */
    private function sendProduct(Product $product, Bool $searched_by_barcode = false)
    {
        $html = str_replace( ['<br />', '<br/>', '<br>'], "\n", view('chat-bots.product')
            ->with([
                'product' => $product,
                'user' => $this->chat_bot->bot_user->user,
                'pricing' => Pricing::init($this->chat_bot->bot_user->user),
                'searched_by_barcode' => $searched_by_barcode,
            ])
            ->render());
            
            $nextPproduct = ProductRepository::getNextProductBySku($product);
            $previousProduct = ProductRepository::getPreviousProductBySku($product);

            $keyboard = Keyboard::make()->inline()
            ->row(
                Keyboard::inlineButton(['text' => '<<< ' . $previousProduct->SKU, 'callback_data' => $product->SKU . ':getPreviousProduct']),
                Keyboard::inlineButton(['text' => $nextPproduct->SKU . ' >>>', 'callback_data' => $product->SKU . ':getNextProduct'])
            )
            ->row(
                // Keyboard::inlineButton(['text' => 'Все фото', 'callback_data' => $product->SKU . ':getFullGallery']),
                Keyboard::inlineButton(['text' => 'Ссылка на сайт', 'url' => routeLocale('product', ['product' => $product])]),
            );

        $this->chat_bot->send(BotResponse::make([
            'image' => $product->photo_path,
            'message' => $html,
            'reply_markup' => $keyboard
        ]));
    }

    #endregion

    #region Is Condition methods

    #endregion

    #region Getters

    /**
     * @return bool
     */
    private function getDeepLinkMark(): ?string
    {
        return $this->chat_bot::getDeepLinkMarkFromRequest($this->request_data);
    }

    /**
     * @return string
     */
    public function getLocale(): string
    {
        return $this->chat_bot::getLocaleFromRequest($this->request_data);
    }

    /**
     * @return string|null
     */
    private function getMessage()
    {
            return $this->chat_bot::getMessageFromRequest($this->request_data);
    }

    /**
     * @return string|null
     */
    private function getCallbackData()
    {
        return $this->chat_bot::getCallbackDataFromRequest($this->request_data);
    }

    #endregion
}
