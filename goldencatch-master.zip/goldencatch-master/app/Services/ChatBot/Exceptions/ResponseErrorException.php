<?php

namespace App\Services\ChatBot\Exceptions;

class ResponseErrorException extends \RuntimeException
{

}
