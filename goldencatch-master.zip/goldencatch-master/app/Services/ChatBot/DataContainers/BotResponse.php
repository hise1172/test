<?php

namespace App\Services\ChatBot\DataContainers;

use App\DataContainers\AbstractDataContainer;

/**
 * @property string image
 * @property string message
 * @property string parse_mode
 */
class BotResponse extends AbstractDataContainer
{
    protected $parse_mode = 'HTML';

    /**
     * @return string
     */
    public function getImage() : string
    {
        if (config('app.debug')) {
//            return 'https://via.placeholder.com/300/09f/fff.png';
        }

        return $this->image;
    }
}
