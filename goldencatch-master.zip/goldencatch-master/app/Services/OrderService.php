<?php


namespace App\Services;

use App\Exceptions\OrderProductException;
use App\Helpers\Cart;
use App\Helpers\TopProduct;
use App\Http\Requests\Order\AbstractOrderRequest;
use App\Jobs\SendNewOrderMailToManagerJob;
use App\Jobs\SendNewOrderNotificationToUserJob;
use App\Models\LiqpayHash;
use App\Models\NovaPoshta\NovaPoshtaCities;
use App\Models\NovaPoshta\NovaPoshtaOrder;
use App\Models\Order;
use App\Models;
use App\Models\Product\Product;
use App\Models\Product\ProductOrder;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Str;
use App\Helpers\Deliver;
use GoogleTagManager;
use InvalidArgumentException;

/**
 * Class OrderService
 * @package App\Services
 */
class OrderService
{
    public $liqpayService;
    public $deliver;
    public $cartService;

    public function __construct(LiqpayService $liqpayService, Deliver $deliver, CartService $cartService)
    {
        $this->liqpayService = $liqpayService;
        $this->deliver = $deliver;
        $this->cartService = $cartService;
    }

    public function index()
    {
        $user = Auth::user();
        /**
         * @var Cart $cart
         */
        $cart = Session::get('cart', new Cart());
        $cart = $cart->productCart();

        return compact('user', 'cart');
    }

    #region Actions

    /**
     * @param AbstractOrderRequest $request
     * @param Cart $cart
     *
     * @return mixed
     */
    public function store(AbstractOrderRequest $request, Cart $cart)
    {
        $order_id = Str::random(30);

        if (!$cart->count()) {
            throw new InvalidArgumentException('The Cart is empty');
        }

        if (
            $cart->getDiscount() > 0
            && (
                !$request->user
                || $cart->getDiscount() > $request->user->getTotalAvailableBonuses($cart->getTotalSumm()->UAH)
            )
        ) {
            throw new \RuntimeException('There is not enough bonuses on your bonuses balance');
        }

        $products = $cart->productCart($request->isResellersConsole);

        if ( $request->get('need_call') === 'yes' ) {
            $request->merge(['need_call'=>'1']);
        }else{
            $request->merge(['need_call'=>null]);
        }

        $request->merge(['order_id' => $order_id]);
        $request->merge(['delivery_id' => $this->deliver->delivery::where('slug', $request->get('delivery_method', Deliver::DEFAULT_METHOD))->first()->id]);
        $request->merge(['price' => $products['total_summ']]);
        $request->merge(['price_without_discount' => $products['summ']]);
        $request->merge(['user_id' => $request->user->id]);
        $request->merge(['lastname' => ""]);

        if ($cart->getDiscount()) {
            $request->merge(['discount' => $cart->getDiscount()]);
        }

        DB::beginTransaction();

        try {
            /** @var Order $order */
            $order = Order::create($request->only([
                'surname',
                'name',
                'lastname',
                'privat_pay',
                'user_id',
                'phone',
                'email',
                'comments',
                'order_id',
                'delivery_id',
                'price',
                'price_without_discount',
                'need_call',
                'order_type_id',
                'payment_method_id',
                'discount',
            ]));

            if ($cart->getDiscount()) {
                SpentBonusOnCheckout::build($request->user, $order, $cart)
                    ->execute();
            }

            foreach ($products['products'] as $cart_product) {
                /** @var Cart\Item $cart_product */

                if ($request->getOrderTypeID() !== Order::TYPE_HELP_REQUEST) {
                    $this->checkProductBeforeSave($cart_product->id, $cart, $request->isResellersConsole);
                }

                $product = CartService::getProductInstance($cart_product->id, $cart);

                if (!isset($cart_product->price) || !$product) {
                    continue;
                }

                /** @var ProductOrder $order_item */
                $order_item = ProductOrder::create([
                    'product_id' => $cart_product->id,
                    'order_id' => $order->id,
                    'count' => $cart_product->count,
                    'price' => $cart_product->price,
                ]);

                ApplyPromotion::cashbackOnCheckout($request->user, $cart, $cart_product, $order_item);

                TopProduct::addProduct($cart_product->id);

                $product->reduceStockBalance($cart_product->count, $request->isResellersConsole);
            }
        } catch (OrderProductException $e) {
            DB::rollBack();

            throw $e;
        }

        DB::commit();

        if (
            $request->getOrderTypeID() === Order::TYPE_GENERIC
            && in_array($request->get('delivery_method'), [
                Models\Delivery::NEWPOST_DEPARTMENT,
                Models\Delivery::NEWPOST_COURIER,
                Models\Delivery::DELIVERY_COMPANY,
                Models\Delivery::AUTOLUX,
                Models\Delivery::TRANSPORT_TO_CITY,
            ])
        ) {
            $request->merge(['order_id' => $order->id]);
            $request->merge(['newpost_region' => NovaPoshtaCities::where('ref', $request->get('newpost_city'))->first()->area]);
            $novaOrder = $request->only(
                'newpost_region',
                'newpost_city',
                'newpost_warehouse',
                'city',
                'order_id'
            );
            $newPoshtaOrder = NovaPoshtaOrder::create($novaOrder);
            $order->address_id = $newPoshtaOrder->id;
            $order->save();

            $newPoshtaOrder->order()->associate($order);
        }

        if ($request->getOrderTypeID() === Order::TYPE_GENERIC) {
            Session::forget('cart');
        }

        GoogleTagManager::purchase($products, $order);

        $order_collection = collect($products['products']);
        $parent_order_collection = $order_collection->map(function ($item, $key) {
            $product = Models\Product\Product::find($item['id']);
            return $product->parent_id ?? $product->id;
        });

        SendNewOrderMailToManagerJob::dispatch($order, $request->isResellersConsole);
        SendNewOrderNotificationToUserJob::dispatch($order);

        return $order;
    }

    #endregion

    #region Getters

    /**
     * @param Product $product
     *
     * @return mixed
     */
    public function getPurchasedProducts(Product $product) {
        $ProductOrdersId = $product->orders->pluck('order_id');
        return LiqpayHash::whereIn('order_id',$ProductOrdersId)->where('is_payed', true)->count();
    }

    /**
     * @param int $count
     *
     * @return mixed
     */
    public function getAll($count = 10)
    {
        return Order::getAllByUserId(Auth::user()->id, $count);
    }

    #endregion

    #region Helpers

    /**
     * @param int $product_id
     * @param Cart $cart
     * @param bool $for_resellers
     */
    public function checkProductBeforeSave(int $product_id, Cart $cart, bool $for_resellers)
    {
        /** @var CartService $cart_service */
        $cart_service = app()->make(CartService::class);

        if (!$cart_service->isValid($for_resellers, $cart)) {
            throw new OrderProductException($cart_service->getValidationErrors());
        }
    }

    #endregion
}
