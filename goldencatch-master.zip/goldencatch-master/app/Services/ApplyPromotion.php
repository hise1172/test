<?php

namespace App\Services;

use App\Models\Product\ProductOrder;
use App\Models\UserPromotion;
use App\Models\Promotion;
use App\User;
use Illuminate\Support\Collection;
use App\Helpers\Cart;
use App\Models\BonusHistory;

class ApplyPromotion
{
    /**
     * @param User $user
     */
    public static function onRegistration(User $user)
    {
        /** @var Promotion[]|Collection $promos */
        $promos = Promotion::getList(Promotion::TRIGGER_REGISTRATION)
            ->where('expire_at', '>', date('Y-m-d H:i:s'));

        foreach ($promos as $promo) {
            UserPromotion::query()
                ->create([
                    'user_id' => $user->id,
                    'promotion_id' => $promo->id,
                ]);
        }
    }

    /**
     * @param User $user
     * @param Cart $cart
     * @param Cart\Item $cart_product
     * @param ProductOrder $order_item
     */
    public static function cashbackOnCheckout(User $user, Cart $cart, Cart\Item $cart_product, ProductOrder $order_item)
    {
        /** @var Promotion|null $checkout_bonuses */
        $product_of_week_bonus = Promotion::getList(Promotion::TRIGGER_CHECKOUT, Promotion::CODE_PRODUCT_OF_WEEK)
            ->first();

        $auto_checkout_bonuses_amount = 0;

        if (
            $product_of_week_bonus
            && $cart_product->is_product_of_week
            && $product_of_week_bonus->min_cart_amount < $cart->getTotalSumm()->UAH
        ) {
            $auto_checkout_bonuses_amount = $product_of_week_bonus->getDiscount($cart_product->price);
        }

        if ($auto_checkout_bonuses_amount > $cart_product->cashback_amount) {
            $order_item->cashback()->save(new BonusHistory([
                'user_id' => $user->id,
                'amount' => $auto_checkout_bonuses_amount,
                'comment' => 'promo_code:' . $product_of_week_bonus->promo_code,
            ]));

            return;
        }

        if ($cart_product->cashback_amount <= 0) {
            return;
        }

        $order_item->cashback()->save(new BonusHistory([
            'user_id' => $user->id,
            'amount' => $cart_product->cashback_amount,
        ]));
    }
}
