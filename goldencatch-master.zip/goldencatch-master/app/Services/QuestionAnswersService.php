<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

/**
 * Class QuestionAnswersService
 * @package App\Services
 */
class QuestionAnswersService
{
    /**
     * @param Request $request
     */
    public function getQuestionAnswerData(Request $request)
    {
        $data = $request->only(['product_id', 'parent_id', 'content']);
        Arr::set($data, 'user_id', Auth::id());
        return $data;
    }

}
