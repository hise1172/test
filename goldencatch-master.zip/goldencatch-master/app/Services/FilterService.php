<?php

namespace App\Services;

use App\Models\Category;
use App\DTOs\Product\ProductFilterDTO;
use App\Helpers\ParseUrlFilter;
use App\Repositories\BrandRepository;
use App\Repositories\TypeFishesRepository;
use App\Repositories\TypesRepository;
use Illuminate\Http\Request;

/**
 * Class FilterService
 * @package App\Services
 */
class FilterService
{
    /**
     * Use to parse url params and return filters
     * @var ParseUrlFilter
     */
    private $urlParser;
    /**
     * Get brands
     * @var BrandRepository
     */
    private $brandRepository;
    /**
     * Get type fishes
     * @var TypeFishesRepository
     */
    private $fishesRepository;
    /**
     * Get type produtcs
     * @var TypesRepository
     */
    private $typesRepository;

    /**
     * FilterService constructor.
     * @param ParseUrlFilter $urlParser
     * @param BrandRepository $brandRepository
     * @param TypeFishesRepository $fishesRepository
     * @param TypesRepository $typesRepository
     */
    public function __construct(
        ParseUrlFilter $urlParser,
        BrandRepository $brandRepository,
        TypeFishesRepository $fishesRepository,
        TypesRepository $typesRepository
    )
    {
        $this->urlParser = $urlParser;
        $this->brandRepository = $brandRepository;
        $this->fishesRepository = $fishesRepository;
        $this->typesRepository = $typesRepository;
    }

    /**
     * Get filters from request
     * @param Request $request
     * @param Category|null $category
     * @return ProductFilterDTO
     */
    public function getProductFilterFromRequest(Request $request, Category $category = null)
    {
        $dto = new ProductFilterDTO();
        $dto->setBrand($this->urlParser->getBrands($request->path()))
            ->setType($this->urlParser->getTypes($request->path()))
            ->setTypeFishes($this->urlParser->getTypeFishes($request->path()))
            ->setCategory($category)
            ->setWeight($this->urlParser->getWeight($request->path()))
            ->setPrice($this->urlParser->getPrice($request->path()))
            ->setSearch($request->get('search'))
            ->setSort($request->get('sort'), $request->get('by', 'asc'));
        return $dto;
    }

    /**
     * Get all brands for view
     * @return mixed
     */
    public function getBrands()
    {
        return $this->brandRepository->all();
    }

    /**
     * Get all type fishes for view
     * @return mixed
     */
    public function getTypeFishes($category=null)
    {
//        dd($this->fishesRepository->all());
//        if(isset($category)){
//
//
//        }
        return $this->fishesRepository->all();
    }

    /**
     * Get all types
     * @return mixed
     */
    public function getTypes($category=null)
    {
        if(isset($category)){

        }
        return $this->typesRepository->all();
    }
}
