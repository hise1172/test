<?php

namespace App\Services\ExportImport\NewProducts;

use App\DataContainers\AbstractDataContainer;
use App\Models\Product\Product;
use RuntimeException;
use InvalidArgumentException;

/**
 * @property string SKU
 * @property string SKU_parent
 * @property string slug
 * @property string name_ru
 * @property string name_ua
 * @property string category_slug
 * @property string brand_slug
 *
 * @property int parent_id
 * @property int category_id
 * @property int brand_id
 */
class TableRow extends AbstractDataContainer
{
    private static array $required_properties = [
        'SKU',
        'slug',
        'name_ru',
        'name_ua',
        'category_slug',
        'brand_slug',
    ];
    private array $allowed_properties = [
        'SKU',
        'SKU_parent',
        'slug',
        'name_ru',
        'name_ua',
        'category_slug',
        'brand_slug',
    ];

    #region Builders

    /**
     * @param array $data
     *
     * @return TableRow
     */
    public static function create(array $data = [])
    {
        $object = parent::create();

        foreach ($data as $name => $value) {
            if (!in_array($name, $object->allowed_properties)) {
                throw new InvalidArgumentException("Property {$name} is not allowed");
            }

            $object->$name = trim($value);
        }

        return $object;
    }

    #endregion

    #region Updates methods

    /**
     * @return ?Product
     */
    public function save(): ?Product
    {
        // Validate date
        if (!$this->category_id) {
            throw new RuntimeException('`category_slug` is invalid. Product SKU: ' . $this->SKU);
        }

        if (!$this->brand_id) {
            throw new RuntimeException('`brand_slug` is invalid. Product SKU: ' . $this->SKU);
        }

        $name = [
            'ru' => $this->name_ru,
            'ua' => $this->name_ua,
        ];

        $data = [
            'SKU' => $this->SKU,
            'slug' => $this->slug,
            'name' => $name,
            'description' => $name,
            'short_description' => $name,
            'category_id' => $this->category_id,
            'brand_id' => $this->brand_id,
            'status' => 0,
            'is_active' => 0,
            'wholesale' => 0,
        ];

        if ($this->parent_id) {
            $data['parent_id'] = $this->parent_id;
        }

        if ($this->SKU_parent) {
            $data['SKU_parent'] = $this->SKU_parent;
        }

        return Product::create($data);
    }

    #endregion

    #region Is Condition methods

    /**
     * @param array $data
     */
    public static function isValid($data = []): bool
    {
        foreach (static::$required_properties as $property_name) {
            if (empty($data[$property_name])) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return bool
     */
    public function isChildProduct(): bool
    {
        return (bool) $this->SKU_parent;
    }

    #endregion
}
