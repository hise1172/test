<?php

namespace App\Services\ExportImport\NewProducts;

use App\Services\ExportImport\BasicImport;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product\Product;
use RuntimeException;

class Import extends BasicImport
{
    private int $changes_count = 0;
    /** @var TableRow[]  */
    private array $parent_products = [];
    /** @var TableRow[]  */
    private array $children_products = [];
    /**
     * @var array
     * [
     *      'SKUs' => [
     *          string => int,
     *          ...
     *      ],
     *      'categories' => [
     *          string => int,
     *          ...
     *      ],
     *      'brands' => [
     *          string => int,
     *          ...
     *      ],
     * ]
     */
    private array $data = [];

    #region Actions

    /**
    * @param array $row
    *
    * @return null
    */
    public function model(array $row)
    {
        if (empty(static::$columns_list)) {
            $this->setColumnList($row);

            return null;
        }

        $data = static::restrictData($row);

        if (!TableRow::isValid($data)) {
            throw new RuntimeException('Required columns are invalid, please check your .CSV file.');
        }

        $row = TableRow::create($data);

        $this->add($row);

        return null;
    }

    /**
     * @return $this
     */
    public function save()
    {
        $this->collectAvailableData();

        // Save Parent products
        foreach ($this->parent_products as $table_row) {
            $product = $this->saveProduct($table_row);

            if ($product === true) {
                continue;
            }

            $this->data['SKUs'][$product->SKU] = $product->id;
            $this->changes_count ++;
        }

        // Save Children products
        foreach ($this->children_products as $table_row) {
            if (empty($this->data['SKUs'][$table_row->SKU_parent])) {
                throw new RuntimeException('`SKU_parent` is invalid. Product SKU ' . $table_row->SKU);
            }

            $table_row->parent_id = $this->data['SKUs'][$table_row->SKU_parent];

            $product = $this->saveProduct($table_row);

            if ($product === true) {
                continue;
            }

            $this->data['SKUs'][$product->SKU] = $product->id;
            $this->changes_count ++;
        }

        return $this;
    }

    /**
     * @param TableRow $table_row
     *
     * @return Product|true
     *      true - a product already exists in DB
     */
    private function saveProduct(TableRow $table_row)
    {
        if (is_numeric($this->data['SKUs'][$table_row->SKU] ?? null)) {
            return true;
        }

        if (!empty($this->data['slugs'][$table_row->SKU][$table_row->slug])) {
            throw new RuntimeException('`slug` already exists in DB. Product SKU ' .  $table_row->SKU);
        }

        $table_row->category_id = !empty($this->data['categories'][$table_row->category_slug])
            ? $this->data['categories'][$table_row->category_slug]
            : null;
        $table_row->brand_id = !empty($this->data['brands'][$table_row->brand_slug])
            ? $this->data['brands'][$table_row->brand_slug]
            : null;

        $product = $table_row->save();

        if (!$product) {
            throw new RuntimeException('Product was not created in DB. Product SKU ' . $table_row->SKU);
        }

        return $product;
    }

    #endregion

    #region Setters

    /**
     * @param TableRow $table_row
     */
    private function add(TableRow $table_row)
    {
        $this->data['SKUs'][$table_row->SKU] = false;
        $this->data['slugs'][$table_row->slug] = false;
        $this->data['categories'][$table_row->category_slug] = false;
        $this->data['brands'][$table_row->brand_slug] = false;

        if ($table_row->isChildProduct()) {
            $this->data['SKUs'][$table_row->SKU_parent] = false;
            $this->children_products[$table_row->SKU] = $table_row;

            return;
        }

        $this->parent_products[$table_row->SKU] = $table_row;
    }

    #endregion

    #region Getters

    /**
     * @return int
     */
    public function getProductsCount(): int
    {
        return count($this->parent_products) + count($this->children_products);
    }

    /**
     * @return int
     */
    public function getChangesCount(): int
    {
        return $this->changes_count;
    }

    #endregion

    #region Helpers

    /**
     * @return void
     */
    private function collectAvailableData()
    {
        // Get Products
        if (!empty($this->data['SKUs'])) {
            $rows = Product::query()
                ->whereIn('SKU', array_keys($this->data['SKUs']))
                ->orWhereIn('slug', array_keys($this->data['slugs']))
                ->get();

            foreach ($rows as $product) {
                /** @var Product $product */
                $this->data['SKUs'][$product->SKU] = $product->id;
                $this->data['slugs'][$product->slug] = $product->id;
            }
        }

        // Get Categories
        if ($this->data['categories']) {
            $rows = Category::query()
                ->whereIn('slug', array_keys($this->data['categories']))
                ->get();

            foreach ($rows as $categories) {
                /** @var Category $categories */
                $this->data['categories'][$categories->slug] = $categories->id;
            }
        }

        // Get Brands
        if ($this->data['brands']) {
            $rows = Brand::query()
                ->whereIn('slug', array_keys($this->data['brands']))
                ->get();

            foreach ($rows as $brand) {
                /** @var Brand $brand */
                $this->data['brands'][$brand->slug] = $brand->id;
            }
        }
    }

    #endregion
}
