<?php

namespace App\Services\ExportImport;

use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;
use InvalidArgumentException;
use RuntimeException;

abstract class BasicImport implements ToModel, WithCustomCsvSettings
{
    protected static array $columns_list = [];
    private string $separator;

    /**
     * @param string $separator
     */
    public function __construct(string $separator)
    {
        if (!in_array($separator, [',', ';'])) {
            throw new InvalidArgumentException('Invalid $separator');
        }

        $this->separator = $separator;
    }

    #region Expanded

    /**
     * @return string[]
     */
    public function getCsvSettings(): array
    {
        return [
            'delimiter' => $this->separator,
        ];
    }

    #endregion

    #region Setters

    /**
     * @param array $column_list
     */
    protected function setColumnList(array $column_list)
    {
        foreach ($column_list as &$value) {
            if (is_numeric($value)) {
                throw new RuntimeException('Invalid columns list');
            }

            $value = trim($value, ' "\'-_+	');

            if (strpos($value, ',') !== false || strpos($value, ';') !== false) {
                throw new RuntimeException('Invalid separator or column name');
            }
        }

        static::$columns_list = $column_list;
    }

    #endregion

    #region Helpers

    /**
     * @param array $row
     *
     * @return array
     */
    protected static function restrictData(array $row): array
    {
        $return = [];

        foreach (static::$columns_list as $index => $column_name) {
            $return[$column_name] = $row[$index] ?? null;
        }

        return $return;
    }

    #endregion
}
