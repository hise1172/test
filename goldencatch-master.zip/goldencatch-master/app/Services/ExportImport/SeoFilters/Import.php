<?php

namespace App\Services\ExportImport\SeoFilters;

use App\Services\ExportImport\BasicImport;
use App\Models\SeoFilters;
use RuntimeException;

class Import extends BasicImport
{
    private int $changes_count = 0;

    private array $seo_filters = [];

    public function model(array $row)
    {
        if (empty(static::$columns_list)) {
            $this->setColumnList($row);

            return null;
        }

        $data = static::restrictData($row);

        if (!TableRow::isValid($data)) {
            throw new RuntimeException('Required columns are invalid, please check your .CSV file.');
        }

        $row = TableRow::create($data);

        $this->add($row);

        return null;
    }

    public function save()
    {
        foreach ($this->seo_filters as $table_row) {
            $filter = $this->saveFilter($table_row);

            if ($filter === true) {
                continue;
            }

            $this->changes_count ++;
        }

        return $this;
    }

    private function saveFilter(TableRow $table_row)
    {

        $filter = $table_row->save();

        if (!$filter) {
            throw new RuntimeException('Product was not created in DB. Product SKU ' . $table_row->SKU);
        }

        return $filter;
    }

    private function add(TableRow $table_row)
    {
        $this->seo_filters[$table_row->uri] = $table_row;
    }

    public function getFiltersCount(): int
    {
        return count($this->seo_filters);
    }

    public function getChangesCount(): int
    {
        return $this->changes_count;
    }


}
