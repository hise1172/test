<?php

namespace App\Services\ExportImport\SeoFilters;

use App\DataContainers\AbstractDataContainer;
use App\Models\SeoFilters;
use RuntimeException;
use InvalidArgumentException;

class TableRow extends AbstractDataContainer
{
    private static array $required_properties = [
        'uri',
        'h1_ru',
        'h1_ua',
        'title_ru',
        'title_ua',
        'description_ru',
        'description_ua',
        'text_ru',
        'text_ua',
        'robots_index',
        'robots_follow',
    ];
    private array $allowed_properties = [
        'uri',
        'h1_ru',
        'h1_ua',
        'title_ru',
        'title_ua',
        'description_ru',
        'description_ua',
        'text_ru',
        'text_ua',
        'robots_index',
        'robots_follow',
    ];

    public static function create(array $data = [])
    {
        $object = parent::create();

        foreach ($data as $name => $value) {
            if (!in_array($name, $object->allowed_properties)) {
                throw new InvalidArgumentException("Property {$name} is not allowed");
            }

            $object->$name = trim($value);
        }

        return $object;
    }

    public function save(): ?SeoFilters
    {

        $h1 = [
            'ru' => $this->h1_ru,
            'ua' => $this->h1_ua,
        ];

        $title = [
            'ru' => $this->title_ru,
            'ua' => $this->title_ua,
        ];

        $description = [
            'ru' => $this->description_ru,
            'ua' => $this->description_ua,
        ];

        $text = [
            'ru' => $this->text_ru,
            'ua' => $this->text_ua,
        ];

        $data = [
            'uri' => $this->uri,
            'h1' => $h1,
            'title' => $title,
            'description' => $description,
            'text' => $text,
            'robots_index' => $this->robots_index,
            'robots_follow' => $this->robots_follow,
        ];

        return SeoFilters::updateOrCreate(
            ['uri' => $data['uri']],
            $data
        );
    }

    public static function isValid($data = []): bool
    {
        foreach (static::$required_properties as $property_name) {
            if (empty($data[$property_name])) {
                return false;
            }
        }

        return true;
    }

}
