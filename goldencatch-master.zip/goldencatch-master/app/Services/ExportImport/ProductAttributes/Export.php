<?php

namespace App\Services\ExportImport\ProductAttributes;

use App\Services\ExportImport\ProductAttributes\TableRow\AdditionalColumn;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Product\Product;
use App\Models\ProductsAttributesNumericValues;
use App\Models\ProductsAttributesTextValues;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;

class Export implements FromCollection
{
    private $brand_ids = [];
    private $category_ids = [];
    private bool $products_of_week_only = false;
    private bool $include_attributes = true;

    /**
     * @param array $brands
     * @param array $categories
     * @param bool $products_of_week_only
     * @param bool $include_attributes
     */
    public function __construct($brands = [], $categories = [], bool $products_of_week_only = false, bool $include_attributes = true)
    {
        $this->brand_ids = $brands;
        $this->category_ids = $categories;
        $this->products_of_week_only = $products_of_week_only;
        $this->include_attributes = $include_attributes;
    }

    #region Actions

    /**
     * The result of the method will be placed into an export file
     *
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $query = Product::query();

        if ($this->brand_ids) {
            $query->whereIn('brand_id', $this->brand_ids);
        }

        if ($this->category_ids) {
            $query->whereIn('category_id', $this->category_ids);
        }

        if ($this->products_of_week_only) {
            $query->where('is_product_of_week', $this->products_of_week_only);
        }

        // Collect Attribute Types
        $additional_columns_list = $this->include_attributes
            ? $this->getAdditionalColumnsList()
            : collect();

        // Collect Products data
        $collected_rows = [];

        foreach ($query->get() as $product) {
            $collected_rows[] = $this->getTableRow($product, $additional_columns_list);
        }

        // Collect export table rows
        $collection = [];

        foreach ($collected_rows as $table_row) {
            $item = $table_row->toArray();

            if (!$collection) {
                // Set a table head
                $collection[] = array_keys($item);
            }

            $collection[] = array_values($item);
        }

        return !$collection ? collect() : $this->removeEmptyColumns($collection);
    }

    /**
     * @param array $collected_rows
     * [
     *      [head_row, ...],
     *      [product_row, ...],
     *      [product_row, ...],
     *      ...
     * ]
     *
     * @return Collection
     */
    public function removeEmptyColumns($collected_rows)
    {
        // Define empty columns
        $empty_columns = $collected_rows[0];

        foreach ($collected_rows as $row_index => $columns) {
            if ($row_index == 0) {
                continue;
            }

            foreach ($columns as $col_index => $value) {
                if ($this->isValueEmpty($value)) {
                    continue;
                }

                unset($empty_columns[$col_index]);
            }
        }

        // Remove empty columns and prepare the method returning data
        $collection = collect([
            array_values(
                array_diff($collected_rows[0], $empty_columns)
            ),
        ]);

        foreach ($collected_rows as $row_index => $columns) {
            if ($row_index == 0) {
                continue;
            }

            // Remove empty columns
            foreach ($columns as $col_index => $value) {
                if (!isset($empty_columns[$col_index])) {
                    continue;
                }

                if (!$this->isValueEmpty($value)) {
                    throw new \LogicException('The column value is not empty, but it has been defined as empty');
                }

                unset($columns[$col_index]);
            }

            $collection->add(array_values($columns));
        }

        return $collection;
    }

    #endregion

    #region Is Condition method

    /**
     * @param mixed $value
     *
     * @return bool
     */
    private function isValueEmpty($value): bool
    {
        return $value === ''
            || $value === []
            || $value === false
            || $value === null;
    }

    #endregion

    #region Setters

    /**
     * @param Product $product
     * @param AdditionalColumn[]|Collection $additional_columns
     *
     * @return TableRow
     */
    private function getTableRow(Product $product, Collection $additional_columns)
    {
        $all_attributes = $product->all_attributes;

        $collected_column_values = [];

        foreach ($additional_columns as $column) {
            /** @var AdditionalColumn $column */
            $column_values = $this->getAdditionalColumnValues($all_attributes, $column);

            $collected_column_values[$column->export_slug] = $column_values;
        }

        return TableRow::create([
            'id' => $product->id,
            'SKU' => $product->SKU,
            'name_ru' => $product->getTranslation('name', 'ru'),
            'name_ua' => $product->getTranslation('name', 'ua'),
            'category_slug' => $product->category->slug ?? '',
            'brand_slug' => $product->brand->slug ?? '',
            'is_active' => $product->is_active,
            'is_product_of_week' => $product->is_product_of_week,
            'additional_columns' => $collected_column_values,
        ]);
    }

    #endregion

    #region Getters

    /**
     * @return AdditionalColumn[]|Collection
     */
    private function getAdditionalColumnsList()
    {
        $result = collect();

        foreach (Attribute::all()->sortBy('filter_type') as $attr) {
            /** @var Attribute $attr */

            switch ($attr->filter_type) {
                case Attribute::TYPE_NUMERIC:
                case Attribute::TYPE_SLUG:
                    $result->put($attr->filter_slug, AdditionalColumn::create([
                        'id' => $attr->id,
                        'slug' => $attr->filter_slug,
                        'export_slug' => $attr->filter_slug,
                        'type_id' => $attr->filter_type,
                    ]));

                    break;

                case Attribute::TYPE_TEXT:
                    $attr_langs = $attr->getOriginal('filter_name');
                    ksort($attr_langs);

                    foreach ($attr_langs as $lang => $name) {
                        $export_slug = "{$attr->filter_slug}_{$lang}";

                        $result->put($export_slug, AdditionalColumn::create([
                            'id' => $attr->id,
                            'slug' => $attr->filter_slug,
                            'export_slug' => $export_slug,
                            'type_id' => $attr->filter_type,
                        ]));
                    }

                    break;

                default:
                    throw new \LogicException('Invalid attribute type');
            }
        }

        return $result;
    }

    /**
     * @param Collection $all_attributes
     * [
     *      [
     *          'parent' => Attribute,
     *          'children' => [
     *              AttributeSlugValue,
     *              ProductsAttributesNumericValues,
     *              ProductsAttributesTextValues,
     *              ...
     *          ],
     *      ],
     *      ...
     * ]
     * @param string $needed_attr
     *
     * @return AdditionalColumn[]
     */
    private function getAdditionalColumnValues(Collection $all_attributes, AdditionalColumn $needed_attr)
    {
        $result = [];

        foreach ($all_attributes as $prod_attr) {
            if ($prod_attr['parent']->filter_slug !== $needed_attr->slug) {
                continue;
            }

            $attrs = $prod_attr['children'];

            foreach ($attrs as $attr) {
                switch ($needed_attr->type_id) {
                    case Attribute::TYPE_SLUG:
                        /** @var AttributeSlugValue $attr */
                        $tmp_attr = clone $needed_attr;
                        $tmp_attr->export_slug = $tmp_attr->slug;
                        $tmp_attr->value = $attr->slug;
                        $result[] = $tmp_attr;

                        break;

                    case Attribute::TYPE_NUMERIC:
                        /** @var ProductsAttributesNumericValues $attr */
                        $tmp_attr = clone $needed_attr;
                        $tmp_attr->export_slug = $tmp_attr->slug;
                        $tmp_attr->value = $attr->value;
                        $result[] = $tmp_attr;

                        break;

                    case Attribute::TYPE_TEXT:
                        /** @var ProductsAttributesTextValues $attr */
                        foreach ($attr->getOriginal('value') as $lang_key => $value) {
                            $tmp_attr = clone $needed_attr;

                            $export_slug = "{$tmp_attr->slug}_{$lang_key}";

                            if ($export_slug !== $needed_attr->export_slug) {
                                continue;
                            }

                            $tmp_attr->export_slug = "{$tmp_attr->slug}_{$lang_key}";
                            $tmp_attr->value = $value;
                            $result[] = $tmp_attr;
                        }

                        break;

                    default:
                        throw new \LogicException('Invalid attribute type');
                }
            }
        }

        return $result;
    }

    #endregion
}
