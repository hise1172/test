<?php

namespace App\Services\ExportImport\ProductAttributes;

use App\DataContainers\AbstractDataContainer;
use App\Services\ExportImport\ProductAttributes\TableRow\AdditionalColumn;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product\Product;
use App\Models\ProductsAttributesNumericValues;
use App\Models\ProductsAttributesTextValues;
use Illuminate\Support\Collection;
use LogicException;
use RuntimeException;

/**
 * @property string id
 * @property string SKU
 * @property string name_ru
 * @property string name_ua
 * @property string category_slug
 * @property string brand_slug
 * @property bool is_active
 * @property bool is_product_of_week
 * @property AdditionalColumn[] $additional_columns
 * [
 *      export_slug => [
 *          AdditionalColumn,
 *          ...
 *      ],
 *      ...
 * ]
 */
class TableRow extends AbstractDataContainer
{
    private array $basic_properties = [
        'id',
        'SKU',
        'name_ru',
        'name_ua',
        'category_slug',
        'brand_slug',
        'is_active',
        'is_product_of_week',
        'additional_columns',
    ];

    /** @var Attribute[] */
    private $_attr_types;
    private $changed_products = [];

    /**
     * @inheritDoc
     */
    public function __get($name)
    {
        if (in_array($name, $this->basic_properties)) {
            $value = parent::__get($name);

            return $name === 'additional_columns' && !$value
                ? []
                : $value;
        }

        return $this->additional_columns[$name] ?? null;
    }

    /**
     * @inheritDoc
     */
    public function __set($name, $value)
    {
        if (in_array($name, $this->basic_properties)) {
            parent::__set($name, $value);

            return;
        }

        $this->_data['additional_columns'][$name] = $value;
    }

    #region Builders

    /**
     * @param array $data
     *
     * @return TableRow
     */
    public static function create(array $data = [])
    {
        $object = parent::create();

        foreach ($data as $name => $value) {
            $object->$name = $value;
        }

        return $object;
    }

    #endregion

    #region Updates methods

    /**
     * @return $this
     */
    public function save()
    {
        $product = Product::find($this->id);

        if (!$product) {
            throw new RuntimeException('Product does not exist. Product ID: ' . $this->id);
        }

        $this->saveProduct($product);
        $this->saveAttributes($product);

        return $this;
    }

    /**
     * @param Product $product
     */
    private function saveProduct(Product $product)
    {
        $is_changed = false;
        $old_product_data = $product->toArray();

        foreach ($this->basic_properties as $property_name) {
            switch ($property_name) {
                case 'additional_columns':
                    break;

                case 'category_slug':
                    if (!$this->isChanged($product->category->slug ?? '', $property_name)) {
                        break;
                    };

                    /** @var Category $category */
                    $category = Category::query()
                        ->where('slug', $this->$property_name)
                        ->first();

                    $product->category_id = $category->id;
                    $is_changed = true;

                    break;

                case 'brand_slug':
                    if (!$this->isChanged($product->brand->slug ?? '', $property_name)) {
                        break;
                    };

                    /** @var Brand $category */
                    $brand = Brand::query()
                        ->where('slug', $this->$property_name)
                        ->first();

                    $product->brand_id = $brand->id;
                    $is_changed = true;

                    break;

                case 'name_ru':
                    if (!$this->isChanged($product->getTranslation('name', 'ru'), $property_name)) {
                        break;
                    };

                    $product->setTranslation('name', 'ru', $this->$property_name);
                    $is_changed = true;

                    break;

                case 'name_ua':
                    if (!$this->isChanged($product->getTranslation('name', 'ua'), $property_name)) {
                        break;
                    };

                    $product->setTranslation('name', 'ua', $this->$property_name);
                    $is_changed = true;

                    break;

                default:
                    if (is_null($this->$property_name) || !$this->isChanged($product->$property_name, $property_name)) {
                        break;
                    };

                    $product->$property_name = $this->$property_name;
                    $is_changed = true;
            }
        }

        if (!$is_changed) {
            return;
        }

        $product->save();
        $this->logChangedProduct($old_product_data);
    }

    /**
     * @param Product $product
     */
    private function saveAttributes(Product $product)
    {
        $attr_types = $this->getAttributeTypes();

        $new_attrs = collect();

        foreach ($attr_types as $type) {
            $new_attrs[$type->filter_slug] = [
                'id' => $type->id,
                'value' => $this->getAttributeValueToSave($type),
            ];
        }

        // Check the product attributes on changes
        if (!$this->isAttributesChanged($product->all_attributes, $new_attrs)) {
            return;
        }

        $old_product_data = $product->toArray();
        $product->all_attributes = $this->prepareNewAttributesList($product, $new_attrs);
        $this->logChangedProduct($old_product_data, $new_attrs->toArray());
    }

    #endregion

    #region Is Condition methods

    /**
     * @param $value
     * @param string $property_name
     *
     * @return bool
     */
    private function isChanged($value, string $property_name)
    {
        return $this->$property_name != $value;
    }

    /**
     * @param Collection $all_product_attributes
     * @param Collection $new_attrs
     *
     * @return bool
     */
    private function isAttributesChanged($all_product_attributes, Collection $new_attrs)
    {
        foreach ($new_attrs as $new_slug => $new_attr) {
            if ($this->hasAttributeType($new_slug, $all_product_attributes)) {
                continue;
            }

            return true;
        }

        foreach ($all_product_attributes as $attribute) {
            /** @var Attribute $parent */
            $parent = $attribute['parent'];

            if (!isset($new_attrs[$parent->filter_slug])) {
                continue;
            }

            /** @var Collection|AttributeSlugValue[]|ProductsAttributesNumericValues[]|ProductsAttributesTextValues[] $children */
            $children = $attribute['children'];

            switch ($parent->filter_type) {
                case Attribute::TYPE_SLUG:
                    if (!$new_attrs[$parent->filter_slug]['value']) {
                        return true;
                    }

                    $db_values = $children
                        ->whereIn('id', $new_attrs[$parent->filter_slug]['value'])
                        ->count();

                    if ($db_values == count($new_attrs[$parent->filter_slug]['value'])) {
                        break;
                    }

                    return true;

                case Attribute::TYPE_NUMERIC:
                    if ((string) $children->first()->value === $new_attrs[$parent->filter_slug]['value']) {
                        break;
                    }

                    return true;


                case Attribute::TYPE_TEXT:
                    $db_value = $children->first()->getOriginal('value');

                    if ($db_value && !$new_attrs[$parent->filter_slug]['value']) {
                        return true;
                    }

                    foreach ($new_attrs[$parent->filter_slug]['value'] as $lang => $value) {
                        if ($db_value[$lang] == $value) {
                            continue;
                        }

                        return true;
                    }

                    break;

                default:
                    throw new LogicException('Invalid attribute type');
            }
        }

        return false;
    }

    /**
     * @param string $needed_type_slug
     * @param Collection $search_in_attributes
     *
     * @return bool
     */
    private function hasAttributeType(string $needed_type_slug, Collection $search_in_attributes): bool
    {
        foreach ($search_in_attributes as $attribute) {
            /** @var Attribute $parent */
            $parent = $attribute['parent'];

            if ($parent->filter_slug != $needed_type_slug) {
                continue;
            }

            return true;
        }

        return false;
    }

    #endregion

    #region Setters

    /**
     * @param array $product
     */
    private function logChangedProduct($old_product)
    {
        $this->changed_products[$old_product['id']] = $old_product['id'];
    }

    #endregion

    #region Getters

    /**
     * @return string[]
     */
    public function toArray() : array
    {
        $return = [
            'id' => '',
            'SKU' => '',
            'name_ru' => '',
            'name_ua' => '',
            'category_slug' => '',
            'brand_slug' => '',
            'is_active' => '',
            'is_product_of_week' => '',
        ];

        $additional_columns = $this->additional_columns;

        foreach (parent::toArray() as $name => $value) {
            if ($name === 'additional_columns') {
                ksort($additional_columns);

                continue;
            }

            if (in_array($name, ['is_active', 'is_product_of_week'])) {
                $return[$name] = (string) (int) $value;

                continue;
            }

            $return[$name] = $value;
        }

        foreach ($additional_columns as $export_slug => $column_values) {
            $value = [];

            foreach ($column_values as $column) {
                /** @var AdditionalColumn $column */
                if ($export_slug !== $column->export_slug) {
                    throw new LogicException('Invalid export_slug');
                }

                $value[] = $column->value;
            }

            $return[$export_slug] = implode(',', $value);
        }

        return $return;
    }

    /**
     * @return Attribute[]|\Illuminate\Database\Eloquent\Collection
     */
    private function getAttributeTypes()
    {
        if ($this->_attr_types) {
            return $this->_attr_types;
        }

        $properties = [];

        foreach (array_keys($this->additional_columns) as $name) {
            if (in_array(substr($name, -3), ['_ru', '_ua'])) {
                $name = substr($name, 0, -3);
            }

            $properties[$name] = true;
        }

        return $this->_attr_types = Attribute::query()
            ->whereIn('filter_slug', array_keys($properties))
            ->get();
    }

    /**
     * @param Attribute $attr_type
     *
     * @return array|mixed|null
     */
    private function getAttributeValueToSave(Attribute $attr_type)
    {
        switch ($attr_type->filter_type) {
            case Attribute::TYPE_SLUG:
                if (!$this->{$attr_type->filter_slug}) {
                    return $this->{$attr_type->filter_slug};
                }

                $slugs = explode(',', $this->{$attr_type->filter_slug});

                foreach ($slugs as &$value) {
                    $value = trim($value);
                }

                return array_column(
                    $attr_type->getSlugValues()
                        ->whereIn('slug', $slugs)
                        ->toArray(),
                    'id'
                );

            case Attribute::TYPE_NUMERIC:
                return trim($this->{$attr_type->filter_slug});

            case Attribute::TYPE_TEXT:
                $result = [];

                foreach ($this->additional_columns as $name => $value) {
                    /** @var string $value */
                    if (strpos($name, '_') === false) {
                        continue;
                    }

                    [$slug, $lang] = explode('_', $name);

                    if (!in_array($lang, ['ru', 'ua'])) {
                        throw new RuntimeException('You try to import unsupported language value. Product ID: ' . $this->id . ', Column name: ' . $name);
                    }

                    if ($slug !== $attr_type->filter_slug || !$value) {
                        continue;
                    }

                    $result[$lang] = trim($value);
                }

                if (!$result) {
                    return null;
                }

                if (count($result) != 2) {
                    throw new RuntimeException('Text attrebute has incorrect value. Product ID: ' . $this->id);
                }

                return $result;

            default:
                throw new LogicException('Invalid attribute type');
        }
    }

    /**
     * @return int[]
     */
    public function getChanges()
    {
        return $this->changed_products;
    }

    /**
     * @param Product $product
     * @param Collection $new_attributes
     *
     * @return Collection
     */
    private function prepareNewAttributesList(Product $product, Collection $new_attributes): ?Collection
    {
        $result = clone $new_attributes;

        foreach ($product->all_attributes as $attribute) {
            /** @var Attribute $parent */
            $parent = $attribute['parent'];
            /** @var Collection|AttributeSlugValue[]|ProductsAttributesNumericValues[]|ProductsAttributesTextValues[] $children */
            $children = $attribute['children'];

            if (isset($new_attributes[$parent->filter_slug])) {
                continue;
            }

            switch ($parent->filter_type) {
                case Attribute::TYPE_SLUG:
                    $value = $children->map(fn (AttributeSlugValue $attr) => $attr->id)->toArray();
                    break;

                case Attribute::TYPE_NUMERIC:
                    $value = implode(',', $children->map(fn (ProductsAttributesNumericValues $attr) => $attr->value)->toArray());
                    break;

                case Attribute::TYPE_TEXT:
                    $value = $children->first()->getOriginal('value');
                    break;

                default:
                    throw new LogicException('Invalid attribute type');
            }

            if (!$value) {
                continue;
            }

            $result[] = [
                'id' => $parent->id,
                'value' => $value,
            ];
        }

        foreach ($result as $key => $attr) {
            if (!$attr['value']) {
                unset($result[$key]);
            }
        }

        return $result;
    }

    #endregion
}
