<?php

namespace App\Services\ExportImport\ProductAttributes\TableRow;

use App\DataContainers\AbstractDataContainer;

/**
 * @property int id
 * @property string slug
 * @property string export_slug
 * @property int type_id
 * @property string value
 */
class AdditionalColumn extends AbstractDataContainer
{
}
