<?php

namespace App\Services\ExportImport\ProductAttributes;

use App\Services\ExportImport\BasicImport;

class Import extends BasicImport
{
    private $changes_count = [];

    #region Actions

    /**
    * @param array $row
    *
    * @return null
    */
    public function model(array $row)
    {
        if (empty(static::$columns_list)) {
            $this->setColumnList($row);

            return null;
        }

        $row = TableRow::create(static::restrictData($row))
            ->save();

        if ($row->getChanges()) {
            $this->changes_count += $row->getChanges();
        }

        return null;
    }

    #endregion

    #region Helpers

    /**
     * @return int
     */
    public function getChangesCount()
    {
        return count($this->changes_count);
    }

    #endregion
}
