<?php

namespace App\Services;

use App\Models\LiqpayHash;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class LiqpayService
{
    private const MESSAGE = 'Goldencach';
    private $liqpayHash;

    /**
     * @param LiqpayHash $liqpayHash
     */

    public function __construct(LiqpayHash $liqpayHash)
    {
        $this->liqpayHash = $liqpayHash;
    }

    public function setSignature($data)
    {
        return base64_encode(sha1(env('LIQPAY_PRIVATE_KEY') . $data . env('LIQPAY_PRIVATE_KEY'), 1));
    }

    /**
     * @param $amount
     * @param $order_id
     * @param $date
     * @return string
     */
    public function setData($amount, $order_id, $date,$id)
    {
        $hash = $this->setHash($date, $order_id);
        $this->liqpayHash::create(['order_hash' => $hash, 'order_id' => $order_id]);
        return base64_encode(json_encode([
            'version' => 3,
            'public_key' => env('LIQPAY_PUBLIC_KEY'),
            'private_key' => env('LIQPAY_PRIVATE_KEY'),
            'action' => 'hold',
            'amount' => $amount,
            'description' => 'Номер заказа:          '.$id,
            'currency' => 'UAH',
            'info' => $hash,
            'order_id' => $order_id,
            'result_url' => route('account.orders'),
            'server_url' => route('api.liqpay.server'),
        ]));
    }

    /**
     * @param $date
     * @param $order_id
     * @return mixed
     */
    public function setHash($date, $order_id)
    {
        $str = self::MESSAGE . $date . $order_id;
        return Hash::make($str);
    }

    /**
     * @param $hash
     * @param Order $order
     * @return boolean
     */
    public function checkPayment($hash, Order $order)
    {
        $compare = self::MESSAGE . $order->created_at . $order->order_id;
        return Hash::check($compare, $hash);
    }

    public function getData(Request $request)
    {
        $signatureCheck = base64_encode( sha1( env('LIQPAY_PRIVATE_KEY') . $request->get('data') . env('LIQPAY_PRIVATE_KEY'), 1) );
        if( $request->get('signature') == $signatureCheck ){
            return json_decode(base64_decode($request->get('data')), true, 512, JSON_UNESCAPED_UNICODE);
        }
        return NULL;
    }
}
