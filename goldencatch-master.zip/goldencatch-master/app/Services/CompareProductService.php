<?php

namespace App\Services;

use App\Helpers\CompareCollection;
use App\Helpers\UniqueCollection;
use App\Models\Category;
use App\Models\Product\Product;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\View\View;

/**
 * Class CompareProductService
 * @package App\Services
 */
class CompareProductService
{
    private const PRODUCT_COMPARES = 'compare_products';

    /**
     * Add product to compare
     * @param Request $request
     * @return array
     */
    public function addProductToCompare(Request $request)
    {
        $response = [];
        $id = $request->get('product');
        /**
         * @var $compareCollection CompareCollection
         * @var $product Product
         */
        $compareCollection = Session::get(self::PRODUCT_COMPARES, new CompareCollection());

        $product = Product::with('category')->find($id);
        $compareCollection->addProduct($product->category->slug, $product->id);
        $count = $compareCollection->count();
        Session::put('compare_products', $compareCollection);

        $response = [
            'category' => $product->category->slug,
            'category_count' => $this->getCompareProductsByCategory($product->category->slug)->count(),
            'count' => $count
        ];

        return $response;
    }

    /**
     * Delete product from compare
     * @param Request $request
     * @return int
     */
    public function deleteProductFromCompare(Request $request)
    {
        $product_id = $request->get('product');
        /**
         * @var CompareCollection $compareCollection
         */
        $compareCollection = Session::get(self::PRODUCT_COMPARES, new UniqueCollection());
        $compareCollection->deleteProduct($product_id);
        $count = $compareCollection->count();
        Session::put(self::PRODUCT_COMPARES, $compareCollection);
        return $count;
    }

    /**
     * View
     * @return array
     */
    public function getComparesProduct()
    {
        /**
         * @var $compareProducts CompareCollection
         */
        $compareProducts = Session::get(self::PRODUCT_COMPARES, collect());
        $categoryProduct = $compareProducts->toArray();

        return $this->makeCompareView($categoryProduct);
    }

    /**
     * @param array $categoryProduct
     * @return array
     */
    private function makeCompareView(array $categoryProduct)
    {
        static $compare_view = [];

        $key = implode(',', array_keys($categoryProduct));

        if (isset($compare_view[$key])) {
            return $compare_view[$key];
        }

        $result = [];
        $category_slugs = Category::query()->whereIn('slug', array_keys($categoryProduct))->get()->keyBy('slug');

        foreach ($categoryProduct as $category_slug => $products_ids) {
            $category = $category_slugs[$category_slug];
            /**
             * @var $category Category
             */
            $result[$category->name] = ['products' => $category->products()->whereIn('id', $products_ids)->get(),
                'category' => $category];
        }

        return $compare_view[$key] = $result;
    }

    /**
     * @param $category
     * @return Collection
     */
    public function getCompareProductsByCategory($category)
    {
        /**
         * @var CompareCollection $compareProducts
         */
        $compareProducts = Session::get(self::PRODUCT_COMPARES, new CompareCollection());

        $product_ids = $compareProducts->compareProductByCategory($category);
        return Product::with(['productAttribute', 'productAttribute.info', 'brand'])
            ->whereIn('id', $product_ids)
            ->get();
    }


    public function getAttributesCompare($products, $difference = false)
    {
        $attributes = ['Артикул' => [], 'brand' => [],];
        foreach ($products as $product) {
            $attributes['Артикул'][$product->id] = $product->SKU;
            foreach ($product->all_attributes as $attribute) {
                // Get array to show the links
                // OR string for direct output
                if( 1 == $attribute['parent']->is_filter && 1 == $attribute['parent']->filter_type ) {
                    foreach ($attribute['children'] as $child){
                        $attributes[ $attribute['parent']->desc_attr_name ][$product->id][] = [
                            'href' => routeLocale( 'catalog.filters', [ 'category' => $product->category->slug, 'filter1' => $attribute['parent']->filter_slug . '-' . $child->slug ] ),
                            'name' => $child->value,
                        ];
                    }
                }
                else {
                    $attributes[ $attribute['parent']->desc_attr_name ][$product->id] = $attribute['children']->pluck('value')->join(', ');
                }
            }

            $attributes['brand'][$product->id] = $product->brand_name;
            $attributes['brand'][$product->brand_name] = $product->brand_slug;
        }
        if ($difference) {
            foreach ($attributes as $attribute => $value) {
                if (count($value) < 2) {
                    continue;
                }
                $keys = array_keys($value);
                $run = true;
                for ($i = 0; $i < count($keys) && $run; ++$i) {
                    for ($j = $i + 1; $j < count($keys) && $run; ++$j) {
                        if ($value[$keys[$i]] != $value[$keys[$j]]) {
                            $run = false;
                        }
                    }
                }
                if ($run) {
                    unset($attributes[$attribute]);
                }
            }
        }
        return $attributes;
    }

    public function dropCategory($categorySlug)
    {
        /**
         * @var CompareCollection $compare
         */
        $compare = Session::get(self::PRODUCT_COMPARES, new CompareCollection());
        $count = $compare->removeCategoryCompare($categorySlug);
        Session::put(self::PRODUCT_COMPARES, $compare);
        return Response::json(compact('count'));
    }
}
