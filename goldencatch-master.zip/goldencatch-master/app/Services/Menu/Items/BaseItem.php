<?php

namespace App\Services\Menu\Items;

abstract class BaseItem
{
    protected string $icon = '';

    protected string $title = '';

    /**
     * @param string $title
     * @return BaseItem
     */
    public function setTitle(string $title): BaseItem
    {
        $this->title = trim($title, '-');

        return $this;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * @return bool
     */
    public function hasTitle(): bool
    {
        return !empty($this->title);
    }

    /**
     * @param string $icon
     * @return BaseItem
     */
    public function setIcon(string $icon): BaseItem
    {
        $this->icon = $icon;

        return $this;
    }

    /**
     * @return string
     */
    public function getIcon(): string
    {
        return $this->icon;
    }

    /**
     * @return bool
     */
    public function isLink(): bool
    {
        return (static::class == LinkItem::class);
    }

    /**
     * @return bool
     */
    public function isParent(): bool
    {
        return (static::class == ParentItem::class);
    }
}
