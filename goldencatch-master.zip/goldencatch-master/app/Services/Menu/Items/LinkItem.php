<?php

namespace App\Services\Menu\Items;

class LinkItem extends BaseItem
{
    protected string $link = '';

    public function __construct(string $link)
    {
        $this->link = $link;
    }

    public function getLink(): string
    {
        return $this->link;
    }
}
