<?php

namespace App\Services\Menu\Items;

use Illuminate\Support\Collection;

class ParentItem extends BaseItem
{
    protected Collection $children;

    public function __construct(Collection $children, string $title)
    {
        $this->children = $children;
    }

    public function hasGroups()
    {
        return ($this->children->first() instanceof ParentItem);
    }

    /**
     * @return BaseItem[]
     */
    public function getChildren(): Collection
    {
        return $this->children;
    }
}
