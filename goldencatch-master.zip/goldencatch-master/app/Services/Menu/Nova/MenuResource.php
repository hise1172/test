<?php

namespace App\Services\Menu\Nova;

use Illuminate\Http\Request;
use Laravel\Nova\Fields\Heading;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Panel;
use Outl1ne\MenuBuilder\Nova\Resources\MenuResource as BasedMenuResource;
use Outl1ne\MenuBuilder\Nova\Fields\MenuBuilderField;
use Outl1ne\MenuBuilder\MenuBuilder;

class MenuResource extends BasedMenuResource
{
    public function fields(Request $request)
    {
        $menusTableName = MenuBuilder::getMenusTableName();
        $menuOptions = collect(MenuBuilder::getMenus())
            ->mapWithKeys(function ($menu, $key) {
                return [$key => $menu['name']];
            })
            ->toArray();

        $maxDepth = 10;

        if ($this->slug) $maxDepth = MenuBuilder::getMenuConfig($this->slug)['max_depth'] ?? 10;

        return [
            Text::make(__('novaMenuBuilder.nameFieldName'), 'name')
                ->sortable()
                ->rules('required', 'max:255'),

            Select::make(__('novaMenuBuilder.menuResourceSingularLabel'), 'slug')
                ->options($menuOptions)
                ->onlyOnForms()
                ->creationRules('required', 'max:255', "unique_menu:$menusTableName,slug,NULL,id")
                ->updateRules('required', 'max:255', "unique_menu:$menusTableName,slug,{{resourceId}},id"),

            Text::make(__('novaMenuBuilder.menuResourceSingularLabel'), 'slug', function ($key) {
                    $menu = MenuBuilder::getMenus()[$key] ?? null;
                    return ($menu === null) ? "<s>{$key}</s>" : $menu['name'];
                })
                ->hideWhenCreating()
                ->hideWhenUpdating()
                ->asHtml(),

            Panel::make(__('novaMenuBuilder.menuItemsPanelName'), [
                Heading::make('Для того, чтобы сделать колонку в подменю, создайте пункт c типом "Text" и укажите название кононки "---" - <a href="https://imgur.com/Dyth0nq" target="_blank">https://imgur.com/Dyth0nq</a>, <a href="https://imgur.com/CJhdBEU" target="_blank">https://imgur.com/CJhdBEU</a>')
                    ->asHtml(),

                MenuBuilderField::make('', 'menu_items')
                    ->hideWhenCreating()
                    ->maxDepth($maxDepth)
                    ->readonly(),
            ])
        ];
    }
}
