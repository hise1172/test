<?php

namespace App\Services\Menu\Nova\Items;

use Laravel\Nova\Fields\Text;
use Outl1ne\MenuBuilder\MenuItemTypes\BaseMenuItemType;

abstract class BaseItem extends BaseMenuItemType
{
    const TYPE_LINK = 'link';
    const TYPE_SIMPLE_LINK = 'simple-link';
    const TYPE_TEXT = 'text';

    /**
     * @inheritDoc
     */
    public static function getFields(): array
    {
        return [
            Text::make('Name UA', 'name_ua'),
        ];
    }
}
