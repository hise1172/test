<?php

namespace App\Services\Menu\Nova\Items;

use Laravel\Nova\Fields\Text;

class SimpleLinkItem extends BaseItem
{
    public static function getIdentifier(): string
    {
        return BaseItem::TYPE_SIMPLE_LINK;
    }

    public static function getName(): string
    {
        return 'Simple Link';
    }

    public static function getType(): string
    {
        return 'text';
    }

    /**
     * @inheritDoc
     */
    public static function getFields(): array
    {
        return array_merge(parent::getFields(), [
            Text::make('URI'),
        ]);
    }
}
