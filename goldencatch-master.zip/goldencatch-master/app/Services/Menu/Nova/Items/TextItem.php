<?php

namespace App\Services\Menu\Nova\Items;

class TextItem extends BaseItem
{
    public static function getIdentifier(): string
    {
        return BaseItem::TYPE_TEXT;
    }

    public static function getName(): string
    {
        return 'Text';
    }

    public static function getType(): string
    {
        return 'text';
    }
}
