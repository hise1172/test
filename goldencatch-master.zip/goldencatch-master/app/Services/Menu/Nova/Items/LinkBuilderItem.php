<?php

namespace App\Services\Menu\Nova\Items;

use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Repositories\CategoryRepository;
use Illuminate\Support\Facades\Cache;
use Laravel\Nova\Fields\Select;
use Outl1ne\MultiselectField\Multiselect;
use Outl1ne\MenuBuilder\Models\MenuItem;

class LinkBuilderItem extends BaseItem
{
    public static function getIdentifier(): string
    {
        return BaseItem::TYPE_LINK;
    }

    public static function getName(): string
    {
        return 'Build Link';
    }

    public static function getType(): string
    {
        return 'text';
    }

    /**
     * @inheritDoc
     */
    public static function getFields(): array
    {
        $attribute_field = Multiselect::make('Аттрибуты', 'attribute_id');
        $cat_field = Select::make('Category', 'category_id');

        $fields = array_merge(parent::getFields(), [
            $cat_field->options(static::getAllCategories())
                ->searchable(),
            $attribute_field
                ->options(static::getAllAttributes())
                ->resolveUsing(function ($value) use ($attribute_field) {
                    $value = (array) json_decode($value, true);

                    foreach ($attribute_field->meta['options'] ?? [] as $index => $item) {
                        if (!in_array($item['id'], $value)) {
                            continue;
                        }

                        $attribute_field->meta['options'][$index]['selected'] = true;
                    }
                }),
        ]);

        return $fields;
    }

    /**
     * @param Multiselect $field
     *
     * @return \Closure
     */
    protected static function resolveMultiselect(Multiselect $field)
    {
        return function ($value, MenuItem $value_2, string $key) use ($field) {
            [, $key] = explode('>', $key);

            if (!isset($value_2->getCustomDataAttribute()[$key])) {
                return;
            }

            $values = json_decode($value_2->getCustomDataAttribute()[$key], true) ?: [];

            foreach ($field->meta['options'] ?? [] as $index => $item) {
                if (!in_array($item['id'], $values)) {
                    continue;
                }

                $field->meta['options'][$index]['selected'] = true;
            }
        };
    }

    /**
     * @return array
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public static function getAllCategories()
    {
        $cache_key = CategoryRepository::class . '_all_rows';

        $items_list = Cache::get($cache_key, []);

        if ($items_list) {
            return $items_list;
        }

        /** @var CategoryRepository $repository */
        $repository = app()->make(CategoryRepository::class);

        $items_list = ['- не вибрано -'];

        foreach ($repository->all() as $category) {
            /** @var Category $category */
            $items_list[$category->id] = $category->name . ' (' . $category->slug . ')';
        }

        $items_list
            && Cache::put($cache_key, $items_list, 3600); // An hour

        return $items_list;
    }

    /**
     * @return array
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public static function getAllAttributes()
    {
        $cache_key = AttributeSlugValue::class . '_all_rows';

        $items_list = Cache::get($cache_key, []);

        if ($items_list) {
            return $items_list;
        }

        $attribute_slug_values = AttributeSlugValue::all();
        $attribute_types = Attribute::all();
        $items_list = [];

        foreach ($attribute_slug_values as $attr) {
            /** @var AttributeSlugValue $attr */
            /** @var Attribute $attribute_type */
            $attribute_type = $attribute_types
                ->where('id', $attr->attribute_id)
                ->first();

            $items_list[$attr->id] = $attr->value . " - {$attribute_type->system_name}";
        }

        $items_list
            && Cache::put($cache_key, $items_list, 3600); // An hour

        return $items_list;
    }
}
