<?php

namespace App\Services\Menu;

use App\Models\AttributeSlugValue;
use App\Models\Category;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class Repository
{
    protected Collection $categoriesStorage;

    protected Collection $attributeSlugValuesStorage;

    public function __construct()
    {
        $this->categoriesStorage = collect();
        $this->attributeSlugValuesStorage = collect();
    }

    public function getCategory(int $categoryId)
    {
        return $this->categoriesStorage->get($categoryId);
    }

    /**
     * @param int $attributeSlugValueId
     *
     * @return AttributeSlugValue
     */
    public function getAttributeSlugValue(int $attributeSlugValueId)
    {
        return $this->attributeSlugValuesStorage->get($attributeSlugValueId);
    }

    /**
     * @param Collection $ids
     */
    public function fireCategories(Collection $ids): void
    {
        if ($ids->isEmpty()) {
            return;
        }

        $key = implode(',', $ids->toArray());
        $cache_categories = Cache::get(static::class . ':fireCategories()');

        if (!empty($cache_categories[$key])) {
            $this->categoriesStorage = $cache_categories[$key];

            return;
        }

        $this->categoriesStorage = $cache_categories[$key] = Category::query()->whereIn('id', $ids)->get()->keyBy('id');

        Cache::put(static::class . ':fireCategories()', $cache_categories, 60); // 1 minute
    }

    /**
     * @param Collection $ids
     */
    public function fireAttributeSlugValues(Collection $ids)
    {
        if ($ids->isEmpty()) {
            return;
        }

        $key = implode('.', $ids->toArray());
        $attributeSlugValuesStorage = Cache::get(static::class . ':fireAttributeSlugValues()');

        if (isset($attributeSlugValuesStorage[$key])) {
            $this->attributeSlugValuesStorage = $attributeSlugValuesStorage[$key];

            return;
        }

        $this->attributeSlugValuesStorage = $attributeSlugValuesStorage[$key] = AttributeSlugValue::query()
            ->with('attribute')
            ->whereIn('id', $ids)
            ->get()
            ->keyBy('id');

        Cache::put(static::class . ':fireAttributeSlugValues()', $attributeSlugValuesStorage, 60); // 1 minute
    }
}
