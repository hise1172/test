<?php

namespace App\Services\Menu;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        if (!app()->runningInConsole()) {
            $this->app->singleton(MenuBuilder::class);
        }

        $this->app->singleton(Repository::class);
    }

}
