<?php

namespace App\Services\Menu;

use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Models\LandingPage;
use App\Services\Menu\Items\LinkItem;
use App\Services\Menu\Items\ParentItem;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class MenuBuilder
{
    protected Repository $repository;

    protected $menusSettings = [];

    protected Collection $menuList;

    public function __construct(Repository $repository)
    {
        $nova_get_menus = Cache::get('nova_get_menus');

        if (!$nova_get_menus) {
            $nova_get_menus = nova_get_menus();

            Cache::put('nova_get_menus', $nova_get_menus, 14400); // 4 hours
        }

        $this->repository = $repository;
        $this->menusSettings = ConvertData::build($nova_get_menus)->render() + config('menu-settings');
        $this->menuList = collect();
        $this->build();
    }

    /**
     * @param string $menuName
     * @return Collection
     */
    public function get(string $menuName): Collection
    {
        return $this->menuList->has($menuName) ? $this->menuList->get($menuName) : collect();
    }

    protected function build(): void
    {
        $this->fireRepository();

        foreach ($this->menusSettings as $menuName => $menuSetting) {
            $this->menuList->put($menuName, $this->buildMenu($menuSetting));
        }
    }

    protected function buildMenu(array $menuSettings): Collection
    {
        $menu = collect();
        foreach ($menuSettings as $itemSettings) {
            switch ($itemSettings['type']) {
                case LinkItem::class:
                    $menu->add($this->buildLinkItem($itemSettings));
                    break;
                case ParentItem::class:
                    $menu->add($this->buildParentItem($itemSettings));
                    break;
            }
        }

        return $menu->filter();
    }


    /**
     * @param array $menuSettings
     * @param array|Collection[] $entitiesIds
     */
    protected function collectIds(array $menuSettings, array &$entitiesIds)
    {
        foreach ($menuSettings as $itemSettings) {
            if ($itemSettings['type'] == ParentItem::class) {
                if (!empty($itemSettings['children'])) {
                    $this->collectIds($itemSettings['children'], $entitiesIds);
                } elseif (!empty($itemSettings['childrenCols'])) {
                    foreach ($itemSettings['childrenCols'] as $itemsSettings) {
                        $this->collectIds($itemsSettings, $entitiesIds);
                    }
                }
            }

            if ($itemSettings['type'] == LinkItem::class) {
                foreach ($itemSettings['linkData'] as $entityType => $entityId) {
                    $entitiesIds[$entityType]->add($entityId);
                }
            }
        }
    }

    /**
     * @param array $itemSettings
     * @return LinkItem
     */
    protected function buildLinkItem(array $itemSettings): ?LinkItem
    {
        if (isset($itemSettings['linkData'][LandingPage::class])) {
            $slug = $itemSettings['linkData'][LandingPage::class];

            return (new LinkItem(routeLocale('landing-page', $slug)))
                ->setTitle(
                    !empty($itemSettings['title'])
                        ? __($itemSettings['title'])
                        : (Category::query()->where('slug', $slug)->first()->name ?? $slug)
                )
                ->setIcon($itemSettings['icon'] ?? '');
        }

        $routeName = 'category.filter';

        $category = isset($itemSettings['linkData'][Category::class])
            ? $this->repository->getCategory($itemSettings['linkData'][Category::class])
            : null;

        $attributeSlagValue = [];

        if (isset($itemSettings['linkData'][AttributeSlugValue::class])) {
            foreach ((array) $itemSettings['linkData'][AttributeSlugValue::class] as $attr_slug_value_id) {
                $attr = $this->repository->getAttributeSlugValue($attr_slug_value_id);

                if ( ! $attr ) {
                    // \App\Models\SemanticRule::where('rulable_type', AttributeSlugValue::class)->where('rulable_id', $attr_slug_value_id)->delete();
                    continue;
                }

                if (!isset($attributeSlagValue[$attr->attribute->filter_slug])) {
                    $attributeSlagValue[$attr->attribute->filter_slug] = [
                        'position' => $attr->attribute->filter_position,
                        'filter_slug' => $attr->attribute->filter_slug,
                        'values' => [],
                    ];
                }

                $attributeSlagValue[$attr->attribute->filter_slug]['values'][] = $attr->slug;
            }
        }

        if (!$category && !$attributeSlagValue) {
            return null;
        }

        $routeArgs = [];
        $i = 1;

        usort($attributeSlagValue, fn ($a, $b) => $a['position'] > $b['position']);

        foreach ($attributeSlagValue ?? [] as $attr_value) {
            $routeArgs['filter' . $i] = $attr_value['filter_slug'] . '-' . implode(',', $attr_value['values']);

            $i ++;
        }

        if ($category) {
            $routeArgs['category'] = $category->slug;
        }

        if ($category && $attributeSlagValue) {
            $routeName = 'catalog.filters';
        } elseif (!$category && $attributeSlagValue) {
            $routeName = 'catalog.filter';
        } else if ($category && !$attributeSlagValue) {
            $routeName = 'category.filter';
        }

        return (new LinkItem(routeLocale($routeName, $routeArgs)))
            ->setTitle(!empty($itemSettings['title']) ? __($itemSettings['title']) : $category->name)
            ->setIcon($itemSettings['icon'] ?? '');
    }

    /**
     * @param array $itemSettings
     * @return ParentItem
     */
    protected function buildParentItem(array $itemSettings): ?ParentItem
    {
        $children = collect();

        if (empty($itemSettings['children'])) {
            return null;
        }

        if (!empty($itemSettings['children'])) {
            $children = $this->buildMenu($itemSettings['children']);
        }

        return (new ParentItem($children, $itemSettings['title'] ?? ''))
            ->setTitle(!empty($itemSettings['title']) ? __($itemSettings['title']) : '')
            ->setIcon($itemSettings['icon'] ?? '');
    }

    /**
     * @return void
     */
    protected function fireRepository(): void
    {
        $entitiesIds = [
            Category::class => collect(),
            AttributeSlugValue::class => collect(),
            LandingPage::class => collect(),
        ];

        foreach ($this->menusSettings as $menusSettings) {
            $this->collectIds($menusSettings, $entitiesIds);
        }

        $this->repository->fireCategories($entitiesIds[Category::class]);

        $attr_ids = [];

        foreach ($entitiesIds[AttributeSlugValue::class] as $id) {
            if (!is_array($id)) {
                $attr_ids[] = $id;

                continue;
            }

            $attr_ids = array_merge($id, $attr_ids);
        }

        $this->repository->fireAttributeSlugValues(collect($attr_ids));
    }
}
