<?php

namespace App\Services\Menu;

use App\DataContainers\AbstractDataContainer;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Translate;
use App\Services\Menu\Items\LinkItem;
use App\Services\Menu\Items\ParentItem;
use App\Services\Menu\Nova\Items\BaseItem;
use Illuminate\Support\Collection;

class ConvertData extends AbstractDataContainer
{
    protected $menus_list = [];

    /**
     * @param array $data - pass result of function nova_get_menus()
     *
     * @return ConvertData
     */
    public static function build(array $data)
    {
        $menus_list = [];

        foreach ($data as $menu) {
            unset($menu['locale']);

            $menus_list[$menu['slug']] = $menu;
        }

        return parent::make(['menus_list' => $menus_list]);
    }

    #region Getters

    /**
     * @return array
     */
    public function render(): array
    {
        $config = [];

        foreach ($this->menus_list as $slug => $menu) {
            $config[$slug] = static::collectItems($menu['menuItems']);
        }

        return $config;
    }

    /**
     * @param array $item
     *
     * @return string
     */
    private static function getTitle(array $item): string
    {
        switch (app()->getLocale()) {
            case Translate::RU:
                return $item['name'];

            case Translate::UA:
                return $item['data']['name_ua'] ?: $item['name'];

            default:
                throw new \LogicException('The current language does not implemented');
        }
    }

    /**
     * @param array $item
     *
     * @return string
     */
    private static function getType(array $item): string
    {
        switch ($item['type']) {
            case BaseItem::TYPE_LINK:
            case BaseItem::TYPE_SIMPLE_LINK:
                return LinkItem::class;

            case BaseItem::TYPE_TEXT:
                return ParentItem::class;

            default:
                throw new \LogicException('The current language does not implemented');
        }
    }

    /**
     * @param array $item
     *
     * @return array|null
     */
    private static function getLinkData(array $item): ?array
    {
        switch ($item['type']) {
            case BaseItem::TYPE_LINK:
            case BaseItem::TYPE_SIMPLE_LINK:
                $result = [];

                foreach ($item['data'] as $key => $data) {
                    $data = json_decode($data, true);

                    if (!$data) {
                        continue;
                    }

                    switch ($key) {
                        case 'category_id':
                            $result[Category::class] = $data;
                            break;

                        case 'attribute_id':
                            $result[AttributeSlugValue::class] = $data;
                            break;

                        case 'brand_ids':
                            $result[Brand::class][] = $data;
                            break;

                        default:
                            throw new \LogicException('The key "' . $key . '" does not implemented');
                    }
                }

                return $result;

            case BaseItem::TYPE_TEXT:
                return null;

            default:
                throw new \LogicException('The current language does not implemented');
        }
    }

    #endregion

    #region Helpers

    /**
     * @param Collection $items
     *
     * @return array
     */
    private static function collectItems(Collection $items): array
    {
        $result = [];

        foreach ($items as $item) {
            if ($item['children']->isNotEmpty()) {
                $result[] = [
                    'type' => ParentItem::class,
                    'title' => static::getTitle($item),
                    'children' => static::collectItems($item['children']),
                ];

                continue;
            }

            $temp = [
                'type' => static::getType($item),
                'title' => static::getTitle($item),
            ];

            $link_data = static::getLinkData($item);

            if ($link_data) {
                $temp['linkData'] = $link_data;
            }

            $result[] = $temp;
        }

        return $result;
    }

    #endregion
}
