<?php

namespace App\Services;

use App\Services\LandingPage\Block;
use Illuminate\Support\Collection;

class LandingPageService
{
    /** @var Collection|Block[] */
    private ?Collection $blocks = null;

    #region Builders

    /**
     * @param array $blocks_data
     * [
     *      block_type => [],
     *      ...
     * ]
     *
     */
    public static function build(array $blocks_data = [])
    {
        $landing = new static();

        foreach ($blocks_data as $block_type => $data) {
            $landing->addBlock(Block::factory($block_type, $data));
        }

        return $landing;
    }

    #endregion

    #region Setters

    /**
     * @param Block $block
     */
    private function addBlock(Block $block)
    {
        if (!$this->blocks) {
            $this->blocks = collect();
        }

        $this->blocks[] = $block;
    }

    #endregion
}
