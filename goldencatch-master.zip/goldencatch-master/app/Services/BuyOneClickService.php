<?php

namespace App\Services;


use App\Models\BuyOneClick;
use App\Repositories\BuyOneClickRepository;
use Illuminate\Http\Request;

class BuyOneClickService
{
    protected $buyOneClickRepository;

    /**
     * BuyOneClickService constructor.
     * @param BuyOneClickRepository $buyOneClickRepository
     */
    public function __construct(BuyOneClickRepository $buyOneClickRepository)
    {
        deprecated(BuyOneClick::class);

        $this->buyOneClickRepository=$buyOneClickRepository;
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function store(Request $request)
    {
        return $this->buyOneClickRepository->create($request->all());
    }
}
