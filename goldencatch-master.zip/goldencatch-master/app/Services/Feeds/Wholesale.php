<?php

namespace App\Services\Feeds;

class Wholesale extends Generator
{

    public function productAddToCsv( $product ){
        if( ! is_numeric($product->SKU) ){
            return [];
        }

        $data = [
            'SKU' => $product->SKU,
            'stock' => $product->isInStock() ? 1 : 0,
            'price' => $product->price,
            'name ru' => $product->getTranslation('name', 'ru'),
            'name ua' => $product->getTranslation('name', 'ua'),
        ];
        return $data;
    }

}
