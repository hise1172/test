<?php

namespace App\Services\Feeds;

use App\Models\Brand;
use App\Models\Category;
use Illuminate\Support\Str;
use App\Models\Product\Product;
use Spatie\ArrayToXml\ArrayToXml;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Console\Exception\LogicException;



class Generator
{

    public $fileName = NULL;
    // change to false if title(first line) in CVS is not need
    public $addTitleCsv = TRUE;
    // You can use own fields for first CVS line instead of autoFiled (id,name,SKU...)
    public $titleCsv = [];
    private $config = [];
    private $data = [];
    private $dataBrands = [];
    private $dataCategories = [];
    private $dataProducts = [];
    private $dataXml = [];
    private $oldProducts = [];
    public $productCounter = 0;
    private $logger = NULL;
    private $csvDelimiter = ',';



    public function categoriesAll()
    {
        $this->dataCategories = Category::select('id', 'name', 'slug')->get();
        return $this;
    }

    /*
    categoriesExcludeSlugs( 'rods', 'reels' )
    categoriesExcludeSlugs( ['rods', 'reels'] )
  */
    public function categoriesExcludeSlugs()
    {
        $categoriesSlug = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty. You can use categoriesAll() method.'
        );
        $this->categoriesAll();
        $this->dataCategories = $this->dataCategories->filter(function ($element) use ($categoriesSlug) {
            return !in_array($element->slug, $categoriesSlug);
        });

        return $this;
    }

    /*
    categoriesExcludeSlugs( 1,2 )
    categoriesExcludeSlugs( [1,2] )
  */
    public function categoriesExcludeIds()
    {
        $categoriesIds = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty. You can use categoriesAll() method.'
        );
        $this->categoriesAll();
        $this->dataCategories = $this->dataCategories->filter(function ($element) use ($categoriesIds) {
            return !in_array($element->id, $categoriesIds);
        });

        return $this;
    }

    public function categoriesOnlySlugs()
    {
        $categoriesSlug = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty.'
        );

        $this->dataCategories = Category::select('id', 'name', 'slug')->whereIn('slug', $categoriesSlug)->get();
        if ($this->dataCategories->count() == 0) {
            throw new LogicException('Categories to display not found. Please check it.');
        }

        return $this;
    }

    public function categoriesOnlyIds()
    {
        $categoriesIds = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty.'
        );

        $this->dataCategories = Category::select('id', 'name', 'slug')->whereIn('id', $categoriesIds)->get();
        if ($this->dataCategories->count() == 0) {
            throw new LogicException('Categories to display not found. Please check it.');
        }

        return $this;
    }


    public function brandsAll()
    {
        $this->dataBrands = Brand::select('id', 'name', 'slug')->get();

        return $this;
    }

    public function brandsExcludeSlugs()
    {
        $brandSlugs = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty. You can use brandsAll() method.'
        );
        $this->brandsAll();
        $this->dataBrands = $this->dataBrands->filter(function ($element) use ($brandSlugs) {
            return !in_array($element->slug, $brandSlugs);
        });

        return $this;
    }

    public function brandsExcludeIds()
    {
        $brandIds = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty. You can use brandsAll() method.'
        );
        $this->brandsAll();
        $this->dataBrands = $this->dataBrands->filter(function ($element) use ($brandIds) {
            return !in_array($element->id, $brandIds);
        });

        return $this;
    }


    public function brandsOnlySlugs()
    {
        $brandSlugs = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty.'
        );

        $this->dataBrands = Brand::select('id', 'name', 'slug')->whereIn('slug', $brandSlugs)->get();
        if ($this->dataBrands->count() == 0) {
            throw new LogicException('Brands to display not found. Please check it.');
        }

        return $this;
    }


    public function brandsOnlyIds()
    {
        $brandIds = $this->argumetsOrFail(
            func_get_args(),
            'Method ' . __FUNCTION__ . ' should not be empty.'
        );

        $this->dataBrands = Brand::select('id', 'name', 'slug')->whereIn('id', $brandIds)->get();
        if ($this->dataBrands->count() == 0) {
            throw new LogicException('Brands to display not found. Please check it.');
        }

        return $this;
    }


    public function productsAll()
    {
        $this->dataProducts = Product::when($this->dataBrands, function ($query) {
            return $query->whereIn('brand_id', $this->dataBrands->pluck('id'));
        })
            ->when($this->dataCategories, function ($query) {
                return $query->whereIn('category_id', $this->dataCategories->pluck('id'));
            })
            ->where('price', '>', 0)
            ->where('is_active', 1)
            ->with('modifications')
            // ->limit(10)
            ->get();

        return $this;
    }


    public function productAddToCsv($product)
    {
        $data = [
            'id' => $product->id,
            'SKU' => $product->SKU,
            'name ru' => $product->getTranslation('name', 'ru'),
            'name ua' => $product->getTranslation('name', 'ua'),
            'price' => $product->price,
        ];
        return $data;
    }


    public function productsFromCsv( $fileNameCsv )
    {

        if( ! Storage::disk('local')->exists( $fileNameCsv ) ){
            throw new LogicException('File "' . $fileNameCsv . '" does not exist in "./storage/app/".');
        }

        $fileContent = Storage::disk('local')->get( $fileNameCsv );

        $this->productIds = [];

        array_map(function($row) {
            if( ! $row ){
                return ;
            }
            $data = str_getcsv($row, ',');
            if( isset($data[0]) && trim($data[0]) ){
                $this->productIds[] = trim($data[0]);
            }
        }, explode("\n", $fileContent));

        if( count($this->productIds) == 0 ){
            throw new LogicException('Products Ids in file "./storage/app/' . $fileNameCsv . '" does not found.');
        }

        $this->dataProducts = Product::
            whereIn('SKU', $this->productIds)
            ->whereNotNull('price')
            ->where('stock', '>', 0)
            ->get();

        return $this;
    }

    function getOldProducts()
    {
        $csv = Storage::disk('local')->get('rozetka_do_not_delete_file.csv');
        $this->oldProducts = [];
        $csv = array_map(function($row) {
            if( ! $row ){
                return ;
            }
            $data = str_getcsv($row, ';') ;
            $this->oldProducts[] = [
                'id' => $data[0],
                'name' => trim($data[1]),
            ];
        }, explode("\n", $csv));
        $this->oldProducts = collect($this->oldProducts);

        return $this;
    }

    function generateId( $id, $name )
    {
        if( ! count($this->oldProducts) ){
            return $id;
        }

        $oldProduct = $this->oldProducts->firstWhere('name', trim($name) );
        if( $oldProduct && isset($oldProduct['id']) && $oldProduct['id'] ){
            return $oldProduct['id'];
        }
        $oldProduct = $this->oldProducts->firstWhere('id', $id );
        if( $oldProduct && isset($oldProduct['id']) && $oldProduct['id'] ){
            return 'g'. $id;
        }

        return $id;
    }

    public function putTitleCsv($file, $product)
    {
        if( count($this->titleCsv) == 0 ){
            $this->titleCsv = array_keys($product);
        }
        $this->linePutCsv($file, $this->titleCsv);
        $this->addTitleCsv = false;
    }

    public function toCsv()
    {
        $file = fopen('php://memory', 'r+');
        foreach ($this->dataProducts as $item) {
            $product = $this->productAddToCsv($item);
            if (count($product)) {
                if ($this->addTitleCsv) {
                    $this->putTitleCsv($file, $product);
                }
                $this->linePutCsv($file, $product);
                $this->productCounter++;
            }
        }
        rewind($file);
        Storage::disk('public')->put($this->getFileName(), stream_get_contents($file));

        return $this;
    }

    public function onlyWithMainPhoto()
    {
        if( ! count($this->dataProducts) ){
            throw new LogicException('There are no products to filter.');
        }

        $this->dataProducts = $this->dataProducts->reject(function ($product) {
            return ( $product->photo == '');
        });

        return $this;
    }

    public function onlyWithDescription()
    {
        if( ! count($this->dataProducts) ){
            throw new LogicException('There are no products to filter.');
        }

        $this->dataProducts = $this->dataProducts->reject(function ($product) {
            return ( ($product->short_description ? $product->short_description : $product->description) == '' );
        });

        return $this;
    }

    public function prepareXml()
    {

        $xmlProducts = [];
        foreach ($this->dataProducts as $key => $product) {

            $attributes = $product->desc_attr;

            if( $product->parent_id && $product->parentProduct ){
                $attributes = array_merge ( $attributes, $product->parentProduct->desc_attr);
            }

            $xmlProducts[$key] = [
                '_attributes' => [
                    'id' => $this->generateId( $product->id, $product->name ),
                    'available' => $product->stock ? "true" : "false"
                ],
                'price' => $product->price,
                'currencyId' => 'UAH',
                'categoryId' => $product->category_id,
                'picture' => str_replace('http://goldencatch.test', 'https://goldencatch.ua', $product->photo),
                'name' => [
                    '_cdata' => $product->name
                ],
                'vendor' => $product->brand_name ?? '',
                'stock_quantity' => $product->stock,
                'description' => [
                    '_cdata' => $product->short_description ? $product->short_description . PHP_EOL : "" . $product->description
                ],
                'param' => [
                    "_attributes" => [
                        "name" => "Артикул"
                    ],
                    "_value" => $product->SKU
                ],
            ];

            // добавляем атрибуты
            $attr_index = 0;
            foreach ( $attributes as $attr_name => $attr_value) {
                $attr_index++;
                $xmlProducts[$key]['param_delete_' . $attr_index] = [
                    "_attributes" => [
                        "name" => $attr_name
                    ],
                    '_cdata' =>  implode(',', $attr_value )
                ];
            }


            // добавляем фото
            try {

                $photos = [];

                foreach ($product->getMedia() as $photo) {
                    $photos[] = asset($photo->getUrl());
                }

                if ($product->parent_id && $product->parentProduct) {
                    foreach ($product->parentProduct->getMedia() as $photo) {
                        $photos[] = asset($photo->getUrl());
                    }
                }

                $photo_index = 0;
                foreach ($photos as $photo) {
                    $photo_index++;
                    $xmlProducts[$key]['picture_delete_' . $photo_index] = $photo;
                }

            } catch (\BadMethodCallException $exception) {
                // $this->error ( 'BadMethodCallException for ProductId ' . $product->id );
            } catch (\BadFunctionCallException $exception) {
                // $this->error( 'BadFunctionCallException for ProductId ' . $product->id );
            } catch (\Throwable $exception) {
                // $this->error( 'Throwable for ProductId ' . $product->id );
            } catch (\Exception $exception) {
                // $this->error( 'Exception for ProductId ' . $product->id );
            }

            $this->productCounter++;
        }


        $xmlCategories = [];

        $categories = Category::get();

        foreach ($categories as $category) {
            array_push($xmlCategories, [
                [
                    '_attributes' => [
                        'id' => $category->id
                    ],
                    '_value' => $category->name
                ]
            ]);
        }

        $this->dataXml = [
            'shop' => [
                'name' => 'Golden Catch',
                'company' => 'Golden Catch',
                'url' => 'https://goldencatch.ua',
                'currencies' => [
                    'currency' => [
                        "_attributes" => [
                            "id" => "UAH",
                            "rate" => "1",
                        ],
                    ],
                ],
                'categories' => [
                    'category' => $xmlCategories
                ],
                'offers' => [
                    'offer' => $xmlProducts
                ]
            ]
        ];

        return $this;
    }


    public function toXml()
    {

        $arrayToXml = new ArrayToXml($this->dataXml, [
            'rootElementName' => 'yml_catalog',
            '_attributes' => [
                'date' => now()->toDateTimeString(),
            ],
        ], true, 'UTF-8');

        $arrayToXml->setDomProperties(['formatOutput' => true]);
        $temp_result = $arrayToXml->prettify()->toXml();
        $result = preg_replace('/_delete_\d/', '', $temp_result);

        Storage::disk('public')->put($this->getFileName(), $result);

        return $this;
    }

    public function linePutCsv($file, $data){
        $data = str_replace(['"', '\\'], ' ', $data);
        fputcsv($file, $data, $this->csvDelimiter);
    }

//    public function toXml()
//    {
//        $arrayToXml = new ArrayToXml($array, [
//            'rootElementName' => 'price',
//        ], true, 'UTF-8');
//
//        $arrayToXml->setDomProperties(['formatOutput' => true]);
//        $result = $arrayToXml->prettify()->toXml();
//
//        Storage::disk('public')->put($this->getFileName(), $result);
//    }

    public function setFileName($fileName)
    {
        if (!$fileName) {
            throw new LogicException('Generator cannot have an empty file name.');
        }
        $this->fileName = $fileName;

        return $this;
    }

    public function getFileName()
    {
        if (!$this->fileName) {
            throw new LogicException('Generator cannot have an empty file name.');
        }
        return $this->fileName;
    }

    public function argumetsOrFail($argumets, $errorText)
    {
        $array = collect($argumets)->flatten()->map(function ($value) {
            return Str::lower($value);
        })->all();
        if (count($array) > 0) {
            return $array;
        }
        throw new LogicException($errorText);
    }
}
