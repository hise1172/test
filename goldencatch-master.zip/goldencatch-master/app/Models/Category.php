<?php

namespace App\Models;

use App\Models\Product\Product;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use Spatie\Translatable\HasTranslations;

/**
 * Class Category
 * @property int id
 * @property int parent_id
 * @property string name category's name
 * @property string photo category's photo path
 * @property string slug category's slug
 *
 * @property SemanticRule semanticRule
 */
class Category extends Model
{
    use HasTranslations;

    public $translatable = ['name', 'description'];

    public $timestamps = false;

    protected $fillable = ['parent_id', 'name', 'slug', 'description'];

    /**
     * Children category
     * @return HasMany
     */
    public function subCategories()
    {
        return $this->hasMany(Category::class, 'parent_id');
    }

    /**
     * Parent category
     * @return BelongsTo
     */
    public function parentCategory()
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }

    /**
     * @return HasMany
     */
    public function products()
    {
        return $this->hasMany(Product::class, 'category_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\MorphOne
     */
    public function semanticRule()
    {
        return $this->morphOne(SemanticRule::class, 'rulable');
    }

//    /**
//     * @param $value
//     */
//    public function setNameAttribute($value)
//    {
//        $this->attributes['name'] = $value;
//        $this->attributes['slug'] = Str::slug($value);
//    }


    /**
     * @inheritDoc
     */
    protected static function boot()
    {
        parent::boot();

        static::deleting(function($model) {
            $model->semanticRule()->delete();
        });
    }
}
