<?php

namespace App\Models;

use App\Helpers\FileUploaded;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;

/**
 * Class ReviewAttach
 * Review's attache, photo or video
 * @property int id
 * @property int product_reiews_id
 * @property string path photo or video path
 * @property string type video or photo type
 * @package App
 */
class ReviewAttach extends Model
{
    const ATTACH_VIDEO = 'video';
    const ATTACH_PHOTO = 'photo';
    public $timestamps = false;
    protected $fillable = ['path', 'type', 'product_reviews_id'];
    protected $appends = ['url'];

    /**
     * Get review
     * @return BelongsTo
     */
    public function review()
    {
        return $this->belongsTo(UserProductReview::class, 'product_reviews_id');
    }

    /**
     * Convert path to url
     * @return string
     */
    public function getUrlAttribute()
    {
        return Storage::disk(FileUploaded::REVIEWS_DISK)->url($this->attributes['path']);
    }

}
