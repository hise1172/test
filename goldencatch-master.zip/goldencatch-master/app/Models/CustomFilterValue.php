<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomFilterValue extends Model
{
    protected $table = 'custom_filters';

    protected $fillable = ['name', 'filter_block_name_id', 'slug'];

    public function filter()
    {
        return $this->hasOne(CustomFilter::class, 'id','filter_block_name_id');
    }
}
