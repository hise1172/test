<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

/**
 *
 * @property int $position
 * @property bool skip
 * @property string replace_word
 * @property string synonym
 * @property bool includes_attr_name
 * @property int $includes_fishing_words
 * @property int rulable_id
 * @property string rulable_type
 */
class SemanticRule extends Model
{
    use HasFactory;
    use HasTranslations;

    const TABLE_NAME = 'semantic_rules';

    const INCLUDES_TYPE_BEFORE = 1;
    const INCLUDES_TYPE_AFTER = 2;

    protected $table = self::TABLE_NAME;

    public $translatable = [
        'replace_word',
        'synonym',
    ];

    protected $fillable = [
        'priority',
        'skip',
        'replace_word',
        'synonym',
        'includes_attr_name',
        'includes_fishing_words',
        'rulable_id',
        'rulable_type',
    ];

    /**
     * Get the parent rulable model
     */
    public function rulable()
    {
        return $this->morphTo();
    }

    /**
     * @param Category|Brand|AttributeSlugValue $item
     * @param string $locale
     *
     * @return mixed|string
     */
    public static function getTitle(object $item, string $locale, $type)
    {
        if (!in_array($type, ['replace_word', 'synonym'])) {
            throw new \InvalidArgumentException('Invalid $type');
        }

        if (
            $item->semanticRule &&
            ($semantic_value = static::getSemanticValue($type, $locale, $item->semanticRule))
        ) {
            return $semantic_value;
        }

        switch (get_class($item)) {
            case Category::class:
                /** @var Category $item */
                return $item->getTranslation('name', $locale);

            case Brand::class:
                /** @var Brand $item */
                return $item->getTranslation('name', $locale);

            case AttributeSlugValue::class:
                /** @var AttributeSlugValue $item */
                if (
                    $item->attribute->semanticRule
                    && ($semantic_value = static::getSemanticValue($type, $locale, $item->attribute->semanticRule))
                ) {
                    return $semantic_value;
                }

                return $item->getTranslation('value', $locale);

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item));
        }
    }

    /**
     * @param $type
     * @param $locale
     * @param SemanticRule $semantic
     *
     * @return string|null
     */
    private static function getSemanticValue($type, $locale, self $semantic)
    {
        switch ($type) {
            case 'synonym':
                if ($semantic->getTranslation('synonym', $locale)) {
                    return $semantic->getTranslation('synonym', $locale);
                }

                break;

            case 'replace_word':
                break;

            default:
                throw new \InvalidArgumentException('Invalid $type');
        }

        if ($semantic->getTranslation('replace_word', $locale)) {
            return $semantic->getTranslation('replace_word', $locale);
        }

        return null;
    }
}
