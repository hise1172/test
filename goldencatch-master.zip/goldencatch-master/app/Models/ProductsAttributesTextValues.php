<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

/**
 * Class ProductCustomFilter
 * @package App\Models
 *
 * @property string $value
 */
class ProductsAttributesTextValues extends Model
{
    use HasTranslations;

    protected $table = 'products_attributes_text_values';

    public $translatable = ['value'];
}
