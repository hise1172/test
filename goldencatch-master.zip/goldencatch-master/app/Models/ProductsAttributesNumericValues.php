<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductCustomFilter
 * @package App\Models
 *
 * @property float $value
 */
class ProductsAttributesNumericValues extends Model
{
    const TABLE_NAME = 'products_attributes_numeric_values';

    protected $table = self::TABLE_NAME;

    const DECIMAL_PLACES = 4;
}
