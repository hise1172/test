<?php

namespace App\Models;

use App\Models\Product\Product;
use App\User;
use Illuminate\Database\Eloquent\Model;

/**
 * Class UserView
 * @package App
 */
class UserView extends Model
{
    protected $fillable = ['product_id', 'user_id', 'ip'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

}
