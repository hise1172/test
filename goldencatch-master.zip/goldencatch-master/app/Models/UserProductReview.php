<?php

namespace App\Models;

use App\Models\Product\Product;
use App\Models\Product\ProductOrder;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class UserProductReview
 * @package App
 */
class UserProductReview extends Model
{
    protected $fillable = [
        'user_id',
        'product_id',
        'comment',
        'good_things',
        'bad_things',
        'product_mark',
        'is_moderated',
        'is_expert',
    ];
    protected $casts = ['created_at' => 'datetime', 'updated_at' => 'datetime'];

    /**
     * User's review
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Product's review
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * Photo or video
     * @return HasMany
     */
    public function attaches()
    {
        return $this->hasMany(ReviewAttach::class, 'product_reviews_id');
    }

    public function getLikesCountAttribute()
    {
        return $this->morphMany( CommentsLikes::class, 'likeable')->where('vote', 1)->count();
    }

    public function getDislikesCountAttribute()
    {
        return $this->morphMany( CommentsLikes::class, 'likeable')->where('vote', 0)->count();
    }

    public function userBoughtBefore()
    {
        if( $this->user->orders->count() ){
            return ProductOrder::whereIn('order_id', $orderIds = $this->user->orders->pluck('id') )
                ->whereIn('product_id', $this->product->modifications->pluck('id')->prepend( $this->product_id ) )
                ->count();
        }
    }
}
