<?php

namespace App\Models;

use App\Models\Product\Product;
use App\Models\Product\ProductType;
use App\Traits\Translatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * Class Types
 * @property string name Type's name
 * @property string slug Type's slug
 * @package App
 */
class Types extends Model
{
    use Translatable;

    public $translate = ['name'];
    protected $fillable = ['name', 'slug'];
    public $timestamps = false;
    protected $with = ['translatable'];

    public function setNameAttribute($value)
    {
        $this->attributes['name'] = $value;
        $this->attributes['slug'] = Str::slug($value);
    }

    public function products() {
        return $this->hasManyThrough(
            Product::class,
            ProductType::class,
            'type_id',
            'id',
            'id',
            'product_id'
        );
    }

    public function getProductsCountAttribute() {
        return $this->products()->count();
    }
}
