<?php

namespace App\Models;

use App\Models\Product\Product;
use App\Models\Product\ProductTypeFishes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * Class TypeFishes
 * @property string name Type fishes name
 * @property string slug Type fishes slug
 * @package App
 */
class TypeFishes extends Model
{

    protected $fillable = ['name', 'slug'];
    public $timestamps = false;

    public function setNameAttribute($value)
    {
        $this->attributes['name'] = $value;
        $this->attributes['slug'] = Str::slug($value);
    }

    public function products() {
        return $this->hasManyThrough(
            Product::class,
            ProductTypeFishes::class,
            'type_fish_id',
            'id',
            'id',
            'product_id'

        );
    }

    public function getProductsCountAttribute() {
        return $this->products()->count();
    }
}
