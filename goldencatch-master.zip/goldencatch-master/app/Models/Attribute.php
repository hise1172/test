<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

/**
 * @property-read int id
 * @property string filter_name
 * @property int filter_type
 * @property string system_name
 * @property string filter_slug
 * @property string filter_position
 * @property bool is_filter
 *
 * @property SemanticRule semanticRule
 * @property AttributeSlugValue[]|\Illuminate\Support\Collection slugValues
 */
class Attribute extends Model
{
    use HasTranslations;

    const FILTER_FISHING_TYPE = 'types';

    public const TYPE_SLUG = 1;

    public const TYPE_NUMERIC = 2;

    public const TYPE_TEXT = 3;

    const TABLE_NAME = 'attributes';

    public $translatable = ['desc_attr_name', 'desc_attr_measurement_unit', 'filter_name', 'filter_measurement_unit'];

    protected $table = self::TABLE_NAME;

    protected ?Collection $_slug_values = null;

    #region Relations

    /**
     * @return HasMany
     */
    public function slugValues()
    {
        return $this->hasMany(AttributeSlugValue::class, 'attribute_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\MorphOne
     */
    public function semanticRule()
    {
        return $this->morphOne(SemanticRule::class, 'rulable');
    }

    #endregion

    #region Getters

    /**
     * @return Collection
     */
    public function getSlugValues()
    {
        return $this->_slug_values ?? ($this->_slug_values = $this->slugValues()->get());
    }

    /**
     * @return Attribute[]|\Illuminate\Database\Eloquent\Collection
     */
    public static function getAll()
    {
        static $active_attributes;

        if ($active_attributes) {
            return $active_attributes;
        }

        return $active_attributes = Attribute::query()
            ->orderBy('desc_attr_position')
            ->get();
    }

    /**
     * @return Attribute[]|\Illuminate\Database\Eloquent\Collection
     */
    public static function getAllDisplayed()
    {
        static $active_attributes;

        if ($active_attributes) {
            return $active_attributes;
        }

        return $active_attributes = Attribute::query()
            ->where('is_desc_attr', 1)
            ->orderBy('desc_attr_position')
            ->get();
    }

    #endregion

    /**
     * @inheritDoc
     */
    protected static function boot()
    {
        parent::boot();

        static::deleting(function($model) {
            foreach ($model->slugValues as $slugValue) {
                $slugValue->delete();
            }
            $model->semanticRule()->delete();
        });
    }
}
