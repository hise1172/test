<?php

namespace App\Models;

use App\Traits\Translatable;
use Illuminate\Database\Eloquent\Model;

/**
 * Class SiteSetting
 * @property string key
 * @property string value
 * @package App
 */
class SiteSetting extends Model
{
    use Translatable;

    public $translate = ['value'];
    protected $fillable = ['key', 'value', 'page'];
    public $timestamps = false;
    protected $with = ['translatable'];
}
