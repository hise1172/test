<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomFilter extends Model
{
    protected $table = 'custom_filters_block_names';

    protected $fillable = ['name', 'active', 'slug'];

    const STATUS_ACTIVE = 1;

    const STATUC_INACTIVE = 0;

    public function filterValues()
    {
        return $this->hasMany(CustomFilterValue::class, 'filter_block_name_id','id');
    }
}
