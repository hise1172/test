<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Spatie\Translatable\HasTranslations;

/**
 * @property string title
 * @property string promo_code
 * @property float amount // use $this->getDiscount() to get available promotion discount for a user
 * @property string units
 * @property float min_cart_amount
 * @property \DateTime start_at
 * @property \DateTime expire_at
 * @property int trigger_id // a trigger which allows a customer to use a promo discount
 * @property bool is_display_in_account
 * @property \DateTime created_at
 * @property \DateTime updated_at
 */
class Promotion extends Model
{
    use HasFactory;
    use HasTranslations;

    const AUTO_GENERATED_CODE_PREFIX = '__auto_code:';

    // Auto promo-codes
    const CODE_PRODUCT_OF_WEEK = 'PRODUCT_OF_WEEK';

    const TABLE_NAME = 'promotions';

    protected $table = self::TABLE_NAME;

    #region Triggers list

    // The triggers are responsible for action when a bonus has to apply

    const TRIGGER_REGISTRATION = 1; // apply bonus on registration
    const TRIGGER_CHECKOUT = 2; // apply bonus on checkout

    #endregion

    /** @inheritDoc  */
    protected $fillable = [
        'title',
        'amount',
        'units',
        'min_cart_amount',
        'start_at',
        'expire_at',
        'trigger_id',
    ];

    protected $casts = [
        'start_at' => 'datetime',
        'expire_at' => 'datetime',
    ];

    public $translatable = [
        'title',
    ];

    #region Extended methods

    /**
     *
     */
    public static function boot()
    {
        parent::boot();

        static::saving(function (Promotion $promotion) {
            if ($promotion->promo_code) {
                return;
            }

            $promotion->promo_code = static::AUTO_GENERATED_CODE_PREFIX . ($promotion->id ?: Str::random(15) . '.' . uniqid());
        });
    }

    #endregion

    #region Builders

    /**
     * @param int $trigger_id
     * @param string|null $promo_code
     *
     * @return static[]|\Illuminate\Database\Eloquent\Collection
     */
    public static function getList(int $trigger_id, string $promo_code = null)
    {
        $query = Promotion::query()
            ->where('trigger_id', '=', $trigger_id)
            ->where('start_at', '<=', date('Y-m-d H:i:s'));

        if ($promo_code === null) {
            return $query->get();
        }

        return $query
            ->where('promo_code', '=', $promo_code)
            ->get();
    }

    #endregion


    #endregion

    #region Getters

    /**
     * @param float $price
     *
     * @return float|int
     */
    public function getDiscount(float $price)
    {
        if ($this->units === 'uah') {
            return $this->amount;
        }

        return  (int) ($price * ($this->amount/100));
    }

    #endregion
}
