<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BuyOneClick extends Model
{
    protected $fillable=['name','link','phone','ip'];

    public function __construct(array $attributes = [])
    {
        deprecated(BuyOneClick::class);

        parent::__construct($attributes);
    }
}
