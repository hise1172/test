<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;
use Spatie\Translatable\HasTranslations;

/**
 * @property int id
 * @property string uri
 * @property string h1
 * @property string title
 * @property string description
 * @property string text
 * @property string generated_text
 * @property bool robots_index
 * @property bool robots_follow
 *
 * @property bool manual_edited
 * @property int products_in_stock
 * @property int min_price
 * @property int max_price
 * @property int step
 * @property int current_rating
 * @property int next_rating
 */
class SeoFilters extends Model
{
    use HasTranslations;
    use Searchable;

    const TABLE_NAME = 'seo_filters';

    const STEP_1 = 1; // category
    const STEP_2 = 2; // category + brand
    const STEP_3 = 3; // category + brand + attribute
    const STEP_4 = 4; // category + two attributes

    protected $table = self::TABLE_NAME;

    public $translatable = [
        'h1',
        'title',
        'description',
        'text',
        'generated_text',
    ];

    protected $fillable = [
        'uri',
        'h1',
        'title',
        'description',
        'open_graph_image',
        'text',
        'generated_text',
        'robots_index',
        'robots_follow',
        'manual_edited',
        'products_in_stock',
        'min_price',
        'max_price',
        'step',
    ];

    #region Getters

    /**
     * @inheritDoc
     */
    public function toSearchableArray()
    {
        return $this->robots_index ? $this->toArray() : [];
    }

    /**
     * @inheritDoc
     */
    public function searchableAs()
    {
        return config('scout.prefix').'seo_filters';
    }

    #endregion

}
