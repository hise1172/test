<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductAnalog
 * @package App\Models\Product
 */
class ProductAnalog extends Model
{
    const TYPE_UP_SALE = 'UP_SALE';
    const TYPE_DOWN_SALE = 'DOWN_SALE';

    public $timestamps = false;
    protected $fillable = ['product_id', 'product_analog_id', 'type', 'discount'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function analog()
    {
        return $this->belongsTo(Product::class, 'product_analog_id');
    }
}
