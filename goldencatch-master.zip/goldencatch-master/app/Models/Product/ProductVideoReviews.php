<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductVideoReviews extends Model
{
    protected $fillable = ['product_id', 'url', 'is_show'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}
