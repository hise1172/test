<?php

namespace App\Models\Product;

use App\Models\CommentsLikes;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class ProductQuestionAnswer
 * @property int id
 * @property int parent_id
 * @property int user_id
 * @property int product_id
 * @property string content
 * @package App
 */
class ProductQuestionAnswer extends Model
{
    protected $fillable = ['content', 'user_id', 'product_id', 'parent_id'];

    /**
     * Who create this post
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Product
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * Question's answers
     * @return HasMany
     */
    public function answers()
    {
        return $this->hasMany(ProductQuestionAnswer::class, 'parent_id');
    }

    /**
     * if this answer get question
     * @return BelongsTo
     */
    public function question()
    {
        return $this->belongsTo(ProductQuestionAnswer::class, 'parent_id');
    }

    public function getLikesCountAttribute()
    {
        return $this->morphMany( CommentsLikes::class, 'likeable')->where('vote', 1)->count();
    }

    public function getDislikesCountAttribute()
    {
        return $this->morphMany( CommentsLikes::class, 'likeable')->where('vote', 0)->count();
    }

}
