<?php

namespace App\Models\Product;

use App\Events\ProductInStock;
use App\Helpers\FileUploaded;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Libs\PageConstructor\Interfaces\PageBlocksInterface;
use App\Libs\PageConstructor\Traits\HasPageBlocks;
use App\Models\Order;
use App\Models\ProductCustomFilter;
use App\Models\ProductFavorite;
use App\Models\ProductsAttributesNumericValues;
use App\Models\ProductsAttributesSlugValues;
use App\Models\ProductsAttributesTextValues;
use App\Models\Promotion;
use App\Models\ReviewAttach;
use App\Models\TypeFishes;
use App\Models\Types;
use App\Models\UserProductReview;
use App\Models\UserView;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;
use Laravel\Scout\Searchable;
use Spatie\Translatable\HasTranslations;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use ValueError;
use InvalidArgumentException;

/**
 * Class Product
 * @property int id
 * @property int parent_id
 * @property int category_id
 * @property int brand_id
 * @property int type_i
 * @property int type_fish_id
 * @property string photo
 * @property string name
 * @property string slug
 * @property float price
 * @property float min_price - @see static::getMinPriceAttribute()
 * @property string description
 * @property string short_description
 * @property string SKU
 * @property string barcode
 * @property string status Comment status
 * @property bool is_active
 * @property bool is_product_of_week
 * @property int product_of_week_cashback_amount - @see static::getProductOfWeekCashbackAmountAttribute()
 * @property float weight
 * @property string $brutto
 * @property float $float_brutto;
 * @property string $volume // in hectoliters
 * @property float $float_volume // in hectoliters
 * @property int stock
 * @property int stock_opt
 * @property Category category
 * @property Brand $brand
 * @property Collection modifications
 * @property bool $retail
 * @property bool $wholesale
 * @property \DateTime $date_arrival
 * @property string $date_arrival_month // @see static::getDateArrivalMonthAttribute()
 *
 * @property float $wholesale_price_uah
 * @property float $wholesale_price_uah_5
 * @property float $wholesale_price_uah_10
 * @property float $wholesale_price_uah_15
 *
 * @property float $min_wholesale_price_uah - @see static::getMinWholesalePriceUahAttribute()
 * @property float $min_wholesale_price_uah_5 - @see static::getMinWholesalePriceUah5Attribute()
 * @property float $min_wholesale_price_uah_10 - @see static::getMinWholesalePriceUah10Attribute()
 * @property float $min_wholesale_price_uah_15 - @see static::getMinWholesalePriceUah15Attribute()
 *
 * @property float $wholesale_usd
 * @property float $wholesale_usd_5
 * @property float $wholesale_usd_10
 * @property float $wholesale_usd_15
 *
 * @property float $min_wholesale_usd - @see static::getMinWholesaleUsdAttribute()
 * @property float $min_wholesale_usd_5 - @see static::getMinWholesaleUsd5Attribute()
 * @property float $min_wholesale_usd_10 - @see static::getMinWholesaleUsd10Attribute()
 * @property float $min_wholesale_usd_15 - @see static::getMinWholesaleUsd15Attribute()
 *
 * @property float $max_cashback_amount - @see static::getMaxCashbackAmountAttribute()
 *
 * @property Collection $all_attributes // @see static::getAllAttributesAttribute() | static::setAllAttributesAttribute()
 * @property Product parentProduct // @see static::parentProduct()
 *
 * @property string photo_path // @see static::getPhotoPathAttribute()
 *
 * @package App\Models\Product
 */
class Product extends Model implements HasMedia, PageBlocksInterface
{
    use HasTranslations;
    use InteractsWithMedia;
    use HasPageBlocks;
    use Searchable;

    const TABLE_NAME = 'products';

    protected $table = self::TABLE_NAME;

    /** @var int - Продукт на складе */
    public const STATUS_IN_STOCK = 1;

    /** @var int - Продукт в ожидании */
    public const STATUS_WAITING = 2;

    /** @var int - Продукт отсутсвует */
    public const STATUS_OUT_STOCK = 0;

    public $translatable = ['name', 'description', 'short_description'];

    protected $casts = [
        'promo_content' => 'json',
        'date_arrival' => 'date',
    ];

    protected $fillable = [
        'parent_id',
        'photo',
        'category_id',
        'brand_id',
        'name',
        'slug',
        'price',
        'stock_price',
        'description',
        'promo_content',
        'short_description',
        'article',
        'status',
        'weight',
        'in_stock',
        'is_active',
        'is_product_of_week',
        'date_arrival',
        'SKU',
        'SKU_parent',
        'stock',
        'stock_opt',
        'width',
        'height',
        'depth',
        'volume',
        'brutto',
        'netto',
        'retail',
        'wholesale',
        'barcode',
        'wholesale_price_uah',
        'wholesale_price_uah_5',
        'wholesale_price_uah_10',
        'wholesale_price_uah_15',
        'wholesale_usd',
        'wholesale_usd_5',
        'wholesale_usd_10',
        'wholesale_usd_15',
    ];

    protected $appends = [
        'attr',
        'descAttr',
        'category_name',
        'brand_name',
        'date_arrival_month',
        'min_price',
        'min_wholesale_price_uah',
        'min_wholesale_price_uah_5',
        'min_wholesale_price_uah_10',
        'min_wholesale_price_uah_15',
        'min_wholesale_usd',
        'min_wholesale_usd_5',
        'min_wholesale_usd_10',
        'min_wholesale_usd_15',
        'mod_id',
        'float_brutto',
        'float_volume',
        'photo_path',
        'product_of_week_cashback_amount',
    ];

    private Promotion|null $product_of_week_bonus = null;

    /**
     * Product category
     * @return BelongsTo
     */
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    /**
     * Product brand
     * @return BelongsTo
     */
    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }

    /**
     * Product photos
     * @return HasMany
     */
    public function photos()
    {
        return $this->hasMany(ProductPhoto::class, 'product_id');
    }

    /**
     * Product video reviews
     * @return HasMany
     */
    public function videoReviews()
    {
        return $this->hasMany(ProductVideoReviews::class, 'product_id');
    }

    /**
     * Product attribute
     * @return HasMany
     */
    public function productAttribute()
    {
        return $this->hasMany(ProductAttribute::class, 'product_id')->where('isVisible', true);
    }

    /**
     * Product analogs
     * @return HasManyThrough
     */
    public function analogs()
    {
        return $this->hasManyThrough(
            Product::class,
            ProductAnalog::class,
            'product_id',
            'id',
            'id',
            'product_analog_id'
        );
    }

    /**
     * Product related
     * @return HasManyThrough
     */
    public function related()
    {
        return $this->hasManyThrough(
            Product::class,
            ProductRelated::class,
            'product_id',
            'id',
            'id',
            'product_related_id'
        );
    }

    /**
     * Recommends product
     * @return HasManyThrough
     */
    public function recommend()
    {
        return $this->hasManyThrough(
            Product::class,
            ProductRecommend::class,
            'product_id',
            'id',
            'id',
            'product_recommend_id'
        );
    }

    /**
     * Product views
     * @return HasManyThrough
     */
    public function views()
    {
        return $this->hasManyThrough(
            User::class,
            UserView::class,
            'product_id',
            'id',
            'id',
            'user_id'
        );
    }

    /**
     * Product video reviews
     * @return HasMany
     */
    public function reviews()
    {
        return $this->hasMany(UserProductReview::class, 'product_id')->latest();
    }

    /**
     * @return HasMany
     */
    public function questions()
    {
        return $this->hasMany(
            ProductQuestionAnswer::class,
            'product_id'
        )
        ->where('parent_id', null)
        ->where('is_moderated', 1);
    }

    /**
     * @return HasMany
     */
    public function modifications()
    {
        return $this->hasMany(Product::class, 'parent_id', 'id');
    }

    /**
     * @return BelongsTo
     */
    public function parentProduct()
    {
        return $this->belongsTo(Product::class, 'parent_id', 'id');
    }

    /**
     * @return BelongsToMany
     */
    public function attributeValues()
    {
        return $this->belongsToMany(AttributeSlugValue::class, ProductAttributeSlugValue::class);
    }

    /**
     * Product type
     * @return BelongsToMany
     */
    public function types()
    {
        return $this->belongsToMany(
            Types::class,
            'product_types',
            'product_id',
            'type_id'
        );
    }

    /**
     * Product type fishes
     * @return BelongsToMany
     */
    public function typesFishes()
    {
        return $this->belongsToMany(
            TypeFishes::class,
            'product_type_fishes',
            'product_id',
            'type_fish_id'
        );
    }

    /**
     * Defining media collections
     */
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('photocollection');
    }

    /**
     * Convert attributes to array [name] => value
     * @return array
     */
    public function getAttrAttribute()
    {
        $productAttribute = [];
//        $productAttribute = ['Вес' => $this->attributes['weight']];
        foreach ($this->productAttribute as $attribute) {
            if ($attribute->isVisible) {
                if (empty($attribute->value)) {
                    $productAttribute[$attribute->info->name] = [];
                } else {
                    $productAttribute[$attribute->info->name][] = $attribute->value;
                }
            }
        }
        return $productAttribute;
    }

    /**
     * Get category name
     * @return mixed
     */
    public function getCategoryNameAttribute()
    {
        return $this->category->name ?? '';
    }

    /**
     * Get brand name
     * @return mixed
     */
    public function getBrandNameAttribute()
    {
        return $this->brand->name ?? '';
    }

    /**
     * Get brand slug
     * @return mixed
     */
    public function getBrandSlugAttribute()
    {
        return $this->brand->slug ?? '';
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }

//    public function setNameAttribute($value)
//    {
//        $this->attributes['name'] = $value;
//        $this->attributes['slug'] = Str::slug($value . '-' . $this->attributes['SKU']);
//    }

    /**
     * @return string
     */
    public function getPhotoAttribute($value)
    {
        if ($value) {
            return Storage::disk(FileUploaded::PRODUCT_DISK)->url($value);
        } else {
            if ($this->modifications->isNotEmpty() && $this->modifications->first()) {
                return Storage::disk(FileUploaded::PRODUCT_DISK)->url($this->modifications->first()->attributes['photo']);
            } else {
                return false;
            }
        }
    }

    /**
     * @return string
     */
    public function getPhotoPathAttribute()
    {
        if ($this->attributes['photo']) {
            return Storage::disk(FileUploaded::PRODUCT_DISK)->path($this->attributes['photo']);
        } else {
if ($this->modifications->isNotEmpty() && $this->modifications->first() && $this->modifications->first()->attributes['photo']) {
                return Storage::disk(FileUploaded::PRODUCT_DISK)->path($this->modifications->first()->attributes['photo']);
            } else {
                return null;
            }
        }
    }

    #region Actions

    /**
     * @inheritDoc
     */
    protected static function boot()
    {
        parent::boot();

        static::saving(function (Product $product) {
            if ($product->getCorrectStatus() == $product->status) {
                return;
            }

            $product->status = $product->getCorrectStatus();
        });
    }

    /**
     * Returns a date_arrival month name. E.g. September
     *
     * @return int
     */
    private function getCorrectStatus(): int
    {
        if ($this->stock > 0) {
            return static::STATUS_IN_STOCK;
        }

        if ($this->stock == 0 && $this->date_arrival > new \DateTime()) {
            return static::STATUS_WAITING;
        }

        return static::STATUS_OUT_STOCK;
    }

    #endregion

    #region Updates methods

    /**
     * @param int $count_to_reduce
     * @param bool $for_resellers
     *
     * @return $this
     */
    public function reduceStockBalance(int $count_to_reduce, bool $for_resellers = false): self
    {
        $property_name = $for_resellers
            ? 'stock_opt'
            : 'stock';

        if ($this->$property_name < $count_to_reduce) {
            throw new InvalidArgumentException('$count_to_reduce cannot be more then ' . $property_name . ' value');
        }

        $this->$property_name = $this->$property_name - $count_to_reduce;

        $this->save();

        return $this;
    }

    /**
     * @return void
     */
    private function removeAllAttributes()
    {
        ProductsAttributesSlugValues::query()->where('product_id', $this->id)->delete();
        ProductsAttributesNumericValues::query()->where('product_id', $this->id)->delete();
        ProductsAttributesTextValues::query()->where('product_id', $this->id)->delete();
    }

    /**
     * @return bool|null
     */
    public function delete()
    {
        $this->removeAllAttributes();

        return parent::delete();
    }

    #endregion

    #region Is Condition methods

    /**
     * @return bool
     */
    public function isProductOfWeek(): bool
    {
        if ($this->modifications->isEmpty()) {
            return $this->is_product_of_week;
        }

        return $this->modifications
            ->where('is_active', 1)
            ->where('is_product_of_week', 1)
            ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
            ->where('stock', '>', 0)
            ->isNotEmpty();
    }

    #endregion

    #region Set Virtual Attribute

    /**
     * @param $value
     */
    public function setDateArrivalAttribute($value)
    {
        if (is_null($value) &&
            array_key_exists('date_arrival', $this->attributes) &&
            !is_null($this->attributes['date_arrival'])) {
            event(new ProductInStock($this));
        }
        $this->attributes['date_arrival'] = $value;
    }

    /**
     * @param $value
     */
    public function setStatusAttribute($value)
    {
        if (!in_array($value, [Product::STATUS_OUT_STOCK, Product::STATUS_IN_STOCK, Product::STATUS_WAITING])) {
            throw new ValueError('Attribute not available');
        }
        if ($value == Product::STATUS_IN_STOCK) {
            if (array_key_exists('date_arrival', $this->attributes) && !is_null($this->attributes['date_arrival'])) {
                $this->setDateArrivalAttribute(null);
            }
        }
        $this->attributes['status'] = $value;
    }

    /**
     * @param $value
     */
    public function setCountAttribute($value)
    {
        if ($value <= 0) {
            $value = 0;
            $this->attributes['status'] = Product::STATUS_OUT_STOCK;
        }
        $this->attributes['count'] = $value;
    }

    /**
     * @param Collection $attributes
     * [
     *      // Slug
     *      [
     *          'id' => int,
     *          'value' => [1, 2, 3, ...],
     *      ],
     *
     *      // Number
     *      [
     *          'id' => int,
     *          'value' => 123.342,
     *      ],
     *
     *      // Text
     *      [
     *          'id' => int,
     *          'value' => [
     *              'ru' => string,
     *              'ua' => string,
     *          ],
     *      ],
     *      ...
     * ]
     */
    public function setAllAttributesAttribute(Collection $attributes)
    {
        /** @var Collection $attr_list */
        static $attr_list;

        if (!$attr_list) {
            $attr_list = Attribute::getAll();
        }

        $new_attributes = [];
        $basic_data = [
            'product_id' => $this->id,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ];

        // Collect new attributes
        foreach ($attributes as $attribute) {
            /** @var Attribute $descAttr */
            $descAttr = $attr_list
                ->map(function (Attribute $attr) use ($attribute) {
                    return $attr->id == $attribute['id']
                        ? $attr
                        : false;
                })
                ->reject(fn ($name) => empty($name))
                ->first();

            if (!$descAttr) {
                throw new \RuntimeException('There is no attribute in attributes list. Needed $attribute[value]: ' . $attribute['value'] . ' | Product ID: ' . $this->id);
            }

            switch ($descAttr->filter_type) {
                case Attribute::TYPE_SLUG:
                    foreach ($attribute['value'] as $id) {
                        $new_attributes[$descAttr->filter_type][] = [
                                'attribute_slug_value_id' => $id,
                            ] + $basic_data;
                    }

                    break;

                case Attribute::TYPE_NUMERIC:
                    $new_attributes[$descAttr->filter_type][] = [
                            'attribute_id' => $descAttr->id,
                            'value' => $attribute['value'],
                        ] + $basic_data;

                    break;

                case Attribute::TYPE_TEXT:
                    $new_attributes[$descAttr->filter_type][] = [
                            'attribute_id' => $descAttr->id,
                            'value' => json_encode($attribute['value']),
                        ] + $basic_data;

                    break;

                default:
                    throw new InvalidArgumentException('Unknown attribute type processed');
            }
        }

        $this->removeAllAttributes();

        // Save the new attributes
        foreach ($new_attributes as $filter_type => $attribute) {
            switch ($filter_type) {
                case Attribute::TYPE_SLUG:
                    ProductsAttributesSlugValues::insert($attribute);
                    break;

                case Attribute::TYPE_NUMERIC:
                    ProductsAttributesNumericValues::insert($attribute);
                    break;

                case Attribute::TYPE_TEXT:
                    ProductsAttributesTextValues::insert($attribute);
                    break;
            }
        }
    }

    #endregion

    #region Getters

    /**
     * @inheritDoc
     */
    public function getPageBlocksDataPropertyName(): string
    {
        return 'promo_content';
    }

    /**
     * @param bool $for_resellers
     *
     * @return int
     */
    public function getStockBalance(bool $for_resellers = false): int
    {
        return $for_resellers
            ? (int) $this->stock_opt
            : (int) $this->stock;
    }

    /**
     * @inheritDoc
     */
    public function toSearchableArray()
    {
        if (!$this->is_active || !$this->retail) {
            return [];
        }

        return [
            'id' => $this->id,
            'SKU' => $this->SKU,
            'barcode' => $this->barcode,
            'name' => $this->getOriginal('name'),
            'slug' => $this->slug,
            'photo' => $this->photo,
            'short_description' => $this->getOriginal('short_description'),
            'description' => $this->getOriginal('description'),
        ];
    }

    /**
     * @return float|int
     */
    public function getFinalCashbackAmount()
    {
        if (!$this->max_cashback_amount && !$this->isProductOfWeek()) {
            return 0;
        }

        return $this->product_of_week_cashback_amount > $this->max_cashback_amount
            ? $this->product_of_week_cashback_amount
            : $this->max_cashback_amount;
    }

    #endregion

    #region Get Virtual Attribute

    /**
     * @return string
     */
    public function getDateArrivalMonthAttribute()
    {
        if (!empty($this->attributes['date_arrival'])) {
            Carbon::setLocale(App::getLocale());

            return Carbon::make($this->attributes['date_arrival'])
                ->getTranslatedMonthName();
        }
        return null;
    }

    /**
     * @param string $price_column
     *
     * @return int
     */
    private function getMinPrice(string $price_column)
    {
        if ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty()) {
            return (int) $this->modifications
                ->where('is_active', 1)
                ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
                ->where('stock', '>', 0)
                ->min($price_column);
        }

        return (int)$this->{$price_column};
    }

    /**
     * Если товар с модификациями то возвращаем цену дешовой модификации
     * @return float|mixed
     */
    public function getMinPriceAttribute()
    {
        if (!empty($this->price)) {
            return $this->price;
        }

        return $this->getMinPrice('price');
    }

    /**
     * Returns minimal wholesale price in UAH for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesalePriceUahAttribute()
    {
        return $this->getMinPrice('wholesale_price_uah');
    }

    /**
     * Returns minimal wholesale price -5% in UAH for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesalePriceUah5Attribute()
    {
        return $this->getMinPrice('wholesale_price_uah_5');
    }

    /**
     * Returns minimal wholesale price -10% in UAH for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesalePriceUah10Attribute()
    {
        return $this->getMinPrice('wholesale_price_uah_10');
    }

    /**
     * Returns minimal wholesale price -15% in UAH for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesalePriceUah15Attribute()
    {
        return $this->getMinPrice('wholesale_price_uah_15');
    }

    /**
     * Returns minimal wholesale price in USD for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesaleUsdAttribute()
    {
        return $this->getMinPrice('wholesale_usd');
    }

    /**
     * Returns minimal wholesale price -5% in USD for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesaleUsd5Attribute()
    {
        return $this->getMinPrice('wholesale_usd_5');
    }

    /**
     * Returns minimal wholesale price -10% in USD for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesaleUsd10Attribute()
    {
        return $this->getMinPrice('wholesale_usd_10');
    }

    /**
     * Returns minimal wholesale price -15% in USD for a group of the products
     *
     * @return float|mixed
     */
    public function getMinWholesaleUsd15Attribute()
    {
        return $this->getMinPrice('wholesale_usd_15');
    }

    /**
     * Returns max cashback amount
     *
     * @return float|mixed
     */
    public function getMaxCashbackAmountAttribute()
    {
        if ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty()) {
            return (float) $this->modifications
                ->where('is_active', 1)
                ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
                ->where('stock', '>', 0)
                ->max('bonus_new');
        }

        return (float) $this->bonus_new;
    }

    /**
     * Если товар с модификациями то возвращаем id самой дешовой модификации
     * @return \Illuminate\Database\Eloquent\HigherOrderBuilderProxy|int|mixed
     */
    public function getModIdAttribute()
    {
        if ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty()) {
            return $this->modifications->sortBy('price')->first()->id;
        }
        return $this->id;
    }

    /**
     * Если это модификация вернуть слаг главного товара
     * @return \Illuminate\Database\Eloquent\HigherOrderBuilderProxy|mixed|string
     */
    public function getMainSlugAttribute()
    {
        if (array_key_exists('parent_id', $this->attributes) && !empty($this->attributes['parent_id'])) {
            $product = Product::query()->where(['id' => $this->attributes['parent_id']])->first();
            if (!empty($product)) {
                return $product->slug;
            }
        }
        return $this->slug;
    }

    /**
     * @return float
     */
    public function getFloatBruttoAttribute()
    {
        return (float) str_replace(',', '.', $this->brutto);
    }

    /**
     * @return float
     */
    public function getFloatVolumeAttribute()
    {
        return (float) str_replace(',', '.', $this->volume);
    }

    /**
     * @return float|int
     */
    public function getProductOfWeekCashbackAmountAttribute()
    {
        if (!$this->isProductOfWeek()) {
            return 0;
        }

        $this->product_of_week_bonus = $this->product_of_week_bonus ?? Promotion::getList(Promotion::TRIGGER_CHECKOUT, Promotion::CODE_PRODUCT_OF_WEEK)
            ->first();

        if (!$this->product_of_week_bonus) {
            return 0;
        }

        $price = (int)$this->price;

        if ($this->modifications->isNotEmpty()) {
            $price = (int) $this->modifications
                ->where('is_active', 1)
                ->where('is_product_of_week', 1)
                ->whereIn('status', [Product::STATUS_IN_STOCK, Product::STATUS_WAITING])
                ->where('stock', '>', 0)
                ->max('price');
        }

        return $this->product_of_week_bonus->getDiscount($price);
    }
    #endregion

    #region Is Condition methods

    /**
     * @return bool
     */
    public function isInStock(): bool
    {
        return ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty())
            ? $this->modifications->filter(fn(Product $child) => $child->isInStock() )->isNotEmpty()
            : $this->attributes['status'] == self::STATUS_IN_STOCK && $this->attributes['stock'] > 0;
    }

    /**
     * @return bool
     */
    public function isWaiting(): bool
    {
        return ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty())
            ? $this->modifications->filter(fn(Product $child) => $child->isWaiting() )->isNotEmpty()
            : $this->attributes['status'] == self::STATUS_WAITING;
    }

    /**
     * @return bool
     */
    public function isOutStock(): bool
    {
        return ($this->relationLoaded('modifications') && $this->modifications->isNotEmpty())
            ? $this->modifications->filter(fn(Product $child) => $child->isOutStock() )->isNotEmpty()
            : $this->attributes['status'] == self::STATUS_OUT_STOCK || $this->attributes['stock'] == 0;
    }

    #endregion

    public function getRatingAttribute()
    {
        $rating = $this->reviews->where('is_moderated', '1')->avg('product_mark');
        return round($rating, 1);
    }

    public function orders()
    {
        return $this->belongsToMany(Order::class, 'product_orders');
    }

    public function getFavoritesAttribute()
    {
        return $this->hasManyThrough(ProductFavorite::class, Product::class, 'id',
            'product_id')->count();
    }

    public function reviewsAttaches()
    {
        return $this->hasManyThrough(
            ReviewAttach::class,
            UserProductReview::class,
            'product_id',
            'product_reviews_id',
            'id',
            'id'
        )->where('is_moderated', true);
    }

    public function getApproveReviewsCountAttribute()
    {
        return $this->reviews()->where('is_moderated', true)->count();
    }

    public function three_d_photos()
    {
        return $this->hasMany(ProductThreeDimensionalPhotos::class, 'product_id');
    }

    public function expertReview()
    {
        return $this->reviews()
        ->where('is_expert', 1)
        ->limit(1);
    }


    public function getPriceAttribute($value)
    {
        return intval($value);
    }

    public function filter()
    {
        return $this->hasMany(ProductCustomFilter::class, 'product_id','id');
    }

    public function seoProduct()
    {
        return $this->hasOne(SeoProduct::class, 'product_id');
    }

    public function is_single()
    {
        return ! $this->parent_id && is_numeric($this->SKU) ;
    }

    public function attrTextValues()
    {
        return $this->hasMany(ProductsAttributesTextValues::class, 'product_id');
    }

    public function attrNumericValues()
    {
        return $this->hasMany(ProductsAttributesNumericValues::class, 'product_id');
    }

    public function attrSlugValues()
    {
        return $this->hasManyThrough(
            AttributeSlugValue::class,
            ProductsAttributesSlugValues::class,
            'product_id',
            'id',
            'id',
            'attribute_slug_value_id'
        );
    }

    /**
     * @param bool $return_hidden_attrs
     *
     * @return array
     */
    public function getDescAttrAttribute($return_hidden_attrs = false)
    {
        $descAttrs = $return_hidden_attrs
            ? Attribute::getAll()
            : Attribute::getAllDisplayed();

        $result = [];
        foreach ($descAttrs as $descAttr) {
            $valuesRelations = collect();
            switch ($descAttr->filter_type) {
                case Attribute::TYPE_SLUG:
                    $valuesRelations = $this->attrSlugValues;
                    break;
                case Attribute::TYPE_TEXT:
                    $valuesRelations = $this->attrTextValues;
                    break;
                case Attribute::TYPE_NUMERIC:
                    $valuesRelations = $this->attrNumericValues;
                    break;
            }

            if ($valuesRelations) {
                $values = $valuesRelations->where('attribute_id', $descAttr->id)->pluck('value');
                if ($values->isNotEmpty()) {
                    $result[$descAttr->desc_attr_name] = $values->toArray();
                }
            }
        }

        return $result;
    }

    /**
     * Returns list of attribute types, based on column `attributes.filter_type`
     *
     * @param bool $return_hidden_attrs
     *
     * @return Collection
     * [
     *      [
     *          'parent' => App\Models\Attribute,
     *          'children' => Illuminate\Database\Eloquent\Collection|AttributeSlugValue[]|ProductsAttributesNumericValues[]|ProductsAttributesTextValues[],
     *      ],
     *      ...
     * ]
     */
    public function getAllAttributesAttribute($return_hidden_attrs = false)
    {
        $descAttrs = $return_hidden_attrs
            ? Attribute::getAll()
            : Attribute::getAllDisplayed();
        $result = collect();

        foreach ($descAttrs as $descAttr) {
            $valuesRelations = collect();

            switch ($descAttr->filter_type) {
                case Attribute::TYPE_SLUG:
                    $valuesRelations = $this->attrSlugValues;
                    break;

                case Attribute::TYPE_TEXT:
                    $valuesRelations = $this->attrTextValues;
                    break;

                case Attribute::TYPE_NUMERIC:
                    $valuesRelations = $this->attrNumericValues;
                    break;
            }

            if ($valuesRelations) {
                $values = $valuesRelations->where('attribute_id', $descAttr->id);

                if ($values->isNotEmpty()) {
                    $result->put($descAttr->id, [
                        'parent' => $descAttr,
                        'children' => $values,
                    ]);
                }
            }
        }

        return $result;
    }

    /**
     * @return string
     */
    public function getModificationShortNameAttribute()
    {
        if( ! $this->parentProduct->exists() ){
            return $this->name;
        }

        $short_raw =  Str::replaceFirst( $this->parentProduct->name, '', $this->name );
        return Str::replaceFirst(' ', '', Str::ucfirst($short_raw) );
    }

    /**
     * @return string
     */
    public function getModificationsFrontendArrayAttribute()
    {
        $empty_collection =  collect();
        if (! $this->relationLoaded('modifications') || ! $this->modifications->isNotEmpty()) {
            return $empty_collection->toJson();
        }

        $active_modifications = $this->modifications
            ->where('is_active','=', 1)
            ->where('stock','>', 0);

        $modification_with_links = $active_modifications->map(function ($modification) {
            $modification['title'] = $modification->modification_short_name;
            $modification['picture'] = asset($modification->photo);

            // $modification['childAttributes'] = collect($modification->desc_attr)->map(function ($attr, $key){
            //     return implode($attr);
            // });
            return $modification;
        });

        $result_modifications = $modification_with_links->map(function ($modification) {
            return collect($modification)
                // ->only(['id', 'price', 'title', 'picture', 'childAttributes'])
                ->only(['id', 'price', 'title', 'picture'])
                ->all();
        });

        return $result_modifications->values()->toJson();
    }
}
