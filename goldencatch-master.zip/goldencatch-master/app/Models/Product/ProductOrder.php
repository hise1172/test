<?php

namespace App\Models\Product;

use App\Models\BonusHistory;
use App\Models\Order;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;

/**
 * @property int count
 * @property int price
 *
 * @property-read Product product
 * @property-read MorphOne|null cashback
 */
class ProductOrder extends Model
{
    public $timestamps = false;
    protected $fillable = ['product_id', 'order_id', 'count', 'price'];

    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * Get a cashback for an order item
     *
     * @return MorphOne
     */
    public function cashback()
    {
        return $this->morphOne(BonusHistory::class, 'bonusable');
    }
}
