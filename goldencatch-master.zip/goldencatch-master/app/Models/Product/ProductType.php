<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Types;

/**
 * Class ProductType
 * @package App
 */
class ProductType extends Model
{
    protected $fillable = ['product_id', 'type_id'];
    public $timestamps = false;
    /**
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * @return BelongsTo
     */
    public function type()
    {
        return $this->belongsTo(Types::class, 'type_id');
    }
}
