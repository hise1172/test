<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductRecommend extends Model
{
    public $timestamps = false;
    protected $fillable = ['product_id', 'product_recommend_id', 'is_recommend'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function recommend()
    {
        return $this->belongsTo(Product::class, 'product_recommend_id');
    }
}
