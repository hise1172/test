<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductRelated extends Model
{
    public $timestamps = false;
    protected $fillable = ['product_id', 'product_related_id', 'wight'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function related()
    {
        return $this->belongsTo(Product::class, 'product_related_id');
    }
}
