<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class ProductAttribute
 * @package App\Models\Product
 */
class ProductAttribute extends Model
{
    public $timestamps = false;
    protected $fillable = ['value', 'product_id', 'product_attribute_name_id', 'isVisible'];

    /**
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * @return BelongsTo
     */
    public function info()
    {
        return $this->belongsTo(ProductAttributeName::class, 'product_attribute_name_id');
    }
}
