<?php

namespace App\Models\Product;


use Illuminate\Database\Eloquent\Model;

class SeoProduct extends Model
{
    protected $fillable = ['product_id', 'title', 'description'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}
