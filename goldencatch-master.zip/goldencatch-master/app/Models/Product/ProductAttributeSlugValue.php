<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductAttributeSlugValue extends Model
{
    protected $table = 'products_attributes_slug_values';
}
