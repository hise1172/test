<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

/**
 * Class ProductPhoto
 * @package App\Models\Product
 */
class ProductPhoto extends Model
{
    protected $appends = ['photo'];
    protected $fillable = ['product_id', 'name', 'path', 'is_show'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * @return string
     */
    public function getPhotoAttribute()
    {
        if ($this->attributes['path']) {
            return Storage::disk('products')->url($this->attributes['path']);
        } else {
            return false;
        }
    }
}
