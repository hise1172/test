<?php

namespace App\Models\Product;

use App\Models\TypeFishes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class ProductTypeFishes
 * @package App
 */
class ProductTypeFishes extends Model
{
    protected $fillable = ['product_id', 'type_fish_id'];
    public $timestamps = false;
    /**
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * @return BelongsTo
     */
    public function typeFishes()
    {
        return $this->belongsTo(TypeFishes::class, 'type_fish_id');
    }
}
