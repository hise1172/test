<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class ProductAttributeName
 * @package App\Models\Product
 */
class ProductAttributeName extends Model
{
    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * @return BelongsTo
     */
    public function attributeName()
    {
        return $this->belongsTo(ProductAttributeName::class, 'product_attribute_name_id');
    }

}
