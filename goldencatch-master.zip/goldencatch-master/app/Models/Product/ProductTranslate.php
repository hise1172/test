<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductTranslate extends Model
{
    protected $table='product_translate';
    protected $fillable = [
        'SKU',
        'lang',
        'name',
        'description',
        'short_description',
    ];
}
