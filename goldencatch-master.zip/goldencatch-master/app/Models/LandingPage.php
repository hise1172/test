<?php

namespace App\Models;

use App\Libs\PageConstructor\Interfaces\PageBlocksInterface;
use App\Libs\PageConstructor\Traits\HasPageBlocks;
use App\Nova\Field\PageConstructor\BlockFields\Property\ImageFieldValue;
use App\Providers\RouteServiceProvider;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Spatie\Translatable\HasTranslations;

/**
 * @property int id
 * @property string title
 * @property string slug
 * @property string created_at
 * @property string updated_at
 * @property string seo_title
 * @property string seo_description
 * @property bool robots_index
 * @property bool robots_follow
 *
 * @property string og_image_url // @see $this->getOgImageUrlAttribute()
 */
class LandingPage extends Model implements PageBlocksInterface
{
    use HasTranslations;
    use HasPageBlocks;
    use HasFactory;

    const TABLE_NAME = 'landing_pages';

    const HOMEPAGE_SLUG = 'homepage';

    public $translatable = [
        'title',
        'seo_title',
        'seo_description',
    ];

    protected $fillable = [
        'title',
        'slug',
        'blocks_data',
        'seo_title',
        'seo_description',
        'og_image',
        'robots_index',
        'robots_follow',
    ];

    protected $casts = ['blocks_data' => 'json'];

    #region Builders

    /**
     * @param string $slug
     *
     * @return static
     */
    public static function init(string $slug)
    {
        return static::query()
            ->where('slug', $slug)
            ->first();
    }

    #endregion

    #region Updates methods

    public function save(array $options = [])
    {
        return parent::save($options);
    }

    #endregion

    #region Getters

    /**
     * @return LandingPage[]|\Illuminate\Database\Eloquent\Collection
     */
    public static function getAll()
    {
        static $all_landings;

        if ($all_landings) {
            return $all_landings;
        }

        return $all_landings = static::all();
    }

    /**
     * @param string $slug
     *
     * @return string
     */
    public static function getURL(string $slug)
    {
        return route(RouteServiceProvider::NAME_HOME) . '/' . $slug;
    }

    /**
     * @inheritDoc
     */
    public function getPageBlocksDataPropertyName(): string
    {
        return 'blocks_data';
    }

    #endregion

    #region Get Virtual Attributes

    /**
     * @return string
     */
    public function getOgImageUrlAttribute(): string
    {
        return Storage::disk(ImageFieldValue::DISC)->url($this->og_image);
    }

    #endregion
}
