<?php

namespace App\Models;

use App\Models\Product\Product;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Spatie\Translatable\HasTranslations;

/**
 * Class Brand
 * @property int id
 * @property string name brand's name
 * @property string slug brand's slug
 * @property string logo_image
 *
 * @property string icon // @see $this->getIconAttribute()
 * @property SemanticRule semanticRule
 */
class Brand extends Model
{
    use HasTranslations;

    const TABLE_NAME = 'brands';
    const DISC = 'catalog';

    protected $table = self::TABLE_NAME;

    protected $fillable = [
        'name',
        'country',
        'logo_image',
    ];

    public $translatable = ['name'];

    public $timestamps = false;

    #region Relations

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\MorphOne
     */
    public function semanticRule()
    {
        return $this->morphOne(SemanticRule::class, 'rulable');
    }

    #endregion

    #region Get Virtual attributes

    /**
     * @return string
     */
    public function getIconAttribute()
    {
        if ($this->logo_image) {
            return Storage::disk(static::DISC)->url($this->logo_image);
        }

        return "images/brands/" . $this->attributes['icon'];
    }

    #endregion

    /**
     * @inheritDoc
     */
    protected static function boot()
    {
        parent::boot();

        static::deleting(function($model) {
            $model->semanticRule()->delete();
        });
    }
}
