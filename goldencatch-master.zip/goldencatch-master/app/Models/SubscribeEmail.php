<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class SubscribeEmail
 * @package App\Models
 * @property int user_id
 * @property string email
 * @property boolean active
 */
class SubscribeEmail extends Model
{
    protected $fillable = ['email', 'active'];
    public $timestamps = false;


}
