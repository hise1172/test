<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int id
 * @property int user_id
 * @property int provider_id
 * @property string provider_user_id
 * @property string first_name
 * @property string last_name
 * @property string username
 * @property string locale
 * @property string created_at
 * @property string updated_at
 *
 * @property User user
 */
class BotUser extends Model
{
    use HasFactory;

    const TABLE_NAME = 'bot_users';

    protected $table = self::TABLE_NAME;

    protected $fillable = [
        'user_id',
        'provider_id',
        'provider_user_id',
        'first_name',
        'last_name',
        'username',
        'locale',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
