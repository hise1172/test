<?php

namespace App\Models;

use App\Models\Product\Product;
use App\Models\Product\ProductAttributeSlugValue;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\Translatable\HasTranslations;

/**
 * @property int id
 * @property int attribute_id
 * @property string slug
 * @property string value // title
 *
 * @property Attribute attribute // @see self::attribute()
 * @property SemanticRule semanticRule
 */
class AttributeSlugValue extends Model
{
    use HasTranslations;

    const TABLE_NAME = 'attributes_slug_values';

    public $translatable = ['value'];

    protected $table = self::TABLE_NAME;

    protected int $productsCount = 0;

    public function attribute()
    {
        return $this->belongsTo(Attribute::class, 'attribute_id');
    }

    /**
     * @param int $productsCount
     * @return AttributeSlugValue
     */
    public function setProductsCount(int $productsCount): AttributeSlugValue
    {
        $this->productsCount = $productsCount;

        return $this;
    }

    public function getProductsCount()
    {
        return $this->productsCount;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\MorphOne
     */
    public function semanticRule()
    {
        return $this->morphOne(SemanticRule::class, 'rulable');
    }

    /**
     * @return BelongsToMany
     */
    public function products()
    {
        return $this->belongsToMany(Product::class, ProductAttributeSlugValue::class);
    }

    /**
     * @inheritDoc
     */
    protected static function boot()
    {
        parent::boot();

        static::deleting(function($model) {
            $model->semanticRule()->delete();
        });
    }
}
