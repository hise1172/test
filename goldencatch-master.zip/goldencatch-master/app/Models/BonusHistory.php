<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int id
 * @property int user_id
 * @property float amount
 * @property int status_id
 * @property string bonusable_type
 * @property int bonusable_id
 * @property string comment
 * @property \DateTime created_at
 * @property string updated_at
 *
 * @property BelongsTo|User user
 */
class BonusHistory extends Model
{
    use HasFactory;

    const TABLE_NAME = 'bonus_history';

    const STATUS_ACTIVE = 1;
    const STATUS_CANCELED = 2;

    protected $table = self::TABLE_NAME;

    protected $fillable = [
        'user_id',
        'amount',
        'status_id',
        'bonusable_type',
        'bonusable_id',
        'comment',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    #region Relations

    /**
     * Get the parent bonusable model (user or post).
     */
    public function bonusable()
    {
        return $this->morphTo();
    }

    /**
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    #endregion
}
