<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class CommentsLikes extends Model
{
    protected $fillable = [
        'user_id',
        'likeable_id',
        'likeable_type',
        'vote',
    ];

    public function likeable()
    {
        return $this->morphTo();
    }

    public function users()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function reviews()
    {
        return $this->belongsTo(UserProductReview::class, 'user_product_reviews_id', 'id');
    }
}
