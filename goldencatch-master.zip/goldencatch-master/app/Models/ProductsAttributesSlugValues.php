<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductCustomFilter
 * @package App\Models
 */
class ProductsAttributesSlugValues extends Model
{
    protected $table = 'products_attributes_slug_values';
}
