<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Catalog
 * This models doesn't use.
 * @package App
 */
class Catalog extends Model
{
    public $timestamps = false;
    protected $fillable = ['catalog_type_id', 'product_id'];

    public function type()
    {
        return $this->belongsTo(CatalogType::class, 'catalog_type_id');
    }

    public function products()
    {
        return $this->belongsTo(CatalogType::class, 'product_id');
    }
}
