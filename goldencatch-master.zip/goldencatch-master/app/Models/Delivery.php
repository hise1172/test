<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Delivery
 *
 * @package App\Models
 *
 * @property int $id
 * @property string $slug
 * @property string $method
 * @property string $price
 */
class Delivery extends Model
{
    const TABL_NAME = 'delivery';

    const NEWPOST_DEPARTMENT = 'newpost_department';
    const NEWPOST_COURIER = 'newpost_courier';
    const PICKUP_ODESSA = 'pickup_odessa';
    const DELIVERY_COMPANY = 'delivery';
    const AUTOLUX = 'autolux';
    const TRANSPORT_TO_CITY = 'transport_to_city';


    protected $table = self::TABL_NAME;

    protected $fillable = [
        'slug',
        'method',
        'price',
    ];

    public function Order()
    {
        $this->hasMany(Order::class, 'delivery_id');
    }
}
