<?php

namespace App\Models;

use App\Models\Product\Product;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class ProductFavorite
 * @package App\Models
 * @property User user
 * @property Product product
 * @property int id
 * @property int user_id
 * @property int product_id
 */
class ProductFavorite extends Model
{
    protected $fillable = ['user_id', 'product_id'];

    /**
     * @return BelongsTo
     */
    public function product()
    {
        return $this->belongsTo('product_id');
    }

    /**
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('user_id');
    }
}
