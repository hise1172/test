<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LiqpayHash extends Model
{
    protected $table = 'liqpay_hash';
    protected $fillable = ['order_hash', 'order_id','is_payed'];

    protected $casts = [
        'answers' => 'array'
    ];

    public function order()
    {
        return $this->hasMany(Order::class, 'order_id', 'order_id');
    }
}
