<?php

namespace App\Models\NovaPoshta;

use Illuminate\Database\Eloquent\Model;

class NovaPoshtaCities extends Model
{
    public $timestamps = false;
    protected $fillable = ['description', 'description_ru', 'ref', 'delivery1',
        'delivery2', 'delivery3', 'delivery4', 'delivery5', 'delivery6', 'delivery7',
        'area', 'settlement_type', 'city_id', 'settlement_type_description',
        'settlement_type_description_ru', 'area_description', 'area_description_ru'];

    public function order()
    {
        return $this->hasMany(NovaPoshtaOrder::class, 'newpost_city', 'ref');
    }
}
