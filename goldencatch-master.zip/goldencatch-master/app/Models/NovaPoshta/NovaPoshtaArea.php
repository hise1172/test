<?php

namespace App\Models\NovaPoshta;

use Illuminate\Database\Eloquent\Model;

/**
 * Class NovaPoshtaArea
 * @package App
 */
class NovaPoshtaArea extends Model
{
    public $timestamps = false;
    protected $fillable = ['ref', 'areas_center', 'description_ru', 'description'];

    public function order()
    {
        return $this->hasMany(NovaPoshtaOrder::class, 'newpost_region', 'ref');
    }
}
