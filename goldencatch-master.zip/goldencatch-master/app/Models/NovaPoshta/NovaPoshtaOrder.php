<?php

namespace App\Models\NovaPoshta;

use App\Models\Order;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class NovaPoshtaOrder
 * @package App\Models
 */
class NovaPoshtaOrder extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'newpost_region',
        'newpost_city',
        'newpost_warehouse',
        'newpost_courier',
        'order_id'
    ];

    /**
     * @return BelongsTo
     */
    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function area()
    {
        return $this->belongsTo(NovaPoshtaArea::class, 'newpost_region', 'ref');
    }

    public function city()
    {
        return $this->belongsTo(NovaPoshtaCities::class, 'newpost_city','ref');
    }

    public function address()
    {
        return $this->belongsTo(NovaPoshtaWarehouses::class, 'newpost_warehouse', 'ref');
    }
}
