<?php

namespace App\Models\NovaPoshta;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string ref
 * @property string site_key
 * @property string description
 * @property string description_ru
 * @property string type_of_warehouse
 * @property string number
 * @property string city_ref
 * @property string city_description
 * @property string city_description_ru
 * @property string longitude
 * @property string latitude
 * @property string post_finance
 * @property string post_terminal
 * @property string international_shipping
 * @property string total_max_weight_allowed
 * @property string place_max_weight_allowed
 */
class NovaPoshtaWarehouses extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'ref',
        'site_key',
        'description',
        'description_ru',
        'type_of_warehouse',
        'number',
        'city_ref',
        'city_description',
        'city_description_ru',
        'longitude',
        'latitude',
        'post_finance',
        'post_terminal',
        'international_shipping',
        'total_max_weight_allowed',
        'place_max_weight_allowed'
    ];

    public function order()
    {
        return $this->hasMany(NovaPoshtaOrder::class, 'newpost_warehouse', 'ref');
    }
}
