<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Redirect extends Model
{
    protected $fillable = [
      'new_url',
      'old_url',
      'turn_on',
    ];
}
