<?php

namespace App\Models;

use App\Helpers\Deliver;
use App\Models\NovaPoshta\NovaPoshtaOrder;
use App\Models\Product\Product;
use App\User;
use App\Models\Product\ProductOrder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;

/**
 * Class Order
 * @package App\Models
 *
 * @property int id
 * @property int $user_id
 * @property string $phone
 * @property string $email
 * @property string $name
 * @property string $surname
 * @property int $payment_method_id
 * @property int price
 * @property float discount
 * @property string tracking_code
 *
 * @property-read Delivery delivery
 * @property-read PaymentMethod paymentMethod
 * @property-read ProductOrder[] productOrders
 * @property-read User user
 * @property-read string $order_hash // @see $this->getOrderHashAttribute()
 * @property-read string delivery_address // @see $this->getDeliveryAddressAttribute()
 *
 */
class Order extends Model
{
    const TYPE_GENERIC = 1;
    const TYPE_ONE_CLICK = 2;
    const TYPE_HELP_REQUEST = 3;

    const TABLE_NAME = 'orders';

    public const ORDER_SUCCESS = 'success';

    protected $table = self::TABLE_NAME;

    protected $fillable = [
        'user_id',
        'name',
        'surname',
        'email',
        'lastname',
        'phone',
        'comments',
        'order_id',
        'delivery_id',
        'tracking_code',
        'price',
        'price_without_discount',
        'need_call',
        'order_type_id',
        'payment_method_id',
        'discount',
    ];

    protected $casts = [
        'crm' => 'array'
    ];

    protected $appends = [
        'order_hash',
        'delivery_address',
    ];

    private ?Delivery $_delivery = null;
    private ?PaymentMethod $_payment_method = null;

    /**
     * @return BelongsToMany
     */
    public function products()
    {
        return $this->belongsToMany(
            Product::class,
            'product_orders',
            'order_id',
            'product_id'
        )
        ->withPivot('count', 'price');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function novaPoshta()
    {
        return $this->hasOne(NovaPoshtaOrder::class, 'order_id');
    }

    public function delivery()
    {
        return $this->belongsTo(Delivery::class, 'delivery_id');
    }

    /**
     * A bonus, which were reduced to pay for an order
     *
     * @return MorphOne
     */
    public function usedBonus()
    {
        return $this->morphOne(BonusHistory::class, 'bonusable');
    }

    /**
     * @return Delivery
     */
    public function getDelivery()
    {
        if ($this->_delivery) {
            return $this->_delivery;
        }

        return $this->_delivery = $this->delivery()->first();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function productOrders()
    {
        return $this->hasMany(ProductOrder::class, 'order_id');
    }

    public function liqpayHash()
    {
        return $this->hasOne(LiqpayHash::class, 'order_id', 'order_id');
    }

    public static function getAllByUserId($user_id, $count = 10)
    {
        return self::where('user_id', $user_id)->latest()->paginate($count);
    }

    public function getStatusNameAttribute()
    {
        if( isset($this->crm['statuses']) && count($this->crm['statuses']) ){
            $statusId = max(array_keys( $this->crm['statuses']) );
            if( isset($this->crm['statuses'][$statusId]['code']) && \Lang::has('catalog.order.status.' . $this->crm['statuses'][$statusId]['code']) ){
                return __('catalog.order.status.' . $this->crm['statuses'][$statusId]['code']);
            }
        }
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method_id');
    }

    /**
     * @return PaymentMethod
     */
    public function getPaymentMethod()
    {
        if ($this->_payment_method) {
            return $this->_payment_method;
        }

        return $this->_payment_method = $this->paymentMethod()->first();
    }

    #region Get Virtual Attributes

    /**
     * @return string
     */
    public function getOrderHashAttribute(): string
    {
        return $this->order_id;
    }

    /**
     * @return string
     */
    public function getDeliveryAddressAttribute()
    {
        if (!in_array($this->delivery->slug, [Deliver::DEFAULT_METHOD, 'newpost_courier'])) {
            return '';
        }

        $this->load(['novaPoshta.city', 'novaPoshta.address']);

        switch (app()->getLocale()) {
            case Translate::RU:
                return $this->novaPoshta->city->area_description_ru . ' об., ' .
                    $this->novaPoshta->city->settlement_type_description_ru . ' ' .
                    $this->novaPoshta->city->description_ru . ', ' .
                    $this->novaPoshta->address->description_ru . '.';

            default:
                return $this->novaPoshta->city->area_description . ' об., ' .
                    $this->novaPoshta->city->settlement_type_description . ' ' .
                    $this->novaPoshta->city->description . ', ' .
                    $this->novaPoshta->address->description . '.';
        }
    }

    #endregion
}
