<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property-read int $id
 * @property string $name
 *
 *
 * @property-read string $key // @see $this->getKeyAttribute()
 */
class PaymentMethod extends Model
{
    use HasFactory;

    // Payment methods
    const LIQPAY = 1;
    const CASH_ON_DELIVERY = 2;
    const BANK_PAYMENT = 3;

    protected $fillable = [
        'name',
    ];

    protected $appends = [
        'key',
    ];

    #region Getters

    /**
     * @return string
     */
    public function getKeyAttribute()
    {
        $data = explode('.', $this->name);

        return end($data);
    }

    /**
     * @param bool $for_resellers_console
     *
     * @return int[]
     */
    public static function getAllowedMethods(bool $for_resellers_console): array
    {
        if (!$for_resellers_console) {
            return [
                static::LIQPAY,
                static::CASH_ON_DELIVERY,
            ];
        }

        return [
            static::CASH_ON_DELIVERY,
            static::BANK_PAYMENT,
        ];
    }

    #endregion
}
