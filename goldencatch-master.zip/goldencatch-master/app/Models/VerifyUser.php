<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class VerifyUser
 * Verification email user
 * @property int id
 * @property int user_id
 * @property string token
 * @property bool verified
 * @property User $user
 * @package App
 */
class VerifyUser extends Model
{
    protected $fillable = ['user_id', 'token', 'revoke'];
    public $timestamps = false;
    /**
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * @return bool
     */
    public function revoke()
    {
        $this->attributes['revoke'] = true;
        return true;
    }

}
