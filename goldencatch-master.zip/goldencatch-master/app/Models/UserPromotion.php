<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\Pivot;

/**
 * @property int user_id
 * @property int promotion_id
 * @property int status_id
 * @property string created_at
 *
 * @property Promotion|BelongsTo promotion
 * @property BonusHistory[]|Collection alreadySpentBonuses // @see $this->alreadySpentBonuses()
 */
class UserPromotion extends Pivot
{
    use HasFactory;

    const TABLE_NAME = 'user_promotions';

    const STATUS_NOT_USED = 1;
    const STATUS_PARTIAL_USAGE = 2;
    const STATUS_USED = 3;

    protected $table = self::TABLE_NAME;

    public $timestamps = false;

    #region Relations

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function promotion()
    {
        return $this->belongsTo(Promotion::class, 'promotion_id');
    }

    /**
     * @return MorphMany
     */
    public function spentBonuses()
    {
        return $this->morphMany(BonusHistory::class, 'bonusable');
    }

    /**
     * Returns a list of already spent bonuses during the current promotion campaign
     *
     * @return MorphMany
     */
    public function alreadySpentBonuses()
    {
        return $this->spentBonuses()
            ->where('created_at', '>=', $this->promotion->start_at)
            ->where('created_at', '<', $this->promotion->expire_at);
    }

    #endregion

    #region Getters

    /**
     * Returns a promotion bonus amount which was not spent yet
     *
     * @return float|int
     */
    public function getDiscount()
    {
        $sum = $this->promotion->amount;

        /** @var BonusHistory[] $bonuses */
        $bonuses = $this->alreadySpentBonuses->where('user_id', '=', $this->user_id);

        foreach ($bonuses as $apply) {
            $sum -= $apply->amount;
        }

        return $sum > 0
            ? $sum
            : 0;
    }

    /**
     * @return float|int
     */
    public function getAlreadySpent()
    {
        return $this->promotion->amount - $this->getDiscount();
    }

    #endregion
}
