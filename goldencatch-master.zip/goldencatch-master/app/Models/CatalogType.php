<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class CatalogType
 * This model doesn't use
 * @package App
 */
class CatalogType extends Model
{
    public $timestamps = false;
    protected $fillable = ['name'];
}
