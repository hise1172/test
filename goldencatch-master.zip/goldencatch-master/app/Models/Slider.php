<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

/**
 * Class Slider
 * @property string title
 * @property string sub_title
 * @property string photo
 * @property string photo_url
 * @property int weight
 * @property int is_active
 * @property string url
 * @package App\Models
 */
class Slider extends Model
{
    public $timestamps = false;
    protected $fillable = ['title', 'sub_title', 'photo', 'weight', 'is_active', 'url'];
    protected $appends = ['photo_url'];

    /**
     * @return string
     */
    public function getPhotoUrlAttribute()
    {
        return Storage::disk('slider')->url($this->photo);
    }
}
