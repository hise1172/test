<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

/**
 * Class Translate
 * @package App\Models
 */
class Translate extends Model
{
    const RU = 'ru';
    const UA = 'ua';

    public $timestamps = false;
    /**
     * @var string[]
     */
    protected $fillable = ['lang', 'name', 'value'];

    /**
     * @return MorphTo
     */
    public function translatable()
    {
        return $this->morphTo();
    }
}
