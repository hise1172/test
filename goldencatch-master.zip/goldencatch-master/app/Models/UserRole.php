<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Class UserRole
 * @package App
 *
 * @property int $id
 * @property string $name
 */
class UserRole extends Model
{
    const ROLE_ADMIN = 'admin';
    const ROLE_USER = 'user';
    const ROLE_EXPERT = 'expert';
    const ROLE_OPT = 'opt';
    const ROLE_OPT_5 = 'opt-5%';
    const ROLE_OPT_10 = 'opt-10%';
    const ROLE_OPT_15 = 'opt-15%';

    protected $fillable = ['name'];
    public $timestamps = false;

    /**
     * Users with current role
     * @return HasMany
     */
    public function users()
    {
        return $this->hasMany(User::class, 'user_role_id');
    }

    public function isAdmin()
    {
        return $this->attributes['name'] == self::ROLE_ADMIN;
    }

    public function isUser()
    {
        return $this->attributes['name'] == self::ROLE_USER;
    }

    public function isExpert()
    {
        return $this->attributes['name'] == self::ROLE_EXPERT;
    }

    /**
     * Returns TRUE, if a current role is a Reseller one
     *
     * @return bool
     */
    public function isReseller(): bool
    {
        return in_array($this->name, [
            self::ROLE_OPT,
            self::ROLE_OPT_5,
            self::ROLE_OPT_10,
            self::ROLE_OPT_15,
        ]);
    }
}
