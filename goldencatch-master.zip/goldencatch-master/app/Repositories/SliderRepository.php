<?php

namespace App\Repositories;

use App\Models\Slider;
use Illuminate\Support\Collection;

/**
 * Class SliderRepository
 * @package App\Repositories
 */
class SliderRepository extends BaseRepository
{
    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return Slider::class;
    }

    /**
     * @return Collection
     */
    public function getSliders()
    {
        return $this->model::where('is_active', true)->orderBy('weight', 'desc')->get();
    }

    /**
     * @return mixed
     */
    public function getDesktopSlider()
    {
        return $this->model::where('title', 'Desktop')->where('is_active', true)->get();
    }

    /**
     * @return mixed
     */
    public function getMobileSlider()
    {
        return $this->model::where('title', 'Mobile')->where('is_active', true)->get();
    }
}
