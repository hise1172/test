<?php

namespace App\Repositories;

use App\DTOs\Product\ProductFilterDTO;
use App\Helpers\FilterCreator;
use App\Helpers\TopProduct;
use App\Models\Product\Product;
use App\Models\Product\ProductOrder;
use App\Models\ProductsAttributesSlugValues;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Cache;

/**
 * Class ProductRepository
 * @property Product $model
 * @package App\Repositories
 * @method Product findById($id)
 */
class ProductRepository extends BaseRepository
{
    const TAXONOMY_BRAND = 'brand';
    const TAXONOMY_ATTR_SLUG_VALUE = 'attribute_slug_value';

    /**
     * Return filter query
     * @var FilterCreator
     */
    private $filterCreator;

    /**
     * ProductRepository constructor.
     * @param FilterCreator $filterCreator
     */
    public function __construct(FilterCreator $filterCreator)
    {
        parent::__construct();
        $this->filterCreator = $filterCreator;
    }

    /**
     * @return string
     */
    protected function getModelClassName()
    {
        return Product::class;
    }

    /**
     * Get product list with pagination
     * @param int $count
     * @param array $params
     * @return LengthAwarePaginator
     */
    public function getProductList($count = 10, $params = [])
    {
        return $this->model->with(['typesFishes', 'types', 'category', 'modifications',
            'brand', 'productAttribute', 'productAttribute.info'])
            ->paginate($count)->appends($params);
    }

    public function getFilteredProductSearch(ProductFilterDTO $filter, $take = 10, $skip = 0 , $count = false, $rows = 0)
    {
        $result = $this->model->with('modifications')
            ->where('SKU_parent', '=', '')
            ->orWhereNull('SKU_parent')
            ->when($filter->getSearch(), function ($q, $search) {
                $this->filterCreator->searchFilter($q, $search);
            });

        if($count) {
            return $result->count('id');
        }

        if ($skip && $rows) {
            $result->skip($skip)->take($rows - $skip);
        }

        if ($take) {
            $result->take( $take );
        }


        return $result->get();
    }

    /**
     * Get filtered product with pagination
     * @param ProductFilterDTO $filter
     * @param int $count
     * @param array $params
     * @return LengthAwarePaginator
     */
    public function getFilteredProductList(ProductFilterDTO $filter, $count = 10, $params = [],$paginate = true)
    {
        return $this->model->with(['modifications', 'typesFishes', 'types', 'category',
            'brand', 'productAttribute', 'productAttribute.info'])
            ->where('SKU_parent', '=', '')
            ->orWhereNull('SKU_parent')
            ->where('is_active', '=', 1)
            ->when($filter->getCategory(), function ($q, $category) {
                $this->filterCreator->categoryFilter($q, $category);
            })
            ->when($filter->getTypes(), function ($q, $types) {
                $this->filterCreator->typesFilter($q, $types);
            })
            ->when($filter->getBrand(), function ($q, $brands) {
                $this->filterCreator->brandsFilter($q, $brands);
            })
            ->when($filter->getTypeFishes(), function ($q, $typeFishes) {
                $this->filterCreator->typeFishes($q, $typeFishes);
            })
            ->when($filter->getSort(), function ($q, $sort) {
                $this->filterCreator->sortFilter($q, $sort);
            })
            ->when($filter->getPrice(), function ($q, $price) {
                $this->filterCreator->priceFilter($q, $price);
            })
            ->when($filter->getWeight(), function ($q, $weight) {
                $this->filterCreator->weightFilter($q, $weight);
            })->when($filter->getSearch(), function ($q, $search) {
                $this->filterCreator->searchFilter($q, $search);
            })
            ->paginate($count)->appends($params);
    }

    /**
     * Покупателям нравится
     * @return \Illuminate\Support\Collection
     */
    public function getTopBuysProduct()
    {
        $productsIds = TopProduct::getProductsIds();
        $products = $this->model->query()->whereIn('id', $productsIds)
            ->get()
            ->toBase()
            ->keyBy('id');
        return $productsIds->map(function ($key) use ($products) {
            return $products[$key];
        });
    }

    /**
     * Return new product
     *
     * @param \Illuminate\Support\Collection[] $filter_details
     *
     * @return Product[]|Collection
     */
    public function getNewProduct(array $filter_details = [])
    {
        $cache_key_suf = [];

        if (isset($filter_details[static::TAXONOMY_BRAND]) && $filter_details[static::TAXONOMY_BRAND]->isNotEmpty()) {
            $cache_key_suf[static::TAXONOMY_BRAND] = static::TAXONOMY_BRAND . '.' . implode('.', $filter_details[static::TAXONOMY_BRAND]->toArray());
        }

        if (isset($filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]) && $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->isNotEmpty()) {
            $cache_key_suf[static::TAXONOMY_ATTR_SLUG_VALUE] = static::TAXONOMY_ATTR_SLUG_VALUE . '.' . implode('.', $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->toArray());
        }

        $cache_key = 'ProductRepositoryGetNewProduct' . implode('.', $cache_key_suf);

        $products = Cache::get($cache_key, []);

        if ($products) {
            return $products;
        }

        $products = $this->getAllNewProducts(static::filterProductByTaxonomy((bool) $cache_key_suf, $filter_details));

        return Cache::remember(
            $cache_key,
            86400, // 1 day
            function () use ($products) { return $products; }
        );
    }

    /**
     * @param callable|null $callback
     *
     * @return Builder[]|Product[]|Collection
     */
    private function getAllNewProducts(callable $callback = null)
    {
        $newUniqueModifications = $this->model::select(['parent_id', 'created_at'])
            ->where('status', Product::STATUS_IN_STOCK)
            ->where('stock', '>', 0)
            ->whereNotNull('parent_id')
            ->where('photo', '!=', '')
            ->limit(20)
            ->orderBy('created_at', 'DESC')
            ->groupBy('created_at')
            ->groupBy('parent_id');

        $newUniqueProducts = $this->model::where('status', Product::STATUS_IN_STOCK)
            ->where('stock', '>', 0)
            ->whereNull('parent_id')
            ->where('photo', '!=', '')
            ->limit(20)
            ->orderBy('created_at', 'DESC');

        if ($callback) {
            $callback($newUniqueProducts);
            $callback($newUniqueModifications);
        }

        $newUniqueModifications = $newUniqueModifications->get()
            ->pluck('parent_id')
            ->toArray();

        $newUniqueProducts = $newUniqueProducts->get()
            ->pluck('id')
            ->toArray();

        $productIds = array_merge($newUniqueProducts, $newUniqueModifications);

        return $this->model::with('modifications')
            ->whereIn('id', $productIds)
            ->limit(20)
            ->orderBy('created_at', 'DESC')
            ->get();
    }

    /**
     * Get best selling products of the last week
     *
     * @param \Illuminate\Support\Collection[] $filter_details
     *
     * @return Builder[]|Collection
     */
    public function getBestSelling(array $filter_details = [])
    {
        $cache_key_suf = [];

        if (isset($filter_details[static::TAXONOMY_BRAND]) && $filter_details[static::TAXONOMY_BRAND]->isNotEmpty()) {
            $cache_key_suf[static::TAXONOMY_BRAND] = static::TAXONOMY_BRAND . '.' . implode('.', $filter_details[static::TAXONOMY_BRAND]->toArray());
        }

        if (isset($filter_details[static::TAXONOMY_ATTR_SLUG_VALUE])  && $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->isNotEmpty()) {
            $cache_key_suf[static::TAXONOMY_ATTR_SLUG_VALUE] = static::TAXONOMY_ATTR_SLUG_VALUE . '.' . implode('.', $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->toArray());
        }

        $cache_key = 'ProductRepositoryGetBestSelling' . implode('.', $cache_key_suf);

        $products = Cache::get($cache_key, []);

        if ($products) {
            return $products;
        }

        /** @var Builder $best_selling_products */
        $best_selling_products = $this->getAllBestSelling(static::filterProductByTaxonomy((bool) $cache_key_suf, $filter_details));

        if (!$best_selling_products) {
            return collect();
        }

        return Cache::remember(
            $cache_key,
            86400, // 1 day
            function () use ($best_selling_products) { return $best_selling_products; }
        );
    }

    /**
     * @param callable|null $callback
     *
     * @return Product[]|Collection|null
     */
    private function getAllBestSelling(callable $callback = null)
    {
        $products = ProductOrder::selectRaw("SUM(count) as sumcount, product_id")
            ->with('product')
            ->whereHas('order', function ($query) {
                $query->whereDate('created_at', '>=', \Carbon\Carbon::today()->subMonth());
            })
            ->groupBy('product_id')
            ->get();

        if( $products->isEmpty() ){
            return null;
        }

        $uniqProducts = [];

        foreach ($products as $orderedProduct) {
            $product_id = (NULL == $orderedProduct->product->parent_id) ? $orderedProduct->product_id : $orderedProduct->product->parent_id;
            $uniqProducts[$product_id] = ( isset( $uniqProducts[$product_id] ) ? $uniqProducts[$product_id] : 0 ) + $orderedProduct->sumcount;
        }

        $productIds = collect($uniqProducts)->sort()->reverse()->keys()->take(200);

        $query = $this->model::with('modifications')
            ->whereIn('id', $productIds)
            ->where('status', Product::STATUS_IN_STOCK)
            ->orderByRaw('FIELD(id, ' . $productIds->implode(',') . ')')
            ->limit(20);

        if ($callback) {
            $callback($query);
        }

        return $query->get();
    }

    /**
     * Get waiting product
     * @return Builder[]|Collection
     */
    public function getWaitProduct()
    {
        return $this->model::with('modifications')
            ->whereNull('SKU_parent')
            ->where('status', Product::STATUS_WAITING)
            ->whereNotNull('date_arrival')
            ->orderBy('date_arrival')
            ->limit(20)
            ->get();
    }

    /**
     * @param $search_string
     * @return mixed
     */
    public function seacrh($search_string)
    {
        return Product::where('name', 'like', "%{$search_string}%")->get();
    }

    public function getProductPrice($product_id)
    {
        $product = Product::find($product_id);
        return $product->price;
    }

    /**
     * Get product by id with relation
     * @param $product_id
     * @return Product
     */
    public function getProductById($product_id)
    {
        $relations = [
            'typesFishes', 'types', 'category', 'modifications',
            'brand', 'photos', 'videoReviews', 'productAttribute',
            'reviews', 'reviews.attaches', 'reviews.user', 'questions',
            'questions.question', 'questions.answers', 'questions.user','seoProduct',
            'attrTextValues', 'attrNumericValues', 'attrSlugValues',
        ];
        return $this->model::with($relations)->find($product_id);


    }

    /**
     * @param ProductFilterDTO $filter
     * @return array
     */
    public function getCustomFilters(ProductFilterDTO $filter)
    {
        return $this->model->with(['modifications', 'typesFishes', 'types', 'category',
        'brand', 'productAttribute', 'productAttribute.info'])
        ->where('SKU_parent', '=', '')
        ->orWhereNull('SKU_parent')
        ->where('is_active', '=', 1)
        ->when($filter->getCategory(), function ($q, $category) {
            $this->filterCreator->categoryFilter($q, $category);
        })
        ->when($filter->getTypes(), function ($q, $types) {
            $this->filterCreator->typesFilter($q, $types);
        })
        ->when($filter->getBrand(), function ($q, $brands) {
            $this->filterCreator->brandsFilter($q, $brands);
        })
        ->when($filter->getTypeFishes(), function ($q, $typeFishes) {
            $this->filterCreator->typeFishes($q, $typeFishes);
        })
        ->when($filter->getSort(), function ($q, $sort) {
            $this->filterCreator->sortFilter($q, $sort);
        })
        ->when($filter->getPrice(), function ($q, $price) {
            $this->filterCreator->priceFilter($q, $price);
        })
        ->when($filter->getWeight(), function ($q, $weight) {
            $this->filterCreator->weightFilter($q, $weight);
        })->when($filter->getSearch(), function ($q, $search) {
            $this->filterCreator->searchFilter($q, $search);
        })->pluck('id')->toArray();

    }

    #region Helpers

    /**
     * @param bool $has_filter
     * @param \Illuminate\Support\Collection[] $filter_details
     *
     * @return \Closure|null
     */
    private static function filterProductByTaxonomy(bool $has_filter, $filter_details)
    {
        if (!$has_filter) {
            return null;
        }

        return function (Builder $query) use ($filter_details) {

            $query->where(function (Builder $query) use ($filter_details) {
                if (isset($filter_details[static::TAXONOMY_BRAND]) && $filter_details[static::TAXONOMY_BRAND]->isNotEmpty()) {
                    $query->orWhereIn('brand_id', $filter_details[static::TAXONOMY_BRAND]->toArray());
                }

                if (isset($filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]) && $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->isNotEmpty()) {
                    $product_ids = ProductsAttributesSlugValues::query()
                        ->select('product_id')
                        ->whereIn('attribute_slug_value_id', $filter_details[static::TAXONOMY_ATTR_SLUG_VALUE]->toArray());

                    $query->orWhereIn('id', $product_ids);
                }
            });
        };
    }

    #endregion

    public static function getNextProductBySku(Product $product){

        return Product::
              where('is_active', true)
            ->where('SKU', '>', $product->SKU + 0)
            ->orderByRaw('SKU * 1 asc') 
            ->limit(1)
            ->first();
    }

    public static function getPreviousProductBySku(Product $product){

        return Product::
              where('is_active', true)
            ->where('SKU', '<', $product->SKU + 0)
            ->orderByRaw('SKU * 1 desc') 
            ->limit(1)
            ->first();
    }
}
