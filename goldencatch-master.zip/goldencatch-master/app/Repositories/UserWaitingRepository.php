<?php

namespace App\Repositories;

use App\Models\UserWaiting;
use Illuminate\Support\Collection;

/**
 * Class UserWaitingRepository
 * @package App\Repositories
 */
class UserWaitingRepository extends BaseRepository
{

    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return UserWaiting::class;
    }

    /**
     * @param $product_id
     * @return Collection
     */
    public function getUsersId($product_id)
    {
        return $this->model::query()
            ->select('user_id')
            ->where('product_id', $product_id)
            ->pluck('user_id');
    }

    /**
     * Delete user's waiting product when product change state
     * @param $id
     * @param array|Collection $usersId
     * @return int
     */
    public function deleteWaitingProduct($id, $usersId)
    {
        return $this->model::query()
            ->where('product_id', $id)
            ->whereIn('user_id', $usersId)
            ->delete();
    }

    /**
     * @param $data
     * @return int
     */
    public function deleteUserProduct($data)
    {
        return $this->model::where($data)->delete();
    }

    public function addUserProduct($data)
    {
        $this->model::query()->updateOrCreate($data);
        return $this->model::where('user_id', $data['user_id'])->count();
    }
}
