<?php

namespace App\Repositories;

use App\Models\Category;

/**
 * Class CategoryRepository
 * @package App\Repositories
 */
class CategoryRepository extends BaseRepository
{
    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return Category::class;
    }
}
