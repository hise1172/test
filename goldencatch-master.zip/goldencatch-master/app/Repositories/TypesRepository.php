<?php

namespace App\Repositories;

use App\Models\Types;

class TypesRepository extends BaseRepository
{

    protected function getModelClassName()
    {
        return Types::class;
    }
}
