<?php

namespace App\Repositories;

use App\Mail\VerifyMail;
use App\Models\UserRole;
use App\Models\VerifyUser;
use App\Rules\Phone;
use App\Services\ApplyPromotion;
use App\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use Laravel\Socialite\Two\User as SocUser;

/**
 * Class UserRepository
 * @package App\Repositories
 */
class UserRepository extends BaseRepository
{

    protected function getModelClassName()
    {
        return User::class;
    }

    /**
     * @param array|Collection $ids
     * @return Collection
     */
    public function getUserByIds($ids)
    {
        return $this->model::query()
            ->whereIn('id', $ids)
            ->whereNotNull('email')
            ->get();
    }

    /**
     * @param array $data
     * [
     *      'name' => string, // mandatory
     *      'surname' => string, // mandatory
     *      'telephone' => string, // mandatory
     *      'email' => string // optional
     *      ...
     * ]
     * @param bool $inform_user
     *
     * @return User
     */
    public function register(array $data, bool $inform_user = true)
    {
        if ($inform_user && empty($data['email'])) {
            $inform_user = false;

            $data['email'] =  trim($data['telephone'], '+') . '@net.net';
        }

        $data['user_role_id'] = UserRole::where('name', UserRole::ROLE_USER)
            ->first()
            ->id;

        if (!empty($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        }

        DB::beginTransaction();

        $user = $this->create($data);

        VerifyUser::updateOrCreate(['user_id' => $user->id, 'token' => Str::random(60)]);

        ApplyPromotion::onRegistration($user);

        DB::commit();

        $inform_user && Mail::to($user->email)->send(new VerifyMail($user));

        return $user;
    }

    /**
     * @param $telephone
     * @param $email
     *
     * @return User|null
     */
    public function getByLogin($telephone = '', $email = ''): ?User
    {
        $phone = Phone::Normalise($telephone);

        $db = $this->model::query();

        if ($phone) {
            $db->orWhere('telephone', $phone);
        }

        if ($email) {
            $db->orWhere('email', $email);
        }

        if (!$db->count()) {
            return null;
        }

        foreach ($db->get() as $user) {
            /** @var User $user */

            if ($phone != $user->telephone) {
                continue;
            }

            return $user;
        }

        return $db->first();
    }

    /**
     * Get user info by service
     *
     * @param SocUser $user
     * @param string $service
     *
     * @return array
     */
    public function getUserParameters(SocUser $user, string $service)
    {
        $service_id = $service . '_id';
        $name_data = explode(' ', $user->getName(), 2);

        return [
            $service_id => $user->getId(),
            'name' => $name_data[0] ?? '',
            'surname' => $name_data[1] ?? '',
            'email' => $user->getEmail(),
            'email_verified_at' => now(),
            'user_role_id' => UserRole::where('name', UserRole::ROLE_USER)->first()->id,
            'avatar' => $user->getAvatar(),
        ];
    }

    /**
     * Get user by auth service
     * @param string $driver
     * @return User|null
     */
    public function getUser(string $driver)
    {
        try {
            return Socialite::driver($driver)->user();
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }

        return null;
    }
}
