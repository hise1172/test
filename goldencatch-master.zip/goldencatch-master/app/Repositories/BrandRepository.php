<?php

namespace App\Repositories;

use App\Models\Brand;

/**
 * Class BrandRepository
 * @package App\Repositories
 */
class BrandRepository extends BaseRepository
{

    protected function getModelClassName()
    {
        return Brand::class;
    }
}
