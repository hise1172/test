<?php


namespace App\Repositories;

use Highlight\Mode;
use Illuminate\Database\Eloquent\Model;

/**
 * Class BaseRepository
 * @property Model $model
 * @package App\Repositories
 */
abstract class BaseRepository
{
    /**
     * @var array
     */
    protected $with = [];
    /**
     * @var Model
     */
    protected $model;

    /**
     * @return mixed
     */
    abstract protected function getModelClassName();

    /**
     * BaseRepository constructor.
     */
    public function __construct()
    {
        $this->model = resolve($this->getModelClassName());
    }

    /**
     * @return mixed
     */
    final public function all()
    {
        return $this->model::all();
    }

    /**
     * @param $id
     * @return Model
     */
    final public function findById($id)
    {
        return $this->model->with($this->with)->findOrFail($id);
    }

    /**
     * @param $data
     * @return mixed
     */
    final public function create($data)
    {
        return $this->model::create($data);
    }

    /**
     * @param $id
     * @param $data
     * @return bool
     */
    final public function update($id, $data)
    {
        return $this->findById($id)->update($data);
    }

    /**
     * @param $id
     * @return int
     */
    final public function delete($id)
    {
        return $this->model->destroy($id);
    }

    public function where($key, $value, $operator = '=')
    {
        return $this->model->where($key, $operator, $value);
    }

    public function whereLike($key, $value, $pattern = '\%%s\%')
    {
        return $this->model->where($key, 'like', sprintf($pattern, $value));
    }

    public function whereGet($key, $value, $operator = '=')
    {
        return $this->where($key, $value, $operator)->get();
    }

    /**
     * @param $key
     * @param $value
     * @param string $operator
     * @return Model
     */
    public function whereFirst($key, $value, $operator = '=')
    {
        return $this->where($key, $value, $operator)->first();
    }

    final public function setRelations($relations)
    {
        if (!is_array($relations)) {
            $this->with = [$relations];
        } else {
            $this->with = $relations;
        }
        return $this;
    }

    public function whereIn($ids)
    {
        return $this->model::with($this->with)->whereIn('id', $ids)->get();
    }
}
