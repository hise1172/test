<?php

namespace App\Repositories;


use App\Models\Story;


/**
 * Class SliderRepository
 * @package App\Repositories
 */
class StoriesRepository extends BaseRepository
{
    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return Story::class;
    }

    /**
     * @return mixed
     */
    public function getStories()
    {
        return $this->model->where('active', 1)->orderBy('order')->get();
    }

}
