<?php

namespace App\Repositories;

use App\Models\Product\Product;
use App\Models\ProductFavorite;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

/**
 * Class ProductFavoriteRepository
 * @package App\Repositories
 */
class ProductFavoriteRepository extends BaseRepository
{
    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return ProductFavorite::class;
    }

    /**
     * Добавить продукт в избранное или обновить его
     * Вернется количество избранного у пользователя
     *
     * @param int $product_id
     * @return int
     */
    public function add(int $product_id)
    {
        if (!Auth::check()) {
            $list = $this->getFromSession();

            Session::put(ProductFavorite::class, array_merge($list, array_diff([$product_id], $list)));

            return $this->getCountFavorite();
        }

        $data = ['user_id' => Auth::id(), 'product_id' => $product_id];
        $this->model::updateOrCreate($data, $data);

        return $this->getCountFavorite(Auth::id());
    }

    /**
     * Удалить из избранного у пользователя
     * Вернется количествого избранноо у пользователя
     *
     * @param int $product_id
     * @return int
     */
    public function remove(int $product_id)
    {
        if (!Auth::check()) {
            Session::put(ProductFavorite::class, array_diff($this->getFromSession(), [$product_id]));

            return $this->getCountFavorite();
        }

        $data = ['user_id' => Auth::id(), 'product_id' => $product_id];
        $this->model::where($data)->delete();

        return $this->getCountFavorite(Auth::id());
    }

    /**
     * Количество избранного по user.id
     *
     * @param null|int $user_id
     * @return int
     */
    public function getCountFavorite($user_id = null)
    {
        if ($user_id === null) {
            return count($this->getFromSession());
        }

        return $this->model::where(compact('user_id'))->count();
    }

    /**
     * @param int $user_id
     * @return Builder
     */
    public function getUserFavorites(int $user_id = null)
    {
        $product_ids = $user_id === null
            ? $this->getFromSession()
            : ProductFavorite::select('product_id')
                ->where(compact('user_id'))
                ->toBase()
                ->get()
                ->pluck('product_id');

        return Product::with('modifications')
            ->whereIn('id', $product_ids);
    }

    /**
     * Returns favorites from session
     *
     * @return []
     */
    public function getFromSession()
    {
        return Session::get(ProductFavorite::class, []);
    }
}
