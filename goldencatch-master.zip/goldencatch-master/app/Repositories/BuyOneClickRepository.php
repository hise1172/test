<?php

namespace App\Repositories;

use App\Models\BuyOneClick;

class  BuyOneClickRepository extends BaseRepository
{
    public function __construct()
    {
        parent::__construct();

        deprecated(BuyOneClick::class);
    }

    protected function getModelClassName()
    {
        return BuyOneClick::class;
    }
}
