<?php

namespace App\Repositories;

use App\Models\TypeFishes;

class TypeFishesRepository extends BaseRepository
{

    protected function getModelClassName()
    {
        return TypeFishes::class;
    }
}
