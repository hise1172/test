<?php

namespace App\Repositories;

use App\Models\SubscribeEmail;

class UserSubscribeRepository extends BaseRepository
{

    protected function getModelClassName()
    {
        return SubscribeEmail::class;
    }

    public function subscribe(string $email, int $user_id = null)
    {
        if (empty($user_id)) {
            SubscribeEmail::updateOrCreate(
                ['email' => $email],
                ['active' => true]
            );
        } else {
            SubscribeEmail::updateOrCreate(
                ['email' => $email],
                [
                    'user_id' => $user_id,
                    'active' => true
                ]
            );
        }
    }

    public function unsubscribe(string $email, int $user_id = null)
    {
        if (!empty($user_id)) {
            $subscribe = $this->whereFirst('user_id', $user_id);
        } else {
            $subscribe = $this->whereFirst('email', $email);
        }
        if ($subscribe) {
            $subscribe->update(['active' => false]);
        }
    }
}
