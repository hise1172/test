<?php

namespace App\Repositories;

use App\Models\UserProductReview;

/**
 * Class ProductReviewRepository
 * @package App\Repositories
 * @method UserProductReview create($data)
 */
class ProductReviewRepository extends BaseRepository
{

    /**
     * @return mixed|string
     */
    protected function getModelClassName()
    {
        return UserProductReview::class;
    }

    public function paginate($user_id, $count = 5)
    {
        return $this->model->where('user_id', $user_id)->latest()->paginate($count);
    }

}
