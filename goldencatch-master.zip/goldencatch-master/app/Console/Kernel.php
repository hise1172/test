<?php

namespace App\Console;

use App\Helpers\TopProduct;
use App\Jobs\SitemapGenerate;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')->hourly();
        $schedule->call(function (){
           TopProduct::clear();
        });
        $schedule->call(function () {
            TopProduct::clear();
        })->dailyAt('00:00');
        $schedule->call(function () {
            new SitemapGenerate();
        })->dailyAt('01:00');

        $schedule
            ->command('novaposhta:area')
            ->weeklyOn(1, '5:00');

        $schedule
            ->command('novaposhta:cities')
            ->weeklyOn(1, '5:02');

        $schedule
            ->command('novaposhta:warehouses')
            ->weeklyOn(1, '5:07');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
