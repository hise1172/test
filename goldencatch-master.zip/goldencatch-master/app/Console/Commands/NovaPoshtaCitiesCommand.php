<?php

namespace App\Console\Commands;

use App\Models\NovaPoshta\NovaPoshtaCities;
use App\Services\NovaPoshtaService;

class NovaPoshtaCitiesCommand extends NovaPoshtaAreaCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'novaposhta:cities';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Novaposhta update cities';

    /** @var NovaPoshtaCities|string  */
    protected $model_class = NovaPoshtaCities::class;

    #region Getters

    /**
     * @param NovaPoshtaService $service
     *
     * @return array
     */
    protected function getDataFormApi(NovaPoshtaService $service): array
    {
        return $service->getCities();
    }

    /**
     * @return array
     */
    protected function getFieldsMapping(): array
    {
        return [
            'Description' => 'description',
            'DescriptionRu' => 'description_ru',
            'Ref' => 'ref',
            'Delivery1' => 'delivery1',
            'Delivery2' => 'delivery2',
            'Delivery3' => 'delivery3',
            'Delivery4' => 'delivery4',
            'Delivery5' => 'delivery5',
            'Delivery6' => 'delivery6',
            'Delivery7' => 'delivery7',
            'Area' => 'area',
            'SettlementType' => 'settlement_type',
            'IsBranch' => 'is_branch',
            'PreventEntryNewStreetsUser' => 'prevent_entry_new_streets_user',
            'CityID' => 'city_id',
            'SettlementTypeDescription' => 'settlement_type_description',
            'SettlementTypeDescriptionRu' => 'settlement_type_description_ru',
            'SpecialCashCheck' => 'special_cash_check',
            'AreaDescription' => 'area_description',
            'AreaDescriptionRu' => 'area_description_ru',
        ];
    }

    #endregion
}
