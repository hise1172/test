<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\App;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

use App\Models\Product\Product;
use App\Models\Category;

use Spatie\ArrayToXml\ArrayToXml;

class GenerateRozetkaFeed extends Command
{
    protected $signature = 'feed:rozetka';

    protected $description = 'Generate rozetka feed for Inquisitors';

    private $oldProducts;

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $logger = Log::channel('importLog');
        App::setLocale('ru');
        $categories_array = [];
        $products_array = [];
        $time = Carbon::now();

        $this->getOldProducts();

        $brandsArray = $this->getIdBrands();

        $products = Product::whereNotNull('price')
            ->when($brandsArray, function ($query, $brandsArray) {
                return $query->whereIn('brand_id', $brandsArray);
            })
            ->where('stock', '>', 0)
            ->get();

        // ray(count($products));


        $categories = Category::get();

        foreach ($categories as $category) {
            array_push($categories_array, [
                [
                    '_attributes' => [
                        'id' => $category->id
                    ],
                    '_value' => $category->name
                ]
            ]);
        }

        foreach ($products as $key => $product) {

            $attributes = $product->desc_attr;

            if( $product->parent_id ){
                $attributes = array_merge ( $attributes, $product->parentProduct->desc_attr);
            }

            // ray( array_merge ($product->desc_attr, $product->parentProduct->desc_attr) );

            $products_array[$key] = [
                '_attributes' => [
                    'id' => $this->generateId( $product->id, $product->name ),
                    'available' => $product->stock ? "true" : "false"
                ],
                'price' => $product->price,
                'currencyId' => 'UAH',
                'categoryId' => $product->category_id,
                'picture' => str_replace('http://goldencatch.test', 'https://goldencatch.com.ua', $product->photo),
                'name' => [
                    '_cdata' => $product->name
                ],
                // 'article' => $product->SKU,
                'vendor' => $product->brand_name ?? '',
                'stock_quantity' => $product->stock,
                'description' => [
                    '_cdata' => $product->short_description ? $product->short_description . PHP_EOL : "" . $product->description
                ],
                'param' => [
                    "_attributes" => [
                        "name" => "Артикул"
                    ],
                    "_value" => $product->SKU
                ],
            ];

            // добавляем атрибуты
            $attr_index = 0;
            foreach ( $attributes as $attr_name => $attr_value) {
                $attr_index++;
                $products_array[$key]['param_delete_' . $attr_index] = [
                    "_attributes" => [
                        "name" => $attr_name
                    ],
                    '_cdata' =>  implode(',', $attr_value )
                ];
            }
        }

        $array = [
            'shop' => [
                'name' => 'Golden Catch',
                'company' => 'Golden Catch',
                'url' => 'https://goldencatch.ua',
                'currencies' => [
                    'currency' => [
                        "_attributes" => [
                            "id" => "UAH",
                            "rate" => "1",
                        ],
                    ],
                ],
                'categories' => [
                    'category' => $categories_array
                ],
                'offers' => [
                    'offer' => $products_array
                ]
            ]
        ];

        $arrayToXml = new ArrayToXml($array, [
            'rootElementName' => 'yml_catalog',
            '_attributes' => [
                'date' => $time->toDateTimeString(),
            ],
        ], true, 'UTF-8');

        $arrayToXml->setDomProperties(['formatOutput' => true]);
        $temp_result = $arrayToXml->prettify()->toXml();
        $result = preg_replace('/_delete_\d/', '', $temp_result);

        Storage::disk('public')->put('feed/rozekta-54235rex4.xml', $result);
        $logger->info("ROZETKA feed generated");
    }

    function generateId( $id, $name )
    {
        $oldProduct = $this->oldProducts->firstWhere('name', trim($name) );
        if( $oldProduct && isset($oldProduct['id']) && $oldProduct['id'] ){
            return $oldProduct['id'];
        }
        $oldProduct = $this->oldProducts->firstWhere('id', $id );
        if( $oldProduct && isset($oldProduct['id']) && $oldProduct['id'] ){
            return 'g'. $id;
        }

        return $id;
    }

    function getIdBrands()
    {
        $brands = config('marketplaces.rozetka.import.brands');
        if( is_array($brands) ){
            return $brands;
        }
        elseif( strpos($brands, ',') !== FALSE ){
            // return array from string (ex. 1,3,20,50,304)
            return explode(',', $brands);
        }
        // return if only single int ID
        return [$brands];
    }

    function getOldProducts()
    {
        $csv = Storage::disk('local')->get('rozetka_do_not_delete_file.csv');
        $this->oldProducts = [];
        $csv = array_map(function($row) {
            if( ! $row ){
                return ;
            }
            $data = str_getcsv($row, ';') ;
            $this->oldProducts[] = [
                'id' => $data[0],
                'name' => trim($data[1]),
            ];
        }, explode("\n", $csv));
        $this->oldProducts = collect($this->oldProducts);
    }
}
