<?php

namespace App\Console\Commands;

use App\Models\Product\ProductTranslate;
use App\Helpers\FileUploaded;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product\Product;
use App\Models\TypeFishes;
use App\Models\Types;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class ProductUaImportCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:import-ua';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $file = fopen('goldencatch.com.ua_CSV_UA.csv', 'r');
        if (!$file) {
            return -1;
        }
        $attributeMap = [];
        $index = 0;
        while (!feof($file) && ($line = fgetcsv($file, 0, ',', '"'))) {
            if (empty($attributeMap)) {
                foreach ($line as $key => $value) {
                    $attributeMap[$value] = $key;
                }
                continue;
            }
            if (empty($line[$attributeMap['SKU']]) || empty($line[$attributeMap['name']])) {
                Log::warning("============================");
                Log::warning("not imported on row: [" . ($index + 1) . "] percents: [" . round(($index / 29526) * 100, 2) . '% ]| SKU: ' . $line[0]);
                Log::warning('is empty SKU: ' . (empty($line[$attributeMap['SKU']]) ? 'true' : 'false'));
                Log::warning('is empty name: ' . (empty($line[$attributeMap['name']]) ? 'true' : 'false'));
                Log::warning("============================");
                continue;
            }
            try {
                $attributes = [];
                $attributes['SKU'] = $line[$attributeMap['SKU']];
                $attributes['name'] = $line[$attributeMap['name']];
                $attributes['lang'] = 'ua';
                $attributes['description'] = $line[$attributeMap['description_long']];
                $attributes['short_description'] = $line[$attributeMap['description_short']];

                ProductTranslate::updateOrCreate(['SKU' => $attributes['SKU']], $attributes);
                $index++;
                Log::info("row: [" . ($index + 1) . "] percents: [" . round(($index / 29526) * 100, 2) . '% ]| SKU: ' . $line[0]);
            } catch (\Exception $exception) {
                Log::debug($line);
                Log::debug($exception);
                Log::error($exception->getMessage());
            }
        }
        return 0;
    }
}
