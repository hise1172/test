<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level2Page;
use App\Models\AttributeSlugValue;
use App\Services\Catalog\Filtration\Filter;

/**
 * @property AttributeSlugValue item2
 */
class CategorySlugAttributePage extends Level2Page
{
    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => $this->item2->attribute->filter_slug,
                'position' => $this->item2->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                'values' => [$this->item2->slug],
            ],
        ];
    }
}
