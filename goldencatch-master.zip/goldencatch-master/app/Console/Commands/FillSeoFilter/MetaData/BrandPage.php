<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level1Page;
use App\Models\Brand;

/**
 * @property Brand item1
 */
class BrandPage extends Level1Page
{
    /**
     * @inheritDoc
     */
    protected function getConcatenatableList(): array
    {
        return [$this->item1];
    }

    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => 'brand',
                'position' => 1,
                'values' => [$this->item1->slug],
            ],
        ];
    }
}
