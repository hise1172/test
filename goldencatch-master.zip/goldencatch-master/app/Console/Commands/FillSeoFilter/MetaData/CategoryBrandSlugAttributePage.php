<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level3Page;
use App\Models\Brand;
use App\Models\SeoFilters;
use App\Services\Catalog\Filtration\Filter;

/**
 * @property Brand item2
 */
class CategoryBrandSlugAttributePage extends Level3Page
{
    /**
     * @inheritDoc
     */
    protected function getStep() : int
    {
        return SeoFilters::STEP_3;
    }

    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => 'brand',
                'position' => 1,
                'values' => [$this->item2->slug],
            ],
            [
                'slug' => $this->item3->attribute->filter_slug,
                'position' => $this->item3->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                'values' => [$this->item3->slug],
            ],
        ];
    }
}
