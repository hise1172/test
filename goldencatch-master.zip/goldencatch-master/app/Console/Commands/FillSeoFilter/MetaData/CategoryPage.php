<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level1Page;
use App\Models\Category;
use App\Models\SemanticRule;
use App\Services\Catalog\Repository;

/**
 * @property Category item1
 */
class CategoryPage extends Level1Page
{
    /**
     * @inheritDoc
     */
    protected function getConcatenatableList(): array
    {
        $data = [];

        if ($this->item1->semanticRule && $this->item1->semanticRule->includes_fishing_words === SemanticRule::INCLUDES_TYPE_BEFORE) {
            $data[] = static::buildConcatenatable('seo.includes_fishing_words.before', $this->item1);
        }

        $data[] = $this->item1;

        if ($this->item1->semanticRule && $this->item1->semanticRule->includes_fishing_words === SemanticRule::INCLUDES_TYPE_AFTER) {
            $data[] = static::buildConcatenatable('seo.includes_fishing_words.after', $this->item1);
        }

        return $data;
    }

    /**
     * @inheritDoc
     */
    protected function prepareCatalog(Repository $catalog)
    {
        $catalog->setCategoryId($this->item1->id);
    }
}
