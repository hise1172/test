<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level1Page;
use App\Models\AttributeSlugValue;
use App\Services\Catalog\Filtration\Filter;

/**
 * @property AttributeSlugValue item1
 */
class SlugAttributePage extends Level1Page
{
    /**
     * @inheritDoc
     */
    protected function getConcatenatableList(): array
    {
        return [
            static::buildConcatenatable('seo.slug_attribute_prefix', $this->item1),
            $this->item1,
        ];
    }

    /**
     * @inheritDoc
     */
    public static function getNeededSlugs()
    {
        return [
            'fishes',
        ];
    }

    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => $this->item1->attribute->filter_slug,
                'position' => $this->item1->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                'values' => [$this->item1->slug],
            ],
        ];
    }
}
