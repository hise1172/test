<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level3Page;
use App\Models\AttributeSlugValue;
use App\Models\SeoFilters;
use App\Services\Catalog\Filtration\Filter;

/**
 * @property AttributeSlugValue item2
 */
class Category2SlugAttributesPage extends Level3Page
{
    /**
     * @inheritDoc
     */
    protected function getStep() : int
    {
        return SeoFilters::STEP_4;
    }

    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => $this->item2->attribute->filter_slug,
                'position' => $this->item2->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                'values' => [$this->item2->slug],
            ],
            [
                'slug' => $this->item3->attribute->filter_slug,
                'position' => $this->item3->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                'values' => [$this->item3->slug],
            ],
        ];
    }
}
