<?php

namespace App\Console\Commands\FillSeoFilter\MetaData\DataObject;

use App\DataContainers\AbstractDataContainer;

/**
 * @property string string
 * @property int position
 */
class Concatenatable extends AbstractDataContainer
{

}
