<?php

namespace App\Console\Commands\FillSeoFilter\MetaData\DataObject;


use App\DataContainers\AbstractDataContainer;

/**
 * @property string filter_key
 * @property int item1_id
 * @property int item2_id
 * @property int item3_id
 * @property int products
 */
class ItemsData extends AbstractDataContainer
{

}
