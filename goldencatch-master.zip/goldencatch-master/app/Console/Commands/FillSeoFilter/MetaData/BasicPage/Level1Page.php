<?php

namespace App\Console\Commands\FillSeoFilter\MetaData\BasicPage;

use App\Console\Commands\FillSeoFilter\MetaData;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Models\SeoFilters;

/**
 * @property Category|Brand|AttributeSlugValue item1
 */
abstract class Level1Page extends MetaData
{
    /**
     * @inheritDoc
     */
    protected function getStep() : int
    {
        return SeoFilters::STEP_1;
    }
}
