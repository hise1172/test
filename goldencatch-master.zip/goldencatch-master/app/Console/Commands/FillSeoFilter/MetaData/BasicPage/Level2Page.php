<?php

namespace App\Console\Commands\FillSeoFilter\MetaData\BasicPage;

use App\Console\Commands\FillSeoFilter\MetaData;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Models\SeoFilters;
use App\Services\Catalog\Repository;

/**
 * @property Category item1
 * @property AttributeSlugValue|Brand item2
 */
abstract class Level2Page extends MetaData
{
    /**
     * @inheritDoc
     */
    protected function getStep() : int
    {
        return SeoFilters::STEP_2;
    }

    /**
     * @inheritDoc
     */
    protected function getConcatenatableList(): array
    {
        return [$this->item1, $this->item2];
    }

    /**
     * @inheritDoc
     */
    protected function prepareCatalog(Repository $catalog)
    {
        $catalog->setCategoryId($this->item1->id);
    }
}
