<?php

namespace App\Console\Commands\FillSeoFilter\MetaData\BasicPage;

use App\Console\Commands\FillSeoFilter\MetaData;
use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Services\Catalog\Repository;

/**
 * @property Category item1
 * @property object item2
 * @property AttributeSlugValue item3
 */
abstract class Level3Page extends MetaData
{
    /**
     * @inheritDoc
     */
    protected function getConcatenatableList(): array
    {
        return [$this->item1, $this->item2, $this->item3];
    }

    /**
     * @inheritDoc
     */
    protected function prepareCatalog(Repository $catalog)
    {
        $catalog->setCategoryId($this->item1->id);
    }
}
