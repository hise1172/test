<?php

namespace App\Console\Commands\FillSeoFilter\MetaData;

use App\Console\Commands\FillSeoFilter\MetaData\BasicPage\Level2Page;
use App\Models\Brand;

/**
 * @property Brand item2
 */
class CategoryBrandPage extends Level2Page
{
    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        return [
            [
                'slug' => 'brand',
                'position' => 1,
                'values' => [$this->item2->slug],
            ],
        ];
    }
}
