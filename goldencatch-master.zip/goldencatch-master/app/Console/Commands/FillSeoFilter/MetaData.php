<?php

namespace App\Console\Commands\FillSeoFilter;

use App\Console\Commands\FillSeoFilter\MetaData\BrandPage;
use App\Console\Commands\FillSeoFilter\MetaData\Category2SlugAttributesPage;
use App\Console\Commands\FillSeoFilter\MetaData\CategoryBrandPage;
use App\Console\Commands\FillSeoFilter\MetaData\CategoryBrandSlugAttributePage;
use App\Console\Commands\FillSeoFilter\MetaData\CategoryPage;
use App\Console\Commands\FillSeoFilter\MetaData\CategorySlugAttributePage;
use App\Console\Commands\FillSeoFilter\MetaData\DataObject\Concatenatable;
use App\Console\Commands\FillSeoFilter\MetaData\SlugAttributePage;
use App\DataContainers\AbstractDataContainer;
use App\Models\Brand;
use App\Models\Category;
use App\Models\SemanticRule;
use App\Models\SeoFilters;
use App\Models\AttributeSlugValue;
use App\Models\Translate;
use App\Services\Catalog\Routing\UrlBuilder;
use App\Traits\SearchInCatalog;

/**
 * @property array uri
 * @property string[] h1 // ['ru' => translate, 'ua' => translate]
 * @property string[] title // ['ru' => translate, 'ua' => translate]
 * @property string[] description // ['ru' => translate, 'ua' => translate]
 * @property string[] text // ['ru' => translate, 'ua' => translate]
 * @property int active_products_in_stock
 * @property int $all_no_parent_products_in_stock
 * @property int min_price
 * @property int max_price
 */
abstract class MetaData extends AbstractDataContainer
{
    use SearchInCatalog;

    protected $text = [
        Translate::RU => '',
        Translate::UA => '',
    ];

    /**
     * @inheritDoc
     */
    public function __set($name, $value)
    {
        if ($name == 'uri') {
            $value = trim($value, '/');
        }

        parent::__set($name, $value);
    }

    #region Builders

    /**
     * @param object|Category|Brand|AttributeSlugValue $item1
     *
     * @return BrandPage|CategoryPage|SlugAttributePage
     */
    public static function level1(object $item1)
    {
        switch (get_class($item1)) {
            case Category::class:
                return CategoryPage::make([
                    'item1' => $item1,
                ]);

            case Brand::class:
                return BrandPage::make([
                    'item1' => $item1,
                ]);

            case AttributeSlugValue::class:
                return SlugAttributePage::make([
                    'item1' => $item1,
                ]);

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item1));
        }
    }

    /**
     * @param Category $item1
     * @param object|Brand|AttributeSlugValue $item2
     *
     * @return CategoryBrandPage|CategorySlugAttributePage
     */
    public static function level2(Category $item1, object $item2)
    {
        switch (get_class($item2)) {
            case Brand::class:
                return CategoryBrandPage::make([
                    'item1' => $item1,
                    'item2' => $item2,
                ]);

            case AttributeSlugValue::class:
                return CategorySlugAttributePage::make([
                    'item1' => $item1,
                    'item2' => $item2,
                ]);

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item1));
        }
    }

    /**
     * @param Category $item1
     * @param AttributeSlugValue|Brand $item2
     * @param AttributeSlugValue $item3
     *
     * @return CategoryBrandSlugAttributePage|Category2SlugAttributesPage
     */
    public static function level3(Category $item1, object $item2, AttributeSlugValue $item3)
    {
        switch (get_class($item2)) {
            case Brand::class:
                return CategoryBrandSlugAttributePage::make([
                    'item1' => $item1,
                    'item2' => $item2,
                    'item3' => $item3,
                ]);

            case AttributeSlugValue::class:
                return Category2SlugAttributesPage::make([
                    'item1' => $item1,
                    'item2' => $item2,
                    'item3' => $item3,
                ]);

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item1));
        }
    }

    /**
     * @param string $string
     * @param Category|Brand|AttributeSlugValue $item
     *
     * @return string
     */
    protected static function buildConcatenatable(string $string, object $item): Concatenatable
    {
        switch (get_class($item)) {
            case Category::class:
            case Brand::class:
            case AttributeSlugValue::class:
                return Concatenatable::make([
                    'string' => $string,
                    'position' => static::getPositionPriority($item),
                ]);

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item));
        }
    }

    #endregion

    #region Abstract methods

    /**
     * @return Category|Brand|AttributeSlugValue|Concatenatable
     */
    abstract protected function getConcatenatableList(): array;

    /**
     * @return int
     */
    abstract protected function getStep(): int;

    #endregion

    #region Actions

    /**
     * @return SeoFilters|null
     */
    public function save()
    {
        $this->beforeSaveAction();

        /** @var SeoFilters $seo_filters */
        $seo_filters = SeoFilters::query()
            ->where('uri', $this->uri)
            ->first();

        if (!$this->all_no_parent_products_in_stock) {
            $seo_filters && static::deleteSeoFilter($seo_filters);

            return null;
        } elseif (!$this->active_products_in_stock) {
            $seo_filters && static::hideSeoFilter($seo_filters);

            return null;
        }

        $seo_filters = $seo_filters ?? new SeoFilters(['uri' => $this->uri]);

        if ($seo_filters->manual_edited) {
            return null;
        }

        $seo_filters->products_in_stock = $this->active_products_in_stock;
        $seo_filters->min_price = $this->min_price;
        $seo_filters->max_price = $this->max_price;
        $seo_filters->robots_index = 1;
        $seo_filters->robots_follow = 1;
        $seo_filters->step = $this->getStep();

        $seo_filters->setTranslations('h1', $this->h1);
        $seo_filters->setTranslations('title', $this->title);
        $seo_filters->setTranslations('description', $this->description);
//        $seo_filters->setTranslations('text', $this->text);

        $seo_filters->save();

        return $seo_filters;
    }

    /**
     * @return void
     */
    protected function beforeSaveAction()
    {
        $catalog = $this->getCatalog();

        $data = $catalog->getActiveProductsAnatylicsData();

        $this->all_no_parent_products_in_stock = $data['all_no_parent_products_in_stock'];
        $this->active_products_in_stock = $data['products_in_stock'];
        $this->min_price = $data['min'];
        $this->max_price = $data['max'];

        $this->uri = UrlBuilder::catalog(
            $catalog->getRouteParams(),
            $this->item1 instanceof Category ? $this->item1 : null
        )->get();

        $this->fillH1();
        $this->fillTitle();
        $this->fillDescription();
    }

    #endregion

    #region Setters

    protected function fillH1()
    {
        $this->h1 = static::getLocalizedValue(
            static::getConcatenatedValue(Translate::RU, $this->getConcatenatableList()),
            static::getConcatenatedValue(Translate::UA, $this->getConcatenatableList())
        );
    }

    /**
     * @return void
     */
    protected function fillTitle()
    {
        $this->title = static::getLocalizedValue(
            $this->h1[Translate::RU] . ' ' . __('seo.buy_for_best_price', [], Translate::RU),
            $this->h1[Translate::UA] . ' ' . __('seo.buy_for_best_price', [], Translate::UA),
        );
    }

    /**
     * @return void
     */
    protected function fillDescription()
    {
        $this->description = static::getLocalizedValue(
            static::getConcatenatedValue(Translate::RU, $this->getConcatenatableList(), 'description') . ' ' . __('seo.buy_for_best_price_description', [], Translate::RU),
            static::getConcatenatedValue(Translate::UA, $this->getConcatenatableList(), 'description') . ' ' . __('seo.buy_for_best_price_description', [], Translate::UA),
        );
    }

    #endregion

    #region Getters

    /**
     * @param $ru_value
     * @param $ua_value
     *
     * @return array
     */
    protected static function getLocalizedValue($ru_value, $ua_value)
    {
        return [
            'ru' => $ru_value,
            'ua' => $ua_value,
        ];
    }

    /**
     * @param $locale
     * @param Category[]|Brand[]|AttributeSlugValue[] $items_list
     *
     * @return string
     */
    protected static function getConcatenatedValue($locale, array $items_list, $type = 'title')
    {
        if (!in_array($type, ['title', 'description'])) {
            throw new \InvalidArgumentException('Invalid $type');
        }

        $sorted_list = [];

        foreach ($items_list as $item) {
            $priority = static::getPositionPriority($item);

            if ($item instanceof Concatenatable) {
                $sorted_list[$priority][] = __($item->string, [], $locale);

                continue;
            }

            if (!$item->semanticRule && !isset($item->attribute->semanticRule)) {
                $sorted_list[$priority][] = $item;

                continue;
            }

            $is_attribute = $item instanceof AttributeSlugValue;

            $semanticRule = $is_attribute
                ? ($item->semanticRule ?? $item->attribute->semanticRule)
                : $item->semanticRule;

            if (
                $is_attribute
                && $semanticRule->includes_attr_name
            ) {
                $sorted_list[$priority][] = $item->attribute->getTranslation('filter_name', $locale);
            }

            $sorted_list[$priority][] = $item;
        }

        ksort($sorted_list);

        $result = [];

        foreach ($sorted_list as $items) {
            foreach ($items as $item) {
                $value = is_string($item)
                    ? trim($item)
                    : trim(
                        $type === 'description'
                            ? SemanticRule::getTitle($item, $locale, 'synonym')
                            : SemanticRule::getTitle($item, $locale, 'replace_word')
                    );

                if ($item instanceof Brand) {
                    $result[] = $value;
                } else {
                    $tmp_value = mb_convert_case($value, MB_CASE_LOWER);

                    $result[] = $result
                        ? $tmp_value
                        : mb_strtoupper(mb_substr($tmp_value, 0, 1)) . mb_substr($tmp_value, 1);
                }
            }
        }

        return implode(' ', $result);
    }

    /**
     * @param Category|Brand|AttributeSlugValue|Concatenatable $item
     *
     * @return int
     */
    private static function getPositionPriority($item)
    {
        if (isset($item->semanticRule->position)) {
            return $item->semanticRule->position;
        }

        switch (get_class($item)) {
            case Category::class:
                return 1000;

            case Brand::class:
                return 2000;

            case AttributeSlugValue::class:
                if (isset($item->attribute->semanticRule->position)) {
                    return $item->attribute->semanticRule->position;
                }

                return 1500;

            case Concatenatable::class:
                return $item->position;

            default:
                throw new \InvalidArgumentException('Caught not implemented entity: ' . get_class($item));
        }
    }

    #endregion

    #region Helpers

    /**
     * @param SeoFilters $seo_filters
     */
    private static function hideSeoFilter(SeoFilters $seo_filters)
    {
        $seo_filters->robots_index = false;
        $seo_filters->save();
    }

    /**
     * @param SeoFilters $seo_filters
     */
    private static function deleteSeoFilter(SeoFilters $seo_filters)
    {
        if ($seo_filters->manual_edited) {
            static::hideSeoFilter($seo_filters);

            return;
        }

        $seo_filters->delete();
    }

    #endregion
}
