<?php

namespace App\Console\Commands\FillSeoFilter;

use App\Console\Commands\FillSeoFilter\GeneratedText\Block\BasicBlock;
use App\Console\Commands\FillSeoFilter\GeneratedText\Step1;
use App\Console\Commands\FillSeoFilter\GeneratedText\Step2;
use App\Console\Commands\FillSeoFilter\GeneratedText\Step3;
use App\Console\Commands\FillSeoFilter\GeneratedText\Step4;
use App\DataContainers\AbstractDataContainer;
use App\Models\SeoFilters;
use App\Models\Translate;

/**
 * @property SeoFilters seo_filter
 */
abstract class GeneratedText  extends AbstractDataContainer
{
    /**
     * @param SeoFilters $seo_filter
     *
     * @return static
     */
    public static function factory(SeoFilters $seo_filter)
    {
        switch ($seo_filter->step) {
            case SeoFilters::STEP_1:
                return Step1::make(['seo_filter' => $seo_filter]);

            case SeoFilters::STEP_2:
                return Step2::make(['seo_filter' => $seo_filter]);

            case SeoFilters::STEP_3:
                return Step3::make(['seo_filter' => $seo_filter]);

            case SeoFilters::STEP_4:
                return Step4::make(['seo_filter' => $seo_filter]);

            default:
                throw new \LogicException('Step does not implement, given ' . $seo_filter->step);
        }
    }

    #region Action

    /**
     * @return $this
     */
    public function save()
    {
        $this->seo_filter->setTranslations('generated_text', [
            Translate::RU => $this->getText(Translate::RU),
            Translate::UA => $this->getText(Translate::UA),
        ]);

        $this->seo_filter->save();

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return BasicBlock[]|string[]
     */
    protected function getBlocksList(): array
    {
        return [
            GeneratedText\Block\HowMuchDoesItCost::class,
            GeneratedText\Block\WhatIsTheMostPopular::class,
        ];
    }

    /**
     * @return string
     */
    protected function getText(string $locale): string
    {
        $generated_texts_list = [];

        $origin_locale = app()->getLocale();
        app()->setLocale($locale);

        foreach ($this->getBlocksList() as $block) {
            $block_object = $block::build($this->seo_filter);

            $data = $block_object->renderFaqPageData();

            if ($block_object->skip()) {
                unset($block_object);

                continue;
            }

            unset($block_object);

            $generated_texts_list = array_merge(
                $generated_texts_list,
                $data
            );
        }

        /** @var \Illuminate\View\View $view */
        $view = view('seo.generated_text_blocks.main_template')
            ->with([
                'seo_filter' => $this->seo_filter,
                'generated_texts_list' => $generated_texts_list,
            ]);

        $result = $view->render();

        $view->getFactory()->flushState();
        $view->getFactory()->flushFinderCache();

        app()->setLocale($origin_locale);

        return $result;
    }

    #endregion
}
