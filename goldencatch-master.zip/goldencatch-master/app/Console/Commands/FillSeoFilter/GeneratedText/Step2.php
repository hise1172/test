<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText;

use App\Console\Commands\FillSeoFilter\GeneratedText;

class Step2 extends GeneratedText
{
    /**
     * @inheritDoc
     */
    protected function getBlocksList(): array
    {
        $blocks = parent::getBlocksList();

        $blocks[] = GeneratedText\Block\ChildrenFiltersList::class;

        return $blocks;
    }
}
