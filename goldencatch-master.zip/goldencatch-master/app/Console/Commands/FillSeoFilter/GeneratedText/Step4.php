<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText;

use App\Console\Commands\FillSeoFilter\GeneratedText;

class Step4 extends GeneratedText
{

}
