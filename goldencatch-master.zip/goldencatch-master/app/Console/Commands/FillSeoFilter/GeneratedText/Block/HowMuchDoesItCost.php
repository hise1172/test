<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\Block;

class HowMuchDoesItCost extends BasicBlock
{
    /**
     * @inheritDoc
     */
    protected function getViewName(): string
    {
        return 'how_much_does_it_cost';
    }

    /**
     * @inheritDoc
     */
    public function getBlockTitle($title_data = null): string
    {
        return __('seo.generated_text_blocks.how_much_does_it_cost.h3', ['h1' => $this->seo_filter->h1]);
    }

    /**
     * @inheritDoc
     */
    protected function getViewVars(): array
    {
        return [$this->renderOne(['genitive_case' => $this->seo_filter->h1])];
    }
}
