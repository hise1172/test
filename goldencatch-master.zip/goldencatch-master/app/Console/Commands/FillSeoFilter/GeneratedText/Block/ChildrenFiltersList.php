<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\Block;

use App\Console\Commands\FillSeoFilter\GeneratedText\DataObject\ChildrenFiltersListAttribute;
use App\Console\Commands\FillSeoFilter\GeneratedText\DataObject\ChildrenFiltersListItem;
use App\Console\Commands\FillSeoFilter\GeneratedText\DataObject\UriParameters;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class ChildrenFiltersList extends BasicBlock
{
    /**
     * @inheritDoc
     */
    protected function getViewName(): string
    {
        return 'children_filters_list';
    }

    /**
     * @inheritDoc
     */
    protected function getViewVars(): array
    {
        $result = [];

        foreach($this->getAttributesList() as $attrribute) {
            $result[] = $this->renderOne(
                ['attribures_list' => $attrribute->list],
                $attrribute->name
            );
        }

        return $result;
    }

    /**
     * @param string|null $attribute_type_name
     *
     * @return string
     */
    public function getBlockTitle($title_data = null) : string
    {
        return __('seo.generated_text_blocks.children_filters_list.h3', [
            'attribute_type_name' => $title_data ?? '---',
            'h1' => $this->seo_filter->h1,
        ]);
    }

    /**
     * @return ChildrenFiltersListAttribute[]
     */
    private function getAttributesList()
    {
        /**
         * @var array $children
         * [
         *      $filter_slug => [
         *          $uri => [
         *              'slugs' => string[],
         *              'products_in_stock' => int,
         *          ],
         *          ...
         *      ],
         *      ...
         * ]
         */
        $children = [];
        $attr_slug_values = [];

        foreach ($this->getChildrenFilters() as $children_seo_filter) {
            $params = UriParameters::parse($children_seo_filter->uri);

            if ($params->attributes->isEmpty()) {
                continue;
            }

            foreach ($params->attributes as $filter_slug => $slugs) {
                $children[$filter_slug][$children_seo_filter->uri]['slugs'] = array_merge($children[$filter_slug][$children_seo_filter->uri]['slugs'] ?? [], $slugs->toArray());
                $children[$filter_slug][$children_seo_filter->uri]['products_in_stock'] = $children_seo_filter->products_in_stock;
                $attr_slug_values = array_merge($attr_slug_values, $slugs->toArray());
            }
        }

        $slug_attributes_list = AttributeSlugValue::query()
            ->whereHas('attribute', function (Builder $query) use ($children) {
                $query->whereIn(Attribute::TABLE_NAME . '.filter_slug', array_keys($children));
            })
            ->whereIn('slug', $attr_slug_values)
            ->with('attribute')
            ->get();

        unset($attr_slug_values);

        /** @var ChildrenFiltersListAttribute[] $children_items_list */
        $children_items_list = [];

        foreach ($children as $filter_slug => $uris) {
            $attr = ChildrenFiltersListAttribute::make([
                'filter_slug' => $filter_slug,
            ]);

            foreach ($uris as $uri => $child) {
                /** @var Collection $list */
                $list = $slug_attributes_list->filter(function (AttributeSlugValue $item) use ($filter_slug, $attr) {
                        if ($attr->name) {
                            return $item->attribute->filter_slug == $filter_slug;
                        }

                        if ($item->attribute->filter_slug != $filter_slug) {
                            return false;
                        }

                        $attr->name = $item->attribute->filter_name;

                        return true;
                    })
                    ->whereIn('slug', $child['slugs'])
                    ->map(function (AttributeSlugValue $item) use ($uri, $child) {
                        return ChildrenFiltersListItem::make([
                            'name' => $item->value,
                            'url' => url($uri),
                            'products_in_stock' => $child['products_in_stock'],
                        ]);
                    });

                $attr->products_in_stock += $child['products_in_stock'];
                $attr->addItem(
                    $list
                );
            }

            if (count($attr->list) < static::MIN_ITEMS_COUNT_IN_BLOCK) {
                continue;
            }

            /** @var array $list */
            $list = $attr->list;

            usort($list, function ($a, $b) {
                return $b->products_in_stock - $a->products_in_stock;
            });

            $attr->list = array_slice($list, 0, static::MAX_ITEMS_COUNT_IN_BLOCK);

            $children_items_list[] = $attr;
        }

        usort($children_items_list, function ($a, $b) {
            return $b->products_in_stock - $a->products_in_stock;
        });

        return $children_items_list;
    }

}
