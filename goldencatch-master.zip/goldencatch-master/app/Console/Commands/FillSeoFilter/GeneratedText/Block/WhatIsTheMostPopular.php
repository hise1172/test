<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\Block;

use App\Console\Commands\FillSeoFilter\GeneratedText\DataObject\UriParameters;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Models\Product\Product;
use App\Services\Catalog\Filtration\Filter;
use App\Services\Catalog\Repository;

class WhatIsTheMostPopular extends BasicBlock
{
    #region Getters

    /**
     * @inheritDoc
     */
    protected function getViewName(): string
    {
        return 'what_is_the_most_popular';
    }

    /**
     * @inheritDoc
     */
    protected function getViewVars(): array
    {
        $this->parseUri();

        /** @var Product[] $products */
        $products = $this->getCatalog()
            ->getPageProducts([
                'count' => 5,
                'sort' => 'views',
                'by' => 'desc',
            ])
            ->items();

        $this->checkItems($products);

        return [$this->renderOne(['products_list' => $products])];
    }

    /**
     * @inheritDoc
     */
    public function getBlockTitle($title_data = null): string
    {
        return __('seo.generated_text_blocks.what_is_the_most_popular.h3', ['h1' => $this->seo_filter->h1]);
    }

    /**
     * @inheritDoc
     */
    protected function getRouteParams(): array
    {
        $params = [];

        if ($this->brand_slug) {
            $params[] = [
                'slug' => 'brand',
                'position' => 1,
                'values' => [$this->brand_slug],
            ];
        }

        if ($this->attributes) {
            foreach ($this->attributes as $key => $slug_attr) {
                try {
                    $params[] = [
                        'slug' => $slug_attr->attribute->filter_slug,
                        'position' => $slug_attr->attribute->filter_position ?? Filter::DEFAULT_POSITION,
                        'values' => [$slug_attr->slug],
                    ];
                } catch (\Throwable $e) {
                    dd([
                        'message' => $e->getMessage(),
                        'trace' => $e->getTraceAsString(),
                        '$key' => $key,
                        '$this->attributes' => $this->attributes,
                    ]);
                }
            }
        }

        return $params;
    }

    #endregion

    #region Helpers

    /**
     * @inheritDoc
     */
    protected function prepareCatalog(Repository $catalog)
    {
        if (!$this->category) {
            return;
        }

        $catalog->setCategoryId($this->category->id);
    }

    /**
     * @return void
     */
    private function parseUri()
    {
        $params = UriParameters::parse($this->seo_filter->uri);

        if ($params->brand->isNotEmpty()) {
            $this->brand_slug = $params->brand->first();
        }

        if ($params->category_slug) {
            $this->category = Category::query()
                ->where('slug', $params->category_slug)
                ->first();
        }

        if ($params->attributes->isNotEmpty()) {
            $this->attributes = collect();

            foreach ($params->attributes as $filter_slug => $slug_attributes) {
                $attr = AttributeSlugValue::query()
                    ->leftJoin(Attribute::TABLE_NAME, Attribute::TABLE_NAME . '.id', '=', AttributeSlugValue::TABLE_NAME . '.attribute_id')
                    ->where('slug', $slug_attributes->first())
                    ->where(Attribute::TABLE_NAME . '.filter_slug', $filter_slug)
                    ->with('attribute')
                    ->first();

                if (!$attr) {
                    continue;
                }

                $this->attributes[$filter_slug] = $attr;
            }
        }
    }

    #endregion
}
