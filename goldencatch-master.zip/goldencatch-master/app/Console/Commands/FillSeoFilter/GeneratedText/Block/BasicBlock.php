<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\Block;

use App\DataContainers\AbstractDataContainer;
use App\Models\AttributeSlugValue;
use App\Models\Category;
use App\Models\SeoFilters;
use App\Traits\SearchInCatalog;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Collection;
use App\Console\Commands\FillSeoFilter\GeneratedText\DataObject\FaqPageData;

/**
 * @property SeoFilters seo_filter
 */
abstract class BasicBlock extends AbstractDataContainer
{
    use SearchInCatalog;

    const MIN_ITEMS_COUNT_IN_BLOCK = 2;
    const MAX_ITEMS_COUNT_IN_BLOCK = 5;

    protected ?Category $category = null;
    protected ?string $brand_slug = null;
    /** @var AttributeSlugValue[]|null  */
    protected ?Collection $attributes = null;
    private bool $skip_rendering = false;

    #region Abstract

    /**
     * @return string
     */
    abstract protected function getViewName(): string;

    /**
     * @return string
     */
    abstract public function getBlockTitle($title_data = null): string;

    /**
     * @return FaqPageData[]
     */
    abstract protected function getViewVars(): array;

    #endregion

    #regino Actions

    /**
     * @param SeoFilters $seo_filter
     *
     * @return static
     */
    public static function build(SeoFilters $seo_filter): self
    {
        return static::make([
            'seo_filter' => $seo_filter,
        ]);
    }

    /**
     * @return FaqPageData[]
     */
    public function renderFaqPageData(): array
    {
        $vars = $this->getViewVars();

        return $vars;
    }

    /**
     * @param array $view_vars
     *
     * @return FaqPageData
     */
    protected function renderOne(array $view_vars, $title = null): FaqPageData
    {
        $view = $this->getView()
            ->with($view_vars);

        $answer = $view->render();

        $view->getFactory()->flushState();
        $view->getFactory()->flushFinderCache();

        return FaqPageData::make([
            'question' => $this->getBlockTitle($title),
            'answer' => $answer,
        ]);
    }

    #endregion

    #region Is Condition methods

    /**
     * @return bool
     */
    final public function skip(): bool
    {
        return $this->skip_rendering;
    }

    #endregion

    #region Setters

    /**
     * @param array|\Countable $count
     *
     * @return void
     */
    protected function checkItems($items)
    {
        $this->skip_rendering = count($items) < static::MIN_ITEMS_COUNT_IN_BLOCK;
    }

    #endregion

    #region Getters

    /**
     * @return View
     */
    protected function getView(): View
    {
        return view('seo.generated_text_blocks.' . $this->getViewName())
            ->with('seo_filter', $this->seo_filter);
    }

    /**
     * @return SeoFilters[]
     */
    protected function getChildrenFilters(): Collection
    {
        return SeoFilters::query()
            ->where('step', '=', $this->seo_filter->step + 1)
            ->where('uri', 'LIKE', $this->seo_filter->uri . '%')
            ->orderBy('products_in_stock', 'desc')
            ->get();
    }

    #endregion
}
