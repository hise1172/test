<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\DataObject;

use App\DataContainers\AbstractDataContainer;

/**
 * @property string question
 * @property string answer
 */
class FaqPageData extends AbstractDataContainer
{

}
