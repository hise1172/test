<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\DataObject;

use App\DataContainers\AbstractDataContainer;

/**
 * @property string name
 * @property string url
 * @property string products_in_stock
 */
class ChildrenFiltersListItem extends AbstractDataContainer
{

}
