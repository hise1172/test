<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\DataObject;

use App\DataContainers\AbstractDataContainer;
use Illuminate\Support\Collection;

/**
 * @property string name
 * @property string filter_slug
 * @property string products_in_stock
 * @property array list
 */
class ChildrenFiltersListAttribute extends AbstractDataContainer
{
    protected array $list = [];

    /**
     * @param Collection $items
     *
     * @return $this
     */
    public function addItem(Collection $items): self
    {
        $this->list = array_merge($items->toArray(), $this->list);

        return $this;
    }
}
