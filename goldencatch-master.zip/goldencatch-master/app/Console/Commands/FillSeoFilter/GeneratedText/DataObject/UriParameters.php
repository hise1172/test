<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText\DataObject;

use App\DataContainers\AbstractDataContainer;
use Illuminate\Support\Collection;

/**
 * @property string category_slug
 * @property Collection|Collection[] attributes
 * @property Collection brand
 */
class UriParameters extends AbstractDataContainer
{
    /**
     * @param string $uri
     *
     * @return static
     */
    public static function parse(string $uri): self
    {
        if (!$uri) {
            throw new \InvalidArgumentException('Invalid $uri');
        }

        $uri = trim($uri, '/');

        $parameters = explode('/', $uri);
        $properties = [
            'attributes' => collect(),
            'brand' => collect(),
        ];
        $was_category_prev = false;

        foreach ($parameters as $parameter) {
            switch ($parameter) {
                case 'catalog':
                    $was_category_prev = true;
                    continue(2);

                case 'filter':
                    $was_category_prev = false;
                    continue(2);
            }

            if ($was_category_prev) {
                $properties['category_slug'] = urldecode($parameter);

                continue;
            }

            if (strpos($parameter, '-') === false) {
                throw new \LogicException('There is invalid $uri in `seo_filters` table: `' . $uri . '`');
            }

            [$type, $slug] = explode('-', $parameter, 2);
            $slug = collect(explode(',', $slug));

            switch ($type) {
                case 'brand':
                    $properties[$type] = $slug;
                    break;

                default:
                    $properties['attributes'][urldecode($type)] = $slug;
            }
        }

        return static::make($properties);
    }
}
