<?php

namespace App\Console\Commands\FillSeoFilter\GeneratedText;

use App\Console\Commands\FillSeoFilter\GeneratedText;

class Step3 extends GeneratedText
{

}
