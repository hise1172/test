<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Models\Category;
use App\Models\Product\Product;
use App\Models\SeoFilters;
use Spatie\ArrayToXml\ArrayToXml;
use Carbon\Carbon;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Builder;
use App\Models\LandingPage;

class SitemapGenerate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sitemap:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate Sitemap XML files';


    private $sitemapArray = [];
    private $sitemapCounter = 0;
    private $divideNumber = 10000;
    private $xmlChildFilesName = [];
    private $defaultDateCarbon = NULL;


    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->defaultDateCarbon = Carbon::instance(now())->format(\DateTime::ATOM);

        Storage::disk('public')->deleteDirectory('sitemap/');

        $this->addStatic();
        $this->addSeofilter();
        $this->addCategories();
        $this->addProducts();
        $this->addLandingPages();

        if( ! count($this->xmlChildFilesName) ){
            $this->error('XML files did not created.');
            return 0;
        }

        $sitemapLoc = [];
        foreach ($this->xmlChildFilesName as $name) {
            $sitemapLoc[] = ['loc' => Storage::disk('public')->url($name)];
        }

        $result = ArrayToXml::convert(['sitemap' => $sitemapLoc], [
            'rootElementName' => 'sitemapindex',
            '_attributes' => [
                'xmlns' => 'http://www.sitemaps.org/schemas/sitemap/0.9',
                'xmlns:xhtml' => 'http://www.w3.org/1999/xhtml',
            ],
        ], true, 'UTF-8');

        Storage::disk('public')->put('sitemap/sitemap.xml', $result);

        $this->info('Sitemap XML files successfully generated.');

    }

    public function addStatic() {
        foreach (config('staticpages') as $value) {
            $this->generateUrls( $value['routeName']);
        }
        $this->createXmlPages('static');
    }

    public function addSeofilter() {

        foreach (SeoFilters::select('uri')->get() as $filter) {

            foreach ( config('app.all_locale') as $localeChild) {
                $this->sitemapCounter++;
                foreach ( config('app.all_locale') as $locale) {
                    if($locale == $localeChild){
                        if( config('app.default_locale') == $locale){
                            $this->sitemapArray[$this->sitemapCounter]['loc'] = asset($filter->uri);
                        }
                        else{
                            $this->sitemapArray[$this->sitemapCounter]['loc'] = asset(  $locale . '/' . ltrim($filter->uri, '/'));
                        }

                    }
                    else{
                        if( config('app.default_locale') == $locale){
                            $this->sitemapArray[$this->sitemapCounter]['xhtml:link'][] = [
                                '_attributes' => [
                                    'rel' => 'alternate',
                                    'href' => asset($filter->uri),
                                    'hreflang' => $locale,
                                ],
                            ];
                        }
                        else{
                            $this->sitemapArray[$this->sitemapCounter]['xhtml:link'][] = [
                                '_attributes' => [
                                    'rel' => 'alternate',
                                    'href' => asset(  $locale . '/' . ltrim($filter->uri, '/')),
                                    'hreflang' => $locale,
                                ],
                            ];
                        }

                    }
                }
            }
        }
        $this->createXmlPages('seofilter');
    }

    public function addCategories()
    {
        $this->sitemapArray = [];
        foreach (Category::select('slug')->whereHas('products', function (Builder $query) {
            $query->where('is_active', true);
            $query->where('stock', '>', 0);
        })->get() as $category) {
            $this->generateUrls( 'category.filter', ['category' => $category->slug] );
        }
        $this->createXmlPages('categories');
    }

    public function addLandingPages()
    {
        $this->sitemapArray = [];
        foreach (LandingPage::where('robots_index', 1)->get() as $page) {
            if($page->slug == LandingPage::HOMEPAGE_SLUG){
                $page->slug = '/';
            }
            $this->generateUrls( 'landing-page', ['slug' => $page->slug] );
        }
        $this->createXmlPages('landingpages');
    }

    public function addProducts()
    {
        $this->sitemapArray = [];
        foreach (Product::select('slug')->where('is_active', true)->whereNull('parent_id')->get() as $product) {
            $this->generateUrls( 'product', ['product' => $product->slug] );
        }
        $this->createXmlPages('products');
    }

    public function createXmlPages( $type ) {
        foreach (array_chunk($this->sitemapArray, $this->divideNumber) as $key => $value) {
            $result = ArrayToXml::convert(['url' => $value], [
                'rootElementName' => 'urlset',
                '_attributes' => [
                    'xmlns' => 'http://www.sitemaps.org/schemas/sitemap/0.9',
                    'xmlns:xhtml' => 'http://www.w3.org/1999/xhtml',
                ],
            ], true, 'UTF-8');

            $fileName = 'sitemap/sitemap-' . $type . '-' . $key . '.xml';
            Storage::disk('public')->put($fileName, $result);
            $this->xmlChildFilesName[] = $fileName;
        }
        $this->sitemapArray = [];
    }

    public function generateUrls( $routeName, $parameters = [], $lastmod = false, $changefreq = false, $priority = false )
    {

        if ( ! Route::has($routeName . '-l')) {
            $this->sitemapCounter++;
            $this->sitemapArray[$this->sitemapCounter]['loc'] = route($routeName, $parameters);
            if( false !== $lastmod){
                $this->sitemapArray[$this->sitemapCounter]['lastmod'] = $lastmod;
            }
            if( false !== $changefreq){
                $this->sitemapArray[$this->sitemapCounter]['changefreq'] = $changefreq;
            }
            if( false !== $priority){
                $this->sitemapArray[$this->sitemapCounter]['priority'] = $priority;
            }

            return ;
        }

        foreach ( config('app.all_locale') as $locale) {
            $this->sitemapCounter++;

            $this->generateUrlsLocale( $this->sitemapCounter, $routeName, $parameters, $locale );

            if( false !== $lastmod){
                $this->sitemapArray[$this->sitemapCounter]['lastmod'] = $lastmod;
            }

            if( false !== $changefreq){
                $this->sitemapArray[$this->sitemapCounter]['changefreq'] = $changefreq;
            }

            if( false !== $priority){
                $this->sitemapArray[$this->sitemapCounter]['priority'] = $priority;
            }
        }

    }

    public function generateUrlsLocale( $iteratorNumber, $routeName, $parameters = [], $lang = '' )
    {
        foreach ( config('app.all_locale') as $locale) {
            if( $lang == $locale){
                if( config('app.default_locale') == $locale){
                    $this->sitemapArray[$iteratorNumber]['loc'] = route($routeName, $parameters);
                }
                else{
                    $this->sitemapArray[$iteratorNumber]['loc'] = route($routeName . '-l', $parameters + ['locale' => $locale]);
                }
            }
            else{
                if( config('app.default_locale') == $locale){
                    $this->sitemapArray[$iteratorNumber]['xhtml:link'][] = [
                        '_attributes' => [
                            'rel' => 'alternate',
                            'href' => route($routeName, $parameters),
                            'hreflang' => $locale,
                        ],
                    ];
                }
                else{
                    $this->sitemapArray[$iteratorNumber]['xhtml:link'][] = [
                        '_attributes' => [
                            'rel' => 'alternate',
                            'href' => route($routeName . '-l', $parameters + ['locale' => $locale]),
                            'hreflang' => $locale,
                        ],
                    ];
                }
            }
        }
    }
}
