<?php

namespace App\Console\Commands;

use App\Events\BonusesHasBeenApprovedEvent;
use App\Models\BonusHistory;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CheckRecentlyApprovedBonuses extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'bonuses:approval_noties';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $date = new \DateTime();
        $return_code = Command::SUCCESS;


        $bonuses = BonusHistory::query()
            ->where('created_at', '<', (clone $date)
                ->sub(new \DateInterval('P14D'))
                ->format('Y-m-d 00:00:00'))
            ->where('created_at', '>', (clone $date)
                ->sub(new \DateInterval('P15D'))
                ->format('Y-m-d 00:00:00'))
            ->where('amount', '>', 0)
            ->where('status_id', BonusHistory::STATUS_ACTIVE)
            ->with('user', function (BelongsTo $query) {
                $query->with('bonusHistory');
            })
            ->groupBy('user_id')
            ->get();

        $this->info('Found ' . $bonuses->count() . ' new bonuses');

        foreach ($bonuses as $bonus) {
            /** @var BonusHistory $bonus */

            if (!$bonus->user) {
                $this->error('There is no user. Bonus History ID: ' . $bonus->id);

                $return_code = Command::INVALID;

                continue;
            }

            event(new BonusesHasBeenApprovedEvent($bonus->user));
        }

        $this->info('Completed');

        return $return_code;
    }
}
