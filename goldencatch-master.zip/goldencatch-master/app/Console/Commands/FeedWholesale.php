<?php

namespace App\Console\Commands;

use App\Services\Feeds\Wholesale;
use Illuminate\Console\Command;

class FeedWholesale extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'feed:wholesale';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Генерация CSV файла для оптовых клиентов';

    protected $generatedFileName = 'feed/wholesale.csv';


    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $productCounter = (new Wholesale())
            ->setFileName($this->generatedFileName)
            // ->categoriesAll( )
            // ->categoriesOnlySlugs( 'rods', 'reels' )
            // ->categoriesOnlyIds( 1,2,3 )
            // ->categoriesExcludeSlugs( ['rods', 'reels'] )
            // ->categoriesExcludeIds( 1, 3 )
            // ->brandsAll( )
            // ->brandsOnlySlugs( 'strike-pro' )
            // ->brandsOnlyIds( 1,3 )
            ->brandsExcludeSlugs('Shimano', 'Ryobi')
            // ->brandsExcludeIds( 1 )
            ->productsAll()
            ->toCsv()
            ->productCounter
            ;

        if ( $productCounter ) {
            $this->info($productCounter . ' products writed to CSV file: ' . $this->generatedFileName);
        } else {
            throw new \LogicException('Products not found.');
        }
        return Command::SUCCESS;
    }
}
