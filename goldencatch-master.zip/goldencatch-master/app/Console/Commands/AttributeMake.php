<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Attribute;

class AttributeMake extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'attr:make {name} {type} {slug?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Make new attribute in `attributes` table with defined name type and optional slug';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $name = $this->argument('name');
        $filterType = $this->argument('type');
        if (!$name || !$filterType) {
            $this->error('Command require two args `name`, `type`');
            return 0;
        }

        $slug = $this->argument('slug');
        if ($filterType == Attribute::TYPE_SLUG && !$slug) {
            $this->error('Command for filter type `slug` required third text arg');
            return 0;
        }

        $attribute = new Attribute();
        $attribute->system_name = $name;
        $attribute->is_desc_attr = 0;
        $attribute->desc_attr_name = ['ua' => '', 'ru' => ''];
        $attribute->desc_attr_measurement_unit = ['ua' => '', 'ru' => ''];
        $attribute->is_filter = 0;
        $attribute->filter_name = ['ua' => $name, 'ru' => $name];
        $attribute->filter_type = $filterType;
        $attribute->filter_position = 0;
        $attribute->filter_measurement_unit = ['ua' => '', 'ru' => ''];
        $attribute->save();

        $this->info('Attribute created; Id: ' . $attribute->id);
    }
}
