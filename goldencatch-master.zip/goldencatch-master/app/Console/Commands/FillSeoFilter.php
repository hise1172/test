<?php

namespace App\Console\Commands;

use App\Console\Commands\FillSeoFilter\MetaData;
use App\Console\Commands\FillSeoFilter\MetaData\DataObject\ItemsData;
use App\Console\Commands\FillSeoFilter\MetaData\SlugAttributePage;
use App\Models\Brand;
use App\Models\Category;
use App\Models\AttributeSlugValue;
use App\Models\Product\Product;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * CLI PROPERTIES:
 * --step=<int> - optional
 */
class FillSeoFilter extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'seo_filter:fill {--step=}?';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    private $brands_list;
    private $categories_list;
    private $slug_attributes_list;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->handleMetaData();

        $this->info('MetaData Generation completed');

        return 0;
    }

    #region Actions

    /**
     * @return void
     */
    private function handleMetaData()
    {
        if (!$this->option('step')) {
            $this->metaDataProcessStep1();

            $this->metaDataProcessStep2();

            $this->metaDataProcessStep3();

            $this->metaDataProcessStep4();

            return;
        }

        switch ($this->option('step')) {
            case 1:
                $this->metaDataProcessStep1();
                break;

            case 2:
                $this->metaDataProcessStep2();
                break;

            case 3:
                $this->metaDataProcessStep3();
                break;

            case 4:
                $this->metaDataProcessStep4();
                break;
        }
    }

    /**
     * 1 уровень: категория, бренд, некоторые самостоятельные атрибуты типа вид рыбы (если нет смысла делать лендинг)
     */
    private function metaDataProcessStep1()
    {
        $this->info('MetaData Step1 started');

        $categories = $this->getCategories();
        $brans = $this->getBrands();
        $attributes = $this->getSlugAttributes()->filter(fn (AttributeSlugValue $attr) => in_array($attr->attribute->filter_slug, SlugAttributePage::getNeededSlugs()));

        $bar = $this->getProgressBar($categories->count() + $brans->count() + $attributes->count());

        $bar->start();

        foreach ([$categories, $brans, $attributes] as $items) {
            foreach ($items as $item) {
                MetaData::level1($item)
                    ->save();

                $bar->advance();
            }
        }

        $bar->finish();
        parent::info("\n");
    }

    /**
     * 2 уровень: категория + бренд, категория + атрибут (Катушки TICA, Воблеры на щуку)
     */
    private function metaDataProcessStep2()
    {
        $this->info('MetaData Step2 started');

        $categories = $this->getCategories();

        $brands = $this->getBrands();
        $attributes = $this->getSlugAttributes();

        $available_items_brand = $this->getCategoriesBrandsWithProductsStep2();
        $available_items_attr = $this->getCategoriesSlugAttributesWithProductsStep2();

        $bar = $this->getProgressBar($available_items_brand->count() + $available_items_attr->count());

        $bar->start();

        foreach ($available_items_brand as $row) {
            $bar->advance();

            if (
                $categories->where('id', $row->item1_id)->isEmpty()
                || $brands->where('id', $row->item2_id)->isEmpty()
            ) {
                continue;
            }

            MetaData::level2(
                $categories->where('id', $row->item1_id)->first(),
                $brands->where('id', $row->item2_id)->first()
            )->save();
        }

        foreach ($available_items_attr as $row) {
            $bar->advance();

            if (
                $categories->where('id', $row->item1_id)->isEmpty()
                || $attributes->where('id', $row->item2_id)->isEmpty()
            ) {
                continue;
            }

            MetaData::level2(
                $categories->where('id', $row->item1_id)->first(),
                $attributes->where('id', $row->item2_id)->first()
            )->save();
        }

        $bar->finish();
        parent::info("\n");
    }

    /**
     * 3 уровень: категория + бренд + атрибут (примеры: Безынерционные катушки TICA)
     */
    private function metaDataProcessStep3()
    {
        $this->info('MetaData Step3 started');

        $categories = $this->getCategories();

        $brands = $this->getBrands();

        $attributes = $this->getSlugAttributes();

        $available_items = $this->getItemsWithProductsStep3();

        $bar = $this->getProgressBar($available_items->count());

        $bar->start();

        // Category + Brans + Attribute
        foreach ($available_items as $row) {
            $bar->advance();

            if (
                $categories->where('id', $row->item1_id)->isEmpty()
                || $brands->where('id', $row->item2_id)->isEmpty()
                || $attributes->where('id', $row->item3_id)->isEmpty()
            ) {
                continue;
            }

            MetaData::level3(
                $categories->where('id', $row->item1_id)->first(),
                $brands->where('id', $row->item2_id)->first(),
                $attributes->where('id', $row->item3_id)->first()
            )->save();
        }

        $bar->finish();
        parent::info("\n");
    }

    /**
     * 3 уровень: категория + 2 атрибута (примеры: Воблеры минноу на щуку)
     */
    private function metaDataProcessStep4()
    {
        $this->info('MetaData Step4 started');

        $categories = $this->getCategories();

        $attributes = $this->getSlugAttributes();

        $available_items = $this->getItemsWithProductsStep4();

        $bar = $this->getProgressBar($available_items->count());

        $bar->start();

        // Category + Attribute + Attribute
        foreach ($available_items as $row) {
            if (
                $categories->where('id', $row->item1_id)->isEmpty()
                || $attributes->where('id', $row->item2_id)->isEmpty()
                || $attributes->where('id', $row->item3_id)->isEmpty()
            ) {
                $bar->advance();

                continue;
            }

            MetaData::level3(
                $categories->where('id', $row->item1_id)->first(),
                $attributes->where('id', $row->item2_id)->first(),
                $attributes->where('id', $row->item3_id)->first()
            )->save();

            $bar->advance();
        }

        $bar->finish();
        parent::info("\n");
    }

    #endregion

    #region Getters

    /**
     * @param int $count
     *
     * @return \Symfony\Component\Console\Helper\ProgressBar
     */
    private function getProgressBar(int $count = 0)
    {
        $bar = $this->output->createProgressBar($count);
        $bar->setFormat('debug');

        return $bar;
    }

    /**
     * @return Collection|Category[]
     */
    private function getCategories(): Collection
    {
        if ($this->categories_list) {
            return clone $this->categories_list;
        }

        $query = static::applyDefaultConditions(Category::query());

        return clone $this->categories_list = $query
            ->get();
    }

    /**
     * @return Collection|Brand[]
     */
    private function getBrands(): Collection
    {
        if ($this->brands_list) {
            return clone $this->brands_list;
        }

        return clone $this->brands_list = static::applyDefaultConditions(Brand::query())
            ->get()
            ->filter(function ($item) {
                return !$item->semanticRule || !$item->semanticRule->skip;
            });
    }

    /**
     * @return Collection|AttributeSlugValue[]
     */
    private function getSlugAttributes(): Collection
    {
        if ($this->slug_attributes_list) {
            return clone $this->slug_attributes_list;
        }

        return clone $this->slug_attributes_list = static::applyDefaultConditions(AttributeSlugValue::query())
            ->with('attribute', function ($query) {
                $query->with('semanticRule');
            })
            ->get()
            ->filter(function (AttributeSlugValue $item) {
                if (!$item->attribute->is_filter) {
                    return false;
                }

                if ($item->semanticRule) {
                    return !$item->semanticRule->skip;
                }

                if ($item->attribute->semanticRule) {
                    return !$item->attribute->semanticRule->skip;
                }

                return true;
            });
    }

    /**
     * @return Collection|ItemsData[]
     */
    private function getCategoriesSlugAttributesWithProductsStep2(): Collection
    {
        $query = [];
        $data = ['p.id', 'p.parent_id'];

        foreach ($data as $col_name) {
            $query[] = '
                SELECT
                    CONCAT("c", c.id, "a", sv.id) AS filter_key,
                    c.id AS item1_id,
                    sv.id AS item2_id,
                    p.id,
                    p.price
                FROM
                    products p
                    LEFT JOIN products par ON par.id = p.parent_id
                    LEFT JOIN products_attributes_slug_values pa ON pa.product_id = ' . $col_name . '
                    LEFT JOIN attributes_slug_values sv ON sv.id = pa.attribute_slug_value_id
                    LEFT JOIN `attributes` a ON a.id = sv.attribute_id
                --
                    LEFT JOIN categories c ON c.id = p.category_id
                WHERE
                    a.is_filter = 1
                    AND c.id IS NOT NULL
                    AND sv.id IS NOT NULL
                    AND (
                        (p.status = 1 AND p.is_active = 1)
                        OR (par.status = 1 AND par.is_active = 1)
                    )
            ';
        }

        $query = '
            SELECT
                t.filter_key,
                t.item1_id,
                t.item2_id,
                COUNT(t.id) AS products,
                CAST(min(t.price) AS UNSIGNED) AS price_from,
                CAST(max(t.price) AS UNSIGNED) AS price_to
            FROM (
                (' . implode(') UNION (', $query) . ')
            ) t
            GROUP BY
                filter_key,
                t.item1_id,
                t.item2_id
        ';

        $rows = DB::select($query);

        return collect($rows)->mapWithKeys(fn ($row) => [$row->filter_key => ItemsData::make((array) $row)]);
    }

    /**
     * @return Collection|ItemsData[]
     */
    private function getCategoriesBrandsWithProductsStep2(): Collection
    {
        $query = '
            SELECT
                t.filter_key,
                t.item1_id,
                t.item2_id,
                COUNT(t.id) AS products,
                CAST(min(t.price) AS UNSIGNED) AS price_from,
                CAST(max(t.price) AS UNSIGNED) AS price_to
            FROM (
                (
                    SELECT
                        CONCAT("c", c.id, "b", b.id) AS filter_key,
                        c.id AS item1_id,
                        b.id AS item2_id,
                        p.id,
                        p.price
                    FROM
                        products p
                        LEFT JOIN products par ON par.id = p.parent_id
                        LEFT JOIN brands b ON b.id = p.brand_id
                        LEFT JOIN categories c ON c.id = p.category_id
                    WHERE
                        c.id IS NOT NULL
                        AND b.id IS NOT NULL
                        AND (
                            (p.status = 1 AND p.is_active = 1)
                            OR (par.status = 1 AND par.is_active = 1)
                        )
                )
            ) t
            GROUP BY
                filter_key,
                t.item1_id,
                t.item2_id
        ';

        $rows = DB::select($query);

        return collect($rows)->mapWithKeys(fn ($row) => [$row->filter_key => ItemsData::make((array) $row)]);
    }

    /**
     * @return Collection|ItemsData[]
     */
    private function getItemsWithProductsStep3(): Collection
    {
        $query = [];
        $data = ['p.id', 'p.parent_id'];

        foreach ($data as $col_name) {
            $query[] = '
                SELECT
                    CONCAT("c", c.id, "b", b.id, "a", sv.id) AS filter_key,
                    c.id AS item1_id,
                    b.id AS item2_id,
                    sv.id AS item3_id,
                    p.id,
                    p.price
                FROM
                    products p
                    LEFT JOIN products par ON par.id = p.parent_id
                    LEFT JOIN products_attributes_slug_values pa ON pa.product_id = ' . $col_name . '
                    LEFT JOIN attributes_slug_values sv ON sv.id = pa.attribute_slug_value_id
                    LEFT JOIN `attributes` a ON a.id = sv.attribute_id
                --
                    LEFT JOIN categories c ON c.id = p.category_id
                    LEFT JOIN brands b ON b.id = p.brand_id
                WHERE
                    a.is_filter = 1
                    AND c.id IS NOT NULL
                    AND b.id IS NOT NULL
                    AND sv.id IS NOT NULL
                    AND (
                        (p.status = 1 AND p.is_active = 1)
                        OR (par.status = 1 AND par.is_active = 1)
                    )
            ';
        }

        $query = '
            SELECT
                t.filter_key,
                t.item1_id,
                t.item2_id,
                t.item3_id,
                COUNT(t.id) AS products,
                CAST(min(t.price) AS UNSIGNED) AS price_from,
                CAST(max(t.price) AS UNSIGNED) AS price_to
            FROM (
                (' . implode(') UNION (', $query) . ')
            ) t
            GROUP BY
                filter_key,
                t.item1_id,
                t.item2_id,
                t.item3_id
        ';

        $rows = DB::select($query);

        return collect($rows)->mapWithKeys(fn ($row) => [$row->filter_key => ItemsData::make((array) $row)]);
    }


    /**
     * @return Collection|ItemsData[]
     */
    private function getItemsWithProductsStep4(): Collection
    {
        $query = [];
        $data = [
            ['p.id', 'p.id'],
            ['p.id', 'p.parent_id'],
            ['p.parent_id', 'p.id'],
            ['p.parent_id', 'p.parent_id'],
        ];

        foreach ($data as $col_name) {
            $query[] = '
                SELECT
                    CONCAT("c", c.id, "a", sv.id, "x", sv2.id) AS filter_key,
                    c.id AS item1_id,
                    sv.id AS item2_id,
                    sv2.id AS item3_id,
                    p.id,
                    p.price
                FROM
                    products p
                    LEFT JOIN products par ON par.id = p.parent_id
                    LEFT JOIN products_attributes_slug_values pa ON pa.product_id = ' . $col_name[0] . '
                    LEFT JOIN attributes_slug_values sv ON sv.id = pa.attribute_slug_value_id
                    LEFT JOIN `attributes` a ON a.id = sv.attribute_id
                --
                    LEFT JOIN products_attributes_slug_values pa2 ON pa2.product_id = ' . $col_name[1] . '
                    LEFT JOIN attributes_slug_values sv2 ON sv2.id = pa2.attribute_slug_value_id
                    LEFT JOIN `attributes` a2 ON a2.id = sv2.attribute_id
                --
                    LEFT JOIN categories c ON c.id = p.category_id
                WHERE
                    a.is_filter = 1
                    AND a2.is_filter = 1
                    AND sv.id != sv2.id
                    AND sv.attribute_id != sv2.attribute_id
                    AND c.id IS NOT NULL
                    AND sv.id IS NOT NULL
                    AND sv2.id IS NOT NULL
                    AND (
                        (p.status = 1 AND p.is_active = 1)
                        OR (par.status = 1 AND par.is_active = 1)
                    )
            ';
        }

        $query = '
            SELECT
                t.filter_key,
                t.item1_id,
                t.item2_id,
                t.item3_id,
                COUNT(t.id) AS products,
                CAST(min(t.price) AS UNSIGNED) AS price_from,
                CAST(max(t.price) AS UNSIGNED) AS price_to
            FROM (
                (' . implode(') UNION (', $query) . ')
            ) t
            GROUP BY
                filter_key,
                t.item1_id,
                t.item2_id,
                t.item3_id
        ';

        $rows = DB::select($query);

        return collect($rows)->mapWithKeys(fn ($row) => [$row->filter_key => ItemsData::make((array) $row)]);
    }

    #endregion

    #region Helpers

    /**
     * @param $message
     * @param $verbosity
     *
     * @return void
     */
    public function info($message, $verbosity = null)
    {
        parent::info('[' . date('Y-m-d H:i:s') . '] ' . $message, $verbosity);
    }

    /**
     * @param EloquentBuilder $query
     *
     * @return EloquentBuilder
     */
    private static function applyDefaultConditions(EloquentBuilder $query)
    {
        return $query
            ->with('semanticRule')
            ->whereHas('products', function (EloquentBuilder $query) {
                $query
                    ->whereHas('modifications', function (EloquentBuilder $query) {
                        $query->where('is_active', true)
                            ->where('status', Product::STATUS_IN_STOCK);
                    })
                    ->whereOr(function (EloquentBuilder $query) {
                        $query->where('is_active', true)
                            ->where('status', Product::STATUS_IN_STOCK);
                    });
            });
    }

    #endregion
}
