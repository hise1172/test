<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Models\Category;
use App\Helpers\FileUploaded;
use App\Models\Product\Product;
use App\Models\Product\ProductAttribute;
use App\Models\Product\ProductAttributeName;
use App\Models\TypeFishes;
use App\Models\Types;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class ProductImport
 * @package App\Console\Commands
 */
class ProductImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:import';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $file = fopen('goldencatch.com.ua_CSV.csv', 'r');
        if (!$file) {
            return -1;
        }
        $attributeMap = [];
        $index = 0;
        while (!feof($file) && ($line = fgetcsv($file, 0, ',', '"'))) {
            if (empty($attributeMap)) {
                foreach ($line as $key => $value) {
                    $attributeMap[$value] = $key;
                }
                continue;
            }


            //empty(trim($line[$attributeMap['price']])) ||
//            if (empty($line[$attributeMap['SKU']]) ||
//                empty($line[$attributeMap['name']]) ||
//                empty($line[$attributeMap['category']]) ||
//                empty($line[$attributeMap['manufacturer']])) {
//                Log::warning("============================");
//                Log::warning("not imported on row: [".($index+1)."] percents: [".round(($index/29526)*100, 2).'% ]| SKU: '.$line[0]);
//                Log::warning('is empty SKU: '.(empty($line[$attributeMap['SKU']]) ? 'true' : 'false' ));
//                Log::warning('is empty name: '.(empty($line[$attributeMap['name']]) ? 'true' : 'false'));
//                Log::warning('is empty category: '. (empty($line[$attributeMap['category']]) ? 'true' : 'false' ));
//                Log::warning('is empty manufacturer: '.(empty($line[$attributeMap['manufacturer']]) ? 'true' : 'false' ));
//                Log::warning("============================");
//                continue;
//            }
            try {

//                $category = $line[$attributeMap['category']];
//                if ($category == 'Блесны') {
//                    $category = 'Блесна';
//                }
//                $arr = explode(' ',trim($line[$attributeMap['name']]));
//                $category=$arr[0];
//                $attributes = [];
                $attributes['SKU'] = $line[$attributeMap['SKU']];
//                $attributes['SKU_parent'] = empty($line[$attributeMap['SKU_parent']]) ?
//                    null : $line[$attributeMap['SKU_parent']];
//                if (!empty(trim($line[$attributeMap['price']]))) {
//                    $attributes['price'] = $line[$attributeMap['price']];
//                }
//                $attributes['description'] = $line[$attributeMap['description_long']];
//                $attributes['short_description'] = $line[$attributeMap['description_short']];
//                $attributes['category_id'] = Category::firstOrCreate(
//                    ['name' => Str::ucfirst($category)]
//                )->id;
//                $attributes['brand_id'] = Brand::updateOrCreate(
//                    ['name' => Str::ucfirst($line[$attributeMap['manufacturer']])],
//                    ['country' => Str::ucfirst($line[$attributeMap['country_of_manufacture']])]
//                )->id;
//                $attributes['status'] = intval($line[$attributeMap['in_stock']]) == 1 ?
//                    Product::PRODUCT_IN_STOCK : Product::PRODUCT_OUT_STOCK;
//                $attributes['is_active'] = $line[$attributeMap['is_active']] == 'Включено';
//                $attributes['name'] = $line[$attributeMap['name']];
                $attributes['photo'] = FileUploaded::saveProductPhotoByUrl($line[$attributeMap['photo_1']]);
                /**
                 * @var Product $product
                 */
                $product = Product::updateOrCreate(['SKU' => $attributes['SKU']], $attributes);

//                $trimAttribute = trim($line[$attributeMap['rr_naznachenie']]);
//                if (!empty($trimAttribute)) {
//                    $typeName = [
//                        'Карповая' => 'Карповое',
//                        'Спиннинговая' => 'Спиннинговое',
//                        'Фидер Матч' => 'Фидерное',
//                        'Морская' => 'Морское',
//                        'Поплавок' => 'Поплавочное'
//                    ];
//                    foreach (explode('  ', $trimAttribute) as $type) {
//                        if (array_key_exists($type, $typeName)) {
//                            $type = $typeName[$type];
//                        }
//                        $product->types()->syncWithoutDetaching(Types::firstOrCreate(['name' => $type]));
//                    }
//                }
//                $fishes = trim($line[$attributeMap['fish']]);
//                if (!empty($fishes)) {
//                    foreach (explode('  ', $fishes) as $fish) {
//                        $product->typesFishes()->syncWithoutDetaching(TypeFishes::firstOrCreate(['name' => $fish]));
//                    }
//                }
                $photos = [];
                for ($i = 2; $i <= 5; $i++) {
                    $photos[] = $line[$attributeMap['photo_' . $i]];
                }
                $this->createProductPhotos($photos, $product);
//                $this->createProductAttribute($line, $attributeMap, $product);
                $index++;
                Log::info("row: [".($index+1)."] percents: [".round(($index/29526)*100, 2).'% ]| SKU: '.$line[0]);
            } catch (Exception $exception) {
                Log::debug($line);
                Log::debug($exception);
                Log::error($exception->getMessage());
            }
        }
        return 0;
    }

    /**
     * @param array $urls
     * @param Product $product
     */
    private function createProductPhotos(array $urls, Product $product)
    {
        foreach ($urls as $url) {
            $saveProductPhoto = FileUploaded::saveProductPhotoByUrl($url);
            if (!empty($saveProductPhoto)) {
                $product->photos()->create(['path' => $saveProductPhoto, 'name' => basename($url)]);
            }
        }
    }

    private function createProductAttribute($line, $attributeMap, Product $product)
    {
        $attrs = $this->attribute();
        foreach ($attrs as $attrName => $translate) {
            if (!empty($line[$attributeMap[$attrName]])) {
                $values = explode('  ', $line[$attributeMap[$attrName]]);
                foreach ($values as $value) {
                    $productAttributeName = ProductAttributeName::firstOrCreate(['name' => $translate]);
                    ProductAttribute::firstOrCreate(['product_id' => $product->id,
                        'product_attribute_name_id' => $productAttributeName->id,
                        'value' => $value]);
                }
            }
        }
    }

    private function attribute()
    {
        return [
            "acses_tip" => "тип",
            "ochki_aksessuari" => "акксесуары",
            'manufacturer' => "производитель",
            'ochki_komplekte' => 'комплект',
            'gruz_ves' => 'вес',
            'kormuska_ves' => 'вес',
            'poplavki_ves_podgruzki' => 'вес подгрузки',
            'palatki_ves' => 'вес',
            'fish' => 'рыба',
            'podsaki_vid' => 'вид',
            'poplavki_vid' => 'вид',
            'katushka_vmestim_shpuli' => 'вместимость шпули',
            'palatki_vmestimost' => 'вместимость',
            'spalniki_vnutr_material' => 'материал внутри',
            'palatki_vodonepron' => 'водонепроницаемая',
            'palatki_visota' => 'высота',
            'palatki_gabariti' => 'габариты',
            'mebel_upakovka_razmer' => 'размер упоковки',
            'rr_garantia' => 'гарантия',
            'leska_diametr' => 'диаметр',
            'snur_diametr' => 'диаметр',
            'flurokarbon_diametr' => 'диаметр',
            'povodki_diametr' => 'диаметр',
            'prikormka_diametr' => 'диаметр',
            'udilisha_dlina' => 'длина',
            'dlina_mm' => 'длина мм.',
            'poplavki_dlina_mm' => 'длина мм.',
            'vobler_dlina' => 'длина',
            'chechli_dlina' => 'длина',
            'poplavki_dlina' => 'длина',
            'povodki_dlina' => 'длина',
            'sadki_dlina' => 'длина',
            'katushki_dop_shpulya' => 'доп. шпуля',
            'palatki_dopolnitelno' => 'дополнительно',
            'zaglublenie_do' => 'заглубление до',
            'katushki_zap_shpulya' => 'запчасти шпуля',
            'zap_chasti' => 'запчасти',
            'palatki_karkas' => 'карказ',
            'katushki_kolich_podshipn' => 'количество подшипников',
            'podstavki_kolvo_nojek' => 'количество ножек',
            'chechli_kolvo_otsekov' => 'количество отсеков',
            'udilisha_sections' => 'секции',
            'podstavki_kolvo_udilish' => 'количество удилищ',
            'katushka_kompl_postavki' => 'поставки',
            'udilisha_konstrukt' => 'конструкция',
            'mebel_karkas' => 'карказ',
            'mebel_konstrk' => 'конструкция',
            'leska_material' => 'материал',
            'ochki_material_linz' => 'материал линз',
            'ochki_material_opravi' => 'материал оправы',
            'poplavki_material' => 'материал',
            'sadki_material' => 'материал',
            'udilisha_material' => 'материал',
            'snur_material' => 'материал',
            'flurokarbon_material' => 'материал',
            'povodki_material' => 'материал',
            'leska_nagruzka' => 'нагрузка',
            'snur_nagruzka' => 'нагрузка',
            'flurokarbon_nagruzka' => 'нагрузка',
            'povodki_nagruzka' => 'нагрузка',
            'vertlugi_nagruzka' => 'нагрузка',
            'spalniki_napolnenie' => 'наполнение',
            'spalniki_narujn_material' => 'наружный материал',
            'kruchki_razmer' => 'размер',
            'vertlugi_razmer' => 'размер',
            'oborudovan_vid' => 'вид',
            'termosa_tip' => 'тип',
            'osnashchenie' => 'оснащение',
            'katushka_peredat_chislo' => 'предаточное число',
            'ochki_plavaushie' => 'плавучесть',
            'korobki_vid' => 'вид',
            'prikormka_vid' => 'вид',
            'vobler_vid' => 'вид',
            'vobler_zaglublenie' => 'заглубление',
            //'rr_naznachenie' => 'назначение',
            'extrimkam_tip' => 'тип',
            'gol_ubori_ponaznacheniyu' => 'назначение',
            'obuv_ponaznacheniyu' => 'назначение',
            'odejda_ponaznacheniyu' => 'назначение',
            'perchatki_ponaznacheniyu' => 'назначение',
            'gol_ubori_sezon' => 'сезон',
            'obuv_sezon' => 'сезон',
            'odejda_posezonu' => 'сезон',
            'perchatki_sezon' => 'сезон',
            'vobler_plavuchest' => 'плавучесть',
            'blesna_tip' => 'тип',
            'bestfor' => 'лучше для',
            'ochki_polyarizatsiya' => 'поляриазация',
            'obuv_razmer' => 'размер',
            'odejda_razmer' => 'размер',
            'silicon_razmer' => 'размер',
            'vobler_razmer' => 'размер',
            'gol_ub_razmer' => 'размер',
            'perchatki_razmer' => 'размер',
            'mebel_gabariti' => 'габариты',
            'leska_razmotka' => 'размотка',
            'flurokarbon_razmotka' => 'размотка',
            'snur_razmotka' => 'размотка',
            'rastsvetka' => 'расцветка',
            'rozetka_vmestimost' => 'вместимость',
            'rozetka_konstrukciya' => 'конструкция',
            'rozetka_naznachenie' => 'назначение',
            'rozetka_forma' => 'форма',
            'rozetka_leska_tip' => 'тип лески',
            'rozetka_yashchiki_vid' => 'вид ящика',
            'podsaki_ruchka' => 'ручка',
            //'country_of_manufacture' => 'Страна регистрации бренда	',
            'leska_struktura' => 'структура',
            'snur_struktura' => 'структура',
            'flurokarbon_struktura' => 'структура',
            'silicon_siedobniy' => 'съедобный',
            'udilisha_diapazon_po_leske_max' => 'максимальный диопазон по леске',
            'udilisha_diapazon_po_leske' => 'диопазон по леске',
            'udilisha_casting_max' => 'кастинговое макс.',
            'udilisha_casting' => 'кастинговое',
            'pva_tip' => 'тип',
            'udilisha_tip_karp' => 'карповое',
            'udilisha_tip_morskie' => 'морское',
            'udilisha_tip_poplavochnie' => 'попловочное',
            "signalizatori_tip" => 'тип',
            'udilisha_tip_spinning' => 'спининг',
            'udilisha_tip_fider' => 'фидер',
            'zapchasti_kat_tip' => 'тип катушки',
            'zapchasti_udil_tip' => 'тип удилища',
            'instr_tip' => 'тип',
            'katushki_tip' => 'тип',
            'leska_tip' => 'тип',
            'mushki_mater_tip' => 'тип',
            'mebel_tip' => 'тип',
            'rozetka_tip' => 'тип',
            'tip_nodja' => 'тип',
            'odejda_tip' => 'тип',
            'ostastki_tip' => 'тип',
            'podstavki_tip' => 'тип',
            'sumki_tip' => 'тип',
            'udilisha_tip' => 'тип',
            'chehli_tip' => 'тип',
            'snur_tip' => 'тип',
            'flurokarbon_tip' => 'тип',
            'fonari_tip' => 'тип',
            'gaz_oborud_tip' => 'тип',
            'gol_ubori_tip' => 'тип',
            'holodilniki_tip' => 'тип',
            'kemp_razn_tip' => 'тип',
            'kruchki_tip' => 'тип',
            'matrasi_tip' => 'тип',
            'obuv_tip' => 'тип',
            'piknik_tip' => 'тип',
            'posuda_tip' => 'тип',
            'silicon_tip' => 'тип',
            'uhod_ekipir_tip' => 'тип экипировки',
            'vertlugi_tip' => 'тип',
            'zashita_nasek_tip' => 'тип защиты от насекомых',
            'katushka_tiporazmer' => 'типо размер',
            'palatki_vsbore' => 'в сборе',
            'sadki_forma' => 'форма',
            'katushka_friktsion' => 'фракцион',
            'ochki_cvet_linz' => 'цвет линз',
            'ochki_cvet_opravi' => 'цвет оправы',
            'color' => 'цвет',
            'flurokarbon_cvet' => 'цвет',
            'snur_color' => 'цвет',
            'kormuska_tip' => 'тип',
            'shtuk_upk' => 'шт/упк',
        ];
    }
}
