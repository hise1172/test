<?php

namespace App\Console\Commands;

use Illuminate\Support\Facades\Storage;
use App\Models\Product\Product;
use Illuminate\Console\Command;

/**
 * Class ProductImport
 * @package App\Console\Commands
 */
class MigrateProductGalleryToSpatie extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:migrate-gallery-to-spatie';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Product images import to spatie gallery';
    
    protected $filename = 'product-spatie-import.txt';
    
    protected $limit = 5000;



    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $productUpdated = FALSE;
        $lastProductId = 0;

        $id = $this->getLastProductId();
        foreach( Product::with('photos')->where('id', '>', $id)->limit( $this->limit )->get() as $product){
            $productUpdated = TRUE;
            if( count( $product->photos ) ){
                $this->checkAndAdd( $product );
                $this->rememberLastProductId( $product->id );
            }
            $lastProductId = $product->id;
        }

        if( $lastProductId > 0 ){
            $this->rememberLastProductId( $lastProductId );
        }

        if( $productUpdated ){
            $this->info( $this->limit . ' products updated!' );
        }
        else{
            $this->info( 'Nothing to update!' );
        }
    }

    function checkAndAdd( $product )
    {
        $spatieGallery = $product->getMedia();
        foreach( $product->photos as $photo){
            if( $spatieGallery->where('file_name', trim( $photo->path ) )->count() ){
                continue;
            }
            if( Storage::disk('products')->exists( trim( $photo->path ) ) ){
                $spatieGallery->push( 
                    $product
                        ->addMediaFromDisk( trim( $photo->path ) , 'products')
                        ->preservingOriginal()
                        ->toMediaCollection('default','products')
                );
            }
        }
    }

    function rememberLastProductId( $id )
    {
        Storage::disk('local')->put($this->filename, $id);
        $this->info( 'Product #' . $id . ' photos is updated.' );
        return $id;
    }

    function getLastProductId()
    {
        if ( ! Storage::disk('local')->exists($this->filename) ) {
            return $this->rememberLastProductId( 0 );
        }
        $productId = Storage::disk('local')->get($this->filename);
        $this->info( 'Last imported product ID #' . $productId );
        return $productId;
    }

}
