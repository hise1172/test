<?php

namespace App\Console\Commands;

use App\Services\Feeds\Generator;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;

class FeedPromua extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'feed:promua';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Генерация XML файла для PROM.UA';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        App::setLocale('ru');

        $generator = (new Generator()) // Должны выгружаться только товары is_active=1
            ->setFileName('feed/promua-o32aj.xml')
            // ->brandsOnlySlugs('tica', 'strike-pro', 'zeox', 'hayabusa', 'goldencatch') // Один метод: если int то это int, а если string то это slug
            // ->getOldProducts() // Для этого фида мне это не нужно
            // ->productsFromCsv( $this->argument('filename') )
            // ->onlyPhysicalProducs() // Это значит что мы не выгружаем родительские товары: только дочерние или отдельно продаваемые товары&. icludeParetns();
            ->productsAll()
            ->onlyWithMainPhoto()
            // ->onlyWithDescription()
            ->prepareXml()
            ->toXml()
            ;

        if ( $generator ) {
            $this->info($generator->productCounter . ' products writed to XML file.');
        } else {
            throw new \LogicException('Products not found.');
        }

        return Command::SUCCESS;
    }
}
