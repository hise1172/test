<?php

namespace App\Console\Commands;

use App\Models\Product\Product;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

/**
 * Class ProductImport
 * @package App\Console\Commands
 */
class ProductDeleteIframes extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:delete-iframes';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Удаление из descriptions товаров iframe видео';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $i = 0;

        $products = Product::where('description', 'like', '%iframe%')->get();
        foreach ($products as $product) {
            $this->deleteTags( $product, 'ua' );
            $this->deleteTags( $product, 'ru' );
            $i++;
        }

        if( $i > 0 ){
            $this->info( $i . ' товаров найдено и обработано.');
        }
        else{
            $this->error( 'Не найдено товаров для обработки.' );
        }

    }

    private function deleteTags( $product, $language )
    {

        $description = $product->getTranslation('description', $language);

        $description = preg_replace('/<iframe.*?\/iframe>/i', '', $description);
        $description = preg_replace('/<iframe(.*?)>/', '', $description);

        $description = str_replace([
            '<strong>Відео огляд:</strong>',
            '<strong>Видео обзор:</strong>',
            '<strong>Видеобзор:</strong>',
            '<h1>Видео инструкция по сборке</h1>',
            '<h1 style="text-align:center;">Видео инструкция по сборке</h1>',
            '<h1>Видео инструкция</h1>',
        ], '', $description);

        $description = preg_replace('/<strong>Відео огляд.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong>Видео обзор.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong><br \/>Відео огляд.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong><br \/>Видео обзор.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong>         Відео огляд.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong>         Видео обзор.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong>Відеообзор.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong>Видеообзор.*?\/strong>/i', '', $description);



        $description = preg_replace('/<strong>Відео:.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong>Видео:.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong> Відео\:.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong> Видео\:.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong> Відео:.*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong> Видео:.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong>Видеобзор.*?\/strong>/i', '', $description);

        $description = preg_replace('/<strong>Обзор .*?\/strong>/i', '', $description);
        $description = preg_replace('/<strong>Обзор .*?\/strong>/i', '', $description);

        $description = preg_replace('/<span>Відеоінструкція.*?\/span>/i', '', $description);
        $description = preg_replace('/<span>Видеоинструкция.*?\/span>/i', '', $description);

        $description = preg_replace('/<span style="color: #333399;">Відеоінструкція.*?\/span>/i', '', $description);
        $description = preg_replace('/<span style="color: #333399;">Видеоинструкция.*?\/span>/i', '', $description);

        $description = preg_replace('/<span class="txt-colr-navy">Видео:.*?\/span>/i', '', $description);
        $description = preg_replace('/<span class="txt-colr-navy">Відео:.*?\/span>/i', '', $description);

        $description = preg_replace('/<span class="txt-colr-navy">Відео\:.*?\/strong>/i', '', $description);
        $description = preg_replace('/<span class="txt-colr-navy">Видео\:.*?\/strong>/i', '', $description);


        $description = preg_replace('/<h1>Відео огляд.*?\/h1>/i', '', $description);
        $description = preg_replace('/<h1>Видео обзор.*?\/h1>/i', '', $description);

        $description = preg_replace('/<h1> Відео огляд.*?\/h1>/i', '', $description);
        $description = preg_replace('/<h1> Видео обзор.*?\/h1>/i', '', $description);

        $description = preg_replace('/<h1 style="text-align: center;">Відео огляд.*?\/h1>/i', '', $description);
        $description = preg_replace('/<h1 style="text-align: center;">Видео обзор.*?\/h1>/i', '', $description);

        $description = preg_replace('/<h1 style="text-align: center;">Відео огляд.*?\/h1>/i', '', $description);
        $description = preg_replace('/<h1 style="text-align: center;">Видео использования.*?\/h1>/i', '', $description);

        $product->setTranslation('description', $language, $description );
        $product->save();
    }



}
