<?php

namespace App\Console\Commands;

use App\Models\SeoFilters;
use App\Traits\CronJob;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ApplySeoFiltersRatingForCurrentWeek extends Command
{
    use CronJob;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'seo_filter:apply_rating';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Start');

        $effected_rows_count = SeoFilters::query()
        ->update([
            'current_rating' => DB::raw('next_rating'),
            'next_rating' => 0,
        ]);

        $this->info("Updated {$effected_rows_count} filters");

        $this->warn("Don't run it twice in a row. It'll reset all ratings");

        return Command::SUCCESS;
    }
}
