<?php

namespace App\Console\Commands;

use App\Models\NovaPoshta\NovaPoshtaWarehouses;
use App\Services\NovaPoshtaService;

class NovaPoshtaWarehousesCommand extends NovaPoshtaAreaCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'novaposhta:warehouses';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Novaposhta update warehouses';

    /** @var NovaPoshtaWarehouses|string  */
    protected $model_class = NovaPoshtaWarehouses::class;


    #region Getters

    /**
     * @param NovaPoshtaService $service
     *
     * @return array
     */
    protected function getDataFormApi(NovaPoshtaService $service): array
    {
        return $service->getWarehouse();
    }

    /**
     * @return array
     */
    protected function getFieldsMapping(): array
    {
        return [
            'Ref' => 'ref',
            'SiteKey' => 'site_key',
            'Description' => 'description',
            'DescriptionRu' => 'description_ru',
            'TypeOfWarehouse' => 'type_of_warehouse',
            'Number' => 'number',
            'CityRef' => 'city_ref',
            'CityDescription' => 'city_description',
            'CityDescriptionRu' => 'city_description_ru',
            'Longitude' => 'longitude',
            'Latitude' => 'latitude',
            'PostFinance' => 'post_finance',
            'POSTerminal' => 'post_terminal',
            'InternationalShipping' => 'international_shipping',
            'TotalMaxWeightAllowed' => 'total_max_weight_allowed',
            'PlaceMaxWeightAllowed' => 'place_max_weight_allowed',
        ];
    }

    #endregion
}
