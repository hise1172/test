<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Attribute;
use App\Models\AttributeSlugValue;
use App\Models\SemanticRule;

use Illuminate\Console\Command;

class MassSkip extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'seo_filter:skip  {--attributes} {--brands} {--categories}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if( $this->option('attributes') ){
            $attrs = Attribute::all();

            foreach($attrs as $attr){
                SemanticRule::updateOrCreate(
                    ['rulable_id' => $attr->id, 'rulable_type' => 'App\Models\Attribute'],    
                    ['skip' => true]
                );
            }

            $this->info('Skipped: ' . count($attrs) . ' attributes' );
        }

        if( $this->option('brands') ){
            $brands = Brand::all();

            foreach($brands as $brand){
                SemanticRule::updateOrCreate(
                    ['rulable_id' => $brand->id, 'rulable_type' => 'App\Models\Brand'],    
                    ['skip' => true]
                );
            }

            $this->info('Skipped: ' . count($brands) . ' brands' );
        }

        if( $this->option('categories') ){
            $cats = Category::all();

            foreach($cats as $cat){
                SemanticRule::updateOrCreate(
                    ['rulable_id' => $cat->id, 'rulable_type' => 'App\Models\Category'],    
                    ['skip' => true]
                );
            }

            $this->info('Skipped: ' . count($cats) . ' categories' );
        }


        return 0;
    }
}
