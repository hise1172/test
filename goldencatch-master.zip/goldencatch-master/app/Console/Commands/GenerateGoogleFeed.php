<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;
use Vitalybaev\GoogleMerchant\Feed;
use Vitalybaev\GoogleMerchant\Product;
use Vitalybaev\GoogleMerchant\Product\Shipping;
use Vitalybaev\GoogleMerchant\Product\Availability\Availability;
use Illuminate\Support\Facades\Log;

class GenerateGoogleFeed extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'generatefeed:google';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate Google Feed and store it';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $logger = Log::channel('importLog');
        App::setLocale('ru');
        $feed = new Feed("goldencatch.ua", "https://goldencatch.ua", "goldencatch.ua");
        $products = \App\Models\Product\Product::
            where('is_active', 1)
            ->whereNull('SKU_parent')
            ->with('modifications')
            ->get();

        $filtered_products = $products->filter(function ($product, $key) {
            return $product->min_price > 0;
        });

        foreach ($filtered_products as $product) {
            $item = new Product();

            $item->setId($product->id);
            $item->setTitle($product->name);
            $item->setDescription($product->name);
            $item->setLink('https://goldencatch.ua/ru/product/' . $product->main_slug);
            $item->setImage(str_replace('http://goldencatch.test', 'https://goldencatch.ua', $product->photo));
            if ($product->isInStock()) {
                $item->setAvailability(Availability::IN_STOCK);
            } else {
                $item->setAvailability(Availability::OUT_OF_STOCK);
            }
            $item->setPrice("{$product->min_price} UAH");
            // $item->setGoogleCategory($product->category_name);
            $item->setGoogleCategory(3334);
            $item->setBrand($product->brand_name);
            $item->setGtin($product->barcode);
            $item->setCondition('new');

            $feed->addProduct($item);
        }

        // Here we get complete XML of the feed, that we could write to file or send directly
        $feedXml = $feed->build();
        Storage::disk('public')->put('feed/google.xml', $feedXml);
        $logger->info("Google feed generated");

        Storage::disk('public')->put('feed/facebook.xml', $feedXml);
        $logger->info("Facebook feed generated");
    }
}
