<?php

namespace App\Console\Commands;

use App\Models\AttributeSlugValue;
use App\Models\ProductsAttributesNumericValues;
use App\Models\ProductsAttributesSlugValues;
use App\Models\ProductsAttributesTextValues;
use Illuminate\Console\Command;
use App\Models\Attribute;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AttributeMigrate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'attr:migrate {id-from} {id-to}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import attribute to new structure';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $attrIdSource = (int)$this->argument('id-from');
        $attrIdDest = (int)$this->argument('id-to');

        $destAttr = Attribute::find($attrIdDest);
        if (!$destAttr) {
            $this->error('Destination attribute not found');
            return;
        }

        $srcFilterValues = DB::table('product_attributes')
            ->where('product_attribute_name_id', $attrIdSource)
            ->get();
        if (empty($srcFilterValues)) {
            $this->error('Source filter does not have values');
            return;
        }

        switch ($destAttr->filter_type) {
            case Attribute::TYPE_SLUG:
                $this->importSlugValues($destAttr, $srcFilterValues);
                break;
            case Attribute::TYPE_NUMERIC:
                $this->importNumericValues($destAttr, $srcFilterValues);
                break;
            case Attribute::TYPE_TEXT:
                $this->importTextValues($destAttr, $srcFilterValues);
                break;
            default:
                $this->error('Destination attribute has invalid filter_type');
                return;
        }

        $this->info('Attribute migration completed');
    }

    private function importSlugValues(Attribute $destAttr, Collection $srcFilterValues)
    {
        foreach ($srcFilterValues as $srcFilterValue) {
            $valueSlug = Str::lower(Str::ascii($srcFilterValue->value));
            if (empty($valueSlug)) {
                continue;
            }

            $existsSlugValue = AttributeSlugValue::query()
                ->where('attribute_id', $destAttr->id)
                ->where('slug', $valueSlug)
                ->first();
            if (!$existsSlugValue) {
                $existsSlugValue = new AttributeSlugValue();
                $existsSlugValue->attribute_id = $destAttr->id;
                $existsSlugValue->slug = $valueSlug;
                $existsSlugValue->value = ['ua' => $srcFilterValue->value, 'ru' => $srcFilterValue->value];
                $existsSlugValue->save();
            }

            $existsValueRelations = ProductsAttributesSlugValues::query()
                ->where('product_id', $srcFilterValue->product_id)
                ->where('attribute_slug_value_id', $existsSlugValue->id)
                ->first();
            if (!$existsValueRelations) {
                $existsValueRelations = new ProductsAttributesSlugValues();
                $existsValueRelations->product_id = $srcFilterValue->product_id;
                $existsValueRelations->attribute_slug_value_id = $existsSlugValue->id;
                $existsValueRelations->save();
            }
        }
    }

    private function importNumericValues(Attribute $destAttr, Collection $srcFilterValues)
    {
        foreach ($srcFilterValues as $srcFilterValue) {
            $value = (float)$srcFilterValue->value;

            $existsValueRelation = ProductsAttributesNumericValues::query()
                ->where('product_id', $srcFilterValue->product_id)
                ->where('attribute_id', $destAttr->id)
                ->where('value', $value)
                ->first();
            if (!$existsValueRelation) {
                $existsValueRelation = new ProductsAttributesNumericValues();
                $existsValueRelation->product_id = $srcFilterValue->product_id;
                $existsValueRelation->attribute_id = $destAttr->id;
                $existsValueRelation->value = $value;
                $existsValueRelation->save();
            }
        }
    }

    private function importTextValues(Attribute $destAttr, Collection $srcFilterValues)
    {
        foreach ($srcFilterValues as $srcFilterValue) {
            if (empty($srcFilterValue->value)) {
                continue;
            }

            ProductsAttributesTextValues::query()
                ->where('product_id', $srcFilterValue->product_id)
                ->where('attribute_id', $destAttr->id)
                ->delete();

            $valueRelation = new ProductsAttributesTextValues();
            $valueRelation->product_id = $srcFilterValue->product_id;
            $valueRelation->attribute_id = $destAttr->id;
            $valueRelation->value = ['ua' => $srcFilterValue->value, 'ru' => $srcFilterValue->value];
            $valueRelation->save();
        }

    }

}
