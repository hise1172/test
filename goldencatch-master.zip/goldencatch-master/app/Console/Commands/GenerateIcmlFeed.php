<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\App;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

use App\Models\Product\Product;
use App\Models\Category;

use Spatie\ArrayToXml\ArrayToXml;

class GenerateIcmlFeed extends Command
{
    protected $signature = 'feed:icml';

    protected $description = 'ICML generation command';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $logger = Log::channel('importLog');
        App::setLocale('ru');
        $categories_array = [];
        $products_array = [];
        $time = Carbon::now();

        $categories = Category::get();

        foreach ($categories as $category) {
            array_push($categories_array, [
                [
                    '_attributes' => [
                        'id' => $category->id
                    ],
                    '_value' => $category->name
                ]
            ]);
        }

        $products_array = [];

        $products_count = Product::count();

        $bar = $this->output->createProgressBar($products_count);
        $bar->start();
        $key = 0;

        Product::chunk(5000, function ($products) use (&$products_array, $bar, &$key) {

                foreach ($products as $product) {
                    $products_array[$key] = [
                        '_attributes' => [
                            'id' => $product->id,
                            'productId' => $product->id,
                            'quantity' => $product->stock
                        ],
                        'url' => 'https://goldencatch.ua/ru/product/' . $product->slug,
                        'price' => $product->price,
                        'purchasePrice' => $product->wholesale_price_uah_15 ?? $product->price,
                        'categoryId' => $product->category_id,
                        'xmlId' => $product->SKU,
                        'productName' => $product->name,
                        'name' => $product->name,
                        'weight' => $product->weight,
                        'barcode' => $product->barcode,
                        'param' => [
                            "_attributes" => [
                                "name" => "Артикул",
                                "code" => "article",
                            ],
                            "_value" => $product->SKU
                        ],
                        'vendor' => $product->brand_name ?? '',
                    ];

                    // добавляем фото
                    try {

                        $photos = [$product->photo];

                        foreach ($product->getMedia() as $photo) {
                            $photos[] = asset($photo->getUrl());
                        }

                        if ($product->parent_id && $product->parentProduct) {
                            foreach ($product->parentProduct->getMedia() as $photo) {
                                $photos[] = asset($photo->getUrl());
                            }
                        }

                        $photo_index = 0;
                        foreach ($photos as $photo) {
                            $photo_index++;
                            $products_array[$key]['picture_delete_' . $photo_index] = $photo;
                        }

                    } catch (\BadMethodCallException $exception) {
                        // $this->error ( 'BadMethodCallException for ProductId ' . $product->id );
                    } catch (\BadFunctionCallException $exception) {
                        // $this->error( 'BadFunctionCallException for ProductId ' . $product->id );
                    } catch (\Throwable $exception) {
                        // $this->error( 'Throwable for ProductId ' . $product->id );
                    } catch (\Exception $exception) {
                        // $this->error( 'Exception for ProductId ' . $product->id );
                    }


                    // добавляем атрибуты
                    $attributes = $product->desc_attr;

                    if ($product->parent_id && $product->parentProduct) {
                        $attributes = array_merge($attributes, $product->parentProduct->desc_attr);
                    }

                    $attr_index = 0;
                    foreach ($attributes as $attr_name => $attr_values) {
                        if( !is_array($attr_values) ){
                            $attr_values = [ $attr_values ];
                        }

                        foreach ($attr_values as $attr_value) {
                            $attr_index++;
                            $products_array[$key]['param_delete_' . $attr_index] = [
                                "_attributes" => [
                                    "name" => $attr_name
                                ],
                                '_cdata' =>  strval($attr_value)
                            ];
                        }
                    }
                    $key++;
                    $bar->advance();
                }

            }); //end foreach

            $bar->finish();


        $array = [
            'shop' => [
                'name' => 'Golden Catch',
                'company' => 'Golden Catch',
                'categories' => [
                    'category' => $categories_array
                ],
                'offers' => [
                    'offer' => $products_array
                ]
            ]
        ];

        $arrayToXml = new ArrayToXml($array, [
            'rootElementName' => 'yml_catalog',
            '_attributes' => [
                'date' => $time->toDateTimeString(),
            ],
        ], true, 'UTF-8');

        $arrayToXml->setDomProperties(['formatOutput' => true]);
        $temp_result = $arrayToXml->prettify()->toXml();

        $result = preg_replace('/_delete_\d+/', '', $temp_result); // Удаляем временные строки

        Storage::disk('public')->put('feed/icml-6q8w9r7t4y6.xml', $result);
        $logger->info("ICML feed generated");
    }
}
