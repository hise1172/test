<?php

namespace App\Console\Commands;

use App\Models\Product\Product;
use Illuminate\Console\Command;

class NewImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:newimport';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $file = fopen('FullExport.csv', 'r');
        $arr=[];
        if (!$file) {
            return -1;
        }
        $attributeMap = [];
        $index = 0;
        while (!feof($file) && ($line = fgetcsv($file, 0, ';', '"'))) {
            if (empty($attributeMap)) {
                foreach ($line as $key => $value) {

                    $attributeMap[$value] = $key;
                }
                continue;
            }

            $sku = $line[$attributeMap['sku']];
            $product=Product::where('SKU',$sku)->first();

            if(isset($product)){
                    array_push($arr,$product->id);
                    if(!empty($line[$attributeMap['weight']])){
                        $product->weight=str_replace(',','.',$line[$attributeMap['weight']]);
                    }

                $product->width=$line[$attributeMap['width']];
                $product->height=$line[$attributeMap['height']];
                $product->depth=$line[$attributeMap['depth']];
                $product->volume=$line[$attributeMap['volume']];
                $product->brutto=$line[$attributeMap['brutto']];
                $product->netto=$line[$attributeMap['netto']];
                $product->price=number_format((float)$line[$attributeMap['price']], 2, '.', '');
                $product->stock=$line[$attributeMap['qty']];
                $product->stock_opt=$line[$attributeMap['opt_qty']];
                $product->stock_price=number_format((float)$line[$attributeMap['special_price']], 2, '.', '');
                $product->retail=$line[$attributeMap['avail']];
                $product->wholesale=$line[$attributeMap['availopt']];
                $product->barcode=$line[$attributeMap['barcode']];
                $product->wholesale_price_uah=$line[$attributeMap['group_price:Опт 0%']];
                $product->wholesale_price_uah_5=$line[$attributeMap['group_price:Опт -5%']];
                $product->wholesale_price_uah_10=$line[$attributeMap['group_price:Опт -10%']];
                $product->wholesale_price_uah_15=$line[$attributeMap['group_price:Опт -15%']];
                $product->wholesale_usd=$line[$attributeMap['group_price:Опт 0% USD']];
                $product->wholesale_usd_5=$line[$attributeMap['group_price:Опт -5% USD']];
                $product->wholesale_usd_10=$line[$attributeMap['group_price:Опт -10% USD']];
                $product->wholesale_usd_15=$line[$attributeMap['group_price:Опт -15% USD']];
                $product->save();
            }

        }
        $count_products=Product::count();
        for($i=0;$i<=$count_products;$i++){
            $product=Product::find($i);
            if($product){
                if(!in_array($product->id,$arr)){
                    $product->stock=0;
                    $product->stock_opt=0;
                    $product->save();
                }
            }
        }
    }
}
