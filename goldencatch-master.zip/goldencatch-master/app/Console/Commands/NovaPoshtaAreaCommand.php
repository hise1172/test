<?php

namespace App\Console\Commands;

use App\Models\NovaPoshta\NovaPoshtaArea;
use App\Models\NovaPoshta\NovaPoshtaCities;
use App\Models\NovaPoshta\NovaPoshtaWarehouses;
use App\Services\NovaPoshtaService;
use App\Traits\CronJob;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Collection;

class NovaPoshtaAreaCommand extends Command
{
    use CronJob;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'novaposhta:area';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Novaposhta update area';

    /** @var NovaPoshtaArea|string  */
    protected $model_class = NovaPoshtaArea::class;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param NovaPoshtaService $service
     * @return void
     */
    public function handle(NovaPoshtaService $service)
    {
        $this->info('Started');

        $response = $this->getDataFormApi($service);

        if (!$response['success']) {
            $this->error('Response error');
            $this->error(print_r($response, true));
            return;
        }

        $this->info('Data collected form API');

        $fields = $this->getFieldsMapping();

        /** @var Collection $available_data */
        $available_data = $this->model_class::query()
            ->whereIn(
                'ref',
                collect($response['data'])->map(fn ($array) => $array['Ref'])->toArray()
            )
            ->get();

        $this->info('Data collected form DB');

        $bar = $this->getProgressBar(count($response['data']));
        $bar->start();

        foreach ($response['data'] as $api_data) {
            $data = [];

            foreach ($api_data as $key => $value) {
                $key = $fields[$key] ?? '';

                if (!$key) {
                    continue;
                }

                if (is_array($value)) {
                    continue;
                }

                $data[$key] = $value;
            }

            /**
             * @see https://developers.novaposhta.ua/view/model/a0cf0f5f-8512-11ec-8ced-005056b2dbe1/method/a1e6f0a7-8512-11ec-8ced-005056b2dbe1
             * @see https://developers.novaposhta.ua/view/model/a0cf0f5f-8512-11ec-8ced-005056b2dbe1/method/a2322f38-8512-11ec-8ced-005056b2dbe1
             * @var NovaPoshtaArea|NovaPoshtaCities|NovaPoshtaWarehouses $model
             */
            $model = $available_data
                ->filter(fn($model) => $model->ref == $api_data['Ref'])
                ->first();

            $model === null
            && $model = new $this->model_class;

            $this->fillModel($model, $data);

            $model->save();

            $bar->advance();
        }

        $bar->finish();
        parent::info("\n");
    }

    #region Getters

    /**
     * Execute the console command.
     *
     * @param NovaPoshtaService $service
     * @return void
     */
    protected function getDataFormApi(NovaPoshtaService $service): array
    {
        return $service->getAreas();
    }

    /**
     * @return array
     */
    protected function getFieldsMapping(): array
    {
        return [
            'Ref' => 'ref',
            'AreasCenter' => 'areas_center',
            'DescriptionRu' => 'description_ru',
            'Description' => 'description',
        ];
    }

    #endregion

    #region Helpers

    /**
     * @param NovaPoshtaArea|NovaPoshtaCities|NovaPoshtaWarehouses $warehouse
     * @param array $data
     */
    protected function fillModel($warehouse, array $data)
    {
        foreach ($data as $property => $value) {
            $warehouse->$property = $value;
        }
    }

    #endregion
}
