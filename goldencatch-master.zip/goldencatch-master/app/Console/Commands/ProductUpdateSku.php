<?php

namespace App\Console\Commands;

use App\Models\Product\Product;
use App\Models\Product\ProductAttribute;
use App\Models\Product\ProductAttributeName;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Class ProductImport
 * @package App\Console\Commands
 */
class ProductUpdateSku extends Command
{
    private $importData = [];
    private $pretend = false;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:update-sku 
        {filename=: File located in ./storage/app/ }
        {--pretend}
        ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update products SKU';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->pretend = $this->option('pretend');

        $this->checkFile();

        $this->getImportData();

        $i = 0;
        foreach ( Product::whereIn( 'SKU', $this->importData->pluck('idOld') )->get() as $product) {
            $newSku = $this->importData->firstWhere('idOld', $product->SKU)['idNew'];
            $oldName = $product->SKU;
            $this->renameNewIdIfExist($newSku);
            $product->SKU = $newSku;
            if( ! $this->pretend ){
                $product->save();
            }
            $this->info('New SKU "' . $newSku . '" for product "' . $product->name . '"(old SKU "' . $oldName . '").');
            $this->importData->forget($oldName);
            $i++;
        }
        
        if( count($this->importData) ){
            foreach ($this->importData as $skuItem) {
                $this->error( 'SKU is not updated idOld = "' . $skuItem['idOld'] . '" idNew = "' . $skuItem['idNew'] . '".');
            }
            $this->info( count( $this->importData ) . ' SKU is not updated.');
        }


        $this->info($i . ' products updated successfully.');

        if ( $this->pretend ) {
            $this->error( 'Data is only pretend to be saved. Option pretend is active.');
        }
    }

    private function renameNewIdIfExist( $sku )
    {
        $product = Product::where('SKU', $sku)->first();
        if( $product ){
            $product->SKU = 'old_' . $product->SKU;
            if ( ! $this->pretend ) {
                $product->save();
            }
            $this->error('SKU "' . $sku . '" renamed to "' . $product->SKU . '" for product "' . $product->name . '".');
        }
    }

    

    private function checkFile()
    {
        if( ! Storage::disk('local')->exists( $this->argument('filename') ) ){
            $this->error('File "' . $this->argument('filename') . '" does not exist.');
            exit;
        }

    }

    private function getImportData()
    {
        $fileContent = Storage::disk('local')->get( $this->argument('filename') );

        if( ! $fileContent ){
            $this->error('File "' . $this->argument('filename') . '" empty.');
            exit;
        }

        array_map(function($row) {
            if( ! $row ){
                return ;
            }
            $data = str_getcsv($row, ',');
            if( isset($data[0], $data[1]) && trim($data[0]) && trim($data[1])){
                $this->importData[] = [
                    'idOld' => trim($data[0]),
                    'idNew' => trim($data[1]),
                ];
            }
        }, explode("\n", $fileContent));

        if( count($this->importData) == 0 ){
            $this->error('Ids in file "' . $this->argument('filename') . '" is not found.');
            exit;
        }

        $this->importData = collect($this->importData)->keyBy('idOld');
    }
}
