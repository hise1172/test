<?php

namespace App\Console\Commands\Promotion;

use App\Services\ApplyPromotion;
use App\User;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Collection;

class ApplyRegistrationBonus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'promo:apply_registration_bonus';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Applies the registration bonus to all users what was registered before now';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        /** @var User[]|Collection $users */
        $users = User::all();

        $i = 0;

        $bar = $this->getProgressBar($users->count());

        $bar->start();

        foreach ($users as $user) {
            ApplyPromotion::onRegistration($user);

            $i ++;

            $bar->advance();
        }

        $bar->finish();
        $this->info("\n");

        return static::SUCCESS;
    }

    /**
     * @param int $count
     *
     * @return \Symfony\Component\Console\Helper\ProgressBar
     */
    private function getProgressBar(int $count = 0)
    {
        $bar = $this->output->createProgressBar($count);
        $bar->setFormat('debug');

        return $bar;
    }
}
