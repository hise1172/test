<?php

namespace App\Console\Commands;

use App\Helpers\FileUploaded;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product\Product;
use App\Models\TypeFishes;
use App\Models\Types;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class ProductWholesaleImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:import-wholesale';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $file = fopen('hansa-opt.csv', 'r');
        if (!$file) {
            return -1;
        }
        $attributeMap = [];
        $index = 0;
        while (!feof($file) && ($line = fgetcsv($file, 0, ';', '"'))) {
            if (empty($attributeMap)) {
                foreach ($line as $key => $value) {
                    switch ($value) {
                        case 'group_price:Опт 0%':
                            $attributeMap['wholesale_usd_0'] = $key;
                            break;
                        case 'group_price:Опт -5%':
                            $attributeMap['wholesale_usd_5'] = $key;
                            break;
                        case 'group_price:Опт -10%':
                            $attributeMap['wholesale_usd_10'] = $key;
                            break;
                        case 'group_price:Опт -15%':
                            $attributeMap['wholesale_usd_15'] = $key;
                            break;
                        default:
                            $attributeMap[$value] = $key;
                    }
                }
                continue;
            }

            try {
                $attributes = [];
                $attributes['SKU'] = $line[$attributeMap['sku']];
                if (!empty(trim($line[$attributeMap['price']]))) {
                    $attributes['price'] = $line[$attributeMap['price']];
                }
                $attributes['wholesale_usd'] = $line[$attributeMap['wholesale_usd_0']];
                $attributes['wholesale_usd_5'] = $line[$attributeMap['wholesale_usd_5']];
                $attributes['wholesale_usd_10'] = $line[$attributeMap['wholesale_usd_10']];
                $attributes['wholesale_usd_15'] = $line[$attributeMap['wholesale_usd_15']];

                Product::where('SKU' , $attributes['SKU'])->update($attributes);
                $index++;
                Log::info("current row: [".($index+1)."]| import: [" . round(($index / 33706) * 100, 2) . '% ]| SKU: ' . $attributes['SKU']);
            } catch (\Exception $exception) {
                Log::debug($line);
                Log::debug($exception);
                Log::error($exception->getMessage());
            }
        }
        return 0;
    }
}
