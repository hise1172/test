<?php

namespace App\Console\Commands;

use App\Console\Commands\FillSeoFilter\GeneratedText;
use App\Models\SeoFilters;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * CLI PROPERTIES:
 * --step=<int> - optional
 * --begin_from_filter_id=<int> - optional, set the parameter, if needs to start a processing from some particular moment
 * --skip_filters=<int> - set how many items the script has to skip before a process starting
 */
class GenerateTextForSeoFilter extends Command
{
    const MAX_ITEMS_COUNT = 1100; // Uses to prevent memory leak issue

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'seo_filter:gen_texts {--step=}? {--begin_from_filter_id=}? {--skip_filters=}?';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    private ?int $begin_from_filter_id = null;
    private ?int $skip_filters_count = null;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->skip_filters_count = $this->option('skip_filters');
        $this->begin_from_filter_id = $this->option('begin_from_filter_id');

        $this->info('Text Generation started');

        $this->handleGeneratedText();

        $this->info('Text Generation completed');

        return 0;
    }

    #region Actions

    /**
     * @return void
     */
    private function handleGeneratedText()
    {
        $step = $this->option('step');

        if (!$step) {
            $this->generatedTextProcess(SeoFilters::STEP_1);
            $this->generatedTextProcess(SeoFilters::STEP_2);
            $this->generatedTextProcess(SeoFilters::STEP_3);
            $this->generatedTextProcess(SeoFilters::STEP_4);

            return;
        }

        switch ($step) {
            case SeoFilters::STEP_1:
            case SeoFilters::STEP_2:
            case SeoFilters::STEP_3:
            case SeoFilters::STEP_4:
                $this->generatedTextProcess($step);
                break;

            default:
                throw new \LogicException('The stap `' . $step . '` is not implemented');
        }
    }

    /**
     * @param int $step
     */
    private function generatedTextProcess(int $step)
    {
        /** @var SeoFilters[]|Collection $filters_list */
        $filters_list = SeoFilters::query()->where('step', $step)->get();

        $this->info('Text Generation Step' . $step . ' started');

        if ($this->skip_filters_count) {
            $filters_list = $filters_list->skip($this->skip_filters_count);
        }

        if ($this->begin_from_filter_id) {
            foreach ($filters_list as $index => $filter) {
                if ($filter->id == $this->begin_from_filter_id) {
                    break;
                }

                unset($filters_list[$index]);
            }
        }

        $bar = $this->getProgressBar($filters_list->count());

        $bar->start();

        foreach ($filters_list as $index => $filter) {
            $this->processGeneratedTextItem($filter);

            $bar->advance();

            if ($bar->getProgress() == static::MAX_ITEMS_COUNT) {
                $command = "php artisan seo_filter:gen_texts --step={$step} --begin_from_filter_id={$filter->id}";

                $this->warn("\nThe process has been reached an Items Count limit. To continue the process \ncall `php artisan {$command}`");

                // Note, the new process could be stopped by commmand `kill <process_id>`, the Ctrl+z will not works
//                exec($command . ' > /dev/null &'); // uncomment to turn on recall the cron in new process.

                return;
            }

            unset($filters_list[$index], $filter);
        }

        $bar->finish();
        $this->info("\n");

        return;
    }

    /**
     * @param SeoFilters $seo_filter
     */
    private function processGeneratedTextItem(SeoFilters $seo_filter)
    {
        GeneratedText::factory($seo_filter)
            ->save();

        DB::flushQueryLog();
        DB::connection()->unsetEventDispatcher();
        DB::connection()->reconnect();
    }

    #endregion

    #region Getters

    /**
     * @param int $count
     *
     * @return \Symfony\Component\Console\Helper\ProgressBar
     */
    private function getProgressBar(int $count = 0)
    {
        $bar = $this->output->createProgressBar($count);
        $bar->setFormat('debug');

        return $bar;
    }

    #endregion

    #region Helpers

    /**
     * @param $message
     * @param $verbosity
     *
     * @return void
     */
    public function info($message, $verbosity = null)
    {
        parent::info('[' . date('Y-m-d H:i:s') . '] ' . $message, $verbosity);
    }

    #endregion
}
