<?php

namespace App\Console\Commands;

use App\Services\ChatBot;
use Illuminate\Console\Command;

class SetupTelegramWebhookCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'telegram:setup_webhook';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return void
     */
    public function handle()
    {
        $bot = ChatBot::factory(ChatBot::TELEGRAM_ID);

        $bot->setupWebhook();

        $this->info('Telegram webhook has been setup successfully');
    }
}
