<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\App;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

use App\Models\Product\Product;
use App\Models\Category;

use Spatie\ArrayToXml\ArrayToXml;

class GenerateHotlineFeed extends Command
{
    protected $signature = 'feed:hotline';

    protected $description = 'Генерация выгрузки для Hotline';

    private $companyName = 'Golden Catch';
    
    private $companyHotlineId = 38940;


    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        App::setLocale('ru');
        $logger = Log::channel('importLog');
        $time = Carbon::now();
        
        $categories = $this->getCategories();
        $products = $this->getProducts();
        
        $array = [
            'date' => $time->toDateTimeString('minute'),
            'firmName' => $this->companyName,
            'firmId' => $this->companyHotlineId,
            'categories' => [
                'category' => $categories
            ],
            'items' => [
                'item' => $products
                ]
            ];
            
            $arrayToXml = new ArrayToXml($array, [
                'rootElementName' => 'price',
            ], true, 'UTF-8');
            
            $arrayToXml->setDomProperties(['formatOutput' => true]);
            $result = $arrayToXml->prettify()->toXml();
            
            Storage::disk('public')->put('feed/hotline.xml', $result);
            
            $logger->info("Hotline feed generated");
            
            $this->info("Hotline feed generated");
        }
        
        public function getCategories()
        {
            $categories = [];
            foreach (Category::select('id', 'name')
            ->get() as $category) {
                $categories[] = [
                    'id' => $category->id,
                    'name' => $category->name,
                ];
            }
            return $categories;
        }
        
        public function getProducts()
        {
            $products_collection = Product::with(['brand:id,name', 'parentProduct:id,slug'])
            ->whereNotNull('price')
            ->whereNotNull('brand_id')
            ->where('stock', '>', 0)
            ->get();
            
            $products = [];
            
            foreach ( $products_collection as $key => $product) {
                
            $products[$product->id] = [
                    'id' => $product->id,
                    'categoryId' => $product->category_id,
                    'code' => $product->SKU,
                    'vendor' => $product->brand->name,
                    'name' => $product->name,
                    'description' => strip_tags( $product->short_description ),
                    'url' => route('product', ['product' => ('' != $product->parent_id ? $product->parentProduct->slug : $product->slug) ]),
                    'image' => asset( $product->photo ),
                    'priceRUAH' => $product->price,
                ];
            if( $product->barcode){
                $products[$product->id]['barcode'] = $product->barcode; 
            }
        }

        return $products;
    }
}
