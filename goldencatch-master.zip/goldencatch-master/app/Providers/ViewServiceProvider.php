<?php

namespace App\Providers;

use App\Helpers\Cart;
use App\Helpers\UniqueCollection;
use App\Repositories\ProductFavoriteRepository;
use App\Services\Menu\MenuBuilder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;
use App\Services\CompareProductService;
use Illuminate\View\View;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        Session::forget('cart');

        if (app()->runningInConsole()) {
            return;
        }

        view()->composer('*', function (View $view) {
            /** @var Cart $cart */
            $cart = Session::get('cart', new Cart());
            /** @var ProductFavoriteRepository $repository */
            $repository = resolve(ProductFavoriteRepository::class);

            $view->with('favorite_count', $repository->getCountFavorite(Auth::id()))
                ->with('compare_count', Session::get('compare_products', new UniqueCollection())->count())
                ->with('cart_count', $cart->count())
                ->with('cart', $cart->productCart($this->app->request->isResellersConsole ?? false)) // Jobs do not have a request data
                ->with('compare_products', (new CompareProductService())->getComparesProduct())
                ->with('headerMenu', app()->make(MenuBuilder::class)->get('headerMenu'))
                ->with('catalogMenu', app()->make(MenuBuilder::class)->get('catalogMenu'));
        });
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
