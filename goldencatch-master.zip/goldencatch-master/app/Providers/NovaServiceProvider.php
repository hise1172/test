<?php

namespace App\Providers;

use Laravel\Nova\Nova;
use Illuminate\Http\Request;
use Laravel\Nova\Cards\Help;
use App\Nova\Dashboards\Main;
use Laravel\Nova\Menu\MenuItem;
use Laravel\Nova\Menu\MenuSection;
use Illuminate\Support\Facades\Gate;
use Laravel\Nova\NovaApplicationServiceProvider;

class NovaServiceProvider extends NovaApplicationServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        Nova::style('admin', asset('css/nova-admin.css'));

        Nova::mainMenu(function (Request $request) {
            return [
                MenuSection::dashboard(Main::class)->icon('chart-bar'),

                MenuSection::make('Продажі', [
                    MenuItem::resource(\App\Nova\Order::class),
                    MenuItem::resource(\App\Nova\UserProductReview::class),
                    MenuItem::resource(\App\Nova\ProductQuestionAnswer::class),
                ])->icon('credit-card')->collapsable(),

                MenuSection::make('Каталог', [
                    MenuItem::resource(\App\Nova\Product::class),
                    MenuItem::resource(\App\Nova\Category::class),
                    MenuItem::resource(\App\Nova\Brand::class),
                    MenuItem::resource(\App\Nova\Attribute::class),
                    MenuItem::resource(\App\Nova\AttributeSlugValue::class),
                ])->icon('collection')->collapsable(),

                MenuSection::make('Маркетинг', [
                    MenuItem::resource(\App\Nova\LandingPageResource::class),
                    MenuItem::resource(\App\Nova\Promotion::class),
                    MenuItem::resource(\App\Nova\StatisticsBonus::class),
                ])->icon('sparkles')->collapsable(),

                MenuSection::make('SEO', [
                    MenuItem::resource(\App\Nova\Errors::class),
                    MenuItem::resource(\App\Nova\Redirect::class),
                    MenuItem::resource(\App\Nova\SeoFilters::class),
                    MenuItem::resource(\App\Nova\SemanticRule::class),
                ])->icon('cursor-click')->collapsable(),

                MenuSection::make('Користувачі', [
                    MenuItem::resource(\App\Nova\User::class),
                    MenuItem::resource(\App\Nova\UserRole::class),
                    MenuItem::resource(\App\Nova\BotUser::class),
                ])->icon('users')->collapsable(),
            ];
        });

        Nova::serving(function () {
            Nova::translations('./resources/lang/vendor/nova/ua.json');
        });
    }

    /**
     * Register the Nova routes.
     *
     * @return void
     */
    protected function routes()
    {
        Nova::routes()
                ->withAuthenticationRoutes()
                ->withPasswordResetRoutes()
                ->register();
    }

    /**
     * Register the Nova gate.
     *
     * This gate determines who can access Nova in non-local environments.
     *
     * @return void
     */
    protected function gate()
    {
        Gate::define('viewNova', function ($user) {
            return $user->user_role_id == 9;
        });
    }

    /**
     * Get the cards that should be displayed on the default Nova dashboard.
     *
     * @return array
     */
    protected function cards()
    {
        return [
            new Help,
        ];
    }

    /**
     * Get the extra dashboards that should be displayed on the Nova dashboard.
     *
     * @return array
     */
    protected function dashboards()
    {
        return [
            new Main
        ];
    }

    /**
     * Get the tools that should be listed in the Nova sidebar.
     *
     * @return array
     */
    public function tools()
    {
        return [
            new \Bakerkretzmar\NovaSettingsTool\SettingsTool,
            new \Outl1ne\MenuBuilder\MenuBuilder,
        ];
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
