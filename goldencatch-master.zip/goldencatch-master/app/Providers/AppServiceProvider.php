<?php

namespace App\Providers;

use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

/**
 * Class AppServiceProvider
 *
 * @package App\Providers
 */
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(\App\StaticSettings::class, function () {
            return \App\StaticSettings::make(storage_path('app/settings.json'));
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Carbon::setLocale(App::getLocale());
        \Spatie\NovaTranslatable\Translatable::defaultLocales(['ru', 'ua']);

        if(strtolower(substr(env('APP_URL'), 0, 5)) === 'https') {
            URL::forceScheme('https');
        }

        Blade::if('allow_quick_orders', function () {
            return config('app.allow_quick_orders');
        });

        Blade::if('allow_help_with_orders', function () {
            return config('app.allow_help_with_orders');
        });

        Blade::if('need_call_by_default', function () {
            return config('app.need_call_by_default');
        });
    }
}
