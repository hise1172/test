<?php

namespace App\User;

use Illuminate\Support\Facades\Log;
use LogicException;
use InvalidArgumentException;

/**
 * Class LogAction
 *
 * @package App\User
 *
 * @method self startResetPassByEmail(string $performed_on_url = '')
 * @method self startResetPassBySMS(string $performed_on_url = '')
 * @method self reachedResetPassURL(string $performed_on_url = '')
 * @method self doneResetPass(string $performed_on_url = '')
 * @method self startRegistration(string $performed_on_url = '')
 * @method self failedRegistration(string $performed_on_url = '')
 * @method self doneRegistration(string $performed_on_url = '')
 * @method self failedLogin(string $performed_on_url = '')
 * @method self successLogin(string $performed_on_url = '')
 */
class LogAction
{
    private const CENNAL_USER_ACTIONS = 'userActionsLog';

    private const REGISTATION_START = 'startRegistration';
    private const REGISTATION_FAILED = 'failedRegistration';
    private const REGISTATION_DONE = 'doneRegistration';

    private const LOGIN_FAILED = 'failedLogin';
    private const LOGGED_IN_SUCCESSFULLY = 'successLogin';

    private const RESET_PASS_BY_EMAIL_START = 'startResetPassByEmail';
    private const RESET_PASS_BY_SMS_START = 'startResetPassBySMS';
    private const RESET_PASS_URL_REACHED = 'reachedResetPassURL';
    private const RESET_PASS_DONE = 'doneResetPass';

    private string $user_id_str;
    private string $performed_on_url = '';

    #region Magic methods

    private function __construct(string $user)
    {
        $this->user_id_str = $user;
    }

    public function __call($name, $arguments)
    {
        switch ($name) {
            case static::REGISTATION_START:
            case static::REGISTATION_FAILED:
            case static::REGISTATION_DONE:
            case static::LOGIN_FAILED:
            case static::LOGGED_IN_SUCCESSFULLY:
            case static::RESET_PASS_BY_EMAIL_START:
            case static::RESET_PASS_BY_SMS_START:
            case static::RESET_PASS_URL_REACHED:
            case static::RESET_PASS_DONE:
                $this->log(
                    $name,
                    ($arguments) ? array_shift($arguments) : ''
                );

                return $this;

            default:
                throw new LogicException('Method ' . $name . ' does not exist');
        }
    }

    #endregion

    #region Builders

    /**
     * @param string $user_id_str
     *
     * @return static
     */
    public static function init(string $user_id_str)
    {
        return new static($user_id_str);
    }

    #endregion

    #region Updates methods

    private function log(string $action_name, string $performed_on_url = '')
    {
        $performed_on_url = $performed_on_url ?: $this->performed_on_url;

        Log::channel(static::CENNAL_USER_ACTIONS)
            ->info("action: '{$action_name}' | email/phone: '{$this->user_id_str}' | performed_url: '{$performed_on_url}'");
    }

    #endregion

    #region Setters

    /**
     * @param string $performed_on_url
     *
     * @return $this
     */
    public function setPerformedOnURL(string $performed_on_url): self
    {
        if (!$performed_on_url) {
            throw new InvalidArgumentException('Invalid $performed_on_url');
        }

        $this->performed_on_url = $performed_on_url;

        return $this;
    }

    #endregion
}
