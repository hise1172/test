<?php

namespace App\Traits;

use App\Services\Catalog\Repository;
use App\Services\Catalog\Routing\RouteParams;

trait SearchInCatalog
{
    /**
     * @return Repository
     */
    protected function getCatalog()
    {
        $route_params = new RouteParams();
        $route_params->initFromExistsSetup($this->getRouteParams());

        $catalog = (new Repository($route_params));

        $this->prepareCatalog($catalog);

        return $catalog;
    }

    /**
     * Returns parameters to filter products in catalog and check a count of them.
     *
     * @return array[]
     * [
     *      [
     *          'slug' => string,
     *          'position' => int,
     *          'values' => array,
     *      ],
     *      ...
     * ]
     */
    protected function getRouteParams(): array
    {
        return [];
    }

    /**
     * @param Repository $catalog
     */
    protected function prepareCatalog(Repository $catalog)
    {
        // $catalog->setCategoryId($category_id);
    }
}
