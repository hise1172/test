<?php

namespace App\Traits;

trait CronJob
{
    /**
     * @param $string
     * @param $verbosity
     *
     * @return void
     */
    public function info($string, $verbosity = null)
    {
        parent::info('[' . date('Y-m-d H:i:s') . '] ' . $string, $verbosity);
    }

    /**
     * @param int $count
     *
     * @return \Symfony\Component\Console\Helper\ProgressBar
     */
    private function getProgressBar(int $count = 0)
    {
        $bar = $this->output->createProgressBar($count);
        $bar->setFormat('debug');

        return $bar;
    }
}
