<?php

namespace App\Traits;

use App\Models\Translate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\App;

/**
 * Trait Translatable
 * add translate array to model with columns to translate
 * add $with translatable to lazy load translates
 * @package App\Traits
 * @property array $translate
 * @property Collection translatable
 */
trait Translatable
{
    /**
     * @return MorphMany
     */
    public function translatable()
    {
        /**
         * @var Model $this
         */
        return $this->morphMany(Translate::class, 'translatable');
    }

    /**
     * Add translate column
     * @param string $name column translated
     * @param string $value translated value
     * @param string|null $lang lang(en, ua), default lang don't use
     * @return bool if success add return true
     */
    public function setTranslate(string $name, string $value, string $lang = null)
    {
        //if locale isn't default lang or null set current locale
        if (!in_array($name, $this->translate)) return false;
        if ($lang == config('app.default_locale')) return false;
        if (empty($lang) && App::getLocale() != config('app.default_locale')) {
            $lang = App::getLocale();
        }
        if (!in_array($lang, config('app.all_locale'))) return false;


        $translate = new Translate(compact('name', 'lang', 'value'));
        /**
         * @var Model $this
         */
        $translate->translatable()->associate($this);
        if ($this->translatable()->updateOrCreate($translate->only(['translatable_id', 'translatable_type', 'name', 'lang']),
            $translate->getAttributes())) return true;
        return false;
    }

    /**
     * Get translate attribute
     * @param string $name
     * @param string $lang
     * @return Model|MorphMany|object|null
     */
    public function getTranslate(string $name, string $lang)
    {
        if (!in_array($name, $this->translate)) return null;
        if ($lang == config('app.locale'))
            return $this->attributes[$name];
        $translate = $this->translatable()
            ->where('lang', $lang)
            ->where('name', $name)
            ->first();
        if (!$translate) return null;
        return $translate->getAttribute('value');
    }

    /**
     * Return attribute with current lang
     * @param $name
     * @return mixed
     */
    public function __get($name)
    {
        if ($this->relationLoaded('translatable') && in_array($name, $this->translate)) {
            $translate = $this->translatable()
                ->where('lang', '=', App::getLocale())
                ->where('name', '=', $name)
                ->first();
            if (!empty($translate))
                return $translate['value'];
        }
        if (!in_array($name, $this->attributesToArray()))
            return parent::__get($name);
        /**
         * @var Model $this
         */
        return $this->attributes[$name];
    }
}
