<?php


namespace App\DTOs\Product;

use App\Models\Category;

/**
 * Class ProductFilterDTO
 * Product filters
 * @package App\DTOs\Product
 */
class ProductFilterDTO
{
    /**
     * @var $brand array product brands
     */
    private $brand;

    /**
     * @var $weight array product weight min, max
     */
    private $weight;
    /**
     * @var $types array product types
     */
    private $types;
    /**
     * @var $type_fishes array product type fishes
     */
    private $type_fishes;
    /**
     * @var $category int product category_id
     */
    private $category;
    /**
     * @var $price array product price min,max
     */
    private $price;
    /**
     * @var $sort array product sort column and sort type(asc, desc)
     */
    private $sort;
    private $search;

    /**
     * Get sort
     * @return array [column] [by]
     */
    public function getSort()
    {
        return $this->sort;
    }

    /**
     * Set sort
     * @param $column string column sort
     * @param $type string type sort(asc, desck)
     * @return ProductFilterDTO
     */
    public function setSort($column, $type)
    {
        if ($column == null)
            return $this;
        $this->sort = compact('column', 'type');
        return $this;
    }

    /**
     * Get weight min max
     * @return array
     */
    public function getWeight()
    {
        return $this->weight;
    }

    /**
     * Get type fishes
     * @return array
     */
    public function getTypeFishes()
    {
        return $this->type_fishes;
    }

    /**
     * Set type fishes
     * @param $type_fishes array
     * @return ProductFilterDTO
     */
    public function setTypeFishes($type_fishes)
    {
        if ($type_fishes == null)
            return $this;
        $this->type_fishes = explode(',', $type_fishes);
        return $this;
    }

    /**
     * Get weight
     * @param $weight string min,max
     * @return ProductFilterDTO
     */
    public function setWeight($weight)
    {
        if ($weight == null)
            return $this;
        $this->weight = preg_split('~,~', $weight);
        return $this;
    }

    /**
     * Set types
     * @param $types string
     * @return ProductFilterDTO
     */
    public function setType($types)
    {
        if ($types == null)
            return $this;
        $this->types = explode(',', $types);
        return $this;
    }

    /**
     * Get types
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }

    /**
     * Set brands
     * @param $brand string
     * @return ProductFilterDTO
     */
    public function setBrand($brand)
    {
        if ($brand == null)
            return $this;
        $this->brand = explode(',', $brand);
        return $this;
    }

    /**
     * Get brands
     * @return array
     */
    public function getBrand()
    {
        return $this->brand;
    }

    /**
     * Get category
     * @return int
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * Set category
     * @param $category Category
     * @return ProductFilterDTO
     */
    public function setCategory($category)
    {
        if ($category == null)
            return $this;
        $this->category = $category->id;
        return $this;
    }

    /**
     * Get price
     * @return array min,max
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set price
     * @param $price string
     * @return ProductFilterDTO
     */
    public function setPrice($price)
    {
        if ($price == null)
            return $this;
        $this->price = preg_split('~,~', $price);
        return $this;
    }

    /**
     * @return mixed
     */
    public function getSearch()
    {
        return $this->search;
    }

    /**
     * @param mixed $search
     * @return ProductFilterDTO
     */
    public function setSearch($search): ProductFilterDTO
    {
        $this->search = $search;
        return $this;
    }

}
