<?php

namespace App\Http\Livewire;

use App\Helpers\Cart;
use App\Models\UserPromotion;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Livewire\Component;
use Livewire\Request as LivewireRequest;
use Livewire\Response as LivewireResponse;

class Checkout extends Component
{
    public $use_bonuses;

    /**
     * @param LivewireRequest $response
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function dehydrate(LivewireResponse $response)
    {
        if ($this->use_bonuses === null) {
            $this->use_bonuses = $this->getCart()->getDiscount() ?: null;
        }

        if ($this->use_bonuses > $this->getBonusesBalance()) {
            $correct_discount = $this->getCart()->getDiscount() - $this->use_bonuses;
            $this->use_bonuses = 0;

            $this->getCart()->applyDiscount(
                $correct_discount < 0 ? 0 : $correct_discount
            );
        }
    }

    public function render(Request $request)
    {
        $cart = $this->getCart()->productCart($request->isResellersConsole);

        return view('livewire.checkout')
            ->with([
                'products' => $cart['products'],
                'available_bonuses' => $this->getBonusesBalance(),
                'summ' => $cart['summ'],
                'total_summ' => $cart['total_summ'],
                'currency_symbol' => $cart['currency_symbol'],
                'discount' => $this->getCart()->getDiscount(),
                'applied_promos' => $this->getAppliedPromos(),
            ]);
    }

    #region Actions

    /**
     * @param string $propertyName
     */
    public function updated($propertyName)
    {
        $rules = [
            'use_bonuses' => 'integer|max:' . $this->getBonusesBalance(),
        ];

        $this->validate($rules, [
            'max' => __('order.form_error.use_bonuses'),
        ]);

        switch ($propertyName) {
            case 'use_bonuses';
                $this->getCart()->applyDiscount($this->use_bonuses ?: 0);
                break;
        }
    }

    #endregion

    #region Getters

    /**
     * @return Cart
     */
    private function getCart()
    {
        $cart = Session::get('cart');

        if ($cart) {
            return $cart;
        }

        $cart = new Cart();

        Session::put('cart', $cart);

        return $cart;
    }

    /**
     * @return int
     */
    private function getBonusesBalance(): int
    {
        /** @var User $user */
        $user = \Auth::user();

        if (!$user) {
            return 0;
        }

        return (int) $user->getTotalAvailableBonuses(
            $this->getCart()->getTotalSumm()->UAH
        );
    }

    /**
     * Returns available promos for a user but the promos conditions do not compare to a current cart
     *
     * @return array
     */
    private function getAppliedPromos(): array
    {
        /** @var User $user */
        $user = \Auth::user();

        if (!$user) {
            return [];
        }

        $result = [];

        $user_promos = $user->getAppliedPromos()
            ->filter(fn (UserPromotion $user_promo) => $user_promo->promotion->min_cart_amount > $this->getCart()->getTotalSumm()->UAH);

        foreach ($user_promos as $user_promo) {
            $result[$user_promo->promotion->min_cart_amount] = ($result[$user_promo->promotion->min_cart_amount] ?? 0) + $user_promo->getDiscount();
        }

        return $result;
    }

    #endregion
}
