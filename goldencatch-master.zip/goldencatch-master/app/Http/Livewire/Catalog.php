<?php

namespace App\Http\Livewire;

use App\DataContainers\Catalog\Breadcrumb;
use App\Helpers\Cart;
use App\Models\AttributeSlugValue;
use App\Models\Brand;
use App\Models\Category;
use App\Services\Catalog\CatalogService;
use App\Services\Catalog\Pricing;
use App\Services\Catalog\Repository as CatalogRepository;
use App\Services\Catalog\Routing\RouteParam;
use App\Services\Catalog\Routing\RouteParams;
use App\Services\Catalog\Routing\UrlBuilder;
use App\Helpers\SeoFilters;
use App\Services\SeoFilterTrackRating;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\Request as LivewireRequest;
use Livewire\Response as LivewireResponse;

/**
 *  HOW TO USE
 * ============
 *
 * The ajax request inits the next methods in the provided order
 *
 * $this->hydrate();
 * $this->filter();
 * $this->render();
 * $this->dehydrate();
 *
 * ============
 *
 *
 * Class Catalog
 *
 * @package App\Http\Livewire
 */
class Catalog extends Component
{
    use WithPagination;

    const DEFAULT_ITEMS_COUNT = 24;

    public array $displayParams = [
        'count' => null,
        'sorting' => null,
        'format' => null
    ];

    public $search = '';

    protected $queryString = [
        'search' => ['except' => ''],
    ];

    public array $routeParams = [];

    public ?string $categorySlug;

    protected $listeners = ['filter'];

    private string $target_url = '';
    /** @var RouteParams */
    protected $_route_params;
    private ?Cart $_cart = null;
    protected ?Pricing $_pricing = null;
    protected ?User $_user = null;


    #region Actions

    /**
     * @param Request $request
     */
    public function mount(Request $request)
    {
        $this->getRouteParams()->initFromRequest($request)
            ->getAll()
            ->each(function(RouteParam $routeParam) {
                $this->routeParams[] = [
                    'slug' => $routeParam->getSlug(),
                    'position' => $routeParam->getPosition(),
                    'values' => $routeParam->getValues()->toArray()
                ];
            });

        if ($category = $request->route()->parameter('category')) {
            $this->categorySlug = $category->slug;
        }

        $this->displayParams['count'] = $request->get('count') ?: self::DEFAULT_ITEMS_COUNT;
        $this->displayParams['sorting'] = $request->get('sorting');
        $this->displayParams['format'] = $request->get('format');
    }

    /**
     * @param LivewireRequest $request
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function hydrate(LivewireRequest $request)
    {
        if (($request->updates[0]['payload']['params'][0] ?? '') === 'category') {
            $this->categorySlug = $request->updates[0]['payload']['params'][1];
            $this->target_url = static::getCategoryRoute($this->categorySlug, $request);
        }

        $this->getRouteParams()->initFromExistsSetup($this->routeParams);
    }

    /**
     * @param LivewireRequest $response
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function dehydrate(LivewireResponse $response)
    {
        $routeParams = $this->getRouteParams();
        $this->collectRouteParams($routeParams);

        $this->emit('cartChanged', $this->getCart()->count(), route('wholesale-catalog', ['showCart' => (bool) $this->getCart()->count()]));

        $url = $this->getFilterUri();

        if ($this->target_url) {
            $this->target_url = '';
        }

        $this->emit('urlChanged', $url);
    }

    /**
     * @param Request $request
     * @param CatalogService $catalogService
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function render(Request $request, CatalogService $catalogService)
    {
        SeoFilterTrackRating::build($this->getFilterUri())
            ->setCookie();

        return view('livewire.catalog.catalog', [
            'catalog' => $this->getCatalog($request, $catalogService),
            'lookupLinks' => SeoFilterTrackRating::build($this->getFilterUri())
                ->getChildrenFiltersList(),
            'category' => $this->getCategory(),
            'seo' => SeoFilters::getSeo(),
            'displayFormat' => $this->displayParams['format'] ?? null,
            'pricing' => $this->getPricing(),
            'breadcrumbs' => $this->getBreadcrumbs()
        ]);
    }

    /**
     * @param string $filterName
     * @param string $filterValue
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function filter(string $filterName, string $filterValue)
    {
        if (!app()->make(CatalogService::class)->validateFilter($filterName, $filterValue)) {
            $this->redirect('catalog');
        }

        $this->getRouteParams()->appendTo($filterName, $filterValue);
        $this->resetPage();
    }

    /**
     * @param $name
     * @param $value
     */
    public function updated($name, $value)
    {
        if (Str::startsWith($name, 'displayParams.')) {
            $paramName = Str::after($name, '.');
            if (array_key_exists($paramName, $this->displayParams)) {
                $this->displayParams[$paramName] = $value;
            }
        }
    }

    #endregion

    #region Setters

    /**
     * @param RouteParams $routeParams
     */
    protected function collectRouteParams(RouteParams $routeParams)
    {
        $newRouteParams = [];
        $routeParams->getAll()
            ->each(function(RouteParam $routeParam) use (&$newRouteParams) {
                $newRouteParams[] = [
                    'slug' => $routeParam->getSlug(),
                    'position' => $routeParam->getPosition(),
                    'values' => $routeParam->getValues()->toArray()
                ];
            });

        $this->routeParams = $newRouteParams;
    }

    #endregion

    #region Getters

    /**
     * @return Category|null
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getCategory()
    {
        return !empty($this->categorySlug)
            ? app()->make(CatalogRepository::class)->getCategoriesBySlug([$this->categorySlug])->first()
            : null;
    }

    /**
     * @return array|null[]
     */
    protected function convertDisplayParams()
    {
        $result = $this->displayParams;

        if (!empty($result['sorting'])) {
            [$result['sort'], $result['by']] = explode('-', $result['sorting']);

            switch($result['sort']) {
                case 'wholesale.price.uah':
                    $result['sort'] = $this->getPricing()->getWholesalePriceName($this->getUser()->getRole()->name, Pricing::CURRENCY_UAH);
                    break;
                case 'wholesale.price.usd':
                    $result['sort'] = $this->getPricing()->getWholesalePriceName($this->getUser()->getRole()->name, Pricing::CURRENCY_USD);
                    break;
            }

            unset($result['sorting']);
        }

        return $result;
    }

    /**
     * @param string $category_slug
     * @param LivewireRequest $request
     *
     * @return string
     */
    private static function getCategoryRoute(string $category_slug, LivewireRequest $request)
    {
        $filters_groups = [];

        foreach ($request->memo['data']['routeParams'] as $param) {
            switch ($param['slug']) {
                case 'types':
                case 'brand':
                case 'dop':
                case RouteParams::PARAM_NAME__SPECIFIC:
                    $filters_groups[$param['slug']] = $param['values'];
                    break;
            }
        }

        $route_params = [
            'category' => $category_slug,
        ];
        $i = 0;

        foreach ($filters_groups as $group_name => $filter_values) {
            switch ($group_name) {
                case 'types':
                case 'brand':
                case 'dop':
                case RouteParams::PARAM_NAME__SPECIFIC:
                    $i ++;
                    $route_params['filter' . $i] = $group_name . '-' . implode(',', $filter_values);

                    break;
            }

            if ($i == CatalogService::MAX_FILTERS_COUNT) {
                break;
            }
        }

        $routeName = 'catalog.filter';

        if ($route_params) {
            $routeName = 'catalog.filters';
        }

        return route($routeName, $route_params);
    }

    /**
     * @return RouteParams
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getRouteParams()
    {
        return $this->_route_params ?? ($this->_route_params = app()->make(RouteParams::class));
    }

    /**
     * @return Cart
     */
    protected function getCart(): Cart
    {
        if ($this->_cart) {
            return $this->_cart;
        }

        if (!Session::has('cart')) {
            Session::put('cart', new Cart());
        }

        return $this->_cart = Session::get('cart');
    }

    /**
     * @return User
     */
    protected function getUser()
    {
        return $this->_user ?? ($this->_user = Auth::user());
    }

    /**
     * @return Pricing
     */
    public function getPricing()
    {
        return $this->_pricing ?? ($this->_pricing = Pricing::init($this->getUser()));
    }

    /**
     * @param Request $request
     * @param CatalogService $catalogService
     *
     * @return \App\Services\Catalog\Catalog
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getCatalog(Request $request, CatalogService $catalogService)
    {
        $cache_key = $this->getCacheKey($request);

        $catalog = Cache::get($cache_key, []);

        if (!$catalog) {
            $catalog = $catalogService->getCatalog(
                $request,
                $this->getCategory() ? $this->getCategory()->id : 0,
                $this->convertDisplayParams(),
                $this->search
            );

//            Cache::put($cache_key, $catalog, 14400); // 4 hours
        }

        return $catalog;
    }

    /**
     * @return string
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getFilterUri()
    {
        $routeParams = $this->getRouteParams();

        return $this->target_url ?: UrlBuilder::catalog($routeParams, $this->getCategory(), $this->displayParams)->get();
    }

    /**
     * @param Request $request
     *
     * @return string
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getCacheKey(Request $request): string
    {
        return $this->getFilterUri() . '_' . json_encode($request->all());
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    private function getBreadcrumbs()
    {
        // Collect data for breadcrumbs
        $category = $this->getCategory();
        $brand = $this->getRouteParams()->get(RouteParams::PARAM_NAME__BRAND);
        $attributes = AttributeSlugValue::query();

        // Attributes
        /** @var Collection|RouteParam[] $route_params */
        $route_params = $this->getRouteParams()->getDynamic();

        foreach ($route_params as $attr) {
            $attributes->orWhereIn('slug', $attr->getValues()->toArray());
        }

        if ($route_params->isNotEmpty()) {
            $attributes = $attributes->get();
            /** @var \Illuminate\Database\Eloquent\Collection|AttributeSlugValue[] $attributes */
        } else {
            $attributes = null;
        }

        // Brand
        if ($brand && $brand->getValues()->count() == 1) {
            /** @var Brand $brand */
            $brand = Brand::query()
                ->where('slug', $brand->getValues()->first())
                ->first();
        } else {
            $brand = null;
        }

        // Collect additional breadcrumb items
        $additional_items = [];

        if ($category) {
            $additional_items[] = Breadcrumb::make([
                'title' => $category->name,
                'url' => routeLocale('category.filter', ['category' => $category->slug]),
            ])->showUrl($brand || $attributes);
        }

        if ($brand) {
            $additional_items[] = Breadcrumb::make([
                'title' => ($category ? $category->name . ' ' : '') . $brand->name,
                'url' => routeLocale('catalog.filter', ['filter1' => 'brand-' . $brand->slug]),
            ])->showUrl((bool) $attributes);
        }

        if ($attributes) {
            [$canonical_uri, ] = explode('?', $this->getFilterUri(), 2);

            $additional_items[] = Breadcrumb::make([
                'title' => implode(', ', $attributes->map(fn ($attr) => $attr->value)->toArray()),
                'url' => url($canonical_uri),
            ])->showUrl(false);
        }

        // Collect breadcrumb items
        $breadcrumbs = collect([
            Breadcrumb::make([
                'url' => routeLocale('main'),
                'title' => __('header.main_title'),
                'seo_title' => __('seo.title-main'),
            ]),
            Breadcrumb::make([
                'url' => routeLocale('catalog'),
                'title' => __('header.catalog'),
            ])->showUrl((bool) $additional_items),
        ])->merge($additional_items);

        return $breadcrumbs;
    }

    #endregion
}
