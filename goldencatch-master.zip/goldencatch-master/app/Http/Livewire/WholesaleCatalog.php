<?php

namespace App\Http\Livewire;

use App\Services\Catalog;
use App\Services\Catalog\CatalogService;
use App\Services\Catalog\Routing\RouteParam;
use App\Services\Catalog\Routing\WholesaleRouteParams;
use App\Services\Catalog\Routing\UrlBuilder;
use Illuminate\Http\Request;
use App\Http\Livewire;
use Illuminate\Support\Facades\Cache;
use Livewire\Request as LivewireRequest;
use Livewire\Response as LivewireResponse;

/**
 * Class Catalog
 *
 * @package App\Http\Livewire\Wholesale\Catalog
 */
class WholesaleCatalog extends Livewire\Catalog
{
    protected $listeners = ['setProductCoutInCart'];

    #region Actions

    /**
     * @param Request $request
     */
    public function mount(Request $request)
    {
        $this->getRouteParams()
            ->initFromRequest($request)
            ->getAll()
            ->each(function(RouteParam $routeParam) {
                $this->routeParams[] = [
                    'slug' => $routeParam->getSlug(),
                    'position' => $routeParam->getPosition(),
                    'values' => $routeParam->getValues()->toArray()
                ];
            });

        $this->displayParams['count'] = $request->get('count', self::DEFAULT_ITEMS_COUNT);
        $this->displayParams['sorting'] = $request->get('sorting');
        $this->displayParams['format'] = $request->get('format');
        $this->displayParams['showCart'] = $request->get('showCart', false);
    }

    /**
     * @param LivewireRequest $request
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function hydrate(LivewireRequest $request)
    {
        $this->getRouteParams()->initFromExistsSetup($this->routeParams);
    }

    /**
     * @param string $filterName
     * @param string $filterValue
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function filter(string $filterName, string $filterValue)
    {
        $this->displayParams['showCart'] = false;

        $this->getRouteParams()->appendTo($filterName, $filterValue);
        $this->resetPage();
    }

    /**
     * @param Request $request
     * @param Catalog\CatalogService $catalogService
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function render(Request $request, Catalog\CatalogService $catalogService)
    {
        return view('livewire.wholesale-catalog.catalog', [
            'cart_instance' => $this->getCart(),
            'pricing' => $this->getPricing(),
            'catalog' => $this->getCatalog($request, $catalogService),
            'contacts_operator_of_resellers_phones' => explode("\n", settings('contacts_operator_of_resellers_phones') ?: ''),
        ]);
    }

    /**
     * @param LivewireRequest $response
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function dehydrate(LivewireResponse $response)
    {
        $routeParams = $this->getRouteParams();
        $this->collectRouteParams($routeParams);

        $this->emit('cartChanged', $this->getCart()->count(), route('wholesale-catalog', ['showCart' => (bool) $this->getCart()->count()]));
        $this->emit('urlChanged', $this->getFilterUri());
    }

    #endregion

    #region Setters

    /**
     * @param int $product_id
     * @param int $count
     */
    public function setProductCoutInCart($product_id, $count)
    {
        $this->getCart()
            ->remove($product_id);

        if ($count <= 0) {
            if (!$this->getCart()->count()) {
                $this->showCatalog();
            }

            return;
        }

        $this->getCart()
            ->add($product_id, $count);
    }

    /**
     * @return void
     */
    public function showCatalog()
    {
        $this->displayParams['showCart'] = 0;
    }

    /**
     * @return void
     */
    public function changeMode()
    {
        $this->displayParams['showCart'] = !$this->displayParams['showCart'];
    }

    /**
     * @param string $filter_param
     */
    public function changeSorting(string $filter_param)
    {
        $sort_key = '';

        switch ($filter_param) {
            case 'retail.price':
                $sort_key = 'price';
                break;

            case 'wholesale.price.uah':
            case 'wholesale.price.usd':
                $sort_key = $filter_param;
                break;
        }

        $this->displayParams['sorting'] = ($this->displayParams['sorting'] ?? '') === $sort_key . '-asc'
            ? $sort_key . '-desc'
            : $sort_key . '-asc';
    }

    #endregion

    #region Getters

    /**
     * @return WholesaleRouteParams
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getRouteParams()
    {
        return $this->_route_params ?? ($this->_route_params = app()->make(WholesaleRouteParams::class));
    }

    /**
     * @param Request $request
     * @param CatalogService $catalogService
     *
     * @return \App\Services\Catalog\Catalog
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getCatalog(Request $request, CatalogService $catalogService)
    {
        $cache_key = $this->getCacheKey($request);

        $catalog = Cache::get($cache_key, []);

        if (!$catalog || $this->displayParams['showCart']) {
            $displayParams = $this->convertDisplayParams() + [
                    'filters_view_namespace' => [
                        'price' => 'wholesale-catalog.filters',
                        'weight' => 'wholesale-catalog.filters',
                    ],
                ];

            $catalog = $catalogService->getCatalog(
                $request,
                $this->displayParams['showCart']
                    ? Catalog\Repository::GET_CART_ITEMS
                    : 0,
                $displayParams,
                $this->search,
                $this->getRouteParams()
            );

            if (!$this->displayParams['showCart']) {
                Cache::put($cache_key, $catalog, 14400); // 4 hours
            }
        }

        return $catalog;
    }

    /**
     * @return string
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    protected function getFilterUri()
    {
        return UrlBuilder::wholesaleCatalog(
                $this->getRouteParams(),
                null,
                $this->displayParams
            )
            ->get();
    }

    #endregion
}
