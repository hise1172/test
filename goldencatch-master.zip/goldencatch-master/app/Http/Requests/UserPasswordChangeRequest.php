<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

/**
 * Class UserPasswordChangeRequest
 *
 * @package App\Http\Requests
 */
class UserPasswordChangeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'new_password' => ['string', 'max:255', 'confirmed'],
            'new_password_confirmation ' => ['string', 'max:255'],
        ];

        if (Auth::user()->hasOldPassword()) {
            $rules['password'] = ['required', 'string', 'max:255', 'password'];
        }

        return $rules;
    }
}
