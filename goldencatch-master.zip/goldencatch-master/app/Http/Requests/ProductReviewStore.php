<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class ProductReviewStore extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'product_id' => ['required', 'exists:products,id'],
            'comment' => ['required', 'string'],
            'good_things' => ['required', 'string'],
            'bad_things' => ['required', 'string'],
            'product_mark' => ['required', 'min:1', 'max:5'],
            'photo' => ['nullable', 'array'],
            'photo.*' => ['required_if:photo,array', 'image']
        ];
    }
}
