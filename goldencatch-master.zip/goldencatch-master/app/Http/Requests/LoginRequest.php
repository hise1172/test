<?php

namespace App\Http\Requests;

use App\Rules\Login;

/**
 * Class LoginRequest
 *
 * @package App\Http\Requests
 */
class LoginRequest extends AbstractRequest
{
    private const LOGIN_TYPE_PHONE = 'phone';
    private const LOGIN_TYPE_EMAIL = 'email';

    private string $login_type = self::LOGIN_TYPE_EMAIL;
    private Login $login_rules;

    #region Actions

    /**
     * @inheritDoc
     */
    protected function prepareForValidation()
    {
        $this->login_rules = new Login($this->isLoginTypeEmail());

        parent::prepareForValidation();
    }

    /**
     * @inheritDoc
     */
    protected function passedValidation()
    {
        $this->replace(
            ['login' => $this->login_rules->getNormalisedLogin()] + $this->all()
        );
    }

    #endregion

    #region Is Condition methods

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isLoginTypeEmail(): bool
    {
        if ($this->login_type) {
            return $this->login_type === static::LOGIN_TYPE_EMAIL;
        }

        if (
            !filter_var($this->get('login'), FILTER_VALIDATE_EMAIL)
            && strlen(
                preg_replace('/[^0-9]/', '', $this->get('login'))
            ) > 8
        ) {
            $this->login_type = static::LOGIN_TYPE_PHONE;
        }

        return $this->login_type === static::LOGIN_TYPE_EMAIL;
    }

    #endregion

    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'login' => [
                'required',
                'string',
                $this->login_rules,
            ],
            'password' => ['required', 'string'],
        ];
    }

    #endregion
}
