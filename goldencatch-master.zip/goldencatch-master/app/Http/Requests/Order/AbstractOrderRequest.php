<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\AbstractRequest;
use App\Repositories\UserRepository;
use App\Rules\Phone;
use App\User;
use Illuminate\Support\Facades\Auth;

/**
 * Class OrderRequest
 *
 * @package App\Http\Requests
 */
abstract class AbstractOrderRequest extends AbstractRequest
{
    protected Phone $phone_rules;

    public User $user;

    #region Abstract methods

    /**
     * @return int
     */
    abstract public function getOrderTypeID(): int;

    /**
     * @return string
     */
    abstract protected function getDefaultFieldValue(): string;

    #endregion

    #region Extended

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * @inheritDoc
     */
    protected function passedValidation()
    {
        if (Auth::check()) {
            $this->user = Auth::user();

            $this->fillDefaultValues();

            return;
        }

        $phone = $this->phone_rules->getNormalisedValue();

        $userRepository = new UserRepository();

        $user = $userRepository->getByLogin($phone, $this->get('email'));

        if (!$user) {
            $user = $this->createUser($userRepository);

            Auth::login($user, true);
        }

        $this->user = $user;

        $this->fillDefaultValues();
    }

    #endregion

    #region Updates methods

    protected function createUser(UserRepository $userRepository) : User
    {
        return $userRepository->register([
            'telephone' => $this->phone_rules->getNormalisedValue(),
            'name' => $this->get('name') ?: $this->getDefaultFieldValue(),
            'surname' => $this->get('surname') ?: $this->getDefaultFieldValue(),
        ]);
    }

    #endregion

    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $this->phone_rules = new Phone();

        return [
            'phone' => ['required', 'string', $this->phone_rules],
        ];
    }

    #endregion

    #region Helpers

    /**
     * @return void
     */
    protected function fillDefaultValues(): void
    {
        $this->merge(['order_type_id' => $this->getOrderTypeID()]);
        $this->merge(['phone' => $this->phone_rules->getNormalisedValue()]);
        $this->merge(['need_call' => true]);
        $this->merge(['comments' => $this->getDefaultFieldValue()]);

        $this->merge(['name' => $this->get('name') ?: $this->user->name]);
        $this->merge(['surname' => $this->get('surname') ?: $this->user->surname]);
    }

    #endregion
}
