<?php

namespace App\Http\Requests\Order;

use App\Models\Order;

/**
 * Class OrderRequest
 *
 * @package App\Http\Requests
 */
class OrderHelpRequest extends AbstractOrderRequest
{
    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules_list = parent::rules();

        return [
            'phone-call' => $rules_list['phone'],
        ];
    }

    /**
     * @return string
     */
    protected function getDefaultFieldValue() : string
    {
        return '- помощь с оформлением -';
    }

    /**
     * @return int
     */
    public function getOrderTypeID(): int
    {
        return Order::TYPE_HELP_REQUEST;
    }

    #endregion
}
