<?php

namespace App\Http\Requests\Order;

use App\Models\Order;
use App\Models\Product\Product;
use RuntimeException;

/**
 * Class OneClickOrderRequest
 *
 * @package App\Http\Requests\Order
 */
class OneClickOrderRequest extends AbstractOrderRequest
{
    public Product $product;

    #region Actions

    /**
     * @inheritDoc
     */
    protected function passedValidation()
    {
        parent::passedValidation();

        /** @var Product $product */
        $product = Product::where('slug', $this->get('slug'));

        if (!$product) {
            throw new RuntimeException('Unknown product');
        }

        $product = $product->first();

        if ($product->modifications->count() > 0) {
            $product = $product->modifications->first();
        }

        $this->product = $product;
    }

    #endregion

    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules_list = parent::rules();

        return [
            'phone' => $rules_list['phone'],
            'slug' => ['required', 'string'],
        ];
    }

    /**
     * @return string
     */
    protected function getDefaultFieldValue() : string
    {
        return '- быстрый заказ -';
    }

    /**
     * @return int
     */
    public function getOrderTypeID(): int
    {
        return Order::TYPE_ONE_CLICK;
    }

    #endregion
}
