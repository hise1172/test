<?php

namespace App\Http\Requests\Order;

use App\Models\Delivery;
use App\Models\Order;
use App\Models\PaymentMethod;
use App\Repositories\UserRepository;
use App\User;
use Illuminate\Validation\Rule;

/**
 * Class OrderRequest
 *
 * @package App\Http\Requests
 */
class OrderRequest extends AbstractOrderRequest
{
    #region Updates methods

    /**
     * @param UserRepository $userRepository
     *
     * @return User
     */
    protected function createUser(UserRepository $userRepository) : User
    {
        return $userRepository->register([
                'telephone' => $this->phone_rules->getNormalisedValue(),
            ] + $this->all());
    }

    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules_list = parent::rules();

        $request = $this;

        return [
            'surname' => ['required', 'string'],
            'name' => ['required', 'string'],
            'phone' => $rules_list['phone'],
            'delivery_method' => ['required', 'string'],
            'newpost_city' => [
                'required',
                'string',
                function($value) use ($request)
                {
                    if ($request->get('delivery_method') !== Delivery::PICKUP_ODESSA) {
                        return true;
                    }

                    return !in_array($value, ['false']);
                },
            ],
            'newpost_warehouse' => [
                Rule::requiredIf(function () use ($request) {
                    return $request->get('delivery_method') === Delivery::NEWPOST_DEPARTMENT;
                }),
                'string',
                function($value) use ($request)
                {
                    if ($request->get('delivery_method') !== Delivery::NEWPOST_DEPARTMENT) {
                        return true;
                    }

                    return !in_array($value, ['false']);
                },
            ],
            'payment_method_id' => [
                'required',
                'string',
                Rule::In(PaymentMethod::getAllowedMethods($this->isResellersConsole)),
            ],
            'email' => ['nullable','string'],
            'comment' => ['nullable', 'string'],
            'need_call' => ['nullable', 'string'],
        ];
    }

    /**
     * @return int
     */
    public function getOrderTypeID(): int
    {
        return Order::TYPE_GENERIC;
    }

    /**
     * @return string
     */
    protected function getDefaultFieldValue() : string
    {
        return '';
    }

    #endregion

    #regio Helpers

    /**
     * @inheritDoc
     */
    protected function fillDefaultValues(): void
    {
        $this->merge(['order_type_id' => $this->getOrderTypeID()]);
    }

    #endregion
}
