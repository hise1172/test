<?php

namespace App\Http\Requests;

use App\Http\Kernel;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

/**
 * Class AbstractRequest
 *
 * @package App\Http\Requests
 */
abstract class AbstractRequest extends FormRequest
{
    #region Abstract methods

    abstract public function rules(): array;

    #endregion

    #region Actions

    /**
     * @throws ValidationException
     */
    protected function prepareForValidation()
    {
        $this->isResellersConsole = Kernel::isResellersConsole(
            $this->server->get(
                'HTTP_HOST',
                $this->server->get('SERVER_NAME', '')
            )
        );
    }

    /**
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function getValidatorInstance()
    {
        return Validator::make($this->all(), $this->rules());
    }

    #endregion
}
