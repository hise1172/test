<?php

namespace App\Http\Requests;

use App\Rules\Phone;

/**
 * Class RegistrationRequest
 *
 * @package App\Http\Requests
 */
class RegistrationRequest extends AbstractRequest
{
    protected Phone $phone_rules;

    #region Actions

    /**
     * @inheritDoc
     */
    protected function passedValidation()
    {
        $this->replace(
            [
                'telephone' => $this->phone_rules->getNormalisedValue(),
            ] + $this->all()
        );
    }

    #endregion

    #region Getters

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $this->phone_rules = new Phone();

        return [
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['required', 'string', 'max:255'],
            'telephone' => ['required', 'string', $this->phone_rules, 'unique:users,telephone'],
            'email' => ['string', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
        ];
    }

    #endregion
}
