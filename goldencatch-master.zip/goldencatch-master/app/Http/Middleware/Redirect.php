<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Cache;
use App\Models\Redirect as Redir;

class Redirect
{

    private $rules;

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if ($request->ajax() || !$request->isMethod('GET')) {
            return $next($request);
        }
        $lang = $request->fullUrl();
        $path = $request->path();
        $redirects = Redir::where('old_url', $path)->orWhere('old_url', $path . '/')->first();
        if ($redirects && $redirects->turn_on==1) {
            return redirect($redirects->new_url,301);
        }

        return $next($request);
//        $pathWithDomain = sprintf("//%s/%s", $request->getHost(), $request->path());
//
//        $uri = preg_replace('/^../', '', $request->path());
//        preg_match('/^../', $request->path(), $lang);
//        $redirect = \App\Models\Redirect::whereIn('old_url', [$uri, $pathWithDomain, 'http:'. $pathWithDomain, 'https:'. $pathWithDomain ])
//            ->where('turn_on', true)->first();
//
//        if (!is_null($redirect)) {
//            if(strripos($redirect->new_url, $request->getHost())) {
//
//                return redirect($redirect->new_url);
//            }
//            return redirect()->away($redirect->new_url);
//        }
//
//        return $next($request);
    }

}
