<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\URL;

class Localization
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (in_array($request->segment(1), config('app.all_locale'))) {
            $locale = $request->segment(1);
            if ($locale == config('app.default_locale')) {
                return redirect(routeLocale('main'));
            }
        } else {
            $locale = config('app.default_locale');
        }

        App::setLocale($locale);
        if ($locale !== config('app.default_locale')) {
            URL::defaults(['locale' => $locale]);
        }

        if (!$request->fullUrlIs('*/lang/*')) {
            if ($request->route()) {
                $request->route()->forgetParameter('locale');
            }
        }

        return $next($request);
    }
}
