<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class HansaMiddleware
{
    const NAME = 'hansa';

    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     *
     * @return \Illuminate\Http\JsonResponse|mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $auth_header = $request->header('Authorization');

        $position = strrpos($request->header('Authorization'), 'Basic ');

        if ($position !== false) {
            $auth_header = substr($auth_header, $position + 6);

            $auth_header = str_contains($auth_header, ',') ? strstr($auth_header, ',', true) : $auth_header;
        }

        $auth_header = base64_decode($auth_header);

        if (strpos($auth_header, ':') === false) {
            return response()->json([
                'status' => 'error',
                'message' => config('app.debug')
                    ? 'Invalid Authorization header'
                    : 'Bad Request',
            ], 403);
        }

        [$request_ip, $request_token] = explode(':', $auth_header, 2);

        if($request_ip !== config('api.hansa_incoming_access.allowed_ip')){
            return response()->json([
                'status' => 'error',
                'message' => config('app.debug')
                    ? 'IP Address not allowed'
                    : 'Access deny',
            ], 401);
        }

        if($request_token !== config('api.hansa_incoming_access.api_token')){
            return response()->json([
                'status' => 'error',
                'message' => config('app.debug')
                    ? 'Wrong API key'
                    : 'Access deny',
            ], 401);
        }

        return $next($request);
    }
}
