<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class ResellerAuthorization
 *
 * @package App\Http\Middleware
 */
class ResellerAuthorization
{
    #region Actions

    /**
     * Handle an incoming request.
     *
     * @param  Request  $request
     * @param  Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if ($request->isResellersConsole) {
            return $this->handleReseller($request, $next, $guard);
        }

        return $next($request);
    }

    /**
     * @param Request $request
     * @param Closure $next
     * @param $guard
     */
    private function handleReseller($request, Closure $next, $guard)
    {
        if (
            static::isPublicUri($request)
            || (
                Auth::guard($guard)->check()
                && Auth::guard($guard)->user()->isReseller()
            )
        ) {
            return $next($request);
        }

        if (
            Auth::guard($guard)->check()
            && !Auth::guard($guard)->user()->isReseller()
        ) {
            Auth::guard($guard)->logout();
        }

        return redirect(route(RouteServiceProvider::NAME_LOGIN));
    }

    #endregion

    #region Is Condition methods

    /**
     * Returns TRUE, if a passed URI is a opened for not authorized users in Resellers Console
     *
     * @param string $uri
     *
     * @return bool
     */
    private static function isPublicUri(Request $request): bool
    {
        if (
            $request->route()->getName() === null
            && self::normaliseURL($request->url()) === self::normaliseURL(route(RouteServiceProvider::NAME_LOGIN))
        ) {
            return true;
        }

        return in_array($request->route()->getName(), [
                RouteServiceProvider::NAME_LOGIN,
                RouteServiceProvider::NAME_RESET_PASSWORD,
                RouteServiceProvider::NAME_RESET_PASSWORD_CHAGE_FORM,
                RouteServiceProvider::NAME_RESET_PASSWORD_SAVE,
                RouteServiceProvider::NAME_RESET_PASSWORD_SMS_VALIDATION,
        ]);
    }

    /**
     * @param string $url
     *
     * @return string
     */
    private static function normaliseURL(string $url): string
    {
        return substr($url, 0, 5) === 'http:'
            ? 'https' . substr($url, 4)
            : $url;
    }

    #endregion
}
