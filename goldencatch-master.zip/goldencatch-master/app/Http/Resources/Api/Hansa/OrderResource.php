<?php

namespace App\Http\Resources\Api\Hansa;

use App\Models\BonusHistory;
use App\Models\Order;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @property Order resource
 */
class OrderResource extends JsonResource
{
    public static $wrap = 'order';

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $total_bonus = 0;

        foreach ($this->resource->usedBonus()->get() as $bonus_history) {
            /** @var BonusHistory $bonus_history */
            $total_bonus += $bonus_history->amount;
        }

        return [
            'externalId' => $this->id,
            'createdAt' => $this->created_at,
            'summ' => $this->price_without_discount,
            'totalSumm' => $this->price,
            'bonusSpent' => $total_bonus,
            'lastName' => $this->name,
            'firstName' => $this->surname,
            'phone' => $this->phone,
            'email' => $this->email,
            'call' => $this->need_call,
            'customerComment' => $this->comments,
            'customer' => [
                'externalId' => $this->user->id
            ],
            'delivery' => [
                'slug' => $this->resource->delivery->slug,
                'data' => [
                    'pickuppointId' => $this->novaPoshta->newpost_warehouse ?? null,
                ],
                'tracking_code' => $this->tracking_code,
            ],
            'items' => ProductResource::collection($this->products)
        ];
    }
}
