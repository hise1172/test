<?php

namespace App\Http\Controllers;

use App\Helpers\SeoHelper;
use App\Helpers\Url;
use App\Models\Category;
use App\Models\Product\Product;
use App\Services\Catalog\CatalogService;
use Illuminate\Http\Request;
use App\Helpers\SeoFilters;
use App\Models;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View as ViewFacade;

/**
 * Class CatalogController
 * @package App\Http\Controllers
 */
class CatalogController extends Controller
{
    private $catalogService;

    public function __construct(CatalogService $catalogService)
    {
        $this->catalogService = $catalogService;
    }

    public function index(Request $request)
    {
        return $this->catalogService->filterRequest($request);
    }

    public function catalog(Request $request, Category $category = null)
    {
        if (!$this->catalogService->validateRequest($request)) {
            return redirect('catalog');
        }

        $seo = SeoFilters::getSeo();

        if ($request->get('page') > 1) {
            $seo['robots_index'] = 'noindex';
        }

        return ViewFacade::make('catalog.index', [
            'meta' => $category
                ? SeoHelper::meta($category->name, '')
                : SeoHelper::meta('', ''),
            'seo' => $seo,
        ]);
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function catalogAutocomplete(Request $request)
    {
        $search_query = trim($request->get('search'));

        if(!$search_query) {
            return response()->json([
                'products' => [],
                'count' => 0,
            ]);
        }

        try {
            $key = 'ProductsSearchString_2:' . json_encode($search_query);

            if (Cache::has($key) && !config('app.debug')) {
                [$seo_filters, $products] = Cache::get($key);
            } else {
                $seo_filters = Models\SeoFilters::search($search_query)
                    ->paginate(4);

                $products = Product::search($search_query)
                    ->paginate(10);

                $seo_filters = $seo_filters ? $seo_filters->items() : [];
                $products = $products ? ($products->items() ?? []) : [] ;

                Cache::put($key, [
                    $seo_filters,
                    $products,
                ], 14400); // 24 hours
            }

            $productsResult = [];

            foreach ($seo_filters as $seo_filter) {
                /** @var Models\SeoFilters $seo_filter */
                $productsResult[] = [
                    'name' => $seo_filter->h1,
                    'url' => Url::getLocatedUrl($seo_filter->uri),
                    'sort' => count($productsResult),
                ];
            }

            foreach ($products as $product) {
                /** @var Product $product */
                $productsResult[] = [
                    'name' => $product->name,
                    'url' => route('product', $product->slug),
                    'sort' => count($productsResult),
                ];
            }
        } catch (\Throwable $e) {
            Log::debug(print_r([
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'Route' => __FILE__ . ':' . __LINE__,
            ], true));

            $catalog = $this->catalogService->getCatalog($request, 0, [], $search_query);
            $productsResult = [];


            foreach ($catalog->getProducts() as $product) {
                /** @var Product $product */
                $productsResult[] = [
                    'name' => $product->name,
                    'url' => route('product', $product->slug),
                    'sort' => count($productsResult),
                ];
            }
        }

        return response()->json([
            'products' => array_slice($productsResult, 0, 10),
        ]);
    }
}
