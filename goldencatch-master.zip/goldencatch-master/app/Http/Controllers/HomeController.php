<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use Illuminate\Contracts\Support\Renderable;

/**
 * Class HomeController
 * Home page (url /home) controller
 * @package App\Http\Controllers
 */
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return Renderable
     */
    public function index()
    {
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('test', 'test');
        return view('home', compact('seo', 'meta'));
    }
}
