<?php

namespace App\Http\Controllers\Auth;

use App\Helpers\SeoFilters;
use App\Http\Controllers\Controller;
use App\Http\Requests\UserPasswordChangeRequest;
use App\Services\UserService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PasswordChange extends Controller
{
    /**
     * @var UserService
     */
    private $service;

    /**
     * PasswordChange constructor.
     * @param UserService $service
     */
    public function __construct(UserService $service)
    {
        $this->service = $service;
    }

    /**
     * @param UserPasswordChangeRequest $request
     * @return RedirectResponse|View
     */
    public function update(UserPasswordChangeRequest $request)
    {
        $seo = SeoFilters::getSeo();
        $success = $this->service->changePassword($request);
        if ($success) {
            return redirect()->route('account.index')->with('success', 'Пароль обновлен');
        }
        return view('account.edit-password', compact('seo'))->with('error', 'Пароль не обновлен');
    }
}
