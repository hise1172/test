<?php

namespace App\Http\Controllers\Auth;

use App\User\LogAction;
use App\ApiIntegration\SMS;
use App\ApiIntegration;
use App\Http\Controllers\Controller;
use App\Http\Requests\SendMailRequest;
use App\User;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Session;

/**
 * Class ForgotPasswordController
 *
 * @package App\Http\Controllers\Auth
 */
class ForgotPasswordController extends Controller
{
    const SESSION_SMS_KEY = 'reset_password.sms.code';
    const SESSION_SMS_TELEPHONE = 'reset_password.sms.telephone';

    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    #region Actions

    /**
     * @link GET /reset-password
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        return view('auth.passwords.email');
    }

    /**
     * @link POST /reset-password
     *
     * @param SendMailRequest $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\RedirectResponse
     */
    public function sendEmail(SendMailRequest $request)
    {
        $result = $request->validate($request->rules());

        $email_or_telephone = trim($result['email']);

        /** @var User $user */
        $user = User::where('email', $email_or_telephone)
            ->orWhere('telephone', $email_or_telephone)
            ->first();

        if (!$user) {
            return back()->withErrors(['email' => 'Нет такого юзера']);
        }

        if ($user->telephone === $result['email']) {
            return $this->sendSMS($request, $user);
        }

        LogAction::init($user->email)
            ->startResetPassByEmail($request->url());

        $status = Password::sendResetLink(
            $request->only('email')
        );

        return $status !== Password::RESET_LINK_SENT
            ? back()->withErrors(['email' => __($status)])
            : view('auth.passwords.reset-done');
    }

    /**
     * @link POST /sms-code-validation
     *
     * @param Request $request
     */
    public function validateSMSCode(Request $request)
    {
        $result = $request->validate([
            'sms_code' => 'required|integer',
        ]);

        if (!Session::get(static::SESSION_SMS_TELEPHONE)) {
            return redirect(route('reset-password'))->withErrors(['email' => 'Invalid telephone number']);
        }

        if (strlen($result['sms_code']) !== SMS::CODE_LENGTH || Session::get(static::SESSION_SMS_KEY) != $result['sms_code']) {
            return redirect(route('password.reset.sms_code.validation_form'))->withErrors(['sms_code' => 'Invalid SMS code']);
        }

        /** @var User $user */
        $user = User::where('telephone', Session::get(static::SESSION_SMS_TELEPHONE))
            ->first();

        Session::remove(static::SESSION_SMS_KEY);
        Session::remove(static::SESSION_SMS_TELEPHONE);

        if (!$user) {
            return redirect(route('reset-password'))->withErrors(['email' => 'Нет такого юзера']);
        }

        return redirect(route('password.reset', [
            'token' => Password::createToken($user),
            'email' => $user->email,
        ]));
    }

    #endregion

    #region Helpers

    /**
     * @link POST /reset-password
     *
     * @param SendMailRequest $request
     * @param User $user
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    private function sendSMS(SendMailRequest $request, User $user)
    {
        LogAction::init($user->telephone)
            ->startResetPassBySMS($request->url());

        try {
            $sms_api = SMS::build($user);

            if (!$sms_api->getBalance()) {
                return back()->withErrors(['email' => __('passwords.sms.too_small_balance')]);
            }

            $code = SMS::generateSMSCode();
            $message = __('passwords.sms.verify_code_message', ['verify_code' => $code]);

            $sms_api->sendSMS($message);
        } catch (ApiIntegration\ResponceErrorException $e) {
            return back()->withErrors(['email' => $e->getMessage()]);
        }

        Session::put(static::SESSION_SMS_KEY, $code);
        Session::put(static::SESSION_SMS_TELEPHONE, $user->telephone);
        Password::deleteToken($user);

        return view('auth.passwords.validate-sms-code', [
            'telephone' => $user->telephone,
        ]);
    }

    #endregion
}
