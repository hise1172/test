<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegistrationRequest;
use App\Providers\RouteServiceProvider;
use App\Repositories\UserRepository;
use App\User;
use Exception;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::NAME_LOGIN;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    #region Actions

    /**
     * Handle a registration request for the application.
     *
     * @param Request $request
     * @return Application|RedirectResponse|Response|Redirector
     */
    public function register(RegistrationRequest $request, UserRepository $user_repository)
    {
        if ($request->isResellersConsole) {
            return redirect(route(RouteServiceProvider::NAME_LOGIN))->with('warning', 'The Resellers Console does not allow to register. Please, contact your out support team');
        }

        $log_action = User\LogAction::init($request->get('email'))
            ->setPerformedOnURL($request->url())
            ->startRegistration();

        try {
            $user = $user_repository->register($request->all());
        } catch (Exception $exception) {
            Log::error($exception);
        }

        if ($response = $this->registered($request, $user)) {
            auth()->login($user, true);

            if (auth()->check()) {
                $log_action->doneRegistration();
            } else {
                $log_action->failedRegistration();
            }

            return $response;
        }

        return $request->wantsJson()
            ? new Response('', 201)
            : redirect($this->redirectPath());
    }

    /**
     * @param Request $request
     * @param $user
     * @return Application|RedirectResponse|Redirector
     */
    public function registered(RegistrationRequest $request, $user)
    {
        $this->guard()->logout();
        return redirect( routeLocale('account.index') )->with('status', __('account.Registration Success'));
    }

    /**
     * @return Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    #endregion
}
