<?php

namespace App\Http\Controllers\Auth;

use App\Http\Requests\LoginRequest;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use App\Repositories\UserRepository;
use App\User;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Laravel\Socialite\Facades\Socialite;

/**
 * Class LoginController
 *
 * @package App\Http\Controllers\Auth
 */
class LoginController extends Controller
{
    const GOOGLE = 'google';
    const FACEBOOK = 'facebook';

    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers {
        login as traitlogin;
    }

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    #region Actions

    /**
     * @param Request $request
     * @return bool
     */
    protected function attemptLogin(LoginRequest $request)
    {
        /**
         * @var User $user
         */
        $user = User::where(
                $request->isLoginTypeEmail() ? 'email' : 'telephone',
                $request->get('login')
            )
            ->first();

        if (
            !$user
            || ($request->isResellersConsole && !$user->isReseller())
        ) {
            return false;
        }

        $password = $request->get('password');

        return $this->guard()->attempt(
            ['email' => $user->email, 'password' => $password],
            $request->filled('remember')
        );
    }

    /**
     * Handle a login request to the application.
     * @param LoginRequest $request
     *
     * @return \Illuminate\Http\JsonResponse|RedirectResponse|\Illuminate\Http\Response
     * @throws ValidationException
     */
    public function login(LoginRequest $request)
    {
        $log_actoin = User\LogAction::init($request->get($this->username()))
            ->setPerformedOnURL($request->url());

        try {
            $result = $this->traitlogin($request);

            $log_actoin->successLogin();

            return $result;
        } catch (ValidationException $e) {
            $log_actoin->failedLogin();

            throw $e;
        }
    }

    /**
     * @param Request $request
     * @param User $user
     * @return RedirectResponse
     */
    public function authenticated(Request $request, $user)
    {
        $user->generateAccessToken();

        return redirect()->intended($this->redirectPath());

        if ($user->hasVerifiedEmail()) {
            return redirect()->intended($this->redirectPath());
        }
        auth()->logout();
        return back()->with('warning', 'You need to confirm your account. We have sent you an activation code, please check your email.');
    }

    /**
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function googleRedirect()
    {
        return Socialite::driver(self::GOOGLE)->redirect();
    }

    /**
     * @param UserRepository $service
     *
     * @return RedirectResponse
     */
    public function googleCallback(UserRepository $service)
    {
        return $this->checkSocialLoginUser($service, self::GOOGLE);
    }

    /**
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function facebookRedirect()
    {
        return Socialite::driver(self::FACEBOOK)->redirect();
    }

    /**
     * @param UserRepository $service
     *
     * @return RedirectResponse
     */
    public function facebookCallback(UserRepository $service)
    {
        return $this->checkSocialLoginUser($service, self::FACEBOOK);
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function showLoginForm(Request $request)
    {
        return view('auth.login')
            ->with([
                'warning' => $request->session()->get('warning', ''),
            ]);
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function username()
    {
        return 'login';
    }

    #endregion

    #region Helpers

    /**
     * @param UserRepository $userRepository
     * @param string $driver
     *
     * @return RedirectResponse
     */
    private function checkSocialLoginUser(UserRepository $userRepository, string $driver): RedirectResponse
    {
        $user = $userRepository->getUser($driver);
        $driver_id_name = $driver . '_id';

        /** @var User $existingUser */
        $existingUser = User::query()
            ->where($driver_id_name, $user->getId())
            ->orWhere('email', $user->getEmail())
            ->limit(1)
            ->first();

        if ($existingUser) {
            if (!$existingUser->$driver_id_name) {
                $existingUser->$driver_id_name = $user->getId();

                $existingUser->save();
            }

            auth()->login($existingUser, true);

            return redirect()->route('main');
        }

        // Create a new user
        $newUser = $userRepository->register(
            $userRepository->getUserParameters($user, $driver)
        );

        auth()->login($newUser, true);

        return redirect()->route('main');
    }

    #endregion
}
