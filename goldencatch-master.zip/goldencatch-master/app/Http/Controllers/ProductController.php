<?php


namespace App\Http\Controllers;


use App\Models\Product\Product;
use App\Services\ProductService;
use App\Services\SeoFilterTrackRating;
use Illuminate\Http\Request;

/**
 * Class ProductController
 * Product view
 * @package App\Http\Controllers
 */
class ProductController extends Controller
{
    /**
     * @var ProductService
     */
    private $productService;

    /**
     * ProductController constructor.
     * @param ProductService $productService
     */
    public function __construct(ProductService $productService)
    {
        $this->productService = $productService;
    }

    /**
     * Get product by slug
     *
     * @param Product $product
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
     */
    public function index(Product $product, Request $request)
    {
        if ($product->parent_id) {
            return redirect(route('product', $product->parentProduct->slug), 301);
        }

        SeoFilterTrackRating::buildFromCookie()
            ->applyRating();

        return $this->productService->getProduct($product, $request);
    }

    /**
     * @param Request $request
     * @return mixed|string
     */
    public function getCountProducts(Request $request)
    {
        if ($request->ajax()) {
            $count_qty = $this->productService->getCountProducts($request);
            if ($count_qty != 'Not Found') {
                if ($request->get('count') > $count_qty) {
                    return $count_qty;

                }
                return $request->get('count');
            }
            return 'Not Found';
        }
        return 'Method is not ajax';
    }
}
