<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Repositories\CategoryRepository;
use App\Services\CompareProductService;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\View\View;

/**
 * Class CompareProductController
 * @package App\Http\Controllers
 */
class CompareProductController extends Controller
{
    /**
     * @var CompareProductService
     */
    private $service;

    public function __construct(CompareProductService $service)
    {
        $this->service = $service;
    }

    /**
     * Compare product
     * @param Request $request
     * @return View
     */
    public function index(Request $request)
    {
        $seo = SeoFilters::getSeo();
        $compares = $this->service->getComparesProduct();

        if (count($compares) == 0) {
            return view('compare.empty');
        }

        return view('compare.index', compact('compares','seo'));
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function addProduct(Request $request)
    {
        $data = $this->service->addProductToCompare($request);
        return Response::json($data + [ 'categories_html' => view('partials.layout.compare-list')->render() ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteProduct(Request $request)
    {
        $count = $this->service->deleteProductFromCompare($request);
        return Response::json(compact('count'));
    }

    /**
     * @param $category
     * @param CategoryRepository $categoryRepository
     * @return RedirectResponse|View
     */
    public function compare($category, CategoryRepository $categoryRepository)
    {
        $seo = SeoFilters::getSeo();
        $products = $this->service->getCompareProductsByCategory($category);
        if ($products->count() == 0) {
            return redirect()->route('product.compare');
        }
        $category = $categoryRepository->whereFirst('slug', $category);
        $attributes = $this->service->getAttributesCompare($products, request()->has('show'));
        return view('compare.index-list', compact('products', 'attributes', 'category', 'seo'));
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function dropCategory(Request $request)
    {
        return $this->service->dropCategory($request->get('category'));
    }
}
