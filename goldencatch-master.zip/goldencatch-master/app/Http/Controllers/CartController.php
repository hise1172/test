<?php

namespace App\Http\Controllers;

use App\Helpers\Error;
use App\Services\CartService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

/**
 * Class CartController
 * @package App\Http\Controllers
 */
class CartController extends Controller
{

    /**
     * @var CartService
     */
    private $cartService;

    /**
     * CartController constructor.
     * @param CartService $cartService
     */
    public function __construct(CartService $cartService)
    {
        $this->cartService = $cartService;
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function add(Request $request)
    {
        $request->validate([
            'product' => 'required|int|min:1',
        ]);

        if (!$this->cartService->canAddItem($request->get('product'), $request->isResellersConsole)) {
            $this->addErrorOnCartChangeAction($request->isResellersConsole);

            return Response::json([
                'status' => false,
                'reload' => true,
            ]);
        }

        $this->cartService->addProduct($request);

        return Response::json([
            'status' => true,
            'view' => $this->cartService->makeView($request->isResellersConsole),
            'count' => $this->cartService->countProducts(),
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function remove(Request $request)
    {
        $count = $this->cartService->removeProduct($request);
        $view = $this->cartService->makeView();
        return Response::json(compact('count', 'view'));
    }

    /**
     * @return JsonResponse
     */
    public function clear()
    {
        $this->cartService->clear();
        $view = $this->cartService->makeView();
        $count = 0;
        return Response::json(compact('view', 'count'));
    }


    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function changeProduct(Request $request)
    {
        if (!$request->filled('minus') && !$this->cartService->canAddItem($request->get('product'), $request->isResellersConsole)) {
            $this->addErrorOnCartChangeAction($request->isResellersConsole);

            return Response::json([
                'status' => false,
                'reload' => true,
            ]);
        }

        $this->cartService->minusPlusProduct($request);

        return Response::json([
            'status' => true,
            'view' => $this->cartService->makeView($request->isResellersConsole),
            'count' => $this->cartService->countProducts(),
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function viewCartProduct(Request $request)
    {
        $productCarts = $this->cartService->getCartOrCreate();
        $cart = $productCarts->productCart();
        $sum = $cart['summ'];
        $count = $productCarts->count();
        return Response::json(compact('sum', 'count'));
    }

    #region Helpers

    /**
     * @param bool $for_resellers
     */
    private function addErrorOnCartChangeAction(bool $for_resellers)
    {
        $this->cartService->fixProductsCount($for_resellers);

        Error::addToResponse($this->cartService->getValidationErrors());
    }

    #endregion
}
