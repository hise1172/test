<?php

namespace App\Http\Controllers;

use App\Http\Requests\SubscrubeRequest;
use App\Models\SubscribeEmail;
use Illuminate\Support\Facades\DB;

class SubscribeController extends Controller
{
    public function index(SubscrubeRequest $request)
    {
        SubscribeEmail::create([
            'email' => $request->get('email'),
            'active' => 1
        ]);

        echo __('footer.thanks for subscribing');
    }
}
