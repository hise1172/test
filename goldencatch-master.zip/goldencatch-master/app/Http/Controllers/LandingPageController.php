<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use App\Models\LandingPage;
use App\Repositories\BrandRepository;
use App\Repositories\ProductRepository;
use App\Repositories\SliderRepository;
use App\Repositories\StoriesRepository;
use Illuminate\Http\Request;
use Jenssegers\Agent\Agent as Agent;

class LandingPageController extends Controller
{
    #region Actions

    /**
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function show(Request $request)
    {
        /** @var string $slug */
        $slug = $request->route()->parameter('slug');

        if (!$slug) {
            throw new \RuntimeException('Invalid $slug');
        }

        $landing = LandingPage::init($slug);

        if (!$landing) {
            if ($slug === LandingPage::HOMEPAGE_SLUG) {
                return $this->showMain($request);
            }

            abort(404);
        }

        return $this->build($landing);
    }

    #endregion

    #region Getters

    /**
     * @param Request $request
     * @param LandingPage $landing
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    private function showMain(Request $request)
    {
        $repository = app()->make(ProductRepository::class);
        $sliderRepository = app()->make(SliderRepository::class);
        $brandRepository = app()->make(BrandRepository::class);
        $storyRepository = app()->make(StoriesRepository::class);

        $seo = SeoFilters::getSeo();
        $Agent = new Agent();
        $sliders = $sliderRepository->getMobileSlider();

        if ($Agent->isDesktop()) {
            $sliders = $sliderRepository->getDesktopSlider();
        }

        $stories=$storyRepository->getStories();
        $new_product = $repository->getNewProduct();
        $bestSellingProducts = $repository->getBestSelling();
        $wait_product = $repository->getWaitProduct();
        $meta = SeoHelper::meta(\Lang::get('seo.title-main'), \Lang::get('seo.description-main'));
        $brands = $brandRepository->all();

        if ($request->get('compare')) {
            $request->session()->flash('flash_message', \Lang::get('content.Select a product to compare'));
        }

        return view('main-page', compact('new_product',
            'bestSellingProducts',
            'wait_product',
            'sliders',
            'seo', 'brands', 'Agent', 'meta','stories'));
    }

    /**
     * @param LandingPage $landing_page
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    private function build(LandingPage $landing_page)
    {
        return view('landing-pages.index')
            ->with([
                'meta' => SeoHelper::meta($landing_page->title, $landing_page->title),
                'landing_page' => $landing_page,
            ]);
    }

    #endregion
}
