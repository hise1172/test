<?php

namespace App\Http\Controllers;

use App\Http\Requests\QuestionAnswersStoreRequest;
use App\Repositories\QuestionAnswerRepository;
use App\Services\QuestionAnswersService;
use Illuminate\Http\Request;

/**
 * Class ProductQuestionAnswersController
 * @package App\Http\Controllers
 */
class ProductQuestionAnswersController extends Controller
{
    /**
     * @var QuestionAnswerRepository
     */
    private $repository;

    /**
     * ProductQuestionAnswersController constructor.
     * @param QuestionAnswerRepository $repository
     */
    public function __construct(QuestionAnswerRepository $repository)
    {
        $this->repository = $repository;
    }

    public function index(QuestionAnswerRepository $repository)
    {
        $questions = $repository->paginate( \Auth::id() );
        return view('account.questions', compact('questions'));
    }

    /**
     * @param QuestionAnswersStoreRequest $request
     * @param QuestionAnswersService $service
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request, QuestionAnswersService $service)
    {
        $answerData = $service->getQuestionAnswerData($request);
        $this->repository->create($answerData);
        return redirect()->back();
    }
}
