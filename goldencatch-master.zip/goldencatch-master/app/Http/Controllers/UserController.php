<?php

namespace App\Http\Controllers;


use App\Helpers\SeoFilters;
use App\Services\OrderService;
use Illuminate\Contracts\Pagination\Paginator;
use App\Http\Requests\UserUpdateRequest;
use App\Models\Order;
use App\Services\UserService;
use App\Services\UserWaitingService;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Class UserController
 * @package App\Http\Controllers
 */
class UserController extends Controller
{
    /**
     * @var UserService
     */
    private $service;

    /**
     * UserController constructor.
     * @param UserService $service
     */
    public function __construct(UserService $service)
    {
        $this->service = $service;
    }

    /**
     * @return View
     */
    public function index()
    {
        $seo = SeoFilters::getSeo();
        /** @var User $user */
        $user = Auth::user();
        // OrderService $orderService
        // $orders = $orderService->getAll(2);
        return view('account.personal', compact(
            'user',
            'seo',
        ));
    }

    /**
     * @return View
     */
    public function edit()
    {
        $seo = SeoFilters::getSeo();
        $user = Auth::user();
        return view('account.edit-account', compact('user', 'seo'));
    }

    public function update(UserUpdateRequest $request)
    {
        $this->service->updateUser($request);
        return redirect()->route('account.edit')->with('success', 'Данные обновлены');
    }

    /**
     * @return View
     */
    public function editPassword()
    {
        $seo = SeoFilters::getSeo();

        /** @var User $user */
        $user = Auth::user();

        return view('account.edit-password', compact('seo'))
            ->with([
                'user_has_old_password' => $user->hasOldPassword()
            ]);
    }

    /**
     * @return View
     */
    public function orders(Request $request, OrderService $service)
    {
        $seo = SeoFilters::getSeo();
        $perPage = $request->get('perPage', 24);
        $orders = $service->getAll($perPage)->appends(['perPage' => $perPage]);
        return view('account.orders.index', compact('seo', 'orders'));
    }

    /**
     * @return View
     */
    public function orderTrack( Order $order )
    {
        // is not owner - redirect
        if( ! $order->user_id  || $order->user_id != Auth::id() ){
            return redirect( routeLocale('order.track', [ 'id' => $order->id ] ) );
        }
        $seo = SeoFilters::getSeo();
        return view('account.orders.order', compact('seo', 'order'));
    }

    /**
     * @param Request $request
     * @param UserWaitingService $service
     * @return View
     */
    public function expectedItems(Request $request, UserWaitingService $service)
    {
        $seo = SeoFilters::getSeo();
        $products = $service->getUserWaitingProduct($request);

        return view('account.expected-items', compact('products', 'seo'));
    }
}
