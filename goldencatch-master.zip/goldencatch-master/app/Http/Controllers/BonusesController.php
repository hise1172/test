<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\View\View;

class BonusesController extends Controller
{
    /**
     * @return View
     */
    public function index()
    {
        /** @var User $user */
        $user = auth()->user();

        return view('account.bonus-club')
            ->with([
                'user' => $user,
            ]);
    }
}
