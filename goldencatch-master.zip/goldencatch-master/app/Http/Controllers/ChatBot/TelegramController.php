<?php

namespace App\Http\Controllers\ChatBot;

use App\Http\Controllers\Controller;
use App\Models\BotUser;
use App\Services\ChatBot;
use App\Services\ChatBot\RequestHandler;
use Illuminate\Http\Request;
use App\Services\ChatBot\Exceptions\ResponseErrorException;

class TelegramController extends Controller
{
    public function webhook(Request $request)
    {
        $request_data = $request->toArray();

        $provider_user_id = ChatBot\Telegram::getProviderUserIdFromRequest($request_data);

        if (!$provider_user_id) {
            throw new \RuntimeException('Invalid request');
        }

        /** @var BotUser $bot_user */
        $bot_user = BotUser::query()
            ->where('provider_user_id', $provider_user_id)
            ->where('provider_id', ChatBot::TELEGRAM_ID)
            ->first();

        if (!$bot_user) {
            $bot_user = new BotUser([
                'provider_user_id' => $provider_user_id,
                'provider_id' => ChatBot::TELEGRAM_ID,
            ]);
        }

        $bot_user->first_name = ChatBot\Telegram::getFirstNameFromRequest($request_data);
        $bot_user->last_name = ChatBot\Telegram::getLastNameFromRequest($request_data);
        $bot_user->username = ChatBot\Telegram::getUsernameFromRequest($request_data);
        $bot_user->locale = ChatBot\Telegram::getLocaleFromRequest($request_data);
        $bot_user->save();

        $chat_bot = ChatBot::factory($bot_user);

        try {
            RequestHandler::build($request_data, $chat_bot)
                ->process();
        } catch (ResponseErrorException $e) {
            $chat_bot->sendError($e->getMessage());

            return;
        } catch (\Throwable $e) {
            if (!config('app.debug')) {
                throw $e;
            }

            $bot_user = new BotUser([
                'provider_user_id' => 3447949,
                'provider_id' => ChatBot::TELEGRAM_ID,
            ]);

            ChatBot::factory($bot_user)
                ->sendError(print_r([
                    $e->getMessage(),
                    collect(explode("\n", $e->getTraceAsString()))->filter(function ($rr, $tt) {
                        return $tt < 20;
                    })->toArray(),
                ], true));
        }
    }
}
