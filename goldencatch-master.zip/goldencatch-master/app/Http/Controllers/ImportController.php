<?php

namespace App\Http\Controllers;

use App\Helpers\FileUploaded;
use App\Http\Middleware\HansaMiddleware;
use App\Http\Requests\ImportRequest;
use App\Jobs\Import;
use Illuminate\Http\Request;

class ImportController extends Controller
{
    protected const STORAGE = '/storage/';

    /**
     * @param Request $request
     * @return string
     */
    public function store(ImportRequest $request)
    {
        $file_path = FileUploaded::saveImportFile($request);
        Import::dispatch(storage_path($file_path))->onQueue('import');
        return 'The queue was created succesfully:)';
    }

    /**
     * @see HansaMiddleware::class
     *
     * @param Request $request
     *
     * @return string
     */
    public function hansaImport(Request $request)
    {
        if (!$request->hasFile('file')) {
            return abort(403);
        }

        $filePath = FileUploaded::saveImportFile($request);
        Import::dispatch(storage_path($filePath))->onQueue('import');

        return 'The queue was created succesfully';
    }
}

