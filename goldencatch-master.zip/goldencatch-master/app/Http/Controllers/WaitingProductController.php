<?php

namespace App\Http\Controllers;

use App\Repositories\UserWaitingRepository;
use App\Services\UserWaitingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class WaitingProductController
 * @package App\Http\Controllers
 */
class WaitingProductController extends Controller
{
    /**
     * @var UserWaitingRepository
     */
    private $repository;

    /**
     * WaitingProductController constructor.
     * @param UserWaitingRepository $repository
     */
    public function __construct(UserWaitingRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param Request $request
     * @param UserWaitingService $service
     * @return JsonResponse
     */
    public function store(Request $request, UserWaitingService $service)
    {
        if (!Auth::check()) {
            return response()->json(null, JsonResponse::HTTP_UNAUTHORIZED);
        }
        $data = $service->getData($request);
        $count = $this->repository->addUserProduct($data);
        return response()->json(compact('count'));
    }


    /**
     * @param Request $request
     * @param UserWaitingService $service
     * @return JsonResponse
     */
    public function destroy(Request $request, UserWaitingService $service)
    {
        if (!Auth::check()) {
            return response()->json(null, JsonResponse::HTTP_UNAUTHORIZED);
        }
        $data = $service->getData($request);
        $count = $this->repository->deleteUserProduct($data);
        return response()->json(compact('count'));
    }
}
