<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HtmlSitemapController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $seoFilters = \App\Models\SeoFilters::all();
        return view('seo.htmlSitemap', ['filters' => $seoFilters]);
    }
}
