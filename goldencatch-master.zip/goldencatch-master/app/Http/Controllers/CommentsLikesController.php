<?php

namespace App\Http\Controllers;

use App\Models\CommentsLikes;
use Illuminate\Http\Request;

class CommentsLikesController extends Controller
{
    public function like(Request $request)
    {
        $likeableModel = $this->getLikeableModel();

        $like = $this->getVote( $request->get('id_comment'), $likeableModel );

        if( $like ){
            if( 0 == $like->vote ){
                $like->vote = 1;
                $like->save();
                return 2;
            }
            $like->delete();
            return 0;
        }

        $lik = [
            'user_id' => auth()->user()->id,
            'likeable_id' => $request->get('id_comment'),
            'likeable_type' => $likeableModel,
            'vote' => 1,
        ];

        CommentsLikes::create($lik);

        return 1;
    }

    public function dislike(Request $request)
    {
        $likeableModel = $this->getLikeableModel();

        $like = $this->getVote( $request->get('id_comment'), $likeableModel );

        if( $like ){
            if( 1 == $like->vote ){
                $like->vote = 0;
                $like->save();
                return 2;
            }
            $like->delete();
            return 0;
        }

        $dis = [
            'user_id' => auth()->user()->id,
            'likeable_id' => $request->get('id_comment'),
            'likeable_type' => $likeableModel,
            'vote' => 0,
        ];

        CommentsLikes::create($dis);

        return 1;
    }

    private function getLikeableModel() {
        $likeable_type = 'App\Models\UserProductReview';
        if(request()->exists('type') && ( request()->get('type') == 'question' || request()->get('type') == 'answer' ) )
        {
            $likeable_type = 'App\Models\Product\ProductQuestionAnswer';
        }
        return $likeable_type;
    }

    private function getVote($id, $type)
    {
        $like = CommentsLikes::where('user_id', auth()->user()->id)
            ->where('likeable_id', $id)
            ->where('likeable_type', $type);
        return $like->first();
    }
}
