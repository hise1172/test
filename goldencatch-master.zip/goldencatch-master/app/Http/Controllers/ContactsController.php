<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use Illuminate\View\View;

/**
 * Class ContactsController
 * @package App\Http\Controllers
 */
class ContactsController extends Controller
{
    /**
     * @return View
     */
    public function index()
    {
        $google_maps_api_key = config('services.maps_api_key');
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('Контакты|Golden Catch', 'test');
        return view('contacts.index', compact('seo', 'meta', 'google_maps_api_key'));
    }
}
