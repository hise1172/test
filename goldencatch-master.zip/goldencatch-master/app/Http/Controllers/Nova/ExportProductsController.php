<?php

namespace App\Http\Controllers\Nova;

use App\Services\ExportImport\ProductAttributes;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class ExportProductsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * @link GET /nova-export-product-attributes/?brands[]=1
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function download(Request $request)
    {
        /** @var User $user */
        $user = Auth::user();

        if (!$user->getRole()->isAdmin()) {
            return redirect(RouteServiceProvider::HOME);
        }

        set_time_limit(1800);

        $brand_ids = $request->get('brands', []);
        $category_ids = $request->get('categories', []);
        $products_of_week_only = (bool) $request->get('products_of_week_only', false);
        $include_attributes = (bool) $request->get('include_attributes', []);

        return Excel::download(new ProductAttributes\Export($brand_ids, $category_ids, $products_of_week_only, $include_attributes), 'export_products_' . date('Y-m-d') . '.csv', \Maatwebsite\Excel\Excel::CSV);
    }
}
