<?php

namespace App\Http\Controllers;

use App\Exceptions\OrderProductException;
use App\Helpers\Cart;
use App\Helpers\Error;
use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use App\Http\Requests\Order\OneClickOrderRequest;
use App\Http\Requests\Order\OrderHelpRequest;
use App\Http\Requests\Order\OrderRequest;
use App\Models\Delivery;
use App\Models\NovaPoshta\NovaPoshtaArea;
use App\Models\NovaPoshta\NovaPoshtaCities;
use App\Models\NovaPoshta\NovaPoshtaWarehouses;
use App\Models\PaymentMethod;
use App\Providers\RouteServiceProvider;
use App\Services\CartService;
use App\Services\Catalog\Pricing;
use App\Services\LiqpayService;
use App\Services\OrderService;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use App\Models;
use Str;
use App\Helpers\Deliver;
use GoogleTagManager;
use App\Models\Order;

/**
 * Class OrderController
 * @package App\Http\Controllers
 */
class OrderController extends Controller
{
    private const ACTION_ORDER_STORED = 'order_stored';

    /**
     * @var OrderService
     */
    private $orderService;

    private $liqpayService;

    private $delivery;

    /**
     * OrderController constructor.
     * @param OrderService $orderService
     * @param LiqpayService $liqpayService
     * @param Deliver $deliver
     */
    public function __construct(OrderService $orderService, LiqpayService $liqpayService, Deliver $deliver)
    {
        $this->orderService = $orderService;
        $this->liqpayService = $liqpayService;
        $this->delivery = $deliver;
    }

    #region Actions

    /**
     * @link GET /order
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|RedirectResponse
     */
    public function index(Request $request, CartService $cart_service)
    {
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('Order', 'Order');
        $user = Auth::user();
        /**
         * @var Cart $cart
         */
        $cart = $cart_service->getCartOrCreate();

        if ($cart->count() == 0) {
            return back();
        }

        if (empty($cart->productCart($request->isResellersConsole)['products'])) {
            Session::remove('cart'); // clean up the Cart if it is broken

            return back();
        }

        if (!$cart_service->isValid($request->isResellersConsole)) {
            $cart_service->fixProductsCount($request->isResellersConsole);

            $cart_service->getValidationErrors()
                && Error::addToResponse($cart_service->getValidationErrors());

            return back();
        }

        $cart = $cart->productCart($request->isResellersConsole);

        $areas = NovaPoshtaArea::all(['ref', 'description_ru']);
        $delivery = $this->delivery->getAllDelivery();

        GoogleTagManager::checkout($cart);

        $cart_collection = collect($cart['products'] ?? null);
        $parent_cart_collection = $cart_collection->map(function ($item, $key) {
            $product = Models\Product\Product::find($item['id']);

            return $product->parent_id ?? $product->id;
        });

        \LaravelFacebookPixel::createEvent('InitiateCheckout', $parameters = [
            'content_ids' => $parent_cart_collection->all(),
            'num_items' => count($cart['products']),
            'value' => $cart['summ'],
            'currency' => Pricing::CURRENCY_UAH,
            'content_type' => 'product',
        ]);

        return view('order.index', compact('user', 'cart', 'areas', 'delivery', 'seo','meta'))
            ->with([
                'isResellersConsole' => $request->isResellersConsole,
                'payment_methods' => PaymentMethod::whereIn(
                        'id',
                        PaymentMethod::getAllowedMethods($request->isResellersConsole)
                    )
                    ->get(),
                'delivery_methods' => static::getDeliveryMethods($delivery, $request->isResellersConsole),
                'message' => $request->session()->pull('message'),
                'total_sum_limit' => $request->isResellersConsole
                    ? 50 // USD
                    : 100, // UAH
            ]);
    }

    /**
     * @link POST /order
     * @param OrderRequest $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(OrderRequest $request)
    {
        /** @var $cart Cart */
        $cart = Session::get('cart', new Cart());

        if (!$cart->count()) {
            return redirect(RouteServiceProvider::HOME);
        }

        try {
            $order = $this->orderService->store($request, $cart);
        } catch (OrderProductException $e) {
            Error::addToResponse($e->getErrors());

            return back();
        }

        return redirect(route('order.show', ['order_hash' => $order->order_hash]))
            ->with(static::ACTION_ORDER_STORED, true);
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show(Request $request)
    {
        $db = Models\Order::where('order_id', $request->route()->parameter('order_hash'));

        if ($db->count() != 1) {
            return redirect(RouteServiceProvider::HOME)->with('error', 'Заказ не найден');
        }

        /** @var Models\Order $order */
        $order = $db->first();

        $seo = SeoFilters::getSeo();
        $products_list = $order->productOrders()->get();
        $count_product = $products_list->sum('count');

        $liqpayData = null;
        $liqpaySignature = null;

        if ($order->payment_method_id == PaymentMethod::LIQPAY) {
            $liqpayData = $this->liqpayService->setData($order->price, $order->order_id, $order->created_at,$order->id);
            $liqpaySignature = $this->liqpayService->setSignature($liqpayData);
        }

        $is_analytics_required = (bool) $request->session()->pull(static::ACTION_ORDER_STORED);

        if ($is_analytics_required) {
            $products = [
                'products' => $products_list,
            ];

            GoogleTagManager::purchase($products, $order);

            $order_collection = collect($products['products']);
            $parent_order_collection = $order_collection->map(function ($item, $key) {
                $product = Models\Product\Product::find($item['id']);
                return $product->parent_id ?? $product->id;
            });

            \LaravelFacebookPixel::createEvent('Purchase', $parameters = [
                'content_ids' => $parent_order_collection->all(),
                'num_items' => $order_collection->count(),
                'value' => $order->price,
                'currency' => Pricing::CURRENCY_UAH,
                'content_type' => 'product',
            ]);

        }

        return view('order.success', compact('liqpayData', 'liqpaySignature', 'order', 'count_product', 'seo'))
            ->with([
                'is_analytics_required' => $is_analytics_required,
                'isResellersConsole' => $request->isResellersConsole,
            ]);
    }

    /**
     * @param OrderHelpRequest $request
     */
    public function helpRequest(OrderHelpRequest $request)
    {
        /** @var $cart Cart */
        $cart = Session::get('cart', new Cart());

        if (!$cart->count()) {
            return back();
        }

        $order = $this->orderService->store($request, $cart);

        return redirect(route('order'))->with('message', 'Заявка успешно отправлена. Код заявки: ' . $order->id);
    }

    /**
     * @param OneClickOrderRequest $clickOrderRequest
     */
    public function byOneClick(OneClickOrderRequest $request)
    {
        $cart = new Cart();

        $cart->add($request->product->id);

        try {
            $order = $this->orderService->store($request, $cart);
        } catch (OrderProductException $e) {
            $errors = $e->getErrors();

            Error::addToResponse($errors);

            return Response::json([
                'status' => false,
                'reload' => true,
                'message' => reset($errors),
            ]);
        }

        return Response::json([
            'status' => true,
            'message' => 'Заявка успешно отправлена. Код заявки: ' . $order->id,
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse|RedirectResponse
     */
    public function novaPoshtaArea(Request $request)
    {
        if (!$request->ajax()) {
            return back();
        }
        return Response::json(NovaPoshtaArea::all(['ref', 'description_ru']));
    }

    /**
     * @param Request $request
     * @return JsonResponse|RedirectResponse
     */
    public function novaPoshtaCity(Request $request)
    {
        if (!$request->ajax()) {
            return back();
        }

        $cities = NovaPoshtaCities::limit(10)
            ->get(['description', 'area_description', 'ref']);

        if ($request->exists('search')) {
            $data = $request->validate([
                'search' => 'string'
            ]);
            $cities = NovaPoshtaCities::where('description', 'like', "{$data['search']}%")
                ->get(['description', 'area_description', 'ref']);
        }

        $result = [];

        foreach ($cities as $city) {
            $result['results'][] = [
                'id' => $city->ref,
                'text' => $city->description . ", " . $city->area_description
            ];
        }

        return Response::json($result);
    }

    /**
     * @param Request $request
     * @return JsonResponse|RedirectResponse
     */
    public function novaPoshtaWarehouses(Request $request)
    {
        if (!$request->ajax()) {
            return back();
        }

        $ref = $request->get('ref');
        $warehouses = NovaPoshtaWarehouses::where('city_ref', $ref)->get(['description', 'ref']);
        if ($request->exists('search')) {
            $data = $request->validate([
                'search' => 'string'
            ]);
            $warehouses = NovaPoshtaWarehouses::where('description', 'like', "%{$data['search']}%")->where('city_ref', $ref)->get(['description', 'ref']);
        }


        $result = [];
        foreach ($warehouses as $warehouse) {
            $result['results'][] = [
                'id' => $warehouse->ref,
                'text' => $warehouse->description
            ];
        }

        return Response::json($result);
    }

    #endregion

    #region Helpers

    /**
     * @param Delivery[] $delivery
     * @param false $for_resellers_console
     *
     * @return array
     */
    public function getDeliveryMethods(Collection $deliveries, bool $for_resellers_console = false): array
    {
        $allowed_methods = [
            Delivery::NEWPOST_DEPARTMENT => true,
        ];

        if ($for_resellers_console) {
            $allowed_methods = [
                Delivery::PICKUP_ODESSA => true,
                Delivery::NEWPOST_DEPARTMENT  => true,
                Delivery::DELIVERY_COMPANY => true,
                Delivery::AUTOLUX => true,
                Delivery::TRANSPORT_TO_CITY => true,
            ];
        }

        $result = [];

        foreach ($deliveries as $delivery) {
            /** @var Delivery $delivery */
            if (!isset($allowed_methods[$delivery->slug])) {
                continue;
            }

            $result[] = $delivery;
        }

        return $result;
    }

    #endregion

    public function track()
    {
        $order = Order::find( (int) request()->get('id') );

        if( ! $order ){
            abort(404);
            return view('order.tracking.empty?' );
        }

        if( Auth::id() && $order->user_id && Auth::id() == $order->user_id ){
            return redirect( routeLocale('account.orders.track', $order) );
        }

        if( ! request()->isMethod('post') ){
            return view('order.tracking.guest', compact('order') );
        }

        if( $order->phone == '' || $order->phone != request()->get('phone') ){
            return back()->withErrors(['phone' => __('catalog.order.Phone number does not match')]);
        }

        return view('order.tracking.details', compact('order') );
    }

}
