<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductReviewStore;
use App\Repositories\ProductReviewRepository;
use App\Services\ProductReviewService;
use Illuminate\Http\Request;
use Doctrine\DBAL\Driver\PDOException;

class ProductReviewController extends Controller
{
    /**
     * @var ProductReviewService
     */
    private $service;

    /**
     * ProductReviewController constructor.
     * @param ProductReviewService $service
     */
    public function __construct(ProductReviewService $service)
    {
        $this->service = $service;
    }

    public function index(ProductReviewRepository $repository)
    {
        $reviews = $repository->paginate( \Auth::id() );
        return view('account.reviews', compact('reviews'));
    }

    public function store(ProductReviewStore $reviewStore, ProductReviewRepository $repository)
    {
        $commentData = $this->service->getReviewData($reviewStore);
        $comment = $repository->create($commentData);
        $this->service->storeImageAttach($reviewStore, $comment->id);
        return back();
    }
}
