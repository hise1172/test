<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Class NewsController
 * @package App\Http\Controllers
 */
class NewsController extends Controller
{
    /**
     * @return View
     */
    public function index()
    {
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('Golden Catch|Интернет магазин', 'Golden Catch|Интернет магазин');
        return view('news.main-page', compact('seo', 'meta'));
    }

    /**
     * @return View
     */
    public function show()
    {
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('Golden Catch|Интернет магазин', 'Golden Catch|Интернет магазин');
        return view('news.single', compact('seo', 'meta'));
    }
}
