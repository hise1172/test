<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBuyOneClickRequest;
use App\Models\BuyOneClick;
use App\Services\BuyOneClickService;
use Illuminate\Http\Request;

class BuyOneClickController extends Controller
{
    protected $buyOneClickService;
    const  URL='/ru/product/';

    /**
     * BuyOneClickController constructor.
     * @param BuyOneClickService $buyOneClickService
     */
    public function __construct(BuyOneClickService $buyOneClickService)
    {
        deprecated(BuyOneClick::class);

        $this->buyOneClickService=$buyOneClickService;
    }

    /**
     * @param StoreBuyOneClickRequest $request
     * @return mixed
     */
    public function store(StoreBuyOneClickRequest $request)
    {
        $request->merge(['ip'=>$request->ip(),'link'=>self::URL.$request->get('link')]);
        $this->buyOneClickService->store($request);
        return back();
    }
}
