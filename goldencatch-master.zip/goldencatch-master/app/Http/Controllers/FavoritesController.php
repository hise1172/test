<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Repositories\ProductFavoriteRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Class FavoritesController
 * @package App\Http\Controllers
 */
class FavoritesController extends Controller
{

    /**
     * @param Request $request
     * @param ProductFavoriteRepository $repository
     * @return View
     */
    public function index(Request $request, ProductFavoriteRepository $repository)
    {
        $seo = SeoFilters::getSeo();
        $products = $repository->getUserFavorites(Auth::id())
            ->paginate($request->get('count'))->appends($request->all());

        return view('account.favorites', compact('products', 'seo'));
    }

    /**
     * @param Request $request
     * @param ProductFavoriteRepository $repository
     * @return JsonResponse|RedirectResponse
     */
    public function store(Request $request, ProductFavoriteRepository $repository)
    {
        if (!$request->isJson()) {
            return redirect()->back();
        }

        $product_id = $request->get('product');
        $count = $repository->add($product_id);

        return response()->json(compact('count'));
    }

    /**
     * @param Request $request
     * @param ProductFavoriteRepository $repository
     * @return JsonResponse|RedirectResponse
     */
    public function destroy(Request $request, ProductFavoriteRepository $repository)
    {
        if (!$request->isJson()) {
            return redirect()->back();
        }

        $product_id = $request->get('product');
        $count = $repository->remove($product_id);

        return response()->json(compact('count'));
    }
}
