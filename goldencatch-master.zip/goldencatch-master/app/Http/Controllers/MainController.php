<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Repositories\ProductRepository;
use App\Repositories\SliderRepository;
use App\Repositories\StoriesRepository;
use Illuminate\Http\Request;
use App\Helpers\SeoHelper;
use App\Repositories\BrandRepository;
use Jenssegers\Agent\Agent as Agent;

/**
 * Class MainController
 * Main page (url /) controller
 * @package App\Http\Controllers
 */
class MainController extends Controller
{
    public function search(Request $request, ProductRepository $repository)
    {
        $seo = SeoFilters::getSeo();

        $new_product = $repository->getNewProduct();
        $wait_product = $repository->getWaitProduct();
        $search_result = $repository->seacrh($request->get('search'));
        return view('product.search', compact('search_result', 'new_product',
            'wait_product', 'seo'));
    }

    public function deliverypay()
    {
        return view('deliverypay');
    }

    public function returnproduct()
    {
        return view('returnproduct');
    }

    public function wholesaleclients()
    {
        return view('wholesaleclients');
    }
}
