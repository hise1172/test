<?php

namespace App\Http\Controllers;

use App\Helpers\SeoFilters;
use App\Helpers\SeoHelper;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Class AboutController
 * @package App\Http\Controllers
 */
class AboutController extends Controller
{
    /**
     * @return View
     */
    public function index()
    {
        $seo = SeoFilters::getSeo();
        $meta = SeoHelper::meta('О нас|Golden Catch', 'test');
        return view('about.about-us', compact('seo', 'meta'));
    }
}
