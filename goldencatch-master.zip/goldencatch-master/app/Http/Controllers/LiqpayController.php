<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Services\LiqpayService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LiqpayController extends Controller
{
    /**
     * @param Request $request
     * @param LiqpayService $service
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function server(Request $request, LiqpayService $service)
    {

        $data = $service->getData($request);

        if( ! $data ){
            return response()->json(['message' => 'not found'], 404);
        }

        /**
         * @var Order $order
         */
        $order = Order::where('order_id', $data['order_id'])->firstOrFail();

        if ($service->checkPayment($data['info'], $order)) {
            $answers = $order->liqpayHash->answers;
            $answers[$data['status'] . '-' . $data['payment_id']] = $data;
            $order->liqpayHash->answers = $answers;
            $order->liqpayHash->save();
        }
        return response()->json(['result' => 'success']);
    }

    /**
     * @param Request $request
     */
    public function client(Request $request)
    {
        $data = json_encode(base64_decode($request->get('data', true, 512, JSON_UNESCAPED_UNICODE)));

        Log::error ('LiqpayController server data:' );
        Log::debug($data);
    }
}
