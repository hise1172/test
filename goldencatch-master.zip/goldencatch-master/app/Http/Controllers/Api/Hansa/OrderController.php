<?php

namespace App\Http\Controllers\Api\Hansa;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Hansa\OrderCollection;
use App\Http\Resources\Api\Hansa\OrderResource;
use App\Models\Order;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     *
     * @return OrderCollection
     */
    public function index(Request $request)
    {
        /** @var Builder $builder */
        $builder = Order::latest();

        $createdAtFrom = $request->date('filter.createdAtFrom');

        if ($createdAtFrom) {
            $builder->where('created_at', '>=', $createdAtFrom->format('Y-m-d'));
        }

        $orders = $builder
            ->paginate(
                $request->get('limit', 10)
            );

        return new OrderCollection($orders);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return OrderResource
     */
    public function show($id)
    {
        /** @var Order $order */
        $order = Order::findOrFail($id);

        return new OrderResource($order);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     *
     * @return OrderResource
     */
    public function update(Request $request, $id)
    {
        /** @var Order $order */
        $order = Order::findOrFail($id);

        $trackNumber = $request->string('delivery.trackNumber');

        if ($trackNumber) {
            $order->tracking_code = $trackNumber;
        }

        $order->save();

        return new OrderResource($order);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
