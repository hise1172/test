<?php

namespace App\Http\Controllers;

use App\Services\Catalog\CatalogService;
use App\Services\Catalog\Routing\WholesaleRouteParams;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View as ViewFacade;

/**
 * Class CatalogController
 * @package App\Http\Controllers
 */
class WholesaleCatalogController extends Controller
{
    private $catalogService;

    public function __construct(CatalogService $catalogService)
    {
        $this->catalogService = $catalogService;
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\View|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function catalog(Request $request)
    {
        if (!$this->catalogService->validateRequest($request, new WholesaleRouteParams())) {
            return redirect(route('wholesale-catalog'));
        }

        return ViewFacade::make('catalog.wholesale');
    }
}
