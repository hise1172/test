<?php

namespace App\Helpers;

use Str;
use App\Jobs\GenerateFuaFeed;
use App\Jobs\GenerateICMLFeed;
use App\Models\Product\Product;
use App\Jobs\GenerateGoogleFeed;
use App\Jobs\GeneratePromuaFeed;
use App\Jobs\GenerateRozetkaFeed;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use App\Jobs\GenerateHotlineFeedJob;

/**
 * Class FileUploaded
 * @package App\Helpers
 */
final class Import
{
    private Collection $keysMapping;

    private Collection $fieldHandlers;

    public function import($file_path)
    {
        $logger = Log::channel('importLog');
        $file = fopen($file_path, 'r');
        if (!$file) {
            return -1;
        }

        $logger->info('Import started');

        $this->initSettings();

        $importKeys = null;
        $importData = collect();
        while (!feof($file) && ($line = fgets($file))) {
            if (empty($importKeys)) {
                $line = str_getcsv($line, ';', '"');
                $importKeys = collect($line)->map(fn($fieldName) => $this->keysMapping->get($fieldName));
                continue;
            }

            if (strpos($line, "\r")) {
                $lines = explode("\r", $line);
                foreach ($lines as $lineStr) {
                    $currentLine = str_getcsv($lineStr, ';', '"');
                    if(count($importKeys->toArray()) == count($currentLine)){
                        $rowData = array_combine($importKeys->toArray(), $currentLine);
                        foreach ($this->fieldHandlers as $fieldName => $handler) {
                            if (is_callable($handler)) {
                                $rowData[$fieldName] = $handler($rowData[$fieldName]);
                            } elseif (is_array($handler)) {
                                foreach ($handler as $h) {
                                    $rowData[$fieldName] = $h($rowData[$fieldName]);
                                }
                            }
                        }

                        $importData->push($rowData);
                    }
                }
            } else {
                $line = str_getcsv($line, ';', '"');
                if(count($importKeys->toArray()) == count($line)){
                    $rowData = array_combine($importKeys->toArray(), $line);
                    foreach ($this->fieldHandlers as $fieldName => $handler) {
                        if (is_callable($handler)) {
                            $rowData[$fieldName] = $handler($rowData[$fieldName]);
                        } elseif (is_array($handler)) {
                            foreach ($handler as $h) {
                                $rowData[$fieldName] = $h($rowData[$fieldName]);
                            }
                        }
                    }

                    $importData->push($rowData);
                }
            }
        }

        $logger->info("Recieved rows for update: {$importData->count()}");

        $updatedProductIds = collect();
        foreach ($importData as $productData) {
            $product = Product::query()->where('SKU', $productData['SKU'])->first();
            if (!$product) {
                continue;
            }

            $product->fill($productData);
            $product->save();

            $updatedProductIds->push($product->id);
        }

        $logger->info("Updated products: {$updatedProductIds->count()}");

        if (!empty($updatedProductIds)) {
            $noStockProducts = Product::query()
                ->select('id')
                ->whereNotIn('id', $updatedProductIds)
                ->whereDoesntHave('modifications')
                ->count();

            Product::query()
                ->select('id')
                ->whereNotIn('id', $updatedProductIds)
                ->whereDoesntHave('modifications')
                ->chunkById(1000, function (Collection $products) {
                    Product::query()
                        ->whereIn('id', $products->map(fn(Product $product) => $product->id))
                        ->update([
                           'status' => 0,
                           'stock' => 0,
                           'stock_opt' => 0,
                       ]);
                });

            $logger->info("Products with no stock: {$noStockProducts}");
        }

        $logger->info("Import was successfully completed");
        GenerateGoogleFeed::dispatch()->onQueue('feeds');
        GenerateICMLFeed::dispatch()->onQueue('feeds');
        GenerateRozetkaFeed::dispatch()->onQueue('feeds');
        GeneratePromuaFeed::dispatch()->onQueue('feeds');
        GenerateFuaFeed::dispatch()->onQueue('feeds');
        GenerateHotlineFeedJob::dispatch()->onQueue('feeds');
    }

    private function initSettings()
    {
        $this->keysMapping = collect([
            'sku'                      => 'SKU',
            'weight'                   => 'weight',
            'width'                    => 'width',
            'height'                   => 'height',
            'depth'                    => 'depth',
            'volume'                   => 'volume',
            'brutto'                   => 'brutto',
            'netto'                    => 'netto',
            'price'                    => 'price',
            'qty'                      => 'stock',
            'opt_qty'                  => 'stock_opt',
            'special_price'            => 'stock_price',
            'avail'                    => 'retail',
            'availopt'                 => 'wholesale',
            'barcode'                  => 'barcode',
            'group_price:Opt 0%'       => 'wholesale_price_uah',
            'group_price:Opt -5%'      => 'wholesale_price_uah_5',
            'group_price:Opt -10%'     => 'wholesale_price_uah_10',
            'group_price:Opt -15%'     => 'wholesale_price_uah_15',
            'group_price:Opt 0% USD'   => 'wholesale_usd',
            'group_price:Opt -5% USD'  => 'wholesale_usd_5',
            'group_price:Opt -10% USD' => 'wholesale_usd_10',
            'group_price:Opt -15% USD' => 'wholesale_usd_15',
        ]);

        $numericFormatter = (fn($value) => str_replace(',', '.', $value));
        $priceFormatter = (fn($price) => number_format((float)$price, 2, '.', ''));
        $this->fieldHandlers = collect([
            'price' => $priceFormatter,
            'stock_price' => $priceFormatter,
            'weight' => [$numericFormatter, $priceFormatter],
        ]);
    }
}
