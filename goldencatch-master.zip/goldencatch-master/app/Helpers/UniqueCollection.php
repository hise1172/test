<?php


namespace App\Helpers;

final class UniqueCollection
{
    /**
     * @var array
     */
    private $items = [];

    public function __construct(...$items)
    {
        foreach ($items as $item) {
            $this->add($item);
        }
    }

    /**
     * count items
     * @return int
     */
    public function count()
    {
        return count($this->items);
    }

    /**
     * add item
     * @param $value
     * @return $this
     */
    public function add($value)
    {
        $key = $this->getKey($value);
        if (!array_key_exists($key, $this->items)) {
            $this->items[$key] = $value;
        }
        return $this;
    }

    /**
     * delete item
     * @param $value
     * @return bool
     */
    public function delete($value)
    {
        $key = $this->getKey($value);
        if (array_key_exists($key, $this->items)) {
            unset($this->items[$key]);
            return true;
        }
        return false;
    }

    /**
     * Return md5 key of value
     * @param $value
     * @return string
     */
    private function getKey($value)
    {
        return md5($value);
    }

    /**
     * Get array value
     * @return array
     */
    public function toArray()
    {
        return array_values($this->items);
    }
}
