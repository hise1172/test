<?php


namespace App\Helpers;

use App\Models\SiteSetting;
use Illuminate\Database\Eloquent\Collection;

/**
 * Class SettingHelper
 * @package App\Helpers
 */
final class SettingHelper
{
    /**
     * @param $page
     * @return array
     */
    public static function settingPage($page)
    {
        $settings = SiteSetting::where('page', $page)
            ->get(['key', 'value'])
            ->mapToGroups(function ($item) {
                return [$item['key'] => $item['value']];
            })->toArray();
        //Convert key to value, or array
        foreach ($settings as $key => $value) {
            $value = array_unique($value);
            if (count($value) == 1) {
                $settings[$key] = $value[0];
            }
        }
        return $settings;
    }

    /**
     * @param $key
     * @return Collection
     */
    public static function get($key)
    {
        return SiteSetting::query()->where('key', $key)->get();
    }

    /**
     * @param mixed ...$keys
     * @return Collection
     */
    public static function getAll(...$keys)
    {
        return SiteSetting::query()->whereIn('key', $keys)->get();
    }
}
