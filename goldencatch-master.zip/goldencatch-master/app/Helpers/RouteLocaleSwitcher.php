<?php

namespace App\Helpers;

use App\DataContainers\AbstractDataContainer;
use App\Models\Translate;
use Illuminate\Support\Facades\Route;

/**
 * @property string route_name
 * @property string[] parameters
 * @property string locale
 */
class RouteLocaleSwitcher extends AbstractDataContainer
{
    protected array $parameters = [];

    #region Builders

    /**
     * @param string $route_name
     * @param array $parameters
     * [
     *      'locale' => string,
     *      ...
     * ]
     *
     * @return static
     */
    public static function build(string $route_name, array $parameters)
    {
        $locale = $parameters['locale'] ?? config('app.default_locale');

        unset($parameters['locale']);

        $object = static::make([
                'route_name' => $route_name,
                'parameters' => $parameters,
            ])
            ->locale($locale);

        return $object;
    }

    #endregion

    #region Is Condition methods

    /**
     * @return bool
     */
    private function isCurrentLocaleDefault(): bool
    {
        return $this->locale === config('app.default_locale');
    }

    /**
     * @return bool
     */
    private function isRouteNameWithLocale(): bool
    {
        return substr($this->route_name, -2) === '-l';
    }

    /**
     * @return bool
     */
    private function isRouteNameDefault(): bool
    {
        return $this->getRouteName() === 'main' || $this->getRouteName() === 'main-l';
    }

    #endregion

    #region Setters

    /**
     * @param string $locale
     *
     * @return $this
     */
    private function locale(string $locale)
    {
        switch ($locale) {
            case Translate::UA:
            case Translate::RU:
                break;

            default:
                throw new \InvalidArgumentException('Invalid $locale');
        }

        $this->locale = $locale;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @return string
     */
    public function getRouteName(): string
    {
        if (!$this->isCurrentLocaleDefault() && !$this->isRouteNameWithLocale()) {
            $this->route_name .= '-l';
        } elseif ($this->isCurrentLocaleDefault() && $this->isRouteNameWithLocale()) {
            $this->route_name = substr($this->route_name, 0, -2);
        }

        if (!Route::has($this->route_name)) {
            return $this->isCurrentLocaleDefault()
                ? 'main'
                : 'main-l';
        }

        return $this->route_name;
    }

    /**
     * @return string[]
     */
    public function getParameters()
    {
        if ($this->isRouteNameDefault()) {
            return $this->isCurrentLocaleDefault()
                ? []
                : ['locale' => $this->locale];
        }

        if ($this->isCurrentLocaleDefault()) {
            unset($this->parameters['locale']);
        } else {
            $this->parameters = [
                    'locale' => $this->locale,
                ] + $this->parameters;
        }

        return $this->parameters;
    }

    #endregion
}
