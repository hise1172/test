<?php


namespace App\Helpers;


class SeoHelper
{
    /**
     * @param $title
     * @param $description
     * @return array|string[]
     */
    static function meta ($title, $description)
    {
        $title = !empty($title) ? $title :\Lang::get('seo.title-helper');
        $description = !empty($description)?$description:\Lang::get('seo.description-helper');
        $metaSeo = [
            'title' => $title,
            'description' => $description,
        ];
        return $metaSeo;

    }

}
