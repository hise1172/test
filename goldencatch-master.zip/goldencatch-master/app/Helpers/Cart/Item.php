<?php

namespace App\Helpers\Cart;

use WebXID\BasicClasses\DataContainerArrayAccess;

/**
 * @property int id
 * @property string name
 * @property string img
 * @property float price
 * @property int count
 * @property float cashback_amount
 * @property bool is_product_of_week
 * @property string slug
 */
class Item extends DataContainerArrayAccess
{

}
