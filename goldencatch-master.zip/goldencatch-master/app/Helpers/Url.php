<?php

namespace App\Helpers;

use App\Models\Translate;

class Url
{
    /**
     * @param string $uri
     * @param string|null $needed_locale
     *
     * @return string
     */
    public static function getLocatedUrl(string $uri, string $needed_locale = null): string
    {
        $needed_locale = $needed_locale ?? app()->getLocale();

        $uri = trim($uri, '/');

        $parts = explode('/', $uri, 2);
        $uri_locale = $parts[0];
        $uri_without_locale = $parts[1] ?? '';

        if (in_array($uri_locale, config('app.all_locale'))) {
            $uri = $uri_without_locale;
        }

        switch ($needed_locale) {
            case Translate::UA:
                return url($uri);

            case Translate::RU:
                return url('/' . $needed_locale . '/' . $uri);

            default:
                throw new \LogicException('Unknown locale ' . $needed_locale);
        }
    }
}
