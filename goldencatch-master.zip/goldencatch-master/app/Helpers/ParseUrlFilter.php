<?php


namespace App\Helpers;

use App\Http\Livewire\Catalog;

/**
 * Class ParseUrlFilter
 *
 * @package App\Helpers
 */
class ParseUrlFilter
{
    /**
     * Regexp for parse url and get brands
     */
    const BRAND_PATTERN = '/brand-([^\/]+)\/?/';

    /**
     * Regexp for parse url and get types
     */
    const TYPE_PATTERN = '/types-([^\/]+)\/?/';

    /**
     * Regexp for parse url and get types fishes
     */
    const TYPE_FISHES_PATTERN = '/fishes-([^\/]+)\/?/';
    /**
     * Regexp for parse url and get price
     */
    const PRICE_PATTERN = '/\/price-([^(\?|\/)]+)/';
    /**
     * Regexp for parse url and get weight
     */
    const WEIGHT_PATTERN = '/\/weight-([^(\?|\/)]+)/';

    /**
     * Parse url path and get matches by pattern
     * @param $path string url path
     * @param $pattern string regexp
     * @return mixed|null matches
     */
    private function parse($path, $pattern)
    {
        preg_match($pattern, $path, $matches);
        if (isset($matches[1]))
            return $matches[1];
        return null;
    }

    /**
     * Parse brand
     * @param $path string url
     * @return mixed|null
     */
    public function getBrands($path)
    {
        return $this->parse($path, ParseUrlFilter::BRAND_PATTERN);
    }

    /**
     * Parse types
     * @param $path string url
     * @return mixed|null
     */
    public function getTypes($path)
    {
        return $this->parse($path, ParseUrlFilter::TYPE_PATTERN);
    }

    /**
     * Parse fishes type
     * @param $path string url
     * @return mixed|null
     */
    public function getTypeFishes($path)
    {
        return $this->parse($path, ParseUrlFilter::TYPE_FISHES_PATTERN);
    }

    /**
     * Parse price
     * @param $path string url
     * @return mixed|null
     */
    public function getPrice($path)
    {
        return $this->parse($path, ParseUrlFilter::PRICE_PATTERN);
    }

    /**
     * Parse weight
     * @param $path string url
     * @return mixed|null
     */
    public function getWeight($path)
    {
        return $this->parse($path, ParseUrlFilter::WEIGHT_PATTERN);
    }

    /**
     * @param string $url
     *
     * @return string
     */
    public static function cleanupCatalogUrl(string $url): string
    {
        [$url, $query] = explode('?', $url, 2);

        parse_str($query, $result);

        $params = array_merge([
            'page',
            'search',
        ], array_keys((new Catalog())->displayParams));

        foreach ($result as $param => $value) {
            if ($param === 'page' && $value == 1) {
                unset($result[$param]);

                continue;
            }

            if (in_array($param, $params) && $value) {
                continue;
            }

            unset($result[$param]);
        }

        return $result
            ? $url . '?' . http_build_query($result)
            : $url;
    }
}
