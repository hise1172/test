<?php

namespace App\Helpers;

class StringConvertion
{
    /**
     * @param string $video_url
     * - https://youtu.be/DDDQNgpcMWk
     * - https://www.youtube.com/watch?v=DDDQNgpcMWk&ab_channel=GoldenCatch
     *
     * @return string
     */
    public static function getYoutubeVideoID(string $video_url): string
    {
        if (strpos($video_url, 'watch?v=') === false) {
            [,$output] = explode('//', $video_url, 2);
            [,$output,] = explode('/', $output, 3);

            return $output;
        }

        $query = parse_url($video_url, PHP_URL_QUERY);
        parse_str($query, $output);

        return $output['v'] ?? '';
    }
}
