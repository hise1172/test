<?php

namespace App\Helpers;


use App\User;

/**
 * Class Bonuses
 * @package App\Helpers
 */
class Bonuses
{
    /**
     * Update field "amount_of_purchases" for user
     * @param $order
     */
    static function setAmountOfPurchases($order)
    {
        $user = User::where('id', $order->user_id)->firstOrFail();
        $user->update([
            'amount_of_purchases' => $user->amount_of_purchases + $order->price
        ]);
    }

    /**
     * Update user's group bonus
     * @param $order
     */
    static function setBonus($order)
    {
        $user = User::findOrFail($order->user_id);

        if ($order->price >= 2000.00 || $user->amount_of_purchases >= 5000.00) {
            $user->update(['bonuses' => '5%']);
        }
        if ($order->price >= 10000.00 || $user->amount_of_purchases >= 15000.00) {
            $user->update(['bonuses' => '10%']);
        }
        if ($order->price >= 20000.00 || $user->amount_of_purchases >= 30000.00) {
            $user->update(['bonuses' => '15%']);
        }
    }
}
