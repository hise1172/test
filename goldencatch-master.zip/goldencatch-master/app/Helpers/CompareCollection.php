<?php

namespace App\Helpers;

use Illuminate\Support\Arr;

/**
 * Class CompareCollection
 * @package App\Helpers
 */
final class CompareCollection
{
    /**
     * Map category -> uniqueCollection
     * @var array
     */
    private $items = [];

    /**
     * Add product by category
     * @param $category
     * @param $product
     */
    public function addProduct($category, $product)
    {
        if ($this->hasCategory($category)) {
            /**
             * @var UniqueCollection $collection
             */
            $collection = $this->items[$category];
            $collection->add($product);
        } else {
            $uniqueCollection = new UniqueCollection($product);
            $this->items[$category] = $uniqueCollection;

        }
    }

    /**
     * Category in collection
     * @param $category
     * @return bool
     */
    private function hasCategory($category)
    {
        return array_key_exists($category, $this->items);
    }

    /**
     * Delete product from category
     * @param $product_id
     * @return bool
     */
    public function deleteProduct($product_id)
    {
        /**
         * @var UniqueCollection $item
         */
        foreach ($this->items as $category => $products) {
            if ($products->delete($product_id)) {
                if ($products->count() == 0) {
                    unset($this->items[$category]);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Category -> product array
     * @return array
     */
    public function toArray()
    {
        $result = [];
        /**
         * @var string $key
         * @var UniqueCollection $value
         */
        foreach ($this->items as $key => $value) {
            $result[$key] = $value->toArray();
        }
        return $result;
    }

    /**
     * Count products to compare
     * @return int
     */
    public function count()
    {
        $count = 0;
        /**
         * @var UniqueCollection $item
         */
        foreach ($this->items as $item) {
            $count += $item->count();
        }
        return $count;
    }

    /**
     * @param $category
     * @return array
     */
    public function compareProductByCategory($category)
    {
        if ($this->hasCategory($category)) {
            /**
             * @var UniqueCollection $products
             */
            $products = $this->items[$category];
            return $products->toArray();
        }
        return [];
    }

    /**
     * Remove category product by slug
     * @param $categorySlug
     * @return int
     */
    public function removeCategoryCompare($categorySlug)
    {
        if ($this->hasCategory($categorySlug)) {
            unset($this->items[$categorySlug]);
        }
        return $this->count();
    }
}
