<?php

namespace App\Helpers;

use App\Models\ReviewAttach;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Throwable;
use Str;
/**
 * Class FileUploaded
 * @package App\Helpers
 */
final class FileUploaded
{
    const PRODUCT_DISK = 'products';
    const REVIEWS_DISK = 'reviews';
    const IMPORT_FILES='app/import';

    /**
     * @param string $url
     * @return string Url to photo or empty string
     */
    public static function saveProductPhotoByUrl($url)
    {
        try {
            if (empty($url)) {
                return '';
            }
            $filesystem = Storage::disk(self::PRODUCT_DISK);
            $fileName = basename($url);
            if ($filesystem->exists($fileName)) {
                return $fileName;
            }
            $file = file_get_contents($url);
            if (empty($file)) {
                return '';
            }
            $filesystem->put($fileName, $file);
            return $fileName;
        } catch (Throwable $exception) {
            Log::error($exception->getMessage());
            Log::info($url . ' Fail download image');
        }
        return '';
    }

    public static function saveUserReview($photos)
    {
        if (empty($photos)) {
            return [];
        }
        $result = [];
        /**
         * @var UploadedFile $photo
         */
        foreach ($photos as $photo) {
            $data['path'] = $photo->store('', self::REVIEWS_DISK);
            $data['type'] = ReviewAttach::ATTACH_PHOTO;
            $result[] = $data;
        }
        return $result;
    }

    /**
     * @param Request $request
     * @return string
     */
    public static function saveImportFile(Request $request)
    {
        $file = $request->file('file');
        $extension = $file->getClientOriginalExtension(); // getting image extension
        $filename = Str::random(10) . time() . '.' . $extension;
        $file->move(storage_path(self::IMPORT_FILES), $filename);
        return self::IMPORT_FILES.'/'.$filename;
    }
}
