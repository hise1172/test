<?php


namespace App\Helpers;

use App\Helpers\Cart\Item;
use App\Models\Product\Product;
use App\Services\Catalog\Pricing;
use App\User;
use Illuminate\Support\Facades\Auth;

/**
 * Class Cart
 * @package App\Helpers
 */
final class Cart
{
    /**
     * @var array
     * [
     *      [
     *          'product' => int, // a product id
     *          'count' => int, // products count in cart
     *      ]
     * ]
     */
    private $items = [];

    /** @var Product[][] */
    private array $products = [];

    private $discount = 0;

    /**
     * @param int $product
     * @param int $count
     *
     * @return $this
     */
    public function add($product, $count = 1)
    {
        $key = $this->getKey($product);

        if (isset($this->items[$key])) {
            $this->items[$key]['count'] = $this->items[$key]['count'] + $count;
        } else {
            $this->items[$key] = compact('product', 'count');
        }

        return $this;
    }

    /**
     * @param $product
     * @return bool
     */
    public function remove($product)
    {
        $key = $this->getKey($product);

        if (!isset($this->items[$key])) {
            return false;
        }

        unset($this->items[$key]);

        return true;
    }

    #region Setters

    /**
     * @param float $discount
     *
     * @return $this
     */
    public function applyDiscount(float $discount)
    {
        if ($discount < 0) {
            throw new \InvalidArgumentException('Invalid $discount');
        }

        $this->discount = $discount;

        return $this;
    }

    #endregion

    #region Getters

    /**
     * @param $value
     * @return string
     */
    public function getKey($value)
    {
        return md5($value);
    }

    /**
     * @return int
     */
    public function count()
    {
        return count(array_keys($this->items));
    }

    /**
     * @return Product[]
     */
    public function getCartProducts()
    {
        static $products = [];

        $product_ids = array_column($this->items, 'product');
        $key = implode(',', $product_ids);

        if (isset($products[$key])) {
            return $products[$key];
        }

        $products = [
            $key => Product::whereIn('id', $product_ids)->get(),
        ];

        return $products[$key];
    }

    /**
     * @param bool $for_reseller_console
     *
     * @return Pricing\CurrencyExchange
     */
    public function getTotalSumm(bool $for_reseller_console = false): Pricing\CurrencyExchange
    {
        $total_summ = [
            Pricing::CURRENCY_UAH => 0,
            Pricing::CURRENCY_USD => 0,
        ];

        if (!$for_reseller_console) {
            $total_summ[Pricing::CURRENCY_UAH] = $this->getPropertyTotalValue('price');

            return Pricing\CurrencyExchange::create($total_summ);
        }

        $pricing = Pricing::init(Auth::user());

        foreach ($this->getCartProducts() as $product) {
            $count = $this->countProduct($product->id);

            $total_summ[Pricing::CURRENCY_UAH] += $count * $pricing->getWholesalePrice($product)->UAH;
            $total_summ[Pricing::CURRENCY_USD] += $count * $pricing->getWholesalePrice($product)->USD;
        }

        return Pricing\CurrencyExchange::create($total_summ);
    }

    /**
     * @param string $format
     *
     * @return float|string
     */
    public function getTotalBrutto()
    {
        return $this->getPropertyTotalValue('float_brutto');
    }

    /**
     * Returns value in cubic meters
     *
     * @param string $format
     *
     * @return float|string
     */
    public function getTotalVolumeInM3()
    {
        return $this->getPropertyTotalValue('float_volume') * 0.1;
    }

    /**
     * @param string $property_name
     * @param string $format
     *
     * @return float|string
     */
    private function getPropertyTotalValue(string $property_name)
    {
        $total_value = 0;

        foreach ($this->getCartProducts() as $product) {
            $total_value += ($product->{$property_name} * $this->countProduct($product->id));
        }

        return $total_value;
    }

    /**
     * @return int
     */
    public function getDiscount(): int
    {
        return $this->discount;
    }

    #endregion

    /**
     * @return $this
     */
    public function clear()
    {
        $this->items = [];
        return $this;
    }

    /**
     * @return array
     * [
     *  [
     *      'product' => int,
     *      'count' => int,
     *  ],
     *  ...
     * ]
     */
    public function toArray()
    {
        return $this->items;
    }

    /**
     * @param $product
     * @return int|mixed
     */
    public function countProduct($product)
    {
        $key = $this->getKey($product);

        if (isset($this->items[$key])) {
            return $this->items[$key]['count'];
        }

        return 0;
    }

    /**
     * @return array
     */
    public function productCart(bool $for_reseller_console = false)
    {
        $seo = SeoFilters::getSeo();
        $result = [
            'products' => collect(),
            'isResellersConsole' => $for_reseller_console,
            'currency_symbol' => $for_reseller_console
                ? '$'
                : '₴',
        ];

        if (empty($this->items)) {
            return $result;
        }

        /** @var User $user */
        $user = Auth::user();

        /** @var Product[] $products */
        $products = $this->getCartProducts();
        $summ = 0;

        $pricing = Pricing::init($user);

        foreach ($products as $product) {
            $result['products'][] = Item::make([
                'id' => $product->id,
                'name' => $product->name,
                'img' => $product->photo,
                'price' => $for_reseller_console
                    ? $pricing->getWholesalePrice($product)->USD
                    : $product->price,
                'count' => $this->countProduct($product->id),
                'cashback_amount' => $product->max_cashback_amount ?: 0,
                'is_product_of_week' => $product->is_product_of_week,
                'slug' => $product->slug,
            ]);
        }

        $total_summ_uah = $this->getTotalSumm($for_reseller_console)->UAH - $this->discount;

        if ($total_summ_uah < 0) {
            $total_summ_uah = 0;
        }

        $result['discount'] = $this->discount;
        $result['summ'] = $for_reseller_console
            ? $this->getTotalSumm($for_reseller_console)->USD
            : $this->getTotalSumm($for_reseller_console)->UAH;

        $result['total_summ'] = $for_reseller_console
            ? $this->getTotalSumm($for_reseller_console)->USD
            : $total_summ_uah;
        $result['seo'] = $seo;

        return $result;
    }

    /**
     * @param $product
     */
    public function plusProduct($product)
    {
        $this->add($product);
    }

    /**
     * @param $product
     *
     * @return $this
     */
    public function minusProduct($product)
    {
        $key = $this->getKey($product);

        if (!isset($this->items[$key])) {
            return $this;
        }

        if (($this->items[$key]['count'] - 1) == 0) {
            $this->remove($product);

            return $this;
        }

        $this->items[$key]['count'] = $this->items[$key]['count'] - 1;

        return $this;
    }
}
