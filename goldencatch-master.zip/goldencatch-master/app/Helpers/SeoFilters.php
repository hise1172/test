<?php
namespace App\Helpers;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

/**
 * Class SeoFilters
 * @package App\Helpers
 */
class SeoFilters
{
    static function getSeo()
    {
        static $cached_seo = [];

        $url = $_SERVER['REQUEST_URI'] ?? ''; // Jobs do not have a request data
        $urlLocale = config('app.default_locale') == \App::getLocale() ? '/' : '/' . \App::getLocale() . '/';
        $url = Str::after($url, $urlLocale);

        if (isset($cached_seo[$url])) {
            return $cached_seo[$url];
        }

        $seo = [];

        if($field = \App\Models\SeoFilters::where('uri', $url)->get()->toArray()) {
            $seo = $field[0];
            $seo['h1'] = $seo['h1'][\App::getLocale()] ?? '';
            $seo['title'] = $seo['title'][\App::getLocale()] ?? '';
            $seo['description'] = $seo['description'][\App::getLocale()] ?? '';
            $seo_text = $seo['text'][\App::getLocale()] ?? '';
            $seo_generated_text = $seo['generated_text'][\App::getLocale()] ?? '';
            $seo['text'] = $seo_text . $seo_generated_text;
            $seo['open_graph_image'] = $seo['open_graph_image'] ? asset( Storage::disk('social')->url($seo['open_graph_image']) ) : '';

            ($field[0]['robots_index'] == 1)?($index = 'index'):($index = 'noindex');
            $seo['robots_index'] = $index;

            ($field[0]['robots_follow'] == 1)?($follow = 'follow'):($follow = 'nofollow');
            $seo['robots_follow'] = $follow;
        }

        return $cached_seo[$url] = $seo;
    }
}
