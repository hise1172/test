<?php


namespace App\Helpers;

use Illuminate\Database\Query\Builder;

/**
 * Class FilterCreator
 * Generate query for filter
 * @package App\Helpers
 */
class FilterCreator
{
    /**
     * Product category filters
     * @param $q Builder
     * @param $category int Category id
     */
    public function categoryFilter($q, $category)
    {
        $q->where('category_id', function ($query) use ($category) {
            $query->select('id')->from('categories')->where('id', $category)->first();
        });
    }

    /**
     * Product types filters
     * @param $q Builder
     * @param $types array types' slug
     */
    public function typesFilter($q, $types)
    {
        $q->whereIn('id', function (Builder $query) use ($types) {
            $query->select('product_id')->from('product_types')
                ->leftJoin('types', 'product_types.type_id', '=', 'types.id')
                ->whereIn('types.slug', $types);
        });
    }

    /**
     * Product brands filters
     * @param $q Builder
     * @param $brands array brand's slug
     */
    public function brandsFilter($q, $brands)
    {
        $q->whereIn('brand_id', function ($query) use ($brands) {
            $query->select('id')->from('brands')->whereIn('slug', $brands);
        });
    }

    /**
     * Product type fishes filter
     * @param $q Builder
     * @param $typeFishes array type fishes
     */
    public function typeFishes($q, $typeFishes)
    {
        $q->whereIn('id', function (Builder $query) use ($typeFishes) {
            $query->select('product_id')->from('product_type_fishes')
                ->leftJoin('type_fishes', 'type_fishes.id', '=', 'product_type_fishes.type_fish_id')
                ->whereIn('type_fishes.slug', $typeFishes)->get();
        });
    }

    /**
     * Product
     * @param $q Builder
     * @param $sort array array with column and type
     */
    public function sortFilter($q, $sort)
    {
        $q->orderBy($sort['column'], $sort['type']);
    }

    /**
     * Product price filter
     * @param $q Builder
     * @param $price array price [0] min [1] max
     */
    public function priceFilter($q, $price)
    {
        $min = $price[0];
        $max = $price[1];

        $q->where([['price', '>=', $min], ['price', '<=', $max]]);
    }

    /**
     * Product weight filter
     * @param $q Builder
     * @param $weight array weight [0] min [1] max
     */
    public function weightFilter($q, $weight)
    {
        $min = $weight[0];
        $max = $weight[1];

        $q->where([['weight', '>=', $min], ['weight', '<=', $max]]);
    }

    public function searchFilter($q, $search)
    {
        $q->where('name', 'like', "%{$search}%");
    }
}
