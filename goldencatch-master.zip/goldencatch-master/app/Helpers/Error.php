<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\MessageBag;
use Illuminate\Support\ViewErrorBag;

class Error
{
    const TYPE_GLOBAL = 'global_error';

    /**
     * @param string|array $message
     * @param string $type
     */
    public static function addToResponse($message, string $type = self::TYPE_GLOBAL)
    {
        if (
            !$message
            || (!is_string($message) && !is_array($message))
        ) {
            throw new \InvalidArgumentException('Invalid $message');
        }

        Session::flash('errors', (new ViewErrorBag)->put($type, new MessageBag((array) $message)));
    }
}
