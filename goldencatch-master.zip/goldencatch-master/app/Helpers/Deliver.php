<?php


namespace App\Helpers;

use App\Models\Delivery;


class Deliver
{
    const DEFAULT_METHOD = Delivery::NEWPOST_DEPARTMENT;

    public $delivery;

    /**
     * Deliver constructor.
     * @param Delivery $delivery
     */
    public function __construct(Delivery $delivery)
    {
        $this->delivery=$delivery;
    }

    /**
     * @return Delivery[]|\Illuminate\Database\Eloquent\Collection
     */
    public function getAllDelivery()
    {
        return $this->delivery::all();
    }

    /**
     * @param Delivery $delivery
     * @return Deliver
     */
    public function setDelivery(Delivery $delivery): Deliver
    {
        $this->delivery = $delivery;
        return $this;
    }

}
