<?php

namespace App\Helpers;

use App\Repositories\ProductRepository;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

/**
 * Top products(покупателям нравится)
 * Продукты которые покупают чаще всего
 * Class TopProduct
 * @package App\Helpers
 */
class TopProduct
{
    const COLLECTION_NAME = 'product-top';
    const COUNT_PRODUCT = 15;

    /**
     * Add product to collection
     * @param $id int Product id
     * @return int 0 - if key increment, 1 if add new
     */
    public static function addProduct($id)
    {
        try {
            $count = 0;
            if (Redis::hExists(self::COLLECTION_NAME, $id)) {
                $count = Redis::hGet(self::COLLECTION_NAME, $id);
            }
            return Redis::hSet(self::COLLECTION_NAME, $id, $count + 1);
        } catch (Exception $exception) {
            Log::error($exception);
            return null;
        }
    }

    /**
     * @return Collection
     */
    public static function getProductsIds()
    {
        try {
            $products = Redis::hGetAll(self::COLLECTION_NAME);
            $collection = collect($products);
            return $collection->take(self::COUNT_PRODUCT)->sort(function ($a, $b) {
                return $b - $a;
            })->keys();
        } catch (Exception $exception) {
            Log::error($exception);
            return Collection::make([]);
        }
    }

    public static function clear()
    {
        try {
            return Redis::del(self::COLLECTION_NAME);
        } catch (Exception $exception) {
            Log::error($exception);
            return null;
        }
    }
}
