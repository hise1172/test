<?php

namespace App\DataContainers\Catalog;

use App\DataContainers\AbstractDataContainer;
use App\Models\SeoFilters;

/**
 * @property string title
 * @property string uri
 */
class ChildrenFilterHintButton extends AbstractDataContainer
{
    /**
     * @param SeoFilters $parent_filter
     * @param SeoFilters $seo_filter
     *
     * @return string
     */
    public static function prepareTitle(SeoFilters $parent_filter, SeoFilters $seo_filter): string
    {
        $title = trim(str_replace(explode(' ', $parent_filter->h1), '', $seo_filter->h1));

        return mb_strtoupper(mb_substr($title, 0, 1)) . mb_substr($title, 1);
    }
}
