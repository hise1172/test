<?php

namespace App\DataContainers\Catalog;

use App\DataContainers\AbstractDataContainer;

/**
 * @property string title
 * @property string seo_title
 * @property string|null url
 */
class Breadcrumb extends AbstractDataContainer
{
    private bool $show_url = true;

    /**
     * @param $name
     *
     * @return mixed|string|null
     */
    public function __get($name)
    {
        $value = parent::__get($name);

        switch ($name) {

            case 'seo_title':
                return $value ?? $this->title;

            default:
                return $value;
        }
    }

    /**
     * @return bool
     */
    public function hasShowUrl(): bool
    {
        return $this->show_url && $this->url;
    }

    /**
     * @param bool $show_url
     *
     * @return $this
     */
    public function showUrl(bool $show_url)
    {
        $this->show_url = $show_url;

        return $this;
    }
}
