<?php

namespace App\Jobs;

use App\Mail\NewOrderToUserMail;
use App\Models\Order;
use App\Services\ChatBot;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendNewOrderNotificationToUserJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private Order $order;
    /**
     * @param Order $order
     */
    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $error = null;

        try {
            $this->sendToChatBot();
        } catch (\Throwable $error) {

        }

        try {
            $this->sendToEmail();
        } catch (\Throwable $error) {

        }

        if ($error instanceof \Throwable) {
            throw $error;
        }
    }

    /**
     *
     */
    private function sendToChatBot()
    {
        if (!$this->order->user->botUser) {
            return;
        }

        ChatBot::factory($this->order->user->botUser)
            ->sendMessage(
                view('chat-bots.new_order_notification')
                    ->with([
                        'order' => $this->order,
                    ])
            );
    }

    /**
     *
     */
    private function sendToEmail()
    {
        Mail::to($this->order->email)
            ->send(new NewOrderToUserMail($this->order));
    }
}
