<?php

namespace App\Jobs;

use App\Mail\NewOrderToManagerMail;
use App\Models\Order;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendNewOrderMailToManagerJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private Order $order;
    private bool $is_resellers_console;

    /**
     * @param Order $order
     * @param User $user
     * @param bool $is_resellers_console
     */
    public function __construct(Order $order, bool $is_resellers_console)
    {
        $this->order = $order;
        $this->is_resellers_console = $is_resellers_console;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $var = $this->is_resellers_console
            ? 'MANAGER_EMAIL_WHOLESALE'
            : 'MANAGER_EMAIL_RETAIL';

        $email = env($var);

        if (!$email) {
            Log::critical('The environment variable "' . $var . '" does not exist');

            return;
        }

        Mail::to($email)
            ->send(new NewOrderToManagerMail($this->order, $this->is_resellers_console));
    }
}
