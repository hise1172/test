<?php

namespace App\Jobs;

use App\Repositories\UserWaitingRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Ramsey\Collection\Collection;

class ClearWaitingProductsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * @var UserWaitingRepository
     */
    private $repository;
    private $product_id;
    /**
     * @var array
     */
    private $usersId;

    /**
     * Create a new job instance.
     * @param $product_id
     * @param array|Collection $usersId
     */
    public function __construct($product_id, $usersId)
    {
        $this->product_id = $product_id;
        $this->usersId = $usersId;
    }

    /**
     * Execute the job.
     *
     * @param UserWaitingRepository $repository
     * @return void
     */
    public function handle(UserWaitingRepository $repository)
    {
        $repository->deleteWaitingProduct($this->product_id, $this->usersId);
    }
}
