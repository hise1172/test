<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

/**
 * Class Login
 *
 * @package App\Rules
 */
class Phone implements Rule
{
    private $phone;

    /**
     * Determine if the validation rule passes.
     *
     * @inheritDoc
     */
    public function passes($attribute, $value): bool
    {
        $this->phone = static::Normalise($value);

        return strlen($this->phone) === 13 && substr($this->phone, 0, 4) === '+380';
    }

    #region Getters

    /**
     * Get the validation error message.
     *
     * @return string|array
     */
    public function message()
    {
        return 'Указано не корректный телефон';
    }

    /**
     * @return string
     */
    public function getNormalisedValue(): string
    {
        return $this->phone;
    }

    /**
     * @param string $phone
     * @param bool $return_plus
     *
     * @return string
     */
    public static function Normalise($phone, bool $return_plus = true): string
    {
        $phone = (string) preg_replace('/[^0-9]/', '', trim($phone));
        $pref = $return_plus
            ? '+'
            : '';

        if (strlen($phone) === 10 && $phone[0] === '0') {
            return $pref . '38' . $phone;
        }

        return substr($phone, 0, 3) === '380'
            ? $pref . $phone
            : $phone;
    }

    #endregion
}
