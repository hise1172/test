<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

/**
 * Class Login
 *
 * @package App\Rules
 */
class Login implements Rule
{
    private bool $is_login_type_email;
    /** @var string */
    private $login;
    private ?Phone $phone_rules = null;

    public function __construct(bool $isLoginTypeEmail)
    {
        $this->is_login_type_email = $isLoginTypeEmail;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @inheritDoc
     */
    public function passes($attribute, $value): bool
    {
        $this->login = trim($value);

        if ($this->is_login_type_email) {
            return filter_var($this->login, FILTER_VALIDATE_EMAIL);
        }

        $this->phone_rules = new Phone();

        $is_phone_valid = $this->phone_rules->passes($attribute, $value);
        $this->login = $this->phone_rules->getNormalisedValue();

        return $is_phone_valid;
    }

    #region Getters

    /**
     * Get the validation error message.
     *
     * @return string|array
     */
    public function message()
    {
        return $this->is_login_type_email
            ? 'Указано не корректный email'
            : $this->phone_rules->message();
    }

    /**
     * @return string
     */
    public function getNormalisedLogin(): string
    {
        return $this->is_login_type_email
            ? $this->login
            : '+' . $this->login;
    }

    #endregion
}
