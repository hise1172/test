<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Plural extends Component
{

    public $count;
    public $translate;

    /**
     * Create a new component instance.
     *
     * How to use:
     *
     *  in blade
     *      <x-plural :count="$product->approveReviewsCount" translate='content.feedback count' />
     *
     *  in translate file
     *  (content.php)
     *      'feedback count' => [
     *          'plural1' => ':count Отзыв',
     *          'plural2' => ':count Отзыва',
     *          'plural5' => ':count Отзывов',
     *      ]
     *
     * Example:
     * <x-plural :count="1" translate='content.feedback count' />
     * return
     * 1 Отзыв
     *
     * <x-plural :count="112" translate='content.feedback count' />
     * return
     * 112 Отзывов
     *
     *
     * function __construct
     * @return void
     */
    public function __construct( $count, $translate )
    {
        $this->count = $count;
        $this->translate = $translate;
    }

    public function getNumber( $num )
    {
        $num = abs($num) % 100; // берем число по модулю и сбрасываем сотни (делим на 100, а остаток присваиваем переменной $num)
        $num_x = $num % 10; // сбрасываем десятки и записываем в новую переменную
        if ($num > 10 && $num < 20) // если число принадлежит отрезку [11;19]
            return 5;
        if ($num_x > 1 && $num_x < 5) // иначе если число оканчивается на 2,3,4
            return 2;
        if ($num_x == 1) // иначе если оканчивается на 1
            return 1;
        return 5;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        $pluralNumber = $this->getNumber( $this->count );
        $translateName = $this->translate . '.plural' . $pluralNumber;
        if( \Lang::has( $translateName ) ){
            return trim( view('components.plural', [
                'count' => $this->count,
                'translate' => $translateName,
                ]) );
        }
        return '';
    }
}
